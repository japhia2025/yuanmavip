<div class="header">
    <div class="logo">
        <img src="{{iawp_url_to('img/logo.png')}}" data-testid="logo"/>
    </div>
</div>