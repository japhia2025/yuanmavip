<label class="column-label" for="iawp_view_counter_label_show">
    <input type="checkbox" name="iawp_view_counter_label_show" id="iawp_view_counter_label_show" <?php checked(true, $show, true); ?>>
    <span><?php esc_html_e('Show the label', 'independent-analytics'); ?></span>
</label>
