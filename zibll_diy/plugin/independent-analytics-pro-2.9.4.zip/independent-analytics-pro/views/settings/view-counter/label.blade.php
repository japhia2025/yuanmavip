<label class="column-label" for="iawp_view_counter_label">
    <input type="text" name="iawp_view_counter_label" id="iawp_view_counter_label" value="<?php echo $label; ?>">
    <p class="description"><?php esc_html_e('Edit the text that displays before the number of views.', 'independent-analytics'); ?></p>
</label>
