<label class="column-label" for="iawp_view_counter_icon">
    <input type="checkbox" name="iawp_view_counter_icon" id="iawp_view_counter_icon" <?php checked(true, $icon, true); ?>>
    <span><?php esc_html_e('Show the icon', 'independent-analytics'); ?></span>
</label>
