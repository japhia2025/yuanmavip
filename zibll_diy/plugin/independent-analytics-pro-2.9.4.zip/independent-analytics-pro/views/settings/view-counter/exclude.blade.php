<label class="column-label" for="iawp_view_counter_exclude">
    <input type="text" name="iawp_view_counter_exclude" id="iawp_view_counter_exclude" value="<?php echo $exclude; ?>">
    <p class="description"><?php esc_html_e('Enter the IDs of any pages you want to exclude separated commas e.g. 32,79,118.', 'independent-analytics'); ?></p>
</label>
