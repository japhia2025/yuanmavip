<?php

namespace IAWP;

/**
 * Intentionally empty. Used as an alternative to null in Report_Options_Parser.
 * @internal
 */
class Empty_Report_Option
{
}
