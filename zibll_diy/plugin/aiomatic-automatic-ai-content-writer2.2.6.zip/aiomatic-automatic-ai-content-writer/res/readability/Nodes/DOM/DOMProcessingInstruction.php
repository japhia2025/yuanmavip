<?php

namespace fivefilters\Readability\Nodes\DOM;

use fivefilters\Readability\Nodes\NodeTrait;

class DOMProcessingInstruction extends \DOMProcessingInstruction
{
    use NodeTrait;
}
