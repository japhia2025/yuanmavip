<?php
/**
 * This is the HTML template for the plugin settings page.
 *
 * These variables are provided by the plugin:
 * @var array $settings Plugin settings.
 * @var string $editor_page_url A fully qualified URL of the admin menu editor page.
 * @var string $settings_page_url
 * @var string $db_option_name
 */

$currentUser = wp_get_current_user();
$isMultisite = is_multisite();
$isSuperAdmin = is_super_admin();
$formActionUrl = add_query_arg('noheader', 1, $settings_page_url);
$isProVersion = apply_filters('admin_menu_editor_is_pro', false);
?>

<?php do_action('admin_menu_editor-display_header'); ?>

	<form method="post" action="<?php echo esc_url($formActionUrl); ?>" id="ws_plugin_settings_form">

		<table class="form-table">
			<tbody>
			<tr>
				<th scope="row">
					谁可以访问此插件
				</th>
				<td>
					<fieldset>
						<p>
							<label>
								<input type="radio" name="plugin_access" value="super_admin"
									<?php checked('super_admin', $settings['plugin_access']); ?>
									<?php disabled( !$isSuperAdmin ); ?>>
								超级管理员

								<?php if ( !$isMultisite ) : ?>
									<br><span class="description">
										在单站点安装中，这通常是
										与管理员角色相同.
									</span>
								<?php endif; ?>
							</label>
						</p>

						<p>
							<label>
								<input type="radio" name="plugin_access" value="manage_options"
									<?php checked('manage_options', $settings['plugin_access']); ?>
									<?php disabled( !current_user_can('manage_options') ); ?>>
								任何具有“管理选项”功能的人

								<br><span class="description">
									默认情况下，只有管理员具有此功能.
								</span>
							</label>
						</p>

						<p>
							<label>
								<input type="radio" name="plugin_access" value="specific_user"
									<?php checked('specific_user', $settings['plugin_access']); ?>
									<?php disabled( $isMultisite && !$isSuperAdmin ); ?>>
								仅限当前用户

								<br>
								<span class="description">
									用户名: <?php echo esc_html($currentUser->user_login); ?>,
								 	用户ID: <?php echo esc_html(get_current_user_id()); ?>
								</span>
							</label>
						</p>
					</fieldset>

					<p>
						<label>
							<input type="checkbox" name="hide_plugin_from_others" value="1"
								<?php checked( $settings['plugins_page_allowed_user_id'] !== null ); ?>
								<?php disabled( !$isProVersion || ($isMultisite && !is_super_admin()) ); ?>
							>
							隐藏 "管理员菜单编辑器<?php if ( $isProVersion ) { echo ' Pro'; } ?>"
							<?php if ( defined('WS_ADMIN_BAR_EDITOR_FILE') || defined('AME_BRANDING_ADD_ON_FILE') ) {
								echo '及其附加组件';
							} ?>
							从其他用户的“插件”页面
							<?php if ( !$isProVersion ) {
								echo '(Pro version only)';
							} ?>
						</label>
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row">
					多站点设置
				</th>
				<td>
					<fieldset id="ame-menu-scope-settings">
						<p>
							<label>
								<input type="radio" name="menu_config_scope" value="global"
								       id="ame-menu-config-scope-global"
									<?php checked('global', $settings['menu_config_scope']); ?>
									<?php disabled(!$isMultisite || !$isSuperAdmin); ?>>
								全部的 &mdash;
								对所有网络站点使用相同的管理菜单设置.
							</label>
						</p>

						<p>
							<label>
								<input type="radio" name="menu_config_scope" value="site"
									<?php checked('site', $settings['menu_config_scope']); ?>
									<?php disabled(!$isMultisite || !$isSuperAdmin); ?>>
								每个站点 &mdash;
								为每个站点使用不同的管理菜单设置.
							</label>
						</p>
					</fieldset>
				</td>
			</tr>

			<?php do_action('admin-menu-editor-display_addons'); ?>

			<tr id="ame-available-modules">
				<th scope="row">
					模块
					<a class="ws_tooltip_trigger"
					   title="模块是可以打开或关闭的插件功能.
					&lt;br&gt;
					关闭未使用的功能将略微提高性能，并可能有助于解决某些兼容性问题.
					">
						<div class="dashicons dashicons-info"></div>
					</a>
				</th>
				<td>
					<fieldset>
						<?php
						global $wp_menu_editor;
						foreach ($wp_menu_editor->get_available_modules() as $moduleId => $module) {
							if ( !empty($module['isAlwaysActive']) ) {
								continue;
							}

							$isCompatible = $wp_menu_editor->is_module_compatible($module);
							$compatibilityNote = '';
							if ( !$isCompatible && !empty($module['requiredPhpVersion']) ) {
								if ( version_compare(phpversion(), $module['requiredPhpVersion'], '<') ) {
									$compatibilityNote = sprintf(
										'所需的PHP版本: %1$s 或稍后。已安装的PHP版本: %2$s',
										esc_html($module['requiredPhpVersion']),
										esc_html(phpversion())
									);
								}
							}

							echo '<p>';
							/** @noinspection HtmlUnknownAttribute */
							printf(
								'<label>
									<input type="checkbox" name="active_modules[]" value="%1$s" %2$s %3$s>
								    %4$s
								</label>',
								esc_attr($moduleId),
								$wp_menu_editor->is_module_active($moduleId, $module) ? 'checked="checked"' : '',
								// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Constant strings.
								$isCompatible ? '' : 'disabled="disabled"',
								esc_html(!empty($module['title']) ? $module['title'] : $moduleId)
							);

							if ( !empty($compatibilityNote) ) {
								// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $compatibilityNote was escaped when generated.
								printf('<br><span class="description">%s</span>', $compatibilityNote);
							}

							echo '</p>';
						}
						?>
					</fieldset>
				</td>
			</tr>

			<tr>
				<th scope="row">界面</th>
				<td>
					<p>
						<label>
							<input type="checkbox" name="hide_advanced_settings"
								<?php checked($settings['hide_advanced_settings']); ?>>
							默认情况下隐藏高级菜单选项
						</label>
					</p>

					<?php if ($isProVersion): ?>
						<p>
						<label>
							<input type="checkbox" name="show_deprecated_hide_button"
								<?php checked($settings['show_deprecated_hide_button']); ?>>
							启用“隐藏（装饰）”工具栏按钮
						</label>
						<br><span class="description">
							此按钮隐藏所选菜单项，但不会使其不可访问.
						</span>
						</p>
					<?php endif; ?>
				</td>
			</tr>

			<tr>
				<th scope="row">编辑器配色方案</th>
				<td>
					<fieldset>
						<p>
							<label>
								<input type="radio" name="ui_colour_scheme" value="classic"
									<?php checked('classic', $settings['ui_colour_scheme']); ?>>
								蓝与黄
							</label>
						</p>

						<p>
							<label>
								<input type="radio" name="ui_colour_scheme" value="modern-one"
									<?php checked('modern-one', $settings['ui_colour_scheme']); ?>>
								现代的
							</label>
						</p>

						<p>
							<label>
								<input type="radio" name="ui_colour_scheme" value="wp-grey"
									<?php checked('wp-grey', $settings['ui_colour_scheme']); ?>>
								灰色
							</label>
						</p>
					</fieldset>
				</td>
			</tr>

			<?php if ($isProVersion): ?>
			<tr>
				<th scope="row">显示子菜单图标</th>
				<td>
					<fieldset id="ame-submenu-icons-settings">
						<p>
							<label>
								<input type="radio" name="submenu_icons_enabled" value="always"
									<?php checked('always', $settings['submenu_icons_enabled']); ?>>
								总是
							</label>
						</p>

						<p>
							<label>
								<input type="radio" name="submenu_icons_enabled" value="if_custom"
									<?php checked('if_custom', $settings['submenu_icons_enabled']); ?>>
								仅当手动选择时
							</label>
						</p>

						<p>
							<label>
								<input type="radio" name="submenu_icons_enabled" value="never"
									<?php checked('never', $settings['submenu_icons_enabled']); ?>>
								从不
							</label>
						</p>
					</fieldset>
				</td>
			</tr>

				<tr>
					<th scope="row">
						新菜单可见性
						<a class="ws_tooltip_trigger"
						   title="此设置控制以下菜单项的默认权限
						    在上次保存的菜单配置中不存在.
							&lt;br&gt;&lt;br&gt;
							这包括插件和主题添加的新菜单.
							在多站点中，它也适用于某些站点上存在但其他站点上不存在的菜单.
							它不会影响您通过管理菜单编辑器界面添加的菜单项.">
							<div class="dashicons dashicons-info"></div>
						</a>
					</th>
					<td>
						<fieldset>
							<p>
								<label>
									<input type="radio" name="unused_item_permissions" value="unchanged"
										<?php checked('unchanged', $settings['unused_item_permissions']); ?>>
									保持不变（默认）

									<br><span class="description">
										无特殊限制。可见性将取决于插件
										添加了菜单.
									</span>
								</label>
							</p>

							<p>
								<label>
									<input type="radio" name="unused_item_permissions" value="match_plugin_access"
										<?php checked('match_plugin_access', $settings['unused_item_permissions']); ?>>
									仅向可以访问此插件的用户显示

									<br><span class="description">
										自动对普通用户隐藏所有新的和无法识别的菜单.
										要使新菜单可见，您必须在菜单编辑器中手动启用它们.
									</span>
								</label>
							</p>

						</fieldset>
					</td>
				</tr>
			<?php endif; ?>

			<tr>
			<th scope="row">
				新菜单位置
				<a class="ws_tooltip_trigger"
				   title="此设置控制上次保存的菜单中不存在的菜单项的位置
					配置.
					&lt;br&gt;&lt;br&gt;
					这包括插件和主题添加的新菜单.
					在多站点中，它也适用于仅存在于某些站点上但不存在于所有站点上的菜单.
					它不会影响您通过管理菜单编辑器界面添加的菜单项.">
					<div class="dashicons dashicons-info"></div>
				</a>
			</th>
			<td>
				<fieldset>
					<p>
						<label>
							<input type="radio" name="unused_item_position" value="relative"
								<?php checked('relative', $settings['unused_item_position']); ?>>
							维持相对秩序

							<br><span class="description">
								尝试将新项目置于相同的相对位置
								就像它们在默认的管理菜单中一样.
							</span>
						</label>
					</p>

					<p>
						<label>
							<input type="radio" name="unused_item_position" value="bottom"
								<?php checked('bottom', $settings['unused_item_position']); ?>>
							底部

							<br><span class="description">
								将新项目放在管理菜单的底部.
							</span>
						</label>
					</p>

				</fieldset>
			</td>
			</tr>

			<?php
			//The free version lacks the ability to render deeply nested menus in the dashboard, so the nesting
			//options are hidden by default. However, if the user somehow acquires a configuration where this
			//feature is enabled (e.g. by importing config from the Pro version), the free version can display
			//and even edit that configuration to a limited extent.
			if ( $isProVersion || !empty($settings['was_nesting_ever_changed']) ):
				?>
				<tr>
					<th scope="row">
						三级菜单
						<a class="ws_tooltip_trigger ame-warning-tooltip"
						   title="警告：实验特性.&lt;br&gt;
						   此功能可能无法按预期工作，并可能导致与其他插件或主题冲突.">
							<div class="dashicons dashicons-admin-tools"></div>
						</a>
					</th>
					<td>
						<fieldset>
							<?php
							$nestingOptions = array(
								'首次使用时询问'                                     => null,
								'启用' . ($isProVersion ? '' : ' (only in editor)') => true,
								'禁用'                                             => false,
							);
							foreach ($nestingOptions as $label => $nestingSetting):
								?>
								<p>
									<label>
										<input type="radio" name="deep_nesting_enabled"
										       value="<?php echo esc_attr(wp_json_encode($nestingSetting)); ?>"
											<?php
											if ( $settings['deep_nesting_enabled'] === $nestingSetting ) {
												echo ' checked="checked"';
											}
											?>>
										<?php echo esc_html($label); ?>
									</label>
								</p>
							<?php endforeach; ?>
						</fieldset>
					</td>
				</tr>
			<?php endif; ?>

			<tr>
				<th scope="row">
					WPML支持
				</th>
				<td>
					<p>
						<label>
							<input type="checkbox" name="wpml_support_enabled"
								<?php checked($settings['wpml_support_enabled']); ?>>
							使用WPML使编辑后的菜单标题可翻译

							<br><span class="description">
								标题将出现在WPML的“字符串”部分.
								如果你不使用WPML或类似的翻译插件,
								您可以安全地禁用此选项.
							</span>
						</label>
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row">
					bbPress超控
				</th>
				<td>
					<p>
						<label>
							<input type="checkbox" name="bbpress_override_enabled"
								<?php checked($settings['bbpress_override_enabled']); ?>>
							阻止bbPress重置角色功能

							<br><span class="description">
								默认情况下，bbPress将自动撤消对动态所做的任何更改
								bbPress角色。启用此选项以覆盖该行为并使其成为可能
								更改bbPress角色功能.
							</span>
						</label>
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row">错误详细程度</th>
				<td>
					<fieldset id="ame-submenu-icons-settings">
						<p>
							<label>
								<input type="radio" name="error_verbosity" value="<?php echo esc_attr(WPMenuEditor::VERBOSITY_LOW); ?>>"
									<?php checked(WPMenuEditor::VERBOSITY_LOW, $settings['error_verbosity']); ?>>
								简单

								<br><span class="description">
									显示没有任何详细信息的通用错误消息.
								</span>
							</label>
						</p>

						<p>
							<label>
								<input type="radio" name="error_verbosity" value="<?php echo esc_attr(WPMenuEditor::VERBOSITY_NORMAL); ?>>"
									<?php checked(WPMenuEditor::VERBOSITY_NORMAL, $settings['error_verbosity']); ?>>
								正常

								<br><span class="description">
									显示一两句话的解释。例如：“当前用户没有
									访问“设置”菜单项所需的“管理选项”功能。"
								</span>
							</label>
						</p>

						<p>
							<label>
								<input type="radio" name="error_verbosity" value="<?php echo esc_attr(WPMenuEditor::VERBOSITY_VERBOSE); ?>>"
									<?php checked(WPMenuEditor::VERBOSITY_VERBOSE, $settings['error_verbosity']); ?>>
								详细

								<br><span class="description">
									像“正常”一样，还包括菜单设置和权限的日志
									导致当前菜单被隐藏。可用于调试.
								</span>
							</label>
						</p>
					</fieldset>
				</td>
			</tr>

			<tr>
				<th scope="row">调试</th>
				<td>
					<p>
					<label>
						<input type="checkbox" name="security_logging_enabled"
							<?php checked($settings['security_logging_enabled']); ?>>
						在每个管理页面上显示插件执行的菜单访问检查
					</label>
					<br><span class="description">
						这可以帮助追踪配置问题并找出原因
						您的菜单权限没有按照应有的方式工作.

						注意：不建议在实时网站上使用此选项，因为
						它可以显示有关菜单配置的信息.
					</span>
					</p>

					<p>
						<label>
							<input type="checkbox" name="force_custom_dashicons"
								<?php checked($settings['force_custom_dashicons']); ?>>
							尝试覆盖其他插件添加的菜单图标CSS
						</label>
					</p>

					<p>
						<label>
							<input type="checkbox" name="delete_orphan_actor_settings"
								<?php checked($settings['delete_orphan_actor_settings']); ?>>
							自动删除与缺少的角色和用户关联的设置
						</label>
						<br><span class="description">
							仅适用于插件的某些部分。在多站点中，此选项被禁用
							默认情况下，因为不同的站点可能具有不同的角色.
						</span>
					</p>

					<p>
						<label>
							<input type="checkbox" name="compress_custom_menu"
								<?php checked($settings['compress_custom_menu']); ?>>
							压缩存储在数据库中的菜单配置数据
						</label>
						<br><span class="description">
							显著减小了
							这个 <code><?php echo esc_html($db_option_name); ?></code> DB 选项,
							但会给每个页面增加解压缩开销.
						</span>
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row">服务器信息</th>
				<td>
					<figure>
						<figcaption>PHP错误日志:</figcaption>

						<code><?php
						echo esc_html(ini_get('error_log'));
						?></code>
					</figure>

					<figure>
						<figcaption>PHP内存使用情况:</figcaption>

						<?php
						printf(
							'%.2f MiB of %s',
							// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- We're using sprintf() to format a float.
							memory_get_peak_usage() / (1024 * 1024),
							esc_html(ini_get('memory_limit'))
						);
						?>
					</figure>
				</td>
			</tr>
			</tbody>
		</table>

		<input type="hidden" name="action" value="save_settings">
		<?php
		wp_nonce_field('save_settings');
		submit_button();
		?>
	</form>

<?php do_action('admin_menu_editor-display_footer'); ?>

<script type="text/javascript">
	jQuery(function($) {
		//Set up tooltips
		$('.ws_tooltip_trigger').qtip({
			style: {
				classes: 'qtip qtip-rounded ws_tooltip_node ws_wide_tooltip'
			}
		});
	});
</script>