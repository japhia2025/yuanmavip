<?php
/**
 * @var array $editor_data Various pieces of data passed by the plugin.
 */
$ame_current_user = wp_get_current_user();
$images_url = $editor_data['images_url'];
$is_pro_version = apply_filters('admin_menu_editor_is_pro', false);
$is_second_toolbar_visible = isset($_COOKIE['ame-show-second-toolbar']) && (intval($_COOKIE['ame-show-second-toolbar']) === 1);
$is_compact_layout_enabled = isset($_COOKIE['ame-compact-layout']) && (intval($_COOKIE['ame-compact-layout']) === 1);
$is_multisite = is_multisite();

$icons = array(
	'cut' => '/gnome-icon-theme/edit-cut-blue.png',
	'copy' => '/gion/edit-copy.png',
	'paste' => '/gnome-icon-theme/edit-paste.png',
	'hide'  =>  '/page-invisible.png',
	'hide-and-deny'  =>  '/font-awesome/eye-slash-color.png',
	'new' => '/page-add.png',
	'delete' => '/page-delete.png',
	'new-separator' => '/separator-add.png',
	'toggle-all' => '/check-all.png',
	'copy-permissions' => '/copy-permissions.png',
	'toggle-toolbar' => '/font-awesome/angle-double-down.png',
	'sort-ascending' => '/sort_ascending.png',
	'sort-descending' => '/sort_descending.png',
);
foreach($icons as $name => $url) {
	$icons[$name] = $images_url . $url;
}
$icons = apply_filters('admin_menu_editor-toolbar_icons', $icons, $images_url);

$toolbarButtons = new ameOrderedMap();
$toolbarButtons->addAll(array(
	'cut'           => array(
		'title' => '剪切',
	),
	'copy'          => array(
		'title' => '复制',
	),
	'paste'         => array(
		'title' => '粘贴',
	),
	'separator-1'   => null,
	'new-menu'      => array(
		'title' => '新菜单',
		'iconName' => 'new',
	),
	'new-separator' => array(
		'title' => '新分隔符',
		'topLevelOnly' => !$is_pro_version,
	),
	'delete'        => array(
		'title' => '删除菜单',
		'class' => array('ws_delete_menu_button'),
	),
	'separator-2'   => null,
));

if ( !$is_pro_version ) {
	ame_register_sort_buttons($toolbarButtons);
}

if ( $editor_data['show_deprecated_hide_button'] ) {
	$toolbarButtons->insertBefore(
		'delete',
		'hide',
		array(
			'title' => '隐藏而不阻止访问（装饰性）',
			'alt'   => 'Hide (cosmetic)',
		)
	);
}

$secondToolbarRow = new ameOrderedMap();
if ( $is_pro_version ) {
	//In the Pro version, the sort buttons are on the second row.
	ame_register_sort_buttons($secondToolbarRow);
}

$secondToolbarRowClasses = array('ws_second_toolbar_row');
if ( !$is_second_toolbar_visible ) {
	$secondToolbarRowClasses[] = 'hidden';
}

do_action('admin_menu_editor-register_toolbar_buttons', $toolbarButtons, $secondToolbarRow, $icons);

if ( count($secondToolbarRow) > 0 ) {
	$toolbarButtons->set(
		'toggle-toolbar',
		array(
			'title' => '切换第二个工具栏',
			'alt'   => 'Toolbar toggle',
			'class' => array('ws_toggle_toolbar_button'),
			'topLevelOnly' => true,
		)
	);
}

/**
 * @param ameOrderedMap $buttons
 * @param array $icons
 * @param array $classes CSS classes to add to the toolbar row.
 */
function ame_output_toolbar_row($buttons, $icons, $classes = array()) {
	$classes = array_merge(array('ws_button_container'), $classes);
	printf('<div class="%s">', esc_attr(implode(' ', $classes)));

	foreach ($buttons as $key => $settings) {
		if ( $settings === null ) {
			echo '<div class="ws_separator">&nbsp;</div>';
			continue;
		}

		if ( !isset($settings['title']) ) {
			$settings['title'] = $key;
		}
		$action = isset($settings['action']) ? $settings['action'] : $key;

		$buttonClasses = array('ws_button');
		if ( !empty($settings['class']) ) {
			$buttonClasses = array_merge($buttonClasses, $settings['class']);
		}

		$attributes = array(
			'data-ame-button-action' => $action,
			'class'                  => implode(' ', $buttonClasses),
			'href'                   => '#',
			'title'                  => $settings['title'],
		);
		if ( isset($settings['attributes']) ) {
			$attributes = array_merge($attributes, $settings['attributes']);
		}

		$iconName = isset($settings['iconName']) ? $settings['iconName'] : $key;
		$icon = '';
		if ( isset($icons[$iconName]) ) {
			$icon = sprintf(
				'<img src="%s" alt="%s">',
				esc_attr($icons[$iconName]),
				esc_attr(isset($settings['alt']) ? $settings['alt'] : $settings['title'])
			);
		}

		$pairs = array();
		foreach ($attributes as $name => $value) {
			$pairs[] = $name . '="' . esc_attr($value) . '"';
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Attribute $pairs and $icon attributes were escaped with esc_attr() above.
		printf('<a %s>%s</a>' . "\n", implode(' ', $pairs), $icon);
	}

	echo '<div class="clear"></div>' . "\n";
	echo '</div>';
}

//Output the "Upgrade to Pro" message
if ( !apply_filters('admin_menu_editor_is_pro', false) ){
	?>
	<script type="text/javascript">
	(function($){
		var screenLinks = $('#screen-meta-links');
		screenLinks.append(
			'<div id="ws-pro-version-notice" class="custom-screen-meta-link-wrap">' +
				'<a href="https://adminmenueditor.com/upgrade-to-pro/?utm_source=Admin%2BMenu%2BEditor%2Bfree&utm_medium=text_link&utm_content=top_upgrade_link&utm_campaign=Plugins" id="ws-pro-version-notice-link" class="show-settings custom-screen-meta-link" target="_blank" title="查看Pro版本详细信息">Upgrade to Pro</a>' +
			'</div>'
		);
	})(jQuery);
	</script>
	<?php
}

?>

<?php do_action('admin_menu_editor-display_header'); ?>

<?php
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Don't need that here, just showing a notice.
if ( !empty($_GET['message']) && (intval($_GET['message']) == 2) ){
	echo '<div id="message" class="error"><p><strong>Failed to decode input! The menu wasn\'t modified.</strong></p></div>';
}

include dirname(__FILE__) . '/../modules/access-editor/access-editor-template.php';
$extrasDirectory = dirname(__FILE__) . '/../extras';
if ( $is_pro_version ) {
	include $extrasDirectory . '/copy-permissions-dialog.php';
}

/**
 * @param ameOrderedMap $toolbar
 */
function ame_register_sort_buttons($toolbar) {
	$toolbar->addAll(array(
		'sort-ascending'  => array(
			'title'      => '升序排序',
			'action'     => 'sort',
			'attributes' => array(
				'data-sort-direction' => 'asc',
			),
		),
		'sort-descending' => array(
			'title'      => '降序排序',
			'action'     => 'sort',
			'attributes' => array(
				'data-sort-direction' => 'desc',
			),
		),
	));
}

?>

<div id='ws_menu_editor' style="visibility: hidden;" class="<?php
	if ( $is_compact_layout_enabled ) {
		echo 'ws_compact_layout';
	} else {
		echo 'ws_large_layout';
	}
?>">

	<?php include dirname(__FILE__) . '/../modules/actor-selector/actor-selector-template.php'; ?>

    <div>

	<div class='ws_main_container'>
		<div class='ws_toolbar'>
			<?php
			ame_output_toolbar_row($toolbarButtons, $icons);
			ame_output_toolbar_row($secondToolbarRow, $icons, $secondToolbarRowClasses);
			?>
		</div>

		<div id='ws_menu_box' class="ws_box">
		</div>

		<div id="ws_top_menu_dropzone" class="ws_dropzone"> </div>
		<?php do_action('admin_menu_editor-container', 'menu'); ?>
	</div>

	<div class='ws_main_container' id="ame-submenu-column-template" style="display: none;">
		<div class='ws_toolbar'>
			<?php
			function ame_button_can_be_in_submenu_toolbar($settings) {
				return empty($settings['topLevelOnly']);
			}

			ame_output_toolbar_row(
				$toolbarButtons->filter('ame_button_can_be_in_submenu_toolbar'),
				$icons
			);

			ame_output_toolbar_row(
				$secondToolbarRow->filter('ame_button_can_be_in_submenu_toolbar'),
				$icons,
				$secondToolbarRowClasses
			);
			?>
		</div>

		<div id='ws_submenu_box' class="ws_box">
		</div>

		<?php do_action('admin_menu_editor-container', 'submenu'); ?>
	</div>

	<div class="ws_basic_container">

		<div class="ws_main_container" id="ws_editor_sidebar">
		<form method="post" action="<?php echo esc_url(add_query_arg('noheader', '1', $editor_data['current_tab_url'])); ?>" id='ws_main_form' name='ws_main_form'>
			<?php wp_nonce_field('menu-editor-form'); ?>
			<input type="hidden" name="action" value="save_menu">
			<?php
			printf('<input type="hidden" name="config_id" value="%s">', esc_attr($editor_data['menu_config_id']));
			?>
			<input type="hidden" name="data" id="ws_data" value="">
			<input type="hidden" name="data_length" id="ws_data_length" value="">
			<input type="hidden" name="selected_actor" id="ws_selected_actor" value="">

			<input type="hidden" name="selected_menu_url" id="ws_selected_menu_url" value="">
			<input type="hidden" name="selected_submenu_url" id="ws_selected_submenu_url" value="">

			<input type="hidden" name="expand_menu" id="ws_expand_selected_menu" value="">
			<input type="hidden" name="expand_submenu" id="ws_expand_selected_submenu" value="">

			<input type="hidden" name="deep_nesting_enabled" id="ws_is_deep_nesting_enabled" value="">

			<button type="button" id='ws_save_menu' class="button button-primary ws_main_button">保存更改</button>
		</form>

			<input type="button" id='ws_reset_menu' value="撤消更改" class="button ws_main_button" />
			<input type="button" id='ws_load_menu' value="加载默认菜单" class="button ws_main_button" />

			<!--
			<input type="button" id='ws_test_access' value="Test access..." class="button ws_main_button" />
			-->

			<?php
			$compact_layout_title = '紧凑布局';
			if ( $is_compact_layout_enabled ) {
				$compact_layout_title = '&#x2713; ' . $compact_layout_title;
			}
			?>
			<input type="button"
			       id='ws_toggle_editor_layout'
			       value="<?php echo esc_attr($compact_layout_title); ?>"
			       class="button ws_main_button" />

			<?php
				do_action('admin_menu_editor-sidebar');
			?>
		</div>

		<div class="clear"></div>
		<div class="metabox-holder">
		<?php
		if ( apply_filters('admin_menu_editor-show_general_box', false) ) :
			$is_general_box_open = true;
			if ( isset($_COOKIE['ame_vis_box_open']) ) {
				$is_general_box_open = ($_COOKIE['ame_vis_box_open'] === '1');
			}
			$box_class = $is_general_box_open ? '' : 'closed';

			?>
				<div class="postbox ws_ame_custom_postbox <?php echo esc_attr($box_class); ?>" id="ws_ame_general_vis_box">
					<button type="button" class="handlediv button-link">
						<span class="toggle-indicator"></span>
					</button>
					<h2 class="hndle">常规</h2>
					<div class="inside">
						<?php do_action('admin_menu_editor-general_box'); ?>
					</div>
				</div>
			<?php
		endif;

		$is_how_to_box_open = true;
		if ( isset($_COOKIE['ame_how_to_box_open']) ) {
			$is_how_to_box_open = ($_COOKIE['ame_how_to_box_open'] === '1');
		}
		$box_class = $is_how_to_box_open ? '' : 'closed';

		if ( $is_pro_version ) {
			$tutorial_base_url = 'https://adminmenueditor.com/documentation/';
		} else {
			$tutorial_base_url = 'https://adminmenueditor.com/free-version-docs/';
		}

		/** @noinspection HtmlUnknownTarget */
		$how_to_link_template = '<a href="' . esc_url($tutorial_base_url) . '%1$s" target="_blank" title="在新选项卡中打开">%2$s</a>';
		$how_to_item_template = '<li>' . $how_to_link_template . '</li>';

		?>
			<div class="postbox ws_ame_custom_postbox <?php echo esc_attr($box_class); ?>" id="ws_ame_how_to_box">
				<button type="button" class="handlediv button-link">
					<span class="toggle-indicator"></span>
				</button>
				<h2 class="hndle">常见问题</h2>
				<div class="inside">
					<ul class="ame-tutorial-list">
						<li><a href="http://waimao.la/" target="_blank" rel="noopener"><strong><span style="color: #ff0000;">WML汉化支持</span></strong></a></li>
						<?php
						if ( $is_pro_version ):
							//Pro version tutorials.
							?>
							<li><?php
								printf(
									//phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML template contains HTML.
									$how_to_link_template,
									'how-to-hide-a-menu-item/',
									'隐藏菜单...'
								);
								?>
								<ul class="ame-tutorial-list">
									<?php
									foreach (
										array(
											'how-to-hide-a-menu-item/#how-to-hide-a-menu-from-a-role'                   => '从角色',
											'how-to-hide-a-menu-item/#how-to-hide-a-menu-from-a-user'                   => '从用户',
											'how-to-hide-a-menu-item/#how-to-hide-a-menu-from-everyone-except-yourself' => '除了你之外的每个人',
											'how-to-hide-menu-without-preventing-access/'                               => '不阻止访问',
										)
										as $how_to_url => $how_to_title
									) {
										printf(
											//phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML template.
											$how_to_item_template,
											esc_attr($how_to_url),
											esc_html($how_to_title)
										);
									}
									?>
								</ul>
							</li>
							<?php
							foreach (
								array(
									'how-to-give-access-to-menu/' => '显示菜单',
									'how-to-move-and-sort-menus/' => '移动和排序菜单',
									'how-to-add-a-new-menu-item/' => '添加新菜单',
								)
								as $how_to_url => $how_to_title
							) {
								printf(
								//phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML template
									$how_to_item_template,
									esc_attr($how_to_url),
									esc_html($how_to_title)
								);
							}

						else:
							//Free version tutorials.
							foreach (
								array(
									'how-to-hide-menus/'          => '隐藏菜单项',
									'how-to-hide-menus-cosmetic/' => '隐藏而不阻止访问',
									'how-to-add-new-menu/'        => '添加新菜单',
								)
								as $how_to_url => $how_to_title
							) {
								printf(
								//phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML template
									$how_to_item_template,
									esc_attr($how_to_url),
									esc_html($how_to_title)
								);
							}
						endif;
						?>
					</ul>
				</div>
			</div>
		</div> <!-- / .metabox-holder -->

		<?php
		$hint_id = 'ws_sidebar_pro_ad';
		$show_pro_benefits = !apply_filters('admin_menu_editor_is_pro', false) && (!isset($editor_data['show_hints'][$hint_id]) || $editor_data['show_hints'][$hint_id]);

		if ( $show_pro_benefits):
			//Decide whether to show the Pro version link, or a link to one of our other WP tools.
			$hash_value = hexdec(substr(md5(get_site_url()), 0, 5)) % 100;

			//Pick one option proportionally to the weights. Weights should add up to 100.
			$sidebar_ad_weights = [
				'pro'                 => 80,
				'adminNoticesBoss'    => 18,
				'adminThemeGenerator' => 2,
			];
			$chosen_ad = array_keys($sidebar_ad_weights)[0];
			$cumulative_weight = 0;
			foreach ($sidebar_ad_weights as $ad => $weight) {
				$cumulative_weight += $weight;
				$chosen_ad = $ad;
				if ($hash_value < $cumulative_weight) {
					break;
				}
			}

			if ($chosen_ad === 'pro'):
				$benefit_variations = array(
					'Hide dashboard widgets.',
					'More menu icons.',
					'Make menus open in a new tab or an iframe.',
					'Prevent users from deleting a specific user.',
				);
				//Pseudo-randomly select one phrase based on the site URL.
				$variation_index = hexdec( substr(md5(get_site_url() . 'ab'), -2) ) % count($benefit_variations);
				$selected_variation = $benefit_variations[$variation_index];

				$pro_version_link = 'https://adminmenueditor.com/upgrade-to-pro/?utm_source=Admin%2BMenu%2BEditor%2Bfree&utm_medium=text_link&utm_content=sidebar_link_nv' . $variation_index . '&utm_campaign=Plugins';
				?>
				<div class="clear"></div>

				<div class="ws_hint" id="<?php echo esc_attr($hint_id); ?>">
					<div class="ws_hint_close" title="关闭">x</div>
					<div class="ws_hint_content">
						<strong>升级到专业版:</strong>
						<ul>
							<li>基于角色的菜单权限.</li>
							<li>对特定用户隐藏项目.</li>
							<li>菜单导入和导出.</li>
							<li>更改菜单颜色.</li>
							<li><?php echo esc_html($selected_variation); ?></li>
						</ul>
						<a href="<?php echo esc_url($pro_version_link); ?>" target="_blank">了解更多</a>
						|
						<a href="https://amedemo.com/" target="_blank">尝试在线演示</a>
					</div>
				</div>
			<?php
			elseif ($chosen_ad === 'adminThemeGenerator'):
				?>
				<div class="clear"></div>

				<div class="ws_hint ame-tgc-sidebar-ad" id="<?php echo esc_attr($hint_id); ?>">
					<div class="ws_hint_close" title="关闭">x</div>
					<div class="ws_hint_content">
						<strong>发现 AdminThemeGenerator.com</strong>
						<ul>
							<li>免费
								<abbr title="管理主题是一个更改WordPress管理仪表板外观的插件">
									管理主题
								</abbr>
								基于Pro版管理菜单编辑器的生成器.
							</li>
							<li>设计自己的管理员配色方案.</li>
							<li>更改管理菜单和工具栏大小.</li>
							<li>自定义按钮、小部件和表格样式.</li>
						</ul>
						<a href="<?php echo esc_url('https://adminthemegenerator.com/'); ?>" target="_blank">
							AdminThemeGenerator.com<span class="dashicons dashicons-external"></span>
						</a>
					</div>
				</div>
			<?php
			elseif ($chosen_ad === 'adminNoticesBoss'):
				?>
				<div class="clear"></div>

				<div class="ws_hint ame-anb-sidebar-ad" id="<?php echo esc_attr($hint_id); ?>">
					<div class="ws_hint_close" title="关闭">x</div>
					<div class="ws_hint_content">
						<strong><span>查看我的其他插件: </span>Admin Notices Boss</strong>
						<ul>
							<li>永久隐藏单个管理通知.</li>
							<li>将通知移动到不显眼的面板.</li>
							<li>隐藏特定角色或用户的通知.</li>
							<li>根据类型（警告、信息等）隐藏通知.</li>
						</ul>
						<a href="<?php echo esc_url('https://adminnoticesboss.com/'); ?>" target="_blank">
							AdminNoticesBoss.com<span class="dashicons dashicons-external"></span>
						</a>
					</div>
				</div>
			<?php
			endif;
		endif;
		?>

	</div> <!-- / .ws_basic_container -->

    </div>

	<div class="clear"></div>

</div> <!-- / .ws_menu_editor -->

<?php do_action('admin_menu_editor-display_footer'); ?>



<?php
	//Create a pop-up capability selector
	$capSelector = array('<select id="ws_cap_selector" class="ws_dropdown" size="10">');

	$capSelector[] = '<optgroup label="Roles">';
 	foreach($editor_data['all_roles'] as $role_id => $role_name){
 		$capSelector[] = sprintf(
		 	'<option value="%s">%s</option>',
		 	esc_attr($role_id),
		 	esc_html($role_name)
	 	);
 	}
 	$capSelector[] = '</optgroup>';

 	$capSelector[] = '<optgroup label="Capabilities">';
 	foreach($editor_data['all_capabilities'] as $cap){
 		$capSelector[] = sprintf(
		 	'<option value="%s">%s</option>',
		 	esc_attr($cap),
		 	esc_html($cap)
	 	);
 	}
 	$capSelector[] = '</optgroup>';
 	$capSelector[] = '</select>';

	 // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Generated HTML, should be escaped above.
 	echo implode("\n", $capSelector);
?>

<!-- Menu icon selector widget -->
<div id="ws_icon_selector" class="ws_with_more_icons" style="display: none;">

	<div id="ws_icon_source_tabs">
	<ul class="ws_tool_tab_nav">
		<?php
		$iconSelectorTabs = apply_filters(
			'admin_menu_editor-icon_selector_tabs',
			array('ws_core_icons_tab' => '仪表图标')
		);
		foreach($iconSelectorTabs as $tabId => $caption) {
			/** @noinspection HtmlUnknownAnchorTarget -- It's a printf placeholder. */
			printf('<li><a href="#%s">%s</a></li>', esc_attr($tabId), esc_html($caption));
		}
		?>
	</ul>

	<?php
	//Let the user select a custom icon via the media uploader.
	//We only support the new WP 3.5+ media API. Hence, the function_exists() check.
	if ( function_exists('wp_enqueue_media') ):
		?>
		<input type="button" class="button"
		       id="ws_choose_icon_from_media"
		       title=“上传图像或从媒体库中选择一个"
		       value="媒体库">
		<div class="clear"></div>
		<?php
	endif;
	?>

	<div class="ws_tool_tab" id="ws_core_icons_tab">
		<div class="ws_icon_search_bar">
			<label>
				<span class="screen-reader-text">图标搜索框</span>
				<input type="text" class="regular-text ws_icon_search_box" placeholder="搜索图标">
			</label>
		</div>

	<?php
	//These dashicons are used in the default admin menu.
	$defaultDashicons = array(
		'admin-generic', 'dashboard', 'admin-post', 'admin-media', 'admin-links', 'admin-page', 'admin-comments',
		'admin-appearance', 'admin-plugins', 'admin-users', 'admin-tools', 'admin-settings', 'admin-network',
	);

	//The rest of Dashicons.
	$dashicons = array(
		'menu',
		'admin-site',
		'admin-home',
		'admin-collapse',
		'filter',
		'admin-customizer',
		'admin-multisite',
		'format-image',
		'format-gallery',
		'format-audio',
		'format-video',
		'format-chat',
		'format-status',
		'format-aside',
		'format-quote',
		'welcome-write-blog',
		'welcome-add-page',
		'welcome-view-site',
		'welcome-widgets-menus',
		'welcome-comments',
		'welcome-learn-more',
		'image-crop',
		'image-rotate',
		'image-rotate-left',
		'image-rotate-right',
		'image-flip-vertical',
		'image-flip-horizontal',
		'image-filter',
		'undo',
		'redo',
		'editor-bold',
		'editor-italic',
		'editor-ul',
		'editor-ol',
		'editor-quote',
		'editor-alignleft',
		'editor-aligncenter',
		'editor-alignright',
		'editor-insertmore',
		'editor-spellcheck',
		'editor-expand',
		'editor-contract',
		'editor-kitchensink',
		'editor-underline',
		'editor-justify',
		'editor-textcolor',
		'editor-paste-word',
		'editor-paste-text',
		'editor-removeformatting',
		'editor-video',
		'editor-customchar',
		'editor-outdent',
		'editor-indent',
		'editor-help',
		'editor-strikethrough',
		'editor-unlink',
		'editor-rtl',
		'editor-break',
		'editor-code',
		'editor-paragraph',
		'editor-table',
		'align-left',
		'align-right',
		'align-center',
		'align-none',
		'lock',
		'unlock',
		'calendar',
		'calendar-alt',
		'visibility',
		'hidden',
		'post-status',
		'edit',
		'edit-large',
		'sticky',
		'external',
		'arrow-up',
		'arrow-down',
		'arrow-left',
		'arrow-right',
		'arrow-up-alt',
		'arrow-down-alt',
		'arrow-left-alt',
		'arrow-right-alt',
		'arrow-up-alt2',
		'arrow-down-alt2',
		'arrow-left-alt2',
		'arrow-right-alt2',
		'leftright',
		'sort',
		'randomize',
		'list-view',
		'excerpt-view',
		'grid-view',
		'move',
		'hammer',
		'art',
		'migrate',
		'performance',
		'universal-access',
		'universal-access-alt',
		'tickets',
		'nametag',
		'clipboard',
		'heart',
		'megaphone',
		'schedule',
		'wordpress',
		'wordpress-alt',
		'pressthis',
		'update',
		'screenoptions',
		'cart',
		'feedback',
		'translation',
		'tag',
		'category',
		'archive',
		'tagcloud',
		'text',
		'media-archive',
		'media-audio',
		'media-code',
		'media-default',
		'media-document',
		'media-interactive',
		'media-spreadsheet',
		'media-text',
		'media-video',
		'playlist-audio',
		'playlist-video',
		'controls-play',
		'controls-pause',
		'controls-forward',
		'controls-skipforward',
		'controls-back',
		'controls-skipback',
		'controls-repeat',
		'controls-volumeon',
		'controls-volumeoff',
		'yes',
		'no',
		'no-alt',
		'plus',
		'plus-alt',
		'plus-alt2',
		'minus',
		'dismiss',
		'marker',
		'star-filled',
		'star-half',
		'star-empty',
		'flag',
		'info',
		'warning',
		'share',
		'share1',
		'share-alt',
		'share-alt2',
		'twitter',
		'rss',
		'email',
		'email-alt',
		'facebook',
		'facebook-alt',
		'networking',
		'googleplus',
		'location',
		'location-alt',
		'camera',
		'images-alt',
		'images-alt2',
		'video-alt',
		'video-alt2',
		'video-alt3',
		'vault',
		'shield',
		'shield-alt',
		'sos',
		'search',
		'slides',
		'analytics',
		'chart-pie',
		'chart-bar',
		'chart-line',
		'chart-area',
		'groups',
		'businessman',
		'id',
		'id-alt',
		'products',
		'awards',
		'forms',
		'testimonial',
		'portfolio',
		'book',
		'book-alt',
		'download',
		'upload',
		'backup',
		'clock',
		'lightbulb',
		'microphone',
		'desktop',
		'laptop',
		'tablet',
		'smartphone',
		'phone',
		'smiley',
		'index-card',
		'carrot',
		'building',
		'store',
		'album',
		'palmtree',
		'tickets-alt',
		'money',
		'thumbs-up',
		'thumbs-down',
		'layout',
		'paperclip',
		'email-alt2',
		'menu-alt',
		'trash',
		'heading',
		'insert',
		'align-full-width',
		'button',
		'align-wide',
		'ellipsis',
		'buddicons-activity',
		'buddicons-buddypress-logo',
		'buddicons-community',
		'buddicons-forums',
		'buddicons-friends',
		'buddicons-groups',
		'buddicons-pm',
		'buddicons-replies',
		'buddicons-topics',
		'buddicons-tracking',
		'admin-site-alt',
		'admin-site-alt2',
		'admin-site-alt3',
		'rest-api',
		'yes-alt',
		'buddicons-bbpress-logo',
		'tide',
		'editor-ol-rtl',
		'instagram',
		'businessperson',
		'businesswoman',
		'color-picker',
		'camera-alt',
		'editor-ltr',
		'cloud',
		'twitter-alt',
		'menu-alt2',
		'menu-alt3',
		'plugins-checked',
		'text-page',
		'update-alt',
		'code-standards',
		'align-pull-left',
		'align-pull-right',
		'block-default',
		'cloud-saved',
		'cloud-upload',
		'columns',
		'cover-image',
		'embed-audio',
		'embed-generic',
		'embed-photo',
		'embed-post',
		'embed-video',
		'exit',
		'html',
		'info-outline',
		'insert-after',
		'insert-before',
		'remove',
		'shortcode',
		'table-col-after',
		'table-col-before',
		'table-col-delete',
		'table-row-after',
		'table-row-before',
		'table-row-delete',
		'saved',
		'airplane',
		'amazon',
		'bank',
		'beer',
		'bell',
		'calculator',
		'coffee',
		'database-add',
		'database-export',
		'database-import',
		'database-remove',
		'database-view',
		'database',
		'drumstick',
		'edit-page',
		'food',
		'fullscreen-alt',
		'fullscreen-exit-alt',
		'games',
		'google',
		'hourglass',
		'linkedin',
		'money-alt',
		'open-folder',
		'pdf',
		'pets',
		'pinterest',
		'printer',
		'privacy',
		'reddit',
		'spotify',
		'superhero-alt',
		'superhero',
		'twitch',
		'whatsapp',
		'youtube',
		'car',
		'podio',
		'xing',
	);

	if ($editor_data['dashicons_available']) {
		function ws_ame_print_dashicon_option($icon, $isExtraIcon = false) {
			printf(
				'<div class="ws_icon_option%3$s" title="%1$s" data-icon-url="dashicons-%2$s">
					<div class="ws_icon_image dashicons dashicons-%2$s"></div>
				</div>',
				esc_attr(ucwords(str_replace('-', ' ', $icon))),
				$icon,
				$isExtraIcon ? ' ws_icon_extra' : ''
			);
		}

		foreach($defaultDashicons as $icon) {
			ws_ame_print_dashicon_option($icon);
		}
		foreach($dashicons as $icon) {
			ws_ame_print_dashicon_option($icon, true);
		}
	}

	$defaultIconImages = array(
		'Blue-grey cogwheel (generic menu icon used by old WP versions)' => admin_url('images/generic.png'),
	);
	foreach($defaultIconImages as $name => $icon) {
		printf(
			'<div class="ws_icon_option" data-icon-url="%1$s">
				<img src="%1$s" alt="%2$s">
			</div>',
			esc_attr($icon),
			esc_attr($name)
		);
	}

	?>
	<div class="ws_icon_option ws_custom_image_icon" title="自定义图像" style="display: none;">
		<img src="<?php echo esc_url(admin_url('images/loading.gif')); ?>" alt="Loading indicator">
	</div>

		<div class="ws_no_matching_icons" style="display: none">未找到结果</div>
		<div class="clear"></div>
	</div>

		<?php do_action('admin_menu_editor-icon_selector'); ?>

	</div><!-- tab container -->

</div>

<span id="ws-ame-screen-meta-contents" style="display:none;">
	<label for="ws-hide-advanced-settings">
		<input type="checkbox" id="ws-hide-advanced-settings"<?php
			if ( $this->options['hide_advanced_settings'] ){
				echo ' checked="checked"';
			}
		?> /> 隐藏高级选项
	</label><br>
</span>


<!-- Confirmation dialog when hiding "Dashboard -> Home" -->
<div id="ws-ame-dashboard-hide-confirmation" style="display: none;">
	<span>
		隐藏 <em>仪表盘 -> 首页</em> 可能会阻止具有所选角色的用户登录!
		你确定要这样做吗?
	</span>

	<h4>Explanation</h4>
	<p>
		WordPress 会自动将用户重定向到 <em>Dashboard -> Home</em> 成功登录后的页面.
		如果隐藏此页面，用户在登录时将收到“权限不足”错误
		由于被重定向到隐藏页面。因此，看起来他们的登录失败.
	</p>

	<h4>Recommendations</h4>
	<p>
		你可以使用类似的插件 <a href="http://wordpress.org/plugins/peters-login-redirect/">Peter 的登录重定向</a>
		将特定角色重定向到不同页面.
	</p>

	<div class="ws_dialog_buttons">
		<?php
		submit_button('Hide the menu', 'primary', 'ws_confirm_menu_hiding', false);
		submit_button('Leave it visible', 'secondary', 'ws_cancel_menu_hiding', false);
		?>
	</div>

	<label class="ws_dont_show_again">
		<input type="checkbox" id="ws-ame-disable-dashboard-hide-confirmation">
		不再显示此消息
	</label>
</div>

<!-- Confirmation dialog when trying to delete a non-custom item. -->
<div id="ws-ame-menu-deletion-error" title="Error" style="display: none;">
	<div class="ws_dialog_panel">
		抱歉，无法永久删除
		<span id="ws-ame-menu-type-desc">{a built-in menu item|an item added by another plugin}</span>.
		你想把它藏起来吗?
	</div>

	<div class="ws_dialog_buttons ame-vertical-button-list">
		<?php
		submit_button('Hide it from all users', 'secondary', 'ws_hide_menu_from_everyone', false);
		submit_button(
			sprintf('对除之外的所有人隐藏它 "%s"', $ame_current_user->get('user_login')),
			'secondary',
			'ws_hide_menu_except_current_user',
			false
		);
		submit_button(
			'对除管理员之外的所有人隐藏它',
			'secondary',
			'ws_hide_menu_except_administrator',
			false
		);
		submit_button('取消', 'secondary', 'ws_cancel_menu_deletion', false);
		?>
	</div>
</div>

<?php include dirname(__FILE__) . '/cap-suggestion-box.php'; ?>

<?php include dirname(__FILE__) . '/test-access-screen.php'; ?>

<?php
if ( $is_pro_version ) {
	include $extrasDirectory . '/page-dropdown.php';
}
?>


<!--suppress JSUnusedLocalSymbols These variables are actually used by menu-editor.js -->
<script type='text/javascript'>
	var defaultMenu = <?php
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Should be JSON.
		echo $editor_data['default_menu_js'];
		?>;
	var customMenu = <?php
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Should also be JSON.
		echo $editor_data['custom_menu_js'];
		?>;
</script>
