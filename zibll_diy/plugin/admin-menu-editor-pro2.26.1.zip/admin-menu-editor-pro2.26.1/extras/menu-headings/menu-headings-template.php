<div id="ws-ame-menu-heading-settings" title="菜单标题" style="display: none;">
	<div class="ws_dialog_panel">
		<div class="ame-scrollable-dialog-content">

			<div class="ws_dialog_subpanel">
				<h3 class="ws-ame-dialog-subheading">文本颜色</h3>
				<fieldset>
					<p>
						<label>
							<input type="radio" name="ame-heading-text-color-type" value="default"
							       data-bind="checked: settings.textColorType">
							使用菜单文本颜色
						</label>
					</p>
					<p>
						<label>
							<input type="radio" name="ame-heading-text-color-type" value="custom"
							       data-bind="checked: settings.textColorType">
							<span class="ame-fixed-label-text">自定义</span>
						</label>
						<label for="ame-custom-heading-text-color" class="hidden">自定义标题文本颜色</label>
						<input type="text" id="ame-custom-heading-text-color"
						       data-bind="ameColorPicker: settings.textColor">
					</p>

				</fieldset>
			</div>

			<div class="ws_dialog_subpanel">
				<h3 class="ws-ame-dialog-subheading">背景颜色</h3>
				<fieldset>
					<p>
						<label>
							<input type="radio" name="ame-heading-background-color-type" value="default"
							       data-bind="checked: settings.backgroundColorType">
							使用菜单背景颜色
						</label>
					</p>
					<p>
						<label>
							<input type="radio" name="ame-heading-background-color-type" value="custom"
							       data-bind="checked: settings.backgroundColorType">
							<span class="ame-fixed-label-text">自定义</span>
						</label>
						<label for="ame-custom-heading-background-color" class="hidden">自定义标题背景
							颜色</label>
						<input type="text" id="ame-custom-heading-background-color"
						       data-bind="ameColorPicker: settings.backgroundColor">
					</p>

				</fieldset>
			</div>

			<div class="ws_dialog_subpanel">
				<h3 class="ws-ame-dialog-subheading">字体</h3>
				<fieldset>
					<p>
						<label for="ame-heading-font-size-value">
							<span class="ame-fixed-label-text">字体大小</span>
						</label>
						<input type="number" name="ame-heading-font-size-value" id="ame-heading-font-size-value"
						       min="1" max="400" size="5"
						       data-bind="value: settings.fontSizeValue">

						<label for="ame-heading-font-size-unit" class="hidden">字体大小单位</label>
						<select name="ame-heading-font-size-unit" id="ame-heading-font-size-unit"
						        class="ame-inline-select-with-input"
						        data-bind="value: settings.fontSizeUnit">
							<option value="percentage">%</option>
							<option value="px">px</option>
							<option value="em">em</option>
						</select>
					</p>

					<p>
						<label>
							<span class="ame-fixed-label-text">字体粗细</span>
							<select name="ame-heading-font-weight" data-bind="value: settings.fontWeight">
								<?php
								$weightOptions = ['继承', '正常', '粗体', '轻细', '粗黑'];
								for ($i = 100; $i <= 900; $i = $i + 100) {
									$weightOptions[] = $i;
								}
								foreach ($weightOptions as $option) {
									printf('<option value="%s">%s</option>', esc_attr($option), esc_html(ucfirst($option)));
								}
								?>
							</select>
						</label>
					</p>

					<p>
						<label>
							<span class="ame-fixed-label-text">变换</span>
							<select name="ame-heading-text-transform" id="ame-heading-text-transform"
							        data-bind="value: settings.textTransform">
								<?php
								$transformOptions = ['暂无', '首字母大写', '大写', '小写', '全角'];
								foreach ($transformOptions as $option) {
									printf('<option value="%s">%s</option>', esc_attr($option), esc_html(ucfirst($option)));
								}
								?>
							</select>
						</label>
					</p>
				</fieldset>
			</div>

			<div class="ws_dialog_subpanel">
				<h3 class="ws-ame-dialog-subheading">底部边框</h3>
				<fieldset id="ame-heading-bottom-border-style" class="ame-css-border-styles">
					<?php
					$styleOptions = array(
						'none'   => '无边框',
						'solid'  => '固体',
						'dashed' => '虚线',
						'double' => '重叠',
						'dotted' => '点缀',
					);
					foreach ($styleOptions as $style => $label):
						?>
						<p>
							<label>
								<input type="radio" name="ame-heading-bb-style" value="<?php echo esc_attr($style); ?>"
								       data-bind="checked: settings.bottomBorder.style">
								<span class="ame-fixed-label-text"><?php echo $label; ?></span>
								<span class="ame-border-sample-container">
								<span class="ame-border-sample"
								      style="border-top-style: <?php echo esc_attr($style); ?>"></span>
							</span>
							</label>
						</p>
					<?php
					endforeach;
					?>
				</fieldset>
			</div>

			<div class="ws_dialog_subpanel">
				<h3 class="ws-ame-dialog-subheading"><label for="ws-ame-heading-border-width">边框宽度</label></h3>
				<input type="number" id="ws-ame-heading-border-width" min="1" max="50" size="4" value="10"
				       data-bind="value: settings.bottomBorder.width"> px
			</div>

			<div class="ws_dialog_subpanel">
				<h3 class="ws-ame-dialog-subheading">显示图标</h3>
				<label for="ame-heading-icon-visibility" class="hidden">标题图标可见性设置</label>
				<select name="ame-heading-icon-visibility" id="ame-heading-icon-visibility"
				        data-bind="value: settings.iconVisibility">
					<?php
					$visibilityOptions = [
						'always'       => '始终',
						'never'        => '从不',
						'if-collapsed' => '仅当菜单折叠时',
					];
					foreach ($visibilityOptions as $option => $text) {
						printf('<option value="%s">%s</option>', esc_attr($option), esc_html($text));
					}
					?>
				</select>
			</div>

			<div class="ws_dialog_subpanel">
				<h3 class="ws-ame-dialog-subheading">填充</h3>
				<fieldset>
					<p>
						<label>
							<input type="radio" name="ame-heading-padding-type" value="auto"
							       data-bind="checked: settings.paddingType">
							自动
						</label>
					</p>
					<p>
						<label>
							<input type="radio" name="ame-heading-padding-type" value="custom"
							       data-bind="checked: settings.paddingType">
							自定义
						</label>
					</p>
				</fieldset>
				<fieldset class="ame-box-side-sizes" data-bind="enable: (settings.paddingType() === 'custom')">
					<label>
						<span class="ame-fixed-label-text">顶部:</span>
						<input type="number" min="0" max="300" data-bind="value: settings.paddingTop"> px
					</label>
					<label>
						<span class="ame-fixed-label-text">底部:</span>
						<input type="number" min="0" max="300" data-bind="value: settings.paddingBottom"> px
					</label>
					<div class="ame-flexbox-break"></div>
					<label>
						<span class="ame-fixed-label-text">左边:</span>
						<input type="number" min="0" max="300" data-bind="value: settings.paddingLeft"> px
					</label>
					<label>
						<span class="ame-fixed-label-text">右边:</span>
						<input type="number" min="0" max="300" data-bind="value: settings.paddingRight"> px
					</label>
				</fieldset>
			</div>

			<div class="ws_dialog_subpanel">
				<h3 class="ws-ame-dialog-subheading">可折叠标题</h3>
				<fieldset>
					<p>
						<label>
							<input type="checkbox" data-bind="checked: settings.collapsible">
							单击时隐藏标题下方的菜单项
						</label>
					</p>
				</fieldset>
			</div>
		</div>
	</div>

	<div class="ws_dialog_buttons">
		<input type="button" class="button-primary" value="OK" id="ws_save_menu_heading_settings"
		       data-bind="click: onConfirm.bind($root)">
		<input type="button" class="button ws_close_dialog" value="取消" data-bind="click: onCancel.bind($root)">
	</div>
</div>