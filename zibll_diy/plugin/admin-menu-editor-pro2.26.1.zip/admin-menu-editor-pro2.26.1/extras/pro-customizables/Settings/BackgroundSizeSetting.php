<?php

namespace YahnisElsts\AdminMenuEditor\ProCustomizable\Settings;

use YahnisElsts\AdminMenuEditor\ProCustomizable\Settings\CssEnumSetting;
use YahnisElsts\AdminMenuEditor\Customizable\Storage\StorageInterface;

class BackgroundSizeSetting extends CssEnumSetting {
	public function __construct($id, StorageInterface $store = null, $params = array()) {
		$enumValues = array('auto', 'cover', 'contain', '100% 100%');

		parent::__construct($id, $store, 'background-size', $enumValues, $params);

		$this->describeChoice(
			'auto',
			'原始大小'
		);
		$this->describeChoice(
			'contain',
			'适应',
			'缩放图像以适应区域，保持纵横比. '
			. '如果禁用图像重复，可能会导致图像周围出现空白.'
		);
		$this->describeChoice(
			'cover',
			'覆盖',
			'缩放图像以完全覆盖该区域，剪裁任何不合适的部分. '
			. '保持纵横比.'
		);
		$this->describeChoice(
			'100% 100%',
			'拉伸填充',
			'缩放图像以精确匹配区域的大小。不保持纵横比.'
		);
	}
}