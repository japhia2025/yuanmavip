<?php

namespace YahnisElsts\AdminMenuEditor\ProCustomizable\Settings;

class Padding extends SpacingSetting {
	protected $label = 'Padding';
	protected $cssPropertyPrefix = 'padding-';
}