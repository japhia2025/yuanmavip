<?php

namespace YahnisElsts\AdminMenuEditor\ProCustomizable\Settings;

class Margins extends SpacingSetting {
	protected $label = '边距';
	protected $cssPropertyPrefix = 'margin-';
	//TODO: What about "auto"?
}