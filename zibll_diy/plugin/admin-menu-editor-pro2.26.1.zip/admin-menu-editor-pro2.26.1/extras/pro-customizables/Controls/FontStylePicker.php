<?php

namespace YahnisElsts\AdminMenuEditor\ProCustomizable\Controls;

use YahnisElsts\AdminMenuEditor\Customizable\Controls\ClassicControl;
use YahnisElsts\AdminMenuEditor\Customizable\HtmlHelper;
use YahnisElsts\AdminMenuEditor\Customizable\Rendering\Renderer;
use YahnisElsts\AdminMenuEditor\Customizable\Settings\Setting;

class FontStylePicker extends ClassicControl {
	protected $koComponentName = 'ame-font-style-picker';

	public function renderContent(Renderer $renderer) {
		$options = [
			'font-style'      => [
				['value' => null, 'text' => '默认字体样式', 'label' => '&mdash;'],
				[
					'value' => 'italic',
					'text'  => '斜体',
					'label' => '<span class="dashicons dashicons-editor-italic"></span>',
				],
			],
			'text-transform'  => [
				['value' => null, 'text' => 'Default letter case', 'label' => '&mdash;'],
				[
					'value' => 'uppercase',
					'text'  => '大写',
					'label' => self::fontSample(['text-transform' => 'uppercase']),
				],
				[
					'value' => 'lowercase',
					'text'  => '小写',
					'label' => self::fontSample(['text-transform' => 'lowercase']),
				],
				[
					'value' => 'capitalize',
					'text'  => '将每个单词大写',
					'label' => self::fontSample(['text-transform' => 'capitalize']),
				],
			],
			'font-variant'    => [
				['value' => null, 'text' => '默认字体变体', 'label' => '&mdash;'],
				[
					'value' => 'small-caps',
					'text'  => '小型大写字母',
					'label' => self::fontSample(['font-variant' => 'small-caps']),
				],
			],
			'text-decoration' => [
				['value' => null, 'text' => '默认文字装饰', 'label' => '&mdash;'],
				[
					'value' => 'underline',
					'text'  => '下划线',
					'label' => '<span class="dashicons dashicons-editor-underline"></span>',
				],
				[
					'value' => 'line-through',
					'text'  => '删除线',
					'label' => '<span class="dashicons dashicons-editor-strikethrough"></span>',
				],
			],
		];

		echo HtmlHelper::tag('fieldset', [
			'class' => array_merge(['ame-font-style-control'], $this->classes),
			'style' => $this->styles,
		]);

		foreach ($options as $property => $choices) {
			if ( !isset($this->settings[$property]) ) {
				continue;
			}

			/** @var Setting $setting */
			$setting = $this->settings[$property];

			foreach ($choices as $choice) {
				$text = !empty($choice['text']) ? $choice['text'] : '';

				$dataBindings = [];

				$classes = ['ame-font-style-control-choice'];
				$inputClasses = [];

				if ( $choice['value'] === null ) {
					$classes[] = 'ame-font-style-null-choice';
					$inputClasses[] = 'ame-font-style-null-input';
					$dataBindings = [
						'ameObservableChangeEvents' => $this->getKoObservableExpression(null, $setting),
					];
				}

				echo HtmlHelper::tag('label', [
					'class' => $classes,
					'title' => $text,
				]);

				//Use a checkbox instead of a radio button because we want a second
				//click on the same option to deselect it.
				echo HtmlHelper::tag(
					'input',
					[
						'type'                   => 'checkbox',
						'name'                   => $this->getFieldName(null, $setting),
						'value'                  => (string)$choice['value'],
						'checked'                => ($choice['value'] === $setting->getValue()),
						'class'                  => $inputClasses,
						'data-ac-setting-id'     => $setting->getId(),
						'data-ame-on-value'      => wp_json_encode($choice['value']),
						'data-ame-off-value'     => wp_json_encode(null),
						'data-ame-font-property' => $property,
						'data-bind'              => $this->makeKoDataBind($dataBindings),
					]
				);

				if ( !empty($text) ) {
					echo HtmlHelper::tag('span', ['class' => 'screen-reader-text'], esc_html($text));
				}

				echo HtmlHelper::tag(
					'span',
					[
						'class' => ['button', 'button-secondary', 'ame-font-style-control-choice-label'],
					],
					$choice['label']
				);

				echo '</label>';
			}
		}

		echo '</fieldset>';

		static::enqueueDependencies();
	}

	protected static function fontSample($styles) {
		return HtmlHelper::tag(
			'span',
			['class' => 'ame-font-sample', 'style' => $styles],
			'ab' //Match Gutenberg's letter case icons in WP 6.0.
		);
	}
}