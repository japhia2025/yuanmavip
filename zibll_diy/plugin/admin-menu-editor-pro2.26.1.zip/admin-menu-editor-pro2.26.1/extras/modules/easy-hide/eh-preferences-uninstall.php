<?php

//This uninstallation code was automatically generated.
//Do not edit this code directly.
///*{WS_PCGN_GENERATED_FILE}*/
if (defined('ABSPATH') && function_exists('delete_metadata')) {
    delete_metadata('user', 0, 'ws_ame_eh_hide_info', '', true);
    delete_metadata('user', 0, 'ws_ame_eh_prefs', '', true);
}