<div id="ws_visible_users_dialog" title="选择可见用户" class="hidden">

	<div id="ws_user_selection_panels">

		<div id="ws_user_selection_source_panel" class="ws_user_selection_panel">
			<label for="ws_available_user_query" class="hidden">搜索用户</label>
			<input type="text" name="ws_available_user_query" id="ws_available_user_query"
			       placeholder="搜索并按Enter键添加用户">

			<div class="ws_user_list_wrapper">
				<table id="ws_available_users" class="widefat striped ws_user_selection_list" title="添加用户"></table>
			</div>

			<div id="ws_loading_users_indicator" class="spinner"></div>
		</div>

		<div id="ws_user_selection_target_panel" class="ws_user_selection_panel">
			<div id="ws_selected_users_caption">选定用户</div>

			<div class="ws_user_list_wrapper" title="">
				<table id="ws_selected_users" class="widefat ws_user_selection_list"></table>
			</div>
		</div>

	</div>

	<div class="ws_dialog_buttons">
		<?php submit_button('保存更改', 'primary', 'ws_ame_save_visible_users', false); ?>
		<input type="button" class="button ws_close_dialog" value="取消">
	</div>

</div>