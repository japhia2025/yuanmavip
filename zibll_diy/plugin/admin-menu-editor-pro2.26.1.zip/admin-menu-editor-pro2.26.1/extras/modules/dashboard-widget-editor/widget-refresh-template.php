<p>
	刷新可用小部件...
	<span class="spinner is-active" style="float: none; vertical-align: bottom;"></span>
</p>

<p>
	<?php
	$dashboardUrl = add_query_arg('ame-cache-buster', time(), admin_url('index.php'));
	?>
	完成后，您将被重定向到小部件设置。如果这在几分钟内没有发生,
	请前往 <a href="<?php echo esc_attr($dashboardUrl); ?>"> 仪表板 -&gt; Home</a> 然后返回
	到此页面.
</p>