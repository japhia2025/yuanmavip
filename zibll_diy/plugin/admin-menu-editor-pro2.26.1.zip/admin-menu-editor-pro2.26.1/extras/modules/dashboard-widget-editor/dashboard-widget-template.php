<template id="ame-dashboard-widget-template">
	这是仪表板小部件模板。
</template>
