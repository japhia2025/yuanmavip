<?php
require_once __DIR__ . '/../../../includes/reflection-callable.php';

require_once 'ameRoleEditor.php';
require_once 'ameRexCapability.php';
require_once 'ameRexCategory.php';
require_once 'ameRexComponent.php';
require_once 'ameRexSettingsValidator.php';

require_once 'ameRexComponentRegistry.php';
require_once 'ameRexCapabilitySearchResultSet.php';
require_once 'ameRexCapabilityDataSource.php';
require_once 'ameRexCapabilityInfoSearch.php';