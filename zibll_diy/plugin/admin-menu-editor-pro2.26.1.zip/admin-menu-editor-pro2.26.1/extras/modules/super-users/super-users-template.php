<?php
/**
 * Variables set by ameModule when it outputs a template.
 *
 * @var string $moduleTabUrl
 * @see ameModule::getTabUrl
 */
?>
<div id="ame-super-user-settings">
	<h3>
		隐藏用户
		<a class="page-title-action" href="#"
		   data-bind="click: $root.selectHiddenUsers.bind($root), text: addButtonText">添加用户</a>
	</h3>

	<table class="wp-list-table widefat fixed striped">
		<thead>
		<tr>
			<th scope="col">用户名</th>
			<th scope="col">名称</th>
			<th scope="col">角色</th>
			<th class="ame-column-user-id num" scope="col">ID</th>
		</tr>
		</thead>

		<!-- ko if: (superUsers().length > 0) -->
		<tbody data-bind="foreach: superUsers">
		<tr>
			<td class="column-username">
				<span data-bind="html: avatarHTML"></span>
				<strong><a data-bind="text: userLogin, attr: {href: $root.getEditLink($data)}"></a></strong>

				<div class="row-actions">
					<span><a href="#" data-bind="click: $root.removeUser.bind($root, $data)">Remove</a></span>
				</div>
			</td>
			<td data-bind="text: displayName"></td>
			<td data-bind="text: $root.formatUserRoles($data)"></td>
			<td data-bind="text: userId" class="num"></td>
		</tr>
		</tbody>
		<!-- /ko -->

		<!-- ko if: (superUsers().length <= 0) -->
		<tbody>
		<tr>
			<td colspan="4">
				未选择用户。点击 "<span data-bind="text: addButtonText"></span>" 隐藏一个或多个用户.
			</td>
		</tr>
		</tbody>
		<!-- /ko -->

		<tfoot>
		<tr>
			<th>用户名</th>
			<th>名称</th>
			<th>角色</th>
			<th class="ame-column-user-id num">ID</th>
		</tr>
		</tfoot>
	</table>

	<form action="<?php echo esc_attr(add_query_arg('noheader', 1, $moduleTabUrl)); ?>" method="post">
		<input type="hidden" name="settings" value="" data-bind="value: settingsData">
		<input type="hidden" name="action" value="ame_save_super_users">
		<?php
		wp_nonce_field('ame_save_super_users');
		submit_button('保存更改', 'primary', 'submit', true);
		?>
	</form>

	<div class="metabox-holder">
	<div class="postbox ws_ame_doc_box" data-bind="css: {closed: !isInfoBoxOpen()}">
		<button type="button" class="handlediv button-link" data-bind="click: toggleInfoBox.bind($root)">
			<span class="toggle-indicator"></span>
		</button>
		<h2 class="hndle" data-bind="click: toggleInfoBox.bind($root)">它是如何工作的</h2>
		<div class="inside">
			<ul>
				<li>隐藏用户不会出现
					在 <a href="<?php echo esc_attr(self_admin_url('users.php')); ?>">用户 &rightarrow; 所有用户</a>
					页面.
				</li>
				<li>普通用户无法编辑或删除它们.</li>
				<li>然而，它们仍然出现在其他地方，比如“帖子”页面上的“作者”栏，以及
					他们的帖子和评论没有受到特别保护.
				</li>
				<li>隐藏用户可以看到其他隐藏用户.
					<ul>
						<li>因此，如果你隐藏自己的用户帐户，你仍然会在“所有用户”下看到它
							除非您切换到其他用户.</li>
					</ul>
				</li>
			</ul>

		</div>
	</div>
	</div>

</div>