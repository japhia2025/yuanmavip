<?php
$result = [
	'sections' => [
		'profile'           => ['label' => '隐藏个人资料字段', 'priority' => 80],
		'sidebar-widgets'   => ['label' => '隐藏侧边栏小工具', 'priority' => 100],
		'sidebars'          => ['label' => '隐藏侧边栏', 'priority' => 120],
		'gutenberg-general' => ['label' => '古腾堡（区块编辑器）', 'priority' => 25],
		'environment-type'  => ['label' => '环境类型', 'priority' => 30],
	],

	'tweaks' => [
		'hide-screen-meta-links' => [
			'label'            => '隐藏屏幕元链接',
			'selector'         => '#屏幕元链接',
			'hideableLabel'    => '屏幕元链接',
			'hideableCategory' => '管理界面',
		],
		'hide-screen-options'    => [
			'label'            => '隐藏“屏幕选项”按钮',
			'selector'         => '#屏幕选项-链接包装',
			'parent'           => '隐藏屏幕元链接',
			'hideableLabel'    => '“屏幕选项”按钮',
			'hideableCategory' => 'admin-ui',
		],
		'hide-help-panel'        => [
			'label'            => '隐藏“帮助”按钮',
			'selector'         => '#上下文帮助链接包装',
			'parent'           => '隐藏屏幕元链接',
			'hideableLabel'    => '“帮助”按钮',
			'hideableCategory' => '管理界面',
		],
		'hide-all-admin-notices' => [
			'label'            => '隐藏所有管理员通知',
			'selector'         => '#wpbody-content .notice, #wpbody-content .updated, #wpbody-content .update-nag',
			'hideableLabel'    => '所有管理员通知',
			'hideableCategory' => '管理界面',
		],

		'hide-gutenberg-options'    => [
			'label'         => '隐藏古腾堡选项菜单（三个垂直点）',
			'selector'      => '#editor .edit-post-header__settings .edit-post-more-menu,'
				. ' #editor .edit-post-header__settings .interface-more-menu-dropdown',
			'section'       => 'gutenberg-general',
			'hideableLabel' => '古腾堡选项菜单',
		],
		'hide-gutenberg-fs-wp-logo' => [
			'label'         => '在古腾堡全屏模式下隐藏WordPress徽标',
			'selector'      => '#editor .edit-post-header a.components-button[href^="edit.php"]',
			'section'       => 'gutenberg-general',
			'hideableLabel' => '古腾堡全屏模式下的WordPress徽标',
		],

		'show-environment-in-toolbar'  => [
			'label'       => '在工具栏中显示环境类型',
			'section'     => 'environment-type',
			'className'   => 'ameEnvironmentNameTweak',
			'includeFile' => __DIR__ . '/ameEnvironmentNameTweak.php',
		],
		'environment-dependent-colors' => [
			'label'       => '根据环境更改菜单颜色',
			'section'     => 'environment-type',
			'className'   => 'ameEnvironmentColorTweak',
			'includeFile' => __DIR__ . '/ameEnvironmentColorTweak.php',
		],

		'hide-inserter-media-tab' => [
			'label'         => '隐藏块插入器中的“媒体”选项卡',
			'selector'      => '#editor #tab-panel-0-media',
			'section'       => 'gutenberg-general',
			'hideableLabel' => '块插入器中的“媒体”选项卡',
		],

		'hide-block-patterns'        => [
			'label'         => '隐藏块模式',
			'isGroup'       => true,
			'section'       => 'gutenberg-general',
			'hideableLabel' => '块模式',
		],
		'hide-patterns-tab-with-css' => [
			'label'         => '在块插入器中隐藏“模式”选项卡',
			'selector'      => '#editor #tab-panel-0-patterns',
			'parent'        => 'hide-block-patterns',
			'section'       => 'gutenberg-general',
			'hideableLabel' => '块插入器中的“模式”选项卡',
		],
		'disable-remote-patterns'    => [
			'label'       => '禁用远程模式',
			'className'   => ameDisableRemotePatternsTweak::class,
			'includeFile' => __DIR__ . '/ameDisableRemotePatternsTweak.php',
			'parent'      => 'hide-block-patterns',
			'section'     => 'gutenberg-general',
		],
		'unregister-all-patterns'    => [
			'label'       => '注销所有可见图案（注意：也会影响“外观→编辑器”）',
			'className'   => ameUnregisterPatternsTweak::class,
			'includeFile' => __DIR__ . '/ameUnregisterPatternsTweak.php',
			'parent'      => 'hide-block-patterns',
			'section'     => 'gutenberg-general',
		],
	],
];

//region Profile tweaks
$profileScreens = ['profile', 'user-edit'];
$profileSection = 'profile';
$profileTweaks = [
	'hide-profile-group-personal-info'   => [
		'label'   => '个人信息',
		'isGroup' => true,
	],
	'hide-profile-visual-editor'         => [
		'label'    => '可视化编辑器',
		'selector' => 'tr.user-rich-editing-wrap',
		'parent'   => 'hide-profile-group-personal-info',
	],
	'hide-profile-syntax-highlighting'   => [
		'label'    => '语法高亮显示',
		'selector' => 'tr.user-syntax-highlighting-wrap',
		'parent'   => 'hide-profile-group-personal-info',
	],
	'hide-profile-color-scheme-selector' => [
		'label'    => '管理员配色方案',
		'selector' => 'tr.user-admin-color-wrap',
		'parent'   => 'hide-profile-group-personal-info',
	],
	'hide-profile-keyboard-shortcuts'    => [
		'label'    => '键盘快捷键',
		'selector' => 'tr.user-comment-shortcuts-wrap',
		'parent'   => 'hide-profile-group-personal-info',
	],
	'hide-profile-toolbar-toggle'        => [
		'label'    => '工具栏',
		'selector' => 'tr.show-admin-bar.user-admin-bar-front-wrap',
		'parent'   => 'hide-profile-group-personal-info',
	],

	'hide-profile-group-name'   => [
		'label'     => '名字',
		'jquery-js' => 'jQuery("#profile-page tr.user-user-login-wrap").closest("table").prev("h2").addBack().hide();',
	],
	'hide-profile-user-login'   => [
		'label'    => '用户名',
		'selector' => 'tr.user-user-login-wrap',
		'parent'   => 'hide-profile-group-name',
	],
	'hide-profile-first-name'   => [
		'label'    => '名称',
		'selector' => 'tr.user-first-name-wrap',
		'parent'   => 'hide-profile-group-name',
	],
	'hide-profile-last-name'    => [
		'label'    => '姓',
		'selector' => 'tr.user-last-name-wrap',
		'parent'   => 'hide-profile-group-name',
	],
	'hide-profile-nickname'     => [
		'label'    => '昵称',
		'selector' => 'tr.user-nickname-wrap',
		'parent'   => 'hide-profile-group-name',
	],
	'hide-profile-display-name' => [
		'label'    => '显示名称',
		'selector' => 'tr.user-display-name-wrap',
		'parent'   => 'hide-profile-group-name',
	],

	'hide-profile-group-contact-info' => [
		'label'     => '联系方式',
		'jquery-js' => 'jQuery("#profile-page tr.user-email-wrap").closest("table").prev("h2").addBack().hide();',
	],
	'hide-profile-email'              => [
		'label'    => '电子邮件',
		'selector' => 'tr.user-email-wrap',
		'parent'   => 'hide-profile-group-contact-info',
	],
	'hide-profile-url'                => [
		'label'    => '网站',
		'selector' => 'tr.user-url-wrap',
		'parent'   => 'hide-profile-group-contact-info',
	],
];

//Find user contact methods and add them to the list of hideable profile fields.
if ( is_callable('wp_get_user_contact_methods') ) {
	$contactMethods = wp_get_user_contact_methods();
	foreach ($contactMethods as $contactMethodId => $contactMethod) {
		$profileTweaks['hide-profile-cm-' . $contactMethodId] = [
			'label'    => $contactMethod,
			'selector' => 'tr.user-' . $contactMethodId . '-wrap',
			'parent'   => 'hide-profile-group-contact-info',
		];
	}
}

//"About Yourself" section.
$profileTweaks = array_merge($profileTweaks, [
	'hide-profile-group-about-yourself' => [
		'label'     => '关于你自己',
		'jquery-js' => 'jQuery("#profile-page tr.user-description-wrap").closest("table").prev("h2").addBack().hide();',
	],

	'hide-profile-user-description' => [
		'label'    => '简历信息',
		'selector' => 'tr.user-description-wrap',
		'parent'   => 'hide-profile-group-about-yourself',
	],

	'hide-profile-picture' => [
		'label'    => '个人资料图片',
		'selector' => 'tr.user-profile-picture',
		'parent'   => 'hide-profile-group-about-yourself',
	],
]);

foreach ($profileTweaks as $tweakId => $tweak) {
	$tweak['section'] = $profileSection;
	$tweak['screens'] = $profileScreens;
	$result['tweaks'][$tweakId] = $tweak;
}
//endregion

return $result;