<?php

class ameTinyMceButtonManager {
	const DETECTED_BUTTON_OPTION = 'ws_ame_detected_tmce_buttons';
	const SECTION_ID = 'tmce-buttons';

	private $detectionEnabled = false;
	private $storageHookSet = false;

	private $newDetectedButtons = array();
	private $cachedKnownButtons = null;

	private $hiddenButtons = array();

	private $builtInButtons = array(
		'kitchensink'    => array('title' => '更多按钮'),
		'wp_add_media'   => array('title' => '添加媒体'),
		'formatselect'   => array('title' => '格式下拉菜单'),
		'alignleft'      => array('title' => '左对齐'),
		'aligncenter'    => array('title' => '居中对齐'),
		'alignright'     => array('title' => '右对齐'),
		'alignjustify'   => array('title' => '证明合法'),
		'alignnone'      => array('title' => '无对齐'),
		'bold'           => array('title' => '粗体'),
		'italic'         => array('title' => '斜体'),
		'underline'      => array('title' => '强调'),
		'strikethrough'  => array('title' => '删除线'),
		'subscript'      => array('title' => '下标'),
		'superscript'    => array('title' => '上标'),
		'outdent'        => array('title' => '减少缩进'),
		'indent'         => array('title' => '增加缩进'),
		'cut'            => array('title' => '剪切'),
		'copy'           => array('title' => '复制'),
		'paste'          => array('title' => '粘贴'),
		'help'           => array('title' => '帮助'),
		'selectall'      => array('title' => '全选'),
		'visualaid'      => array('title' => '视觉辅助'),
		'newdocument'    => array('title' => '新建文档'),
		'removeformat'   => array('title' => '清除格式'),
		'remove'         => array('title' => '消除'),
		'blockquote'     => array('title' => '引用'),
		'undo'           => array('title' => '撤消'),
		'redo'           => array('title' => '重做'),
		'fontsizeselect' => array('title' => '字体大小'),
		'fontselect'     => array('title' => '字体系列'),
		'styleselect'    => array('title' => '样式下拉菜单'),
		'insert'         => array('title' => '插入菜单'),
		'charmap'        => array('title' => '特殊字符'),
		'hr'             => array('title' => '水平线'),
		'numlist'        => array('title' => '编号列表'),
		'bullist'        => array('title' => '项目符号列表'),
		'media'          => array('title' => '插入/编辑媒体'),
		'pastetext'      => array('title' => '粘贴为文本'),
		'forecolor'      => array('title' => '文本颜色'),
		'backcolor'      => array('title' => '背景颜色'),
		'wp_adv'         => array('title' => '工具栏切换'),
		'wp_more'        => array('title' => '插入“阅读更多”标签'),
		'wp_page'        => array('title' => '分页符'),
		'wp_help'        => array('title' => '键盘快捷键'),
		'wp_code'        => array('title' => '代码'),
		'link'           => array('title' => '插入/编辑链接'),
		'unlink'         => array('title' => '删除链接'),
		'spellchecker'   => array('title' => '切换拼写检查器'),
	);

	public function __construct() {
		add_action('admin_init', array($this, 'toggleButtonDetection'));

		$buttonFilters = array('mce_buttons', 'mce_buttons_2', 'mce_buttons_3', 'mce_buttons_4');
		foreach ($buttonFilters as $filter) {
			add_filter($filter, array($this, 'filterButtons'), 9000, 1);
		}

		add_action('admin-menu-editor-register_tweaks', array($this, 'registerButtonTweaks'), 10, 1);
	}

	public function toggleButtonDetection() {
		$this->detectionEnabled = current_user_can('activate_plugins') || current_user_can('edit_others_pages');
	}

	public function filterButtons($buttons) {
		//Sanity check: $buttons should be an array or something array-like.
		if ( !is_array($buttons) && !($buttons instanceof ArrayAccess) ) {
			return $buttons;
		}

		if ( $this->detectionEnabled ) {
			$this->detectNewButtons($buttons);
		}
		$buttons = $this->removeHiddenButtons($buttons);
		return $buttons;
	}

	private function detectNewButtons($buttons) {
		$newButtons = array_diff($buttons, $this->getKnownButtonIds());
		if ( !empty($newButtons) ) {
			$this->newDetectedButtons = array_merge($this->newDetectedButtons, $newButtons);
			if ( !$this->storageHookSet ) {
				add_action('shutdown', array($this, 'storeNewButtons'));
				$this->storageHookSet = true;
			}
		}
	}

	public function storeNewButtons() {
		$newButtons = array_fill_keys($this->newDetectedButtons, time());
		$buttons = array_merge($this->getDetectedButtons(), $newButtons);

		//Filter out built-in buttons. We already know they exist, so there's no need
		//to store them in the database.
		$buttons = array_diff_key($buttons, $this->getBuiltInButtons());
		$this->saveDetectedButtons($buttons);

		$this->newDetectedButtons = array();
	}

	private function saveDetectedButtons($buttons) {
		$this->cachedKnownButtons = null;

		$handle = null;
		if ( function_exists('flock') ) {
			$handle = @fopen(__FILE__, 'r');
			if ( !$handle ) {
				return;
			}
			$success = @flock($handle, LOCK_EX | LOCK_NB);
			if ( !$success ) {
				fclose($handle);
				return;
			}
		}

		if ( is_multisite() ) {
			update_site_option(self::DETECTED_BUTTON_OPTION, $buttons);
		} else {
			update_option(self::DETECTED_BUTTON_OPTION, $buttons, 'yes');
		}

		if ( $handle !== null ) {
			@flock($handle, LOCK_UN);
			fclose($handle);
		}
	}

	/**
	 * @param string[] $buttons
	 * @return string[]
	 */
	private function removeHiddenButtons($buttons) {
		if ( empty($this->hiddenButtons) ) {
			return $buttons;
		}
		return array_diff($buttons, $this->hiddenButtons);
	}

	private function getKnownButtons() {
		if ( $this->cachedKnownButtons === null ) {
			$this->cachedKnownButtons = array_merge($this->getDetectedButtons(), $this->getBuiltInButtons());
		}
		return $this->cachedKnownButtons;
	}

	/**
	 * @return string[]
	 */
	private function getKnownButtonIds() {
		return array_keys($this->getKnownButtons());
	}

	/**
	 * @return array
	 */
	private function getDetectedButtons() {
		if ( is_multisite() ) {
			$buttons = get_site_option(self::DETECTED_BUTTON_OPTION, array());
		} else {
			$buttons = get_option(self::DETECTED_BUTTON_OPTION, array());
		}
		if ( !is_array($buttons) ) {
			return array();
		}
		return $buttons;
	}

	private function getBuiltInButtons() {
		return $this->builtInButtons;
	}

	/**
	 * @param ameTweakManager $tweakManager
	 */
	public function registerButtonTweaks($tweakManager) {
		$tweakManager->addSection(self::SECTION_ID, 'Hide TinyMCE Buttons', 150);
		$theCallback = array($this, 'flagButtonAsHidden');

		$buttons = $this->getKnownButtons();
		$buttonTweaks = array();
		foreach ($buttons as $id => $details) {
			$label = $id;
			if ( isset($details['title']) ) {
				$label = sprintf('%s (%s)', $details['title'], $id);
			}

			$tweak = new ameDelegatedTweak('hide-tmce-' . $id, $label, $theCallback, array($id));
			$tweak->setSectionId(self::SECTION_ID);
			$buttonTweaks[] = $tweak;
		}

		//Sort tweaks by label.
		uasort(
			$buttonTweaks,
			/**
			 * @param ameBaseTweak $a
			 * @param ameBaseTweak $b
			 * @return int
			 */
			function ($a, $b) {
				return strnatcasecmp($a->getLabel(), $b->getLabel());
			}
		);

		foreach ($buttonTweaks as $tweak) {
			$tweakManager->addTweak($tweak);
		}
	}

	/** @noinspection PhpUnused Actually used in registerButtonTweaks(). */
	public function flagButtonAsHidden($buttonId) {
		$this->hiddenButtons[] = $buttonId;
	}
}