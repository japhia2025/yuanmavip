# Notes to self about system requirements

### IE11 does not need to be supported
WordPress 5.8 dropped support for IE11: 
https://wordpress.org/news/2021/05/dropping-support-for-internet-explorer-11/

### PHP 5.6.20
WordPress 6.2 still supports PHP 5.6.20 even though it recommends PHP 7.4+.
