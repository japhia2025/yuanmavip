<?php
/**
 * @var string $tabUrl Fully qualified URL of the "Plugins" tab.
 */
?>

<div id="ame-plugin-visibility-editor">
		<form method="post" data-bind="submit: saveChanges" class="ame-pv-save-form" action="<?php
		echo esc_url(add_query_arg(array('noheader' => '1'), $tabUrl));
		?>">

			<?php submit_button('保存更改', 'primary', 'submit', false); ?>

			<input type="hidden" name="action" value="save_plugin_visibility">
			<?php wp_nonce_field('save_plugin_visibility'); ?>

			<input type="hidden" name="settings" value="" data-bind="value: settingsData">
			<input type="hidden" name="selected_actor" value="" data-bind="value: selectedActor">
		</form>

		<?php require AME_ROOT_DIR . '/modules/actor-selector/actor-selector-template.php'; ?>

		<table class="widefat plugins">
			<thead>
				<tr>
					<th scope="col" class="ame-check-column">
						<!--suppress HtmlFormInputWithoutLabel -->
						<input type="checkbox" data-bind="checked: areAllPluginsChecked">
					</th>
					<th scope="col">插件</th>
					<th scope="col">描述</th>
				</tr>
			</thead>

			<tbody data-bind="foreach: plugins">
			<tr
				data-bind="
				css: {
					'active': isActive,
					'inactive': !isActive
				},
				visible: !isBeingEdited()
			">

				<!--
				Alas, we can't use the "check-column" class for this checkbox because WP would apply
				the default "check all boxes" behaviour and override our Knockout bindings.
				-->
				<th scope="row" class="ame-check-column">
					<!--suppress HtmlFormInputWithoutLabel -->
					<input
						type="checkbox"
						data-bind="
						checked: isChecked,
						attr: {
							id: 'ame-plugin-visible-' + $index(),
							'data-plugin-file': fileName
						}">
				</th>

				<td class="plugin-title">
					<label data-bind="attr: { 'for': 'ame-plugin-visible-' + $index() }">
						<strong data-bind="text: name"></strong>
					</label>
					<div class="row-actions">
						<span class="edit">
							<a href="#" title="Edit plugin name and description. This is a cosmetic change - the actual plugin files are not affected."
							   data-bind="click: openInlineEditor.bind($data)">编辑</a>
						</span>
					</div>
				</td>

				<td><p data-bind="text: description"></p></td>
			</tr>
			<tr class="inline-edit-row" data-bind="if: isBeingEdited, visible: true"
			    style="display: none;">
				<td class="colspanchange" colspan="3">
					<div class="inline-edit-wrapper">
						<fieldset class="ame-pv-inline-edit-left">
							<legend class="inline-edit-legend" data-bind="text: defaultProperties['name']">
								编辑插件属性
							</legend>
							<div class="inline-edit-col">
								<label>
									<span class="title">名称</span>
									<span class="input-text-wrap">
									<input type="text" data-bind="value: editableProperties['name']"
									       class="ame-pv-custom-name">
								</span>
								</label>
								<label>
									<span class="title">作者</span>
									<span class="input-text-wrap">
									<input type="text" data-bind="value: editableProperties['author']"
									       class="ame-pv-custom-author">
								</span>
								</label>
								<label>
									<span class="title">网站URL</span>
									<span class="input-text-wrap">
									<input type="text" data-bind="value: editableProperties['siteUrl']"
									       class="ame-pv-custom-site-url">
								</span>
								</label>
								<label>
									<span class="title">版本</span>
									<span class="input-text-wrap">
									<input type="text" data-bind="value: editableProperties['version']"
									       class="ame-pv-custom-version-number">
								</span>
								</label>
							</div>
						</fieldset>
						<fieldset class="ame-pv-inline-edit-right">
							<div class="inline-edit-col">
								<label>
									<span class="title">描述</span>
									<textarea name="plugin-description" cols="30" rows="5"
									          class="ame-pv-custom-description"
									          data-bind="value: editableProperties['description']"></textarea>
								</label>
							</div>
						</fieldset>

						<p class="submit">
							<?php
							submit_button(
								'更新',
								'primary save',
								'pv-update',
								false,
								array(
									'data-bind' => 'click: confirmEdit.bind($data)',
								)
							);
							?>

							<?php
							submit_button(
								'取消',
								'secondary cancel',
								'pv-cancel',
								false,
								array(
									'data-bind' => 'click: cancelEdit.bind($data)',
								)
							);
							?>

							<a class="ame-pv-inline-reset" href="#"
							   title="Reset name and description to default values"
							   data-bind="click: resetNameAndDescription.bind($data)">重置为默认值</a>

							<br class="clear">
						</p></div>
				</td>
			</tr>
			</tbody>

			<tfoot>
				<tr class="inactive ame-pv-new-plugin-visibility-row">
					<th scope="row" class="ame-check-column">
						<input
							type="checkbox"
							data-bind="checked: areNewPluginsVisible"
							id="ame-pv-new-plugin-visibility">
					</th>
					<td class="plugin-title">
						<label for="ame-pv-new-plugin-visibility">
							<strong>[新插件]</strong>
						</label>
					</td>
					<td>
						<p>
							此设置控制所选角色是否能够
							查看新安装的插件.
						</p>
						<ul>
							<li>选中：默认情况下，新插件将可见.</li>
							<li>未选中：新插件将自动隐藏.</li>
						</ul>
					</td>
				</tr>

				<tr>
					<th scope="col" class="ame-check-column">
						<!--suppress HtmlFormInputWithoutLabel -->
						<input type="checkbox" data-bind="checked: areAllPluginsChecked">
					</th>
					<th scope="col">插件</th>
					<th scope="col">描述</th>
				</tr>
			</tfoot>

		</table>

	</div> <!-- /module container -->
