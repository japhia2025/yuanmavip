<?php
/**
 * @var string $moduleTabUrl
 */

$dragIconUrl = plugins_url('drag-indicator.svg', __FILE__);

if ( defined('AME_DISABLE_REDIRECTS') && constant('AME_DISABLE_REDIRECTS') ) {
	?>
	<div class="notice notice-warning">
		<p>
			自定义重定向当前已禁用，因为 <code>AME_DISABLE_REDIRECTS</code> 设置为
			<code>true</code>.
		</p>
	</div>
	<?php
}
?>
<div id="ame-redirector-ui-root" data-bind="visible: isLoaded" style="display: none">
	<!-- A second level of tabs, uh oh! -->
	<ul data-bind="foreach: availableTriggers" role="tablist" class="ame-rui-trigger-selector ame-rui-sub-tabs">
		<li class="ame-rui-tab" data-bind="css: { 'ame-rui-active-tab': ($data.trigger === $root.selectedTrigger()) }">
			<a data-bind="
				text: label,
				click: $root.selectedTrigger.bind($root.selectedTrigger, $data.trigger),
				attr: {'data-text': label}"
			   class="ame-rui-tab-label"
			   role="tab"></a>
		</li>
	</ul>

	<div id="ame-rui-column-container">
		<div id="ame-rui-main-section">

			<!-- ko if: (selectedTrigger() === 'registration') -->
			<p>
				注册重定向在有人注册新帐户后立即发生
				但在他们第一次登录之前。默认情况下，用户被重定向到
				“查看电子邮件”页面.
			</p>
			<!-- /ko -->

			<!-- ko if: currentTriggerView().supportsUserSettings -->
			<h3>用户</h3>
			<div data-bind="
		template: {name: 'ame-redirect-list-template', data: {items: currentTriggerView().users}},
		visible: currentTriggerView().users().length > 0"></div>

			<!-- ko if: (userSelectionUi === 'dropdown') -->

			<p>
				<!-- ko if: (addableUsers().length > 0) -->
				<label for="ame-rui-add-user" class="screen-reader-text">添加用户</label>
				<select id="ame-rui-add-user" class="ame-rui-add-actor-dropdown"
				        data-bind="options: addableUsers,
		         optionsText: 'userLogin',
		         value: selectedUserToAdd,
		         optionsCaption: '添加用户',
		         hasFocus: userSelectorHasFocus"></select>
				<!-- /ko -->
				<!-- ko if: (addableUsers().length <= 0) -->
				<span class="description">此列表包括所有用户.</span>
				<!-- /ko -->
			</p>
			<!-- /ko -->
			<!-- ko if: (userSelectionUi === 'search') -->
			<form method="post" data-bind="submit: addEnteredUserLogin.bind($root)">
				<p>
					<label for="ame-rui-user-search-query" class="screen-reader-text">搜索用户</label>
					<input type="text" id="ame-rui-user-search-query" placeholder="Enter a username"
					       data-bind="
			        textInput: userLoginQuery,
			        ameRuiUserAutocomplete: { filter: filterUserAutocompleteResults.bind($root) }">
					<input type="button" class="button" id="ame-rui-add-user" value="添加用户"
					       data-bind="enable: addUserButtonEnabled, click: addEnteredUserLogin.bind($root)">
				</p>
			</form>
			<!-- /ko -->
			<!-- /ko -->

			<!-- ko if: currentTriggerView().supportsRoleSettings -->
			<h3>角色</h3>
			<div data-bind="
		template: {name: 'ame-redirect-list-template', data: {items: currentTriggerView().roles}},
		visible: currentTriggerView().roles().length > 0"></div>

			<p>
				<!-- ko if: (addableRoles().length > 0) -->
				<label for="ame-rui-add-role" style="display: none;">添加角色</label>
				<select id="ame-rui-add-role" class="ame-rui-add-actor-dropdown"
				        data-bind="options: addableRoles,
		         optionsText: 'displayName',
		         value: selectedRoleToAdd,
		         optionsCaption: '添加角色',
		         hasFocus: roleSelectorHasFocus"></select>
				<!-- /ko -->
				<!-- ko if: (addableRoles().length <= 0) -->
				<span class="description">此列表包括所有角色.</span>
				<!-- /ko -->
			</p>
			<!-- /ko -->

			<!-- ko if: currentTriggerView().supportsActorSettings -->
			<h3>默认</h3>
			<p>
				默认设置将应用于不符合上述任何规则的用户。离开现场
				空，让WordPress或其他插件选择重定向.
			</p>
			<!-- /ko -->
			<!-- ko ifnot: currentTriggerView().supportsActorSettings -->
			<h3>所有用户</h3>
			<!-- /ko -->
			<div data-bind="using: currentTriggerView().defaultRedirect" class="ame-rui-default-redirect-container">
				<div class="ame-rui-redirect">
					<div class="ame-rui-redirect-content">
						<ame-redirect-url-input params="redirect: $data, menuItems: $root.menuItems"
						                        class="ame-rui-url-template"></ame-redirect-url-input>

						<label class="ame-rui-shortcodes-enabled" title="处理重定向URL中的短代码">
							<input type="checkbox" data-bind="checked: shortcodesEnabled, enable: canToggleShortcodes">
							<span class="dashicons dashicons-shortcode"></span>
							<span class="ame-rui-button-label">启用短代码</span>
						</label>
					</div>
				</div>
			</div>

		</div>
		<div id="ame-rui-sidebar">
			<div id="ame-rui-main-actions">

			</div>
		</div>
	</div>

	<form class="ame-rui-save-form" method="post" data-bind="submit: saveChanges" action="<?php
	echo esc_url(add_query_arg(array('noheader' => '1'), $moduleTabUrl));
	?>">
		<?php
		submit_button(
			null, 'primary', 'submit', true,
			[
				'data-bind' => 'disable: isSaving',
				'disabled'  => 'disabled',
			]
		);
		?>
		<input type="hidden" name="settings" value="" data-bind="value: settingsData">
		<input type="hidden" name="action" value="ame-save-redirect-settings">
		<?php wp_nonce_field('ame-save-redirect-settings'); ?>
		<input type="hidden" name="selectedTrigger" data-bind="value: selectedTrigger">
	</form>

	<label for="ame-rui-menu-items" style="display: none">管理菜单项</label>
	<select name="ame-rui-menu-items" id="ame-rui-menu-items" size="10" style="display: none;"
	        data-bind="options: menuDropdownOptions, optionsText: 'title', value: selectedMenuDropdownItem">
	</select>
</div>

<div style="display: none;">
	<template id="ame-redirect-list-template">
		<div data-bind="sortable: {
			data: $data.items,
			allowDrop: false,
			options: {
				handle: '.ame-rui-drag-handle'
			}}"
		     class="ame-rui-redirect-list">
			<div class="ame-rui-redirect">
				<div class="ame-rui-drag-handle">
					<img src="<?php echo esc_url($dragIconUrl); ?>" alt="Drag indicator" width="24">
				</div>
				<div class="ame-rui-redirect-content">
					<div class="ame-rui-actor">
						<label data-bind="text: displayName(), attr: {'for': inputElementId}"></label>
						<span class="ame-rui-missing-actor-indicator"
						      data-bind="
						      if: $root.isMissingActor(actor),
						      attr:{title: 'This ' + actorTypeNoun() + ' does not exist on the current site.'}">
							（缺省）
						</span>
					</div>
					<ame-redirect-url-input params="redirect: $data, menuItems: $root.menuItems"
					                        class="ame-rui-url-template"></ame-redirect-url-input>
					<label class="ame-rui-shortcodes-enabled" title="Process shortcodes in the redirect URL">
						<input type="checkbox" data-bind="checked: shortcodesEnabled, enable: canToggleShortcodes">
						<span class="dashicons dashicons-shortcode"></span>
						<span class="ame-rui-button-label">启用短代码</span>
					</label>
					<div class="ame-rui-actions">
						<button class="button ame-rui-delete" title="删除重定向"
						        data-bind="click: $parent.items.remove.bind($parent.items, $data)">
							<span class="dashicons dashicons-trash"></span>
							<span class="ame-rui-button-label">删除</span>
						</button>
					</div>
				</div>
			</div>
		</div>
	</template>

	<template id="ame-redirect-url-component">
		<!--suppress HtmlFormInputWithoutLabel -->
		<input type="text"
		       data-bind="
		        value: displayValue,
		        attr: {'id' : redirect.inputElementId, 'readonly': isUrlReadonly},
				hasFocus: redirect.inputHasFocus,
				css: {'ame-rui-has-url-dropdown': redirect.urlDropdownEnabled}"
		       class="regular-text">
		<!-- ko if: redirect.urlDropdownEnabled -->
		<div class="ame-rui-url-dropdown-trigger">
			<span class="am-rui-trigger-icon"></span>
		</div>
		<!-- /ko -->
	</template>
</div>
