<?php

namespace YahnisElsts\AdminMenuEditor\Customizable\Design;

require_once __DIR__ . '/constants.php';

use ameModule;
use WPMenuEditor;
use YahnisElsts\AdminMenuEditor\Customizable\Builders\ElementBuilderFactory;
use YahnisElsts\AdminMenuEditor\Customizable\Builders\SettingFactory;
use YahnisElsts\AdminMenuEditor\Customizable\Controls\Tooltip;
use YahnisElsts\AdminMenuEditor\Customizable\Settings\BooleanSetting;
use YahnisElsts\AdminMenuEditor\Customizable\SettingsForm;
use YahnisElsts\AdminMenuEditor\Customizable\Storage\AbstractSettingsDictionary;
use YahnisElsts\AdminMenuEditor\Customizable\Storage\CompressedStorage;
use YahnisElsts\AdminMenuEditor\Customizable\Storage\ScopedOptionStorage;
use YahnisElsts\AdminMenuEditor\Customizable\Storage\StorageInterface;

//todo: This can be in a namespaces because that requires PHP 5.3 and we already require PHP 5.6.

//TODO: This could be a "Core Settings Module" that is always loaded, defines the UI, and handles form submission.
class SampleModule extends ameModule {
	protected $tabSlug = 'settings-refactor';
	protected $tabTitle = '设置 X';

	protected $settingsFormAction = 'save-settings-v2';

	/**
	 * @var SettingsForm|null
	 */
	private $form = null;

	/**
	 * @var AmeCoreSettings|null
	 */
	private $settings = null;

	protected function outputMainTemplate() {
		$this->getSettingsForm()->output();
		return true;
	}

	public function handleSettingsForm($post = array()) {
		$this->getSettingsForm()->handleUpdateRequest($post);
	}

	private function getSettingsForm() {
		if ( $this->form === null ) {
			$this->form = SettingsForm::builder($this->settingsFormAction)
				->id('ws_plugin_settings_form')
				->structure($this->getInterfaceStructure())
				->settings($this->getSettingsDictionary()->getRegisteredSettings())
				->submitUrl($this->getTabUrl(array('noheader' => 1)))
				->redirectAfterSaving($this->getTabUrl(), array('message' => '1'))
				->treatMissingFieldsAsEmpty()
				->postProcessSettings(
				/**
				 * @param $values
				 * @param array<string,\YahnisElsts\AdminMenuEditor\Customizable\Settings\AbstractSetting> $settingsById
				 * @return void
				 */
					function ($values, $settingsById) {
						//Update the allowed user ID when changing "who can access this plugin".
						if ( isset($settingsById['plugin_access'], $settingsById['allowed_user_id']) ) {
							if ( $settingsById['plugin_access']->getValue() === 'specific_user' ) {
								$settingsById['allowed_user_id']->update(get_current_user_id());
							} else {
								$settingsById['allowed_user_id']->update(null);
							}
						}
					}
				)
				->build();
		}
		return $this->form;
	}

	private function getSettingsDictionary() {
		if ( $this->settings === null ) {
			$optionName = $this->menuEditor->is_pro_version() ? 'ws_menu_editor_pro' : 'ws_menu_editor';

			$store = new ScopedOptionStorage(
				$optionName,
				//Core settings are always global even if menu settings are per-site.
				ScopedOptionStorage::GLOBAL_SCOPE
			);

			$this->settings = new AmeCoreSettings($this->menuEditor, $store);
		}
		return $this->settings;
	}

	private function getInterfaceStructure() {
		$isProVersion = $this->menuEditor->is_pro_version();
		$settings = $this->getSettingsDictionary();

		$b = new ElementBuilderFactory($settings);
		$structure = $b->structure(
			$b->group(
				'谁可以访问此插件',
				$b->radioGroup('plugin_access'),
				$b->auto('hide_plugin_from_others')
			)->stacked(),

			$b->auto('menu_config_scope'),

			$this->createModulesGroup($b),

			$b->group(
				'接口',
				$b->auto('hide_advanced_settings'),
				$b->auto('show_deprecated_hide_button')->onlyIf($isProVersion)
			)->stacked(),

			$b->group(
				'编辑器配色方案',
				$b->radioGroup('ui_colour_scheme')
			),

			$b->auto('submenu_icons_enabled')->onlyIf($isProVersion),

			$b->group(
				'新菜单可见性',
				$b->radioGroup('unused_item_permissions')
			)
				->onlyIf($isProVersion)
				->tooltip(
					"此设置控制以下菜单项的默认权限
					 在上次保存的菜单配置中不存在.
					 <br><br>
					 这包括由插件和主题添加的新菜单.
					 在 Multisite 中，它也适用于某些站点上存在的菜单，但不适用于其他站点上的菜单.
					 它不会影响您通过管理员菜单编辑器界面添加的菜单项."
				),

			$b->auto('unused_item_position')
				->asGroup()
				->tooltip(
					"此设置控制不存在的菜单项的位置 
					 在上次保存的菜单配置中.
					 <br><br>
					 这包括由插件和主题添加的新菜单.
					 在多站点中，它也适用于仅存在于某些站点上但并非存在于所有站点上的菜单.
					 它不会影响您通过管理员菜单编辑器界面添加的菜单项."
				),

			$b->auto('deep_nesting_enabled')
				->asGroup()
				->tooltip(
					"注意：实验性功能.<br>
					 此功能可能无法按预期工作，并可能导致与其他插件或主题发生冲突.",
					Tooltip::EXPERIMENTAL
				)
				//The free version lacks the ability to render deeply nested menus in the dashboard, so the nesting
				//options are hidden by default. However, if the user somehow acquires a configuration where this
				//feature is enabled (e.g. by importing config from the Pro version), the free version can display
				//and even edit that configuration to a limited extent.
				->onlyIf(
					$isProVersion || $settings->get('was_nesting_ever_changed')
				),

			$b->group(
				'WPML支持',
				$b->auto('wpml_support_enabled')
			)->stacked(),

			$b->group(
				'bbPress 覆盖',
				$b->auto('bbpress_override_enabled')
			)->stacked(),

			$b->auto('error_verbosity'),

			$b->group(
				'调试',
				$b->auto('security_logging_enabled'),
				$b->auto('force_custom_dashicons'),
				$b->auto('compress_custom_menu')
			)->stacked(),

			$b->group(
				'服务器信息',
				$b->html(
					"<figure>
						<figcaption>PHP error log:</figcaption>

						<code>" . esc_html(ini_get('error_log')) . "</code>
					</figure>

					<figure>
						<figcaption>PHP 内存使用情况:</figcaption> "
					. sprintf(
						'%.2f MiB of %s',
						memory_get_peak_usage() / (1024 * 1024),
						esc_html(ini_get('memory_limit'))
					)
					. " </figure>"
				)
			)
		);

		return $structure->build();
	}

	private function createModulesGroup(ElementBuilderFactory $b) {
		$activeModulesGroup = $b->group('Modules')
			->id('ame-available-modules')
			->stacked()
			->fieldset()
			->tooltip(
				'模块是可以打开或关闭的插件功能. <br>'
				. '关闭未使用的功能将略微提高性能 '
				. '并可能有助于解决某些兼容性问题.'
			);

		foreach ($this->menuEditor->get_available_modules() as $id => $module) {
			if ( !empty($module['isAlwaysActive']) ) {
				continue;
			}

			$isCompatible = $this->menuEditor->is_module_compatible($module);
			$compatibilityNote = '';
			if ( !$isCompatible && !empty($module['requiredPhpVersion']) ) {
				if ( version_compare(phpversion(), $module['requiredPhpVersion'], '<') ) {
					$compatibilityNote = sprintf(
						'Required PHP version: %1$s or later. Installed PHP version: %2$s',
						htmlspecialchars($module['requiredPhpVersion']),
						htmlspecialchars(phpversion())
					);
				}
			}

			$activeModulesGroup->add(
				$b->checkbox()
					->label(htmlspecialchars(!empty($module['title']) ? $module['title'] : $id))
					->description($compatibilityNote)
					->enabled($isCompatible)
					->params(array(
						'inputAttributes' => array(
							'name'    => 'is_active_module[]',
							'value'   => $id,
							'checked' => $this->menuEditor->is_module_active($id, $module),
						),
					))
			);
		}
		return $activeModulesGroup;
	}
}

class AmeCoreSettings extends AbstractSettingsDictionary {
	/**
	 * @var WPMenuEditor
	 */
	protected $menuEditor;

	public function __construct(WPMenuEditor $menuEditor, StorageInterface $store = null) {
		if ( !isset($store) ) {
			$store = new ScopedOptionStorage(
				'ws_menu_editor_pro',
				ScopedOptionStorage::GLOBAL_SCOPE
			);
		}
		$this->menuEditor = $menuEditor;
		parent::__construct($store);

		if ( $this->store instanceof CompressedStorage ) {
			$this->store->setCompressionEnabled($this->get('compress_custom_menu', false));
		}
	}

	protected function createDefaults() {
		return $this->menuEditor->get_default_options();
	}

	protected function createSettings() {
		$factory = new SettingFactory($this->store, $this->defaults);

		$isMultisite = is_multisite();
		$isSuperAdmin = is_super_admin();
		$isProVersion = $this->menuEditor->is_pro_version();
		$currentUser = wp_get_current_user();
		$menuEditor = $this->menuEditor;

		$settings = array(
			$factory->stringEnum(
				'plugin_access',
				array('super_admin', 'manage_options', 'specific_user'),
				'Who can access this plugin'
			)
				->describeChoice(
					'super_admin',
					'Super Admin',
					$isMultisite ? null : '在单站点安装中，这通常与管理员角色相同.',
					$isSuperAdmin
				)
				->describeChoice(
					'管理选项',
					'任何具有“管理选项”功能的人',
					'默认情况下，只有管理员具有此功能.',
					current_user_can('manage_options')
				)
				->describeChoice(
					'specific_user',
					'仅当前用户',
					'Login: ' . esc_html($currentUser->user_login) . ', user ID: ' . esc_html(get_current_user_id()),
					//In Multisite only Super Admins can choose this option.
					$isSuperAdmin || !$isMultisite
				),
			$factory->integer(
				'allowed_user_id',
				'（内部）当“plugin_access”为“specific_user”时可以访问插件的用户 ID.',
				array(
					'default'    => null,
					'isEditable' => '__return_false', //Not directly editable by the user.
				)
			),
			new AmeHidePluginSetting('hide_plugin_from_others', $this->store),
			$factory->stringEnum(
				'menu_config_scope',
				array('global', 'site'),
				'多站点设置',
				array(
					'isEditable' => function () use ($isMultisite) {
						return $isMultisite && is_super_admin();
					},
				)
			)
				->describeChoice(
					'global',
					'全局 &mdash;	对所有网络站点使用相同的管理员菜单设置.'
				)
				->describeChoice(
					'site',
					'每个站点 &mdash; 为每个站点使用不同的管理员菜单设置.'
				),
			$factory->boolean(
				'hide_advanced_settings',
				'默认情况下隐藏高级菜单选项'
			),
			$factory->boolean(
				'security_logging_enabled',
				'在每个管理员页面上显示插件执行的菜单访问检查',
				array(
					'description' => "这有助于跟踪配置问题 
						并弄清楚为什么您的菜单权限没有按应有的方式工作.

						注意：不建议在实时站点上使用此选项，因为
						它可以显示有关您的菜单配置的信息.",
				)
			),
			$factory->boolean(
				'show_deprecated_hide_button',
				'启用“隐藏（装饰）”工具栏按钮',
				array(
					'description' => "此按钮可隐藏选定的菜单项，而不会使其无法访问.",
				)
			),
			$factory->stringEnum(
				'submenu_icons_enabled',
				array('always', 'if_custom', 'never'),
				'显示子菜单图标'
			)->describeChoice('if_custom', '仅当手动选择时'),
			$factory->boolean(
				'force_custom_dashicons',
				'尝试覆盖其他插件添加的菜单图标 CSS'
			),
			$factory->stringEnum(
				'ui_colour_scheme',
				array('classic', 'modern-one', 'wp-grey'),
				'编辑器配色方案'
			)
				->describeChoice('classic', '蓝色和黄色')
				->describeChoice('modern-one', '现代')
				->describeChoice('wp-grey', '灰色'),
			$factory->stringEnum(
				'unused_item_position',
				array('relative', 'bottom'),
				'新菜单位置'
			)
				->describeChoice(
					'relative',
					'保持相对秩序',
					'尝试将新项放在相同的相对位置 '
					. '就像它们在默认的管理员菜单中一样.'
				)
				->describeChoice(
					'bottom',
					'底部',
					'将新项目放在管理员菜单的底部.'
				),
			$factory->stringEnum(
				'unused_item_permissions',
				array('unchanged', 'match_plugin_access'),
				'新菜单可见性'
			)
				->describeChoice(
					'unchanged',
					'保持不变（默认）',
					'没有特殊限制。可见性将取决于添加菜单的插件.'
				)
				->describeChoice(
					'match_plugin_access',
					'仅向可以访问此插件的用户显示',
					'自动向普通用户隐藏所有新的和无法识别的菜单. '
					. '要使新菜单可见，您必须在菜单编辑器中手动启用它们.'
				),
			$factory->enum(
				'error_verbosity',
				array(
					WPMenuEditor::VERBOSITY_LOW,
					WPMenuEditor::VERBOSITY_NORMAL,
					WPMenuEditor::VERBOSITY_VERBOSE,
				),
				'Error verbosity level'
			)
				->describeChoice(
					WPMenuEditor::VERBOSITY_LOW,
					'简单',
					'显示不带任何详细信息的一般错误消息.'
				)
				->describeChoice(
					WPMenuEditor::VERBOSITY_NORMAL,
					'正常',
					'显示一两句话的解释。例如：“当前'
					. ' 用户不具备所需的“manage_options”功能'
					. ' 访问“设置”菜单项."'
				)
				->describeChoice(
					WPMenuEditor::VERBOSITY_VERBOSE,
					'详细',
					'像“正常”一样，但也包括菜单设置和权限的日志
					 这导致当前菜单被隐藏。用于调试.'
				),
			$factory->boolean(
				'compress_custom_menu',
				"压缩存储在数据库中的菜单配置数据",
				array(
					'description' => sprintf(
						"显著减小了 <code>%s</code> DB 选项,
						但会增加每个页面的解压缩开销.",
						esc_html($this->store->getStorageKey())
					),
				)
			),
			$factory->boolean(
				'wpml_support_enabled',
				'使用WPML使编辑过的菜单标题可翻译',
				array(
					'description' => '标题将显示在WPML的“字符串”部分中. '
						. '如果您不使用WPML或类似的翻译插件, '
						. '您可以安全地禁用此选项.',
				)
			),
			$factory->boolean(
				'bbpress_override_enabled',
				'阻止 bbPress 重置角色功能',
				array(
					'description' => '默认情况下，bbPress 将自动撤消任何 '
						. '对动态 bbPress 角色所做的更改。启用此选项 '
						. '选项来覆盖该行为并使其成为可能 '
						. '更改 bbPress 角色功能.',
				)
			),
			$factory->enum(
				'deep_nesting_enabled',
				array(null, true, false),
				'三级菜单',
				array('default' => null)
			)
				->describeChoice(null, '首次使用时询问')
				->describeChoice(true, '启用' . ($isProVersion ? '' : ' （仅在编辑器中）'))
				->describeChoice(false, '禁用'),
			$factory->custom(
				'is_active_module',
				'array',
				function ($inputValue) use ($menuEditor) {
					if ( empty($inputValue) ) {
						return array();
					}

					//Convert to [$moduleId => $enabled].
					$activeModules = (array)$inputValue;
					$activeModules = array_fill_keys(array_map('strval', $activeModules), true);

					//Filter out modules that are invalid or not installed.
					$availableModules = $menuEditor->get_available_modules();
					$activeModules = array_intersect_key($activeModules, $availableModules);

					//Explicitly set disabled modules to false.
					return array_merge(
						array_map('__return_false', $availableModules),
						$activeModules
					);
				},
				'Modules'
			),
		);

		//Index settings by ID.
		$result = array();
		foreach ($settings as $setting) {
			$result[$setting->getId()] = $setting;
		}
		return $result;
	}
}

class AmeHidePluginSetting extends BooleanSetting {
	const SETTING_KEY = 'plugins_page_allowed_user_id';

	protected $defaultValue = false;

	public function __construct($id, StorageInterface $store = null, $params = array()) {
		$isProVersion = self::isProVersion();
		if ( !isset($params['label']) ) {
			$label = '隐藏“管理员菜单编辑器”' . ($isProVersion ? ' Pro' : '') . '"';
			if ( defined('WS_ADMIN_BAR_EDITOR_FILE') || defined('AME_BRANDING_ADD_ON_FILE') ) {
				$label .= ' 及其附加组件 ';
			}
			$label .= ' 从其他用户的“插件”页面';
			if ( !$isProVersion ) {
				$label .= ' (Pro version only)';
			}
			$params['label'] = $label;
		}

		parent::__construct($id, $store, $params);
	}

	public function getValue($customDefault = null) {
		/** @noinspection PhpRedundantOptionalArgumentInspection */
		$userId = $this->store->getPath(self::SETTING_KEY, null);
		return ($userId !== null);
	}

	public function update($validValue) {
		if ( !$this->store ) {
			return false;
		}
		$success = $this->store->setPath(
			self::SETTING_KEY,
			$validValue ? get_current_user_id() : null
		);
		$this->notifyUpdated();
		return $success;
	}

	public function isEditableByUser() {
		if ( !self::isProVersion() ) {
			return false;
		}

		if ( is_multisite() ) {
			$allowed = is_super_admin();
		} else {
			$allowed = current_user_can('manage_options');
		}
		return $allowed && parent::isEditableByUser();
	}

	protected static function isProVersion() {
		static $isPro = null;
		if ( $isPro === null ) {
			$isPro = apply_filters('admin_menu_editor_is_pro', false);
		}
		return $isPro;
	}
}