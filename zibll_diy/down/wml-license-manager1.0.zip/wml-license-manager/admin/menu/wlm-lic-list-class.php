<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-10 08:03:32
 $ @ 最后修改: 2024-11-15 12:38:15
 $ @ 文件路径: \wml-license-manager\admin\menu\wlm-lic-list-class.php
 $ @ 简要说明: 由Japhia开发用于WordPress主题/插件通用的授权许可管理系统。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class WPLM_List_Licenses extends WP_List_Table {

	function __construct() {
		global $status, $page;

		//设置父级默认值
		parent::__construct(
			array(
				'singular' => 'item',     //所列记录的单数名称
				'plural'   => 'items',    //所列记录的复数名称
				'ajax'     => false,        //这个表支持ajax吗？
			)
		);

	}

	function column_default( $item, $column_name ) {
		//状态
		switch ($item['lic_status'])
		{
		case "pending":
			$item['lic_status']='<font color="green">空闲</font>';
			break;
		case "active":
			$item['lic_status']='<font color="blue">活跃</font>';
			break;
		case "blocked":
			$item['lic_status']='<font color="red">封锁</font>';
			break;
		case "expired":
			$item['lic_status']='<del><font color="gray">过期</font></del>';
			break;
		default:
			$item['lic_status']='';
		}
		//类型
		switch ($item['type'])
		{
		case 0:
			$item['type']='永久';
			break;
		case 1:
			$item['type']='月卡';
			break;
		case 2:
			$item['type']='季卡';
			break;
		case 3:
			$item['type']='年卡';
			break;
		default:
			$item['type']='';
		}
		
		return $item[ $column_name ];
	}

	function column_id( $item ) {
		$row_id  = $item['id'];
		$actions = array(
			'edit'   => sprintf( '<a href="admin.php?page=wlm_lic_addedit&edit_record=%s">编辑</a>', $row_id ),
			'delete' => sprintf(
				'<a href="admin.php?page=wlm-main&action=delete_license&id=%s&_wpnonce=%s" onclick="return confirm(\'您确定要删除此记录吗？\')">删除</a>',
				$row_id,
				wp_create_nonce( 'wlm-delete-license-' . $row_id )
			),
		);
		return sprintf(
			'%1$s <span style="color:silver"></span>%2$s',
			/*$1%s*/ $item['id'],
			/*$2%s*/ $this->row_actions( $actions )
		);
	}


	function column_cb( $item ) {
		return sprintf(
			'<input type="checkbox" name="%1$s[]" value="%2$s" />',
			/*$1%s*/ $this->_args['singular'],  //让我们简单地重新调整表格的单一标签
			/*$2%s*/ $item['id']                //复选框的值应该是记录的id
		);
	}

	function column_active( $item ) {
		if ( $item['active'] == 1 ) {
			return 'active';
		} else {
			return 'inactive';
		}
	}

	function get_columns() {
		$columns = array(
			'cb'                  => '<input type="checkbox" />', // 渲染复选框。
			'id'                  => 'ID',
			'license_key'         => '许可密钥',
			'type'         		  => '类型',
			'lic_status'          => '状态',
			'max_allowed_domains' => '域名',
			'email'               => '注册邮箱',
			'date_created'        => '创建日期',
			'date_renewed'        => '续订日期',
			'date_expiry'         => '到期',
			'product_ref'         => '产品参考',
			'user_ref'         => '用户备注',
		);
		return $columns;
	}

	function get_sortable_columns() {
		$sortable_columns = array(
			'id'           => array( 'id', false ),
			'license_key'  => array( 'license_key', false ),
			'type'   	   => array( 'type', false ),
			'lic_status'   => array( 'lic_status', false ),
			'date_created' => array( 'date_created', false ),
			'date_renewed' => array( 'date_renewed', false ),
			'date_expiry'  => array( 'date_expiry', false ),
		);
		return $sortable_columns;
	}

	function get_bulk_actions() {
		$actions = array(
			'delete' => '删除',
		);
		return $actions;
	}

	function process_bulk_action() {
		if ( 'delete' === $this->current_action() ) {
			check_admin_referer( 'bulk-' . $this->_args['plural'] );
			//Process delete bulk actions
			if ( ! isset( $_REQUEST['item'] ) ) {
				$error_msg = __( '错误-请使用复选框选择一些记录', 'wlm' );
				echo '<div id="message" class="error fade"><p>' . esc_html( $error_msg ) . '</p></div>';
				return;
			} else {
				$nvp_key           = $this->_args['singular'];
				$records_to_delete = filter_input( INPUT_GET, $nvp_key, FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );
				foreach ( $records_to_delete as $row ) {
					WLM_Utility::delete_license_key_by_row_id( $row );
				}
				echo '<div id="message" class="updated fade"><p>已成功删除所选记录！</p></div>';
			}
		}
	}


	/*
	 * 此功能将从数据库中删除所选的许可证密钥条目。
	 */
	function delete_license_key( $key_row_id ) {
		WLM_Utility::delete_license_key_by_row_id( $key_row_id );
		echo '<div id="message" class="updated"><p><strong>';
		echo '已成功删除所选条目！';
		echo '</strong></p></div>';
	}

	function search_box( $text, $input_id ) {
		if ( empty( $_REQUEST['s'] ) && ! $this->has_items() ) {
			return;
		}

		$input_id = $input_id . '-search-input';

		if ( ! empty( $_REQUEST['orderby'] ) ) {
			echo '<input type="hidden" name="orderby" value="' . esc_attr( $_REQUEST['orderby'] ) . '" />';
		}
		if ( ! empty( $_REQUEST['order'] ) ) {
			echo '<input type="hidden" name="order" value="' . esc_attr( $_REQUEST['order'] ) . '" />';
		}
		if ( ! empty( $_REQUEST['post_mime_type'] ) ) {
			echo '<input type="hidden" name="post_mime_type" value="' . esc_attr( $_REQUEST['post_mime_type'] ) . '" />';
		}
		if ( ! empty( $_REQUEST['detached'] ) ) {
			echo '<input type="hidden" name="detached" value="' . esc_attr( $_REQUEST['detached'] ) . '" />';
		}
		?>

<div class="postbox">
	<h3 class="hndle"><label for="title">许可证搜索</label></h3>
	<div class="inside">
		<p>使用电子邮件、名称、密钥、域或交易ID搜索许可证</p>
		<label class="screen-reader-text" for="<?php echo esc_attr( $input_id ); ?>"><?php echo esc_html( $text ); ?>:</label>
		<input type="search" id="<?php echo esc_attr( $input_id ); ?>" name="s" size="40" value="<?php _admin_search_query(); ?>" />
		<?php submit_button( $text, 'button', false, false, array( 'id' => 'search-submit' ) ); ?>
	</div>
</div>


		<?php
	}

	function prepare_items() {
		/**
		 * 首先，让我们决定每页显示多少条记录
		 */
		$per_page     = 50;
		$current_page = $this->get_pagenum();
		$columns      = $this->get_columns();
		$hidden       = array();
		$sortable     = $this->get_sortable_columns();

		$this->_column_headers = array( $columns, $hidden, $sortable );

		$this->process_bulk_action();

		global $wpdb;
		$license_table = WLM_TBL_LICENSE_KEYS;
		$domain_table  = WLM_TBL_LICENSE_DOMAIN;

		/**
		 * 订购参数：
		 * 将用于对结果进行排序的参数。
		 */
		$orderby = ! empty( $_GET['orderby'] ) ? wp_strip_all_tags( $_GET['orderby'] ) : 'id';
		$order   = ! empty( $_GET['order'] ) ? wp_strip_all_tags( $_GET['order'] ) : 'DESC';

		$order_str = sanitize_sql_orderby( $orderby . ' ' . $order );

		$limit_from = ( $current_page - 1 ) * $per_page;

		if ( ! empty( $_REQUEST['s'] ) ) {
			$search_term = trim( sanitize_text_field( wp_unslash( $_REQUEST['s'] ) ) );
			$placeholder = '%' . $wpdb->esc_like( $search_term ) . '%';

			$select = "SELECT `lk` . * , CONCAT( COUNT( `rd` . `lic_key_id` ), '/', `lk` . `max_allowed_domains` ) AS `max_allowed_domains`";

			$after_select = "FROM `$license_table` `lk`
			LEFT JOIN `$domain_table` `rd` ON `lk`.`id` = `rd`.`lic_key_id`
			WHERE `lk`.`license_key` LIKE %s
			OR `lk`.`email` LIKE %s
			OR `lk`.`txn_id` LIKE %s
			OR `lk`.`first_name` LIKE %s
			OR `lk`.`last_name` LIKE %s
			OR `rd`.`registered_domain` LIKE %s";

			$after_query = "GROUP BY `lk` . `id` ORDER BY $order_str
			LIMIT $limit_from, $per_page";

			$q = "$select $after_select $after_query";

			$data = $wpdb->get_results(
				$wpdb->prepare(
					$q,
					$placeholder,
					$placeholder,
					$placeholder,
					$placeholder,
					$placeholder,
					$placeholder
				),
				ARRAY_A
			);

                        // 用于统计不同许可证密钥总数的SQL查询。
                        // 使用COUNT（DISTINCT lk.id）：这可确保您计算的是不同许可证密钥的数量（而不是域的数量）
                        $found_rows_q = $wpdb->prepare(
                            "SELECT COUNT(DISTINCT `lk`.`id`)
                             $after_select",
                            $placeholder,
                            $placeholder,
                            $placeholder,
                            $placeholder,
                            $placeholder,
                            $placeholder
                        );

                        // 获取项目总数。
			$total_items = intval( $wpdb->get_var( $found_rows_q ) );
		} else {
			$after_select = "FROM `$license_table` `lk`
			LEFT JOIN `$domain_table` `rd`
			ON `lk` . `id` = `rd` . `lic_key_id`";

			$after_query = "GROUP BY `lk` . `id`
			ORDER BY $order_str
			LIMIT $limit_from, $per_page";

			$q = "SELECT `lk` . * ,
				CONCAT( COUNT( `rd` . `lic_key_id` ), '/', `lk` . `max_allowed_domains` ) as `max_allowed_domains`
				$after_select$after_query";

			$data = $wpdb->get_results( $q, ARRAY_A );

                        // 用于统计不同许可证密钥总数的SQL查询。
			//$found_rows_q = "SELECT COUNT( * ) $after_select";//旧查询。
                        //使用COUNT（DISTINCT lk.id）：这可确保您计算的是不同许可证密钥的数量（而不是域的数量）
                        $found_rows_q = "SELECT COUNT(DISTINCT `lk`.`id`) $after_select";

                        // 获取项目总数。
			$total_items = intval( $wpdb->get_var( $found_rows_q ) );
		}
		$this->items = $data;
		$this->set_pagination_args(
			array(
				'total_items' => $total_items,                     // 我们必须计算物品的总数。
				'per_page'    => $per_page,                        // 我们必须确定一个页面上要显示多少项目。
				'total_pages' => ceil( $total_items / $per_page ), // 我们必须计算总页数。
			)
		);
	}
}
