<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-10 08:03:32
 $ @ 最后修改: 2024-11-16 02:53:48
 $ @ 文件路径: \wml-license-manager\admin\menu\wlm-integration-help.php
 $ @ 简要说明: 由Japhia开发用于WordPress主题/插件通用的授权许可管理系统。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

function wlm_integration_help_menu() {
	?>
	<style type="text/css">
	.lic_mgr_code{border:1px solid #C2D7EF; background-color:#E2EDFF; margin:10px 0; padding:10px; width:800px; font-family:"Consolas","Bitstream Vera Sans Mono","Courier New",Courier,monospace !important; font-size:13px;}
        .wlm_yellow_box {background: #FFF6D5; border: 1px solid #D1B655; color: #3F2502; margin: 10px 0px 10px 0px; padding: 5px 5px 5px 10px; text-shadow: 1px 1px #FFFFFF;}
	</style>
	<?php

	$options                 = get_option( 'wlm_plugin_options' );
	$creation_secret_key     = isset($options['lic_creation_secret']) && !empty($options['lic_creation_secret']) ? $options['lic_creation_secret'] : '';
	$secret_verification_key = isset($options['lic_verification_secret']) && !empty($options['lic_verification_secret']) ? $options['lic_verification_secret'] : '';

	echo '<div class="wrap">';
	echo '<h2>许可证管理器集成帮助</h2>';
	echo '<div id="poststuff"><div id="post-body">';

    echo '<h3>安装的一些关键变量信息</h3>';

	$api_query_post_url = WLM_SITE_HOME_URL;
	echo '<strong>用于安装的许可证API查询POST URL</strong>';
	echo '<div class="lic_mgr_code">' . esc_url( $api_query_post_url ) . '</div>';

	echo '<strong>许可证激活或停用API密钥</strong>';
	echo '<div class="lic_mgr_code">' . esc_html( $secret_verification_key ) . '</div>';

	echo '<strong>许可证创建API密钥</strong>';
	echo '<div class="lic_mgr_code">' . esc_html( $creation_secret_key ) . '</div>';


	echo '</div></div>';
	echo '</div>';
}
