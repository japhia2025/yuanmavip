<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-10 08:03:32
 $ @ 最后修改: 2024-11-16 02:52:05
 $ @ 文件路径: \wml-license-manager\admin\menu\wlm-lic-settings.php
 $ @ 简要说明: 由Japhia开发用于WordPress主题/插件通用的授权许可管理系统。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

function wlm_lic_settings_menu() {

	echo '<div class="wrap">';
	echo '<h2>WML-授权系统 v' . esc_html( WLM_VERSION ) . '</h2>';
	echo '<div id="poststuff"><div id="post-body">';

	wp_lic_mgr_general_settings();

	echo '</div></div>';
	echo '</div>';
}

function wp_lic_mgr_general_settings() {

	if ( isset( $_REQUEST['wlm_reset_log'] ) ) {
		check_admin_referer( 'wlm_reset_debug_log', 'wlm_reset_debug_log_nonce' );
		//$wlm_logger = new WLM_Debug_Logger();
		global $wlm_debug_logger;
		$wlm_debug_logger->reset_log_file();
		$wlm_debug_logger->reset_log_file( 'log-cron-job.txt' );
		echo '<div id="message" class="updated fade"><p>调试日志文件已重置！</p></div>';
	}

	if ( isset( $_POST['wlm_save_settings'] ) ) {

		//Check nonce
		check_admin_referer( 'wlm_settings_nonce_action', 'wlm_settings_nonce_val' );

		$default_max_domains = filter_input( INPUT_POST, 'default_max_domains', FILTER_SANITIZE_NUMBER_INT );
		$default_max_domains = empty( $default_max_domains ) ? 1 : $default_max_domains;

        $lic_creation_secret = isset( $_POST['lic_creation_secret'] ) ? sanitize_text_field( stripslashes ( $_POST['lic_creation_secret'] ) ) : '';

        $lic_prefix = isset( $_POST['lic_prefix'] ) ? sanitize_text_field( stripslashes ( $_POST['lic_prefix'] ) ) : '';
		$lic_prefix = empty( $lic_prefix ) ? '' : WLM_Utility::sanitize_strip_trim_wlm_text( $lic_prefix );

        $lic_verification_secret = isset( $_POST['lic_verification_secret'] ) ? sanitize_text_field( stripslashes ( $_POST['lic_verification_secret'] ) ) : '';

		$curr_opts = get_option( 'wlm_plugin_options' );

		$options = array(
			'lic_creation_secret'     => $lic_creation_secret,
			'lic_prefix'              => $lic_prefix,
			'default_max_domains'     => $default_max_domains,
			'lic_verification_secret' => $lic_verification_secret,
			'enable_auto_key_expiry'  => isset( $_POST['enable_auto_key_expiry'] ) ? '1' : '',
			'enable_debug'            => isset( $_POST['enable_debug'] ) ? '1' : '',
		);

		$options = array_merge( $curr_opts, $options );

		update_option( 'wlm_plugin_options', $options );

		echo '<div id="message" class="updated fade"><p>';
		echo '选项已更新！';
		echo '</p></div>';
	}

	$options = get_option( 'wlm_plugin_options' );

	$secret_key = isset($options['lic_creation_secret']) && !empty($options['lic_creation_secret']) ? $options['lic_creation_secret'] : '';
	if ( empty( $secret_key ) ) {
		$secret_key = uniqid( '', true );
	}
	$secret_verification_key = isset($options['lic_verification_secret']) && !empty($options['lic_verification_secret']) ? $options['lic_verification_secret'] : '';
	if ( empty( $secret_verification_key ) ) {
		$secret_verification_key = uniqid( '', true );
	}

    $lic_prefix = isset($options['lic_prefix']) && !empty($options['lic_prefix']) ? $options['lic_prefix'] : '';
    $default_max_domains = isset($options['default_max_domains']) && !empty($options['default_max_domains']) ? $options['default_max_domains'] : '';
    $enable_auto_key_expiry = isset($options['enable_auto_key_expiry']) && !empty($options['enable_auto_key_expiry']) ? 'checked="checked"' : '';
    $enable_debug_checked = isset($options['enable_debug']) && !empty($options['enable_debug']) ? 'checked="checked"' : '';
	?>

	<div class="postbox">
		<h3 class="hndle"><label for="title">快速使用指南</label></h3>
		<div class="inside">

			<p>1. 在购买时首先注册密钥.</p>
			<p>2. 添加代码，以便在激活时询问钥匙.</p>
			<p>3. 集成实时在线密钥验证部分.</p>
		</div></div>

	<form method="post" action="">
		<?php wp_nonce_field( 'wlm_settings_nonce_action', 'wlm_settings_nonce_val' ); ?>

		<div class="postbox">
			<h3 class="hndle"><label for="title">通用许可证管理器设置</label></h3>
			<div class="inside">
				<table class="form-table">

					<tr valign="top">
						<th scope="row">创建许可证的密钥</th>
						<td><input type="text" name="lic_creation_secret" value="<?php echo esc_attr( $secret_key ); ?>" size="40" />
							<br />此密钥将用于验证任何许可证创建请求。你可以用一些随机的东西来改变它.</td>
					</tr>

					<tr valign="top">
						<th scope="row">许可证验证请求的密钥</th>
						<td><input type="text" name="lic_verification_secret" value="<?php echo esc_attr( $secret_verification_key ); ?>" size="40" />
							<br />此密钥将用于验证来自客户站点的任何许可证验证请求。重要！一旦您的客户开始使用您的产品，请勿更改此值！</td>
					</tr>

					<tr valign="top">
						<th scope="row">许可证密钥前缀</th>
						<td><input type="text" name="lic_prefix" value="<?php echo esc_attr( $lic_prefix ); ?>" size="40" />
							<br />您可以选择为许可证密钥指定前缀。此前缀将添加到唯一生成的许可证密钥中。</td>
					</tr>

					<tr valign="top">
						<th scope="row">允许的最大域数</th>
						<td><input type="text" name="default_max_domains" value="<?php echo esc_attr( $default_max_domains ); ?>" size="6" />
							<br />每个许可证有效的最大域/安装数（默认值）。</td>
					</tr>

					<tr valign="top">
						<th scope="row">自动过期许可证密钥</th>
						<td><input name="enable_auto_key_expiry" type="checkbox" <?php echo esc_attr($enable_auto_key_expiry) ?> value="1"/>
							<p class="description">启用后，当达到密钥的到期日期值时，它将自动将许可证密钥的状态设置为“已过期”。
							它不会远程停用钥匙。它只是将数据库中的密钥状态更改为已过期.</p>
						</td>
					</tr>
				</table>
			</div></div>

		<div class="postbox">
			<h3 class="hndle"><label for="title">调试和测试设置</label></h3>
			<div class="inside">
				<table class="form-table">

					<tr valign="top">
						<th scope="row">启用调试日志记录</th>
						<td><input name="enable_debug" type="checkbox" <?php echo esc_attr($enable_debug_checked) ?> value="1"/>
							<p class="description">如果选中，调试输出将写入日志文件（除非您正在排除故障，否则请将其禁用）.</p>
							<br />- 单击查看调试日志文件 <a href="<?php echo esc_attr( wp_nonce_url( 'admin.php?page=wlm_lic_settings&wlm_view_log=1', 'wlm_view_debug_log', 'wlm_view_debug_log_nonce' ) ); ?>" target="_blank">这里</a>.
							<br />- 通过单击重置调试日志文件 <a href="<?php echo esc_attr( wp_nonce_url( 'admin.php?page=wlm_lic_settings&wlm_reset_log=1', 'wlm_reset_debug_log', 'wlm_reset_debug_log_nonce' ) ); ?>" target="_blank" onclick="return confirm('您确定要重置调试日志文件吗？');">这里</a>.
						</td>
					</tr>

				</table>
			</div></div>

		<div class="submit">
			<input type="submit" class="button-primary" name="wlm_save_settings" value=" <?php esc_html_e( '更新选项', 'wlm' ); ?>" />
		</div>
	</form>
	<?php
}
