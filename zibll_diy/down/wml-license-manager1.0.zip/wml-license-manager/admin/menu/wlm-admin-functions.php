<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-10 08:03:32
 $ @ 最后修改: 2024-11-15 09:24:00
 $ @ 文件路径: \wml-license-manager\admin\menu\wlm-admin-functions.php
 $ @ 简要说明: 由Japhia开发用于WordPress主题/插件通用的授权许可管理系统。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

function wlm_admin_func_menu() {

	echo '<div class="wrap">';
	echo '<h2>许可证管理器管理功能</h2>';
	echo '<div id="poststuff"><div id="post-body">';

	$wlm_options = get_option( 'wlm_plugin_options' );

	$post_url = '';

	if ( isset( $_POST['send_deactivation_request'] ) ) {
		check_admin_referer( 'wlm_send_deact_req' );
		$post_url                 = filter_input( INPUT_POST, 'lic_mgr_deactivation_req_url', FILTER_SANITIZE_URL );
		$secretKeyForVerification = $wlm_options['lic_verification_secret'];
		$data                     = array();
		$data['secret_key']       = $secretKeyForVerification;

                if (empty($post_url)){
                    wp_die('URL值为空。返回并输入有效的URL值。');
                }

                // 将查询发送到许可证管理器服务器
                $response = wp_remote_get(add_query_arg($data, $post_url), array('timeout' => 20, 'sslverify' => false));

                // 检查响应中的错误
                if (is_wp_error($response)){
                    echo "意外错误！查询返回错误。";
                }

                // 许可证数据。
                $license_data = json_decode(wp_remote_retrieve_body($response));

		echo '<div id="message" class="updated fade"><p>';
		echo '请求已发送到指定的URL！';
		echo '</p></div>';
                echo '<p>以下是响应的可变转储：</p>';
                var_dump($license_data);
	}
	?>
	<br />
	<div class="postbox">
		<h3 class="hndle"><label for="title">发送许可证停用消息</label></h3>
		<div class="inside">
			<br /><strong>输入许可证停用消息将发送到的URL</strong>
			<br /><br />
			<form method="post" action="">
				<?php wp_nonce_field( 'wlm_send_deact_req' ); ?>
				<input name="lic_mgr_deactivation_req_url" type="text" size="100" value="<?php esc_attr( $post_url ); ?>"/>
				<div class="submit">
					<input type="submit" name="send_deactivation_request" value="发送请求" class="button" />
				</div>
			</form>
		</div></div>
	<?php
	echo '</div></div>';
	echo '</div>';
}
