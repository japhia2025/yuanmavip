<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-09 17:24:42
 $ @ 最后修改: 2024-11-15 12:16:19
 $ @ 文件路径: \wml-license-manager\admin\menu\wml-admin-init.php
 $ @ 简要说明: 由Japhia开发用于WordPress主题/插件通用的授权许可管理系统。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/


defined( 'ABSPATH' ) || exit;

/*
 * 只有当“is_admin（）”检查为真时，才会包含此文件。
 * 管理菜单渲染代码位于此文件中。
 */

//创建主菜单
function wlm_lic_add_settings_menu()
{
    add_menu_page('WML授权', 'WML授权', WLM_MANAGEMENT_PERMISSION, WLM_MAIN_MENU_SLUG, 'wlm_lic_manage_menu', WLM_MENU_ICON);
	add_submenu_page(WLM_MAIN_MENU_SLUG, '管理授权', '管理授权', WLM_MANAGEMENT_PERMISSION, WLM_MAIN_MENU_SLUG, 'wlm_lic_manage_menu' );
	add_submenu_page(WLM_MAIN_MENU_SLUG, '添加许可', '添加许可', WLM_MANAGEMENT_PERMISSION, 'wlm_lic_addedit', 'wlm_lic_addedit_menu' );
    add_submenu_page(WLM_MAIN_MENU_SLUG, '批量添卡', '批量添卡', WLM_MANAGEMENT_PERMISSION, 'wlm_lic_addbatch', 'wlm_lic_addbatch_menu');
	add_submenu_page(WLM_MAIN_MENU_SLUG, '设置参数', '设置参数', WLM_MANAGEMENT_PERMISSION, 'wlm_lic_settings', 'wlm_lic_settings_menu' );
    add_submenu_page(WLM_MAIN_MENU_SLUG, '管理功能', '管理功能', WLM_MANAGEMENT_PERMISSION, 'wlm_admin_func', 'wlm_admin_func_menu');
    add_submenu_page(WLM_MAIN_MENU_SLUG, '集成帮助', '集成帮助', WLM_MANAGEMENT_PERMISSION, 'wlm_integration_help', 'wlm_integration_help_menu');
}
add_action( 'admin_menu', 'wlm_lic_add_settings_menu' );

//包括子菜单处理文件
require_once WP_LICENSE_MANAGER_PATH . '/admin/menu/wlm-lic-manage.php';
require_once WP_LICENSE_MANAGER_PATH . '/admin/menu/wlm-lic-addedit.php';
require_once WP_LICENSE_MANAGER_PATH . '/admin/menu/wlm-lic-addbatch.php';
require_once WP_LICENSE_MANAGER_PATH . '/admin/menu/wlm-lic-settings.php';
require_once WP_LICENSE_MANAGER_PATH . '/admin/menu/wlm-admin-functions.php';
require_once WP_LICENSE_MANAGER_PATH . '/admin/menu/wlm-integration-help.php';


?>