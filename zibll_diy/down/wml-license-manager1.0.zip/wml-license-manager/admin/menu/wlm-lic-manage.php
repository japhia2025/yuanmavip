<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-10 08:03:32
 $ @ 最后修改: 2024-11-15 11:52:26
 $ @ 文件路径: \wml-license-manager\admin\menu\wlm-lic-manage.php
 $ @ 简要说明: 由Japhia开发用于WordPress主题/插件通用的授权许可管理系统。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

function wlm_lic_manage_menu() {
	include_once 'wlm-lic-list-class.php'; // 用于呈现许可证列表表。
	$license_list = new WPLM_List_Licenses();
	// 执行列表表格形式的行操作任务。

        $action = isset( $_GET['action'] ) ? sanitize_text_field( stripslashes ( $_GET['action'] ) ) : '';

	if ( ! empty( $action ) ) {
		$id = filter_input( INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT );
		if ( ! empty( $id ) ) {
			$id = intval( $id );
			// Nonce检查
			check_admin_referer( 'wlm-delete-license-' . $id );
		}
	}

	switch ( $action ) {
		case 'delete_license':
			// 已单击列表表中某行的删除链接。
			if ( ! empty( $id ) ) {
				$license_list->delete_license_key( intval( $id ) );
			}
			break;
		default:
			break;
	}

        $page = isset( $_GET['page'] ) ? sanitize_text_field( stripslashes ( $_GET['page'] ) ) : '';

	// 获取、准备、排序和过滤我们的数据。。。
	$license_list->prepare_items();

	?>
<style>
th#id {
	width: 100px;
}

th#license_key {
	width: 300px;
}

th#type {
	width: 75px;
}

th#max_allowed_domains {
	width: 75px;
}

th#lic_status {
	width: 100px;
}

th#date_created {
	width: 125px;
}

th#date_renewed {
	width: 125px;
}

th#date_expiry {
	width: 125px;
}
</style>
<div class="wrap">
	<h2>管理许可证
		<a href="<?php echo esc_attr( add_query_arg( 'page', 'wlm_lic_addedit', get_admin_url( null, 'admin.php' ) ) ); ?>" class="page-title-action">添加新许可证</a>
	</h2>
	<div id="poststuff">
		<div id="post-body">
			<form id="tables-filter" method="get">
				<?php wp_nonce_field( 'wlm_license_list_actions', 'wlm_license_list_actions' ); ?>

				<?php $license_list->search_box( '搜索', 'wlm_search' ); ?>

				<div class="postbox">
					<h3 class="hndle"><label for="title">软件许可证</label></h3>
					<div class="inside">
						<!-- 对于插件，我们还需要确保表单发布回我们当前的页面 -->
						<input type="hidden" name="page" value="<?php echo esc_attr( $page ); ?>" />
						<!-- 现在我们可以渲染完成的列表表 -->
						<?php $license_list->display(); ?>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<script>
jQuery('input#doaction').click(function(e) {
	return confirm('您确定要对所选条目执行此批量操作吗？');
});
</script>
	<?php
}
