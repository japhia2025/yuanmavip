<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-09 17:24:06
 $ @ 最后修改: 2024-11-10 15:09:21
 $ @ 文件路径: \wml-license-manager\admin\admin.php
 $ @ 简要说明: 由Japhia开发用于WordPress主题/插件通用的授权许可管理系统。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

defined( 'ABSPATH' ) || exit;

//创建仪表台菜单
include_once 'menu/wml-admin-init.php';

?>