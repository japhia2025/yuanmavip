<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-10 02:30:22
 $ @ 最后修改: 2024-11-10 14:12:54
 $ @ 文件路径: \wml-license-manager\installer.php
 $ @ 简要说明: 由Japhia开发用于WordPress主题/插件通用的授权许可管理系统。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

//***** 安装程序 *****
global $wpdb;
require_once ABSPATH . 'wp-admin/includes/upgrade.php';

//***安装程序变量***
$lic_key_table    = WLM_TBL_LICENSE_KEYS;
$lic_domain_table = WLM_TBL_LICENSE_DOMAIN;

$charset_collate = '';
if ( ! empty( $wpdb->charset ) ) {
	$charset_collate = "DEFAULT CHARACTER SET $wpdb->charset";
} else {
	$charset_collate = 'DEFAULT CHARSET=utf8';
}
if ( ! empty( $wpdb->collate ) ) {
	$charset_collate .= " COLLATE $wpdb->collate";
}

//添加KYE表
$lk_tbl_sql = 'CREATE TABLE ' . $lic_key_table . " (
      id int(12) NOT NULL auto_increment,
      license_key varchar(255) NOT NULL,
      type smallint(1) NOT NULL,
      max_allowed_domains int(12) NOT NULL,
      lic_status ENUM('pending', 'active', 'blocked', 'expired') NOT NULL DEFAULT 'pending',
      first_name varchar(32) NOT NULL default '',
      last_name varchar(32) NOT NULL default '',
      email varchar(64) NOT NULL,
      company_name varchar(100) NOT NULL default '',
      txn_id varchar(64) NOT NULL default '',
      manual_reset_count varchar(128) NOT NULL default '',
      date_created date NOT NULL DEFAULT '0000-00-00',
      date_renewed date NOT NULL DEFAULT '0000-00-00',
      date_expiry date NOT NULL DEFAULT '0000-00-00',
      product_ref varchar(255) NOT NULL default '',
      subscr_id varchar(128) NOT NULL default '',
      user_ref varchar(255) NOT NULL default '',
      PRIMARY KEY (id),
      KEY `max_allowed_domains` (`max_allowed_domains`)
      )" . $charset_collate . ';';
dbDelta( $lk_tbl_sql );

//添加授权域名表
$ld_tbl_sql = 'CREATE TABLE ' . $lic_domain_table . ' (
      id INT NOT NULL AUTO_INCREMENT ,
      lic_key_id INT NOT NULL ,
      lic_key varchar(255) NOT NULL ,
      registered_domain text NOT NULL ,
      item_reference varchar(255) NOT NULL,
      PRIMARY KEY ( id ),
      KEY `lic_key_id` (`lic_key_id`)
      )' . $charset_collate . ';';
dbDelta( $ld_tbl_sql );

//options添加数据库版本号
update_option( 'wlm_db_version', WLM_DB_VERSION );

// 添加默认 options
$options = array(
	'lic_creation_secret'     => uniqid( '', true ),
	'lic_prefix'              => '',
	'default_max_domains'     => '1',
	'lic_verification_secret' => uniqid( '', true ),
	'enable_debug'            => '',
);
add_option( 'wlm_plugin_options', $options );
