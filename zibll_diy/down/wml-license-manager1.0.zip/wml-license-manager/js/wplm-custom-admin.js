jQuery(document).ready(function ($) {
	//在日期字段上添加日期选择器侦听器
	if ($.fn.datepicker) {
		$('.wplm_pick_date').datepicker({
			dateFormat: 'yy-mm-dd'
		});
	}

	//在下面添加其他仅限管理员端的jquery代码

});