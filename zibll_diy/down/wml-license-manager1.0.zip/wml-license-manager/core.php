<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-10 03:10:02
 $ @ 最后修改: 2024-11-10 15:32:41
 $ @ 文件路径: \wml-license-manager\core.php
 $ @ 简要说明: 由Japhia开发用于WordPress主题/插件通用的授权许可管理系统。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

//Defines
global $wpdb;
define( 'WLM_TBL_LICENSE_KEYS', $wpdb->prefix . 'wlm_key' );//KEY表名
define( 'WLM_TBL_LICENSE_DOMAIN', $wpdb->prefix . 'wlm_reg_domain' );//REG表名
define( 'WLM_MANAGEMENT_PERMISSION', apply_filters( 'wlm_management_permission_role', 'manage_options' ) );//菜单管理权限
define( 'WLM_MAIN_MENU_SLUG', 'wlm-main' );//菜单别名
define( 'WLM_MENU_ICON', 'dashicons-lock' );//菜单图标

//Includes
require_once 'inc/wlm-debug-logger.php';//调试记录器
require_once 'inc/wlm-error-codes.php';//错误代码
require_once 'inc/wlm-utility.php';//实用函数
require_once 'inc/wlm-init-time-tasks.php';//定时任务
require_once 'inc/wlm-api-utility.php';//响应接口
require_once 'inc/wlm-api-listener.php';//API请求接口
require_once 'inc/wlm-third-party-integration.php';//销售和发送邮件
//仅包含管理员端文件
if ( is_admin() ) {
	include_once 'admin/admin.php';
}

//动作钩子
add_action( 'init', 'wlm_init_handler' );
add_action( 'plugins_loaded', 'wlm_plugins_loaded_handler' );//数据库初始化，启用激活时加载触发

//初始化调试记录器
global $wlm_debug_logger;
$wlm_debug_logger = new WLM_Debug_Logger();

//执行初始化任务
function wlm_init_handler() {
	$init_task    = new WLM_Init_Time_Tasks();//定时任务
	$api_listener = new WLM_API_Listener();
}

//插件加载时间任务
function wlm_plugins_loaded_handler() {
	//当plugins_loaded操作被触发时运行
	if ( is_admin() ) {
		//检查是否需要数据库更新
		if ( get_option( 'wlm_db_version' ) != WLM_DB_VERSION ) {
			require_once dirname( __FILE__ ) . '/installer.php';
		}
	}

}

//TODO-需要将其移动到ajax处理程序文件中
//add_action( 'wp_ajax_wlm_delete_domain', 'wlm_del_reg_dom' );
function wlm_del_reg_dom() {
	$out = array( 'status' => 'fail' );

	if ( ! current_user_can( 'administrator' ) ) {
		wp_send_json( $out );
	}

	global $wpdb;

	$lic_id    = filter_input( INPUT_POST, 'lic_id', FILTER_SANITIZE_NUMBER_INT, FILTER_VALIDATE_INT );
	$domain_id = filter_input( INPUT_POST, 'domain_id', FILTER_SANITIZE_NUMBER_INT, FILTER_VALIDATE_INT );

	if ( empty( $lic_id ) || empty( $domain_id ) ) {
		wp_send_json( $out );
	}

	$reg_table = WLM_TBL_LICENSE_DOMAIN;

	if ( ! check_ajax_referer( sprintf( 'wlm_delete_domain_lic_%s_id_%s', $lic_id, $domain_id ), false, false ) ) {
		wp_send_json( $out );
	}

        do_action( 'wlm_before_registered_domain_delete', $domain_id );
  
	$wpdb->query( $wpdb->prepare( "DELETE FROM $reg_table WHERE id=%d", $domain_id ) ); //phpcs:ignore

	$out['status'] = 'success';
        $out = apply_filters( 'wlm_registered_domain_delete_response', $out );
  
	wp_send_json( $out );
}
