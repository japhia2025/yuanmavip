<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-09 17:07:21
 $ @ 最后修改: 2024-11-10 19:12:46
 $ @ 文件路径: \wml-license-manager\wml-license-manager.php
 $ @ 简要说明: 由Japhia开发用于WordPress主题/插件通用的授权许可管理系统。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/
/*
Plugin Name: WML-授权系统
Plugin URI: https://waimao.la
Description: 由Japhia开发的主题/插件通用的授权许可系统管理，为您的web应用程序提供软件许可证管理解决方案（WordPress插件、主题、基于PHP的会员脚本等），有问题联系QQ:181682233。
Author: Japhia
Version: 1.0
Author URI: https://waimao.la
*/
if ( ! defined( 'ABSPATH' ) ) {
	exit; //如果直接访问，则退出
}

//全局变量区
define( 'WLM_VERSION', '1.0' );//插件版本号
define( 'WLM_DB_VERSION', '1.0' );//数据库版本号
define( 'WP_LICENSE_MANAGER_FOLDER', dirname( plugin_basename( __FILE__ ) ) );//插件目录名-wml-license-manager
define( 'WP_LICENSE_MANAGER_URL', plugins_url( '', __FILE__ ) );//插件目录网址
define( 'WP_LICENSE_MANAGER_PATH', plugin_dir_path( __FILE__ ) );//插件绝对目录
define( 'WLM_SITE_HOME_URL', home_url() );//首页地址
define( 'WLM_WP_SITE_URL', site_url() );//安装设置的网址

//载入核心文件
require_once 'core.php';

//激活处理程序
function wlm_activate_handler() {
	//执行安装程序任务
	wlm_db_install();

	//安排每日的cron事件
	//wp_schedule_event( time(), 'daily', 'wlm_daily_cron_event' );

	do_action( 'wlm_activation_complete' );
}
register_activation_hook( __FILE__, 'wlm_activate_handler' );

//停用处理程序
function wlm_deactivate_handler() {
	//清除每日cron事件
	//wp_clear_scheduled_hook( 'wlm_daily_cron_event' );

	do_action( 'wlm_deactivation_complete' );
}
register_deactivation_hook( __FILE__, 'wlm_deactivate_handler' );

//安装程序功能
function wlm_db_install() {
	//运行安装程序
	//require_once dirname( __FILE__ ) . '/wlm_installer.php';
}

// 在WP 仪表板的插件菜单中添加设置链接。
function wlm_add_settings_link( $links, $file ) {
    if ( $file == plugin_basename( __FILE__ ) ) {
	$settings_link = '<a style="color: green;" href="admin.php?page=wlm_lic_settings">' . (__( "授权设置", "wlm" )) . '</a>';
	array_unshift( $links, $settings_link );
    }
    return $links;
}
add_filter( 'plugin_action_links', 'wlm_add_settings_link', 10, 2 );
?>