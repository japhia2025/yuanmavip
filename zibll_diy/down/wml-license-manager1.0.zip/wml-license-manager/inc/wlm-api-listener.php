<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-10 14:26:23
 $ @ 最后修改: 2024-11-15 09:29:59
 $ @ 文件路径: \wml-license-manager\inc\wlm-api-listener.php
 $ @ 简要说明: 由Japhia开发用于WordPress主题/插件通用的授权许可管理系统。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

/*
 * 此类侦听API查询并执行API请求
 * 可用的API操作
 * 1) wlm_create_new
 * 2) wlm_activate
 * 3) wlm_deactivate
 * 4) wlm_check
 */

class WLM_API_Listener {

	function __construct() {

		if ( isset( $_REQUEST['wlm_action'] ) && isset( $_REQUEST['secret_key'] ) ) {

			//调试日志
			global $wlm_debug_logger;
			$action_type = sanitize_text_field( $_REQUEST['wlm_action'] );
			$ip_address  = WLM_Utility::get_ip_address();
			$wlm_debug_logger->log_debug( 'API - 请求来自 IP: ' . $ip_address . ', Action type: ' . $action_type );

			//触发动作钩
			do_action( 'wlm_api_listener_init' );

			//这是针对许可证管理器的API查询。处理查询。
			$this->creation_api_listener();
			$this->activation_api_listener();
			$this->deactivation_api_listener();
			$this->check_api_listener();
		}
	}

	function creation_api_listener() {
		if ( isset( $_REQUEST['wlm_action'] ) && trim( $_REQUEST['wlm_action'] ) == 'wlm_create_new' ) {
			//处理licene创建API查询
			global $wlm_debug_logger;

			$options        = get_option( 'wlm_plugin_options' );
			$lic_key_prefix = $options['lic_prefix'];

			WLM_API_Utility::verify_secret_key_for_creation(); //Verify the secret key first.

			$wlm_debug_logger->log_debug( 'API - license creation (wlm_create_new) request received.' );

			//Action hook
			do_action( 'wlm_api_listener_wlm_create_new' );

			$fields = array();
			if ( isset( $_REQUEST['license_key'] ) && ! empty( $_REQUEST['license_key'] ) ) {
				$fields['license_key'] = WLM_Utility::sanitize_strip_trim_wlm_text( $_REQUEST['license_key'] );//使用您通过请求传递的密钥
			} else {
				$fields['license_key'] = $lic_key_prefix.md5(uniqid( $lic_key_prefix ));//使用md5+随机生成的密钥，默认：uniqid( $lic_key_prefix )
			}
			$fields['lic_status']   = isset( $_REQUEST['lic_status'] ) ? wp_unslash( WLM_Utility::sanitize_strip_trim_wlm_text( $_REQUEST['lic_status'] ) ) : 'pending';
			$fields['first_name']   = wp_unslash( WLM_Utility::sanitize_strip_trim_wlm_text( $_REQUEST['first_name'] ) );
			$fields['last_name']    = wp_unslash( WLM_Utility::sanitize_strip_trim_wlm_text( $_REQUEST['last_name'] ) );
			$fields['email']        = sanitize_email( $_REQUEST['email'] );
			$fields['company_name'] = isset( $_REQUEST['company_name'] ) ? wp_unslash( WLM_Utility::sanitize_strip_trim_wlm_text( $_REQUEST['company_name'] ) ) : '';
			$fields['txn_id']       = WLM_Utility::sanitize_strip_trim_wlm_text( $_REQUEST['txn_id'] );
			if ( empty( $_REQUEST['max_allowed_domains'] ) ) {
				$fields['max_allowed_domains'] = $options['default_max_domains'];
			} else {
				$fields['max_allowed_domains'] = intval( $_REQUEST['max_allowed_domains'] );
			}
			$fields['date_created'] = isset( $_REQUEST['date_created'] ) ? sanitize_text_field( $_REQUEST['date_created'] ) : date( 'Y-m-d' );
			$fields['date_expiry']  = isset( $_REQUEST['date_expiry'] ) ? sanitize_text_field( $_REQUEST['date_expiry'] ) : '';
			$fields['product_ref']  = isset( $_REQUEST['product_ref'] ) ? wp_unslash( WLM_Utility::sanitize_strip_trim_wlm_text( $_REQUEST['product_ref'] ) ) : '';
                        $fields['subscr_id'] = isset( $_REQUEST['subscr_id'] ) ? wp_unslash( WLM_Utility::sanitize_strip_trim_wlm_text( $_REQUEST['subscr_id'] ) ) : '';
                        $fields['user_ref'] = isset( $_REQUEST['user_ref'] ) ? wp_unslash( WLM_Utility::sanitize_strip_trim_wlm_text( $_REQUEST['user_ref'] ) ) : '';

			global $wpdb;
			$tbl_name = WLM_TBL_LICENSE_KEYS;
			$result   = $wpdb->insert( $tbl_name, $fields );
			if ( $result === false ) {
				//error inserting
				$args = ( array(
					'result'     => 'error',
					'message'    => 'License creation failed',
					'error_code' => WLM_Error_Codes::CREATE_FAILED,
				) );
				WLM_API_Utility::output_api_response( $args );
			} else {
				$args = ( array(
					'result'  => 'success',
					'message' => 'License successfully created',
					'key'     => $fields['license_key'],
				) );
				WLM_API_Utility::output_api_response( $args );
			}
		}
	}

	/*
	 * Query Parameters
	 * 1) wlm_action = wlm_create_new
	 * 2) secret_key
	 * 3) license_key
	 * 4) registered_domain (optional)
	 */

	function activation_api_listener() {
		if ( isset( $_REQUEST['wlm_action'] ) && trim( $_REQUEST['wlm_action'] ) == 'wlm_activate' ) {
			//处理许可证激活API查询
			global $wlm_debug_logger;

			WLM_API_Utility::verify_secret_key(); //请先验证密钥。

			$wlm_debug_logger->log_debug( 'API - license activation (wlm_activate) request received.' );

			//Action hook
			do_action( 'wlm_api_listener_wlm_activate' );

			$fields                      = array();
			$fields['lic_key']           = WLM_Utility::sanitize_strip_trim_wlm_text( $_REQUEST['license_key'] );
			$fields['registered_domain'] = isset($_REQUEST['registered_domain']) ? trim( wp_unslash( sanitize_text_field( $_REQUEST['registered_domain'] ) ) ) : '';
			$fields['item_reference']    = isset($_REQUEST['item_reference']) ? trim( sanitize_text_field( $_REQUEST['item_reference'] ) ) : '';
			$wlm_debug_logger->log_debug( 'License key: ' . $fields['lic_key'] . ' Domain: ' . $fields['registered_domain'] );

			global $wpdb;
			$tbl_name  = WLM_TBL_LICENSE_KEYS;
			$reg_table = WLM_TBL_LICENSE_DOMAIN;
			$key       = $fields['lic_key'];
			$sql_prep1 = $wpdb->prepare( "SELECT * FROM $tbl_name WHERE license_key = %s", $key );
			$retLic    = $wpdb->get_row( $sql_prep1, OBJECT );

			$sql_prep2   = $wpdb->prepare( "SELECT * FROM $reg_table WHERE lic_key = %s", $key );
			$reg_domains = $wpdb->get_results( $sql_prep2, OBJECT );
			if ( $retLic ) {
				if ( $retLic->lic_status == 'blocked' ) {
                                        //Trigger action hook
                                        do_action( 'wlm_api_listener_wlm_activate_key_blocked', $key );

					$args = ( array(
						'result'     => 'error',
						'message'    => '您的许可证密钥被阻止',
						'error_code' => WLM_Error_Codes::LICENSE_BLOCKED,
					) );
					WLM_API_Utility::output_api_response( $args );
				} elseif ( $retLic->lic_status == 'expired' ) {
                                        //Trigger action hook
                                        do_action( 'wlm_api_listener_wlm_activate_key_expired', $key );

					$args = ( array(
						'result'     => 'error',
						'message'    => '您的许可证密钥已过期',
						'error_code' => WLM_Error_Codes::LICENSE_EXPIRED,
					) );
					WLM_API_Utility::output_api_response( $args );
				}

				if ( count( $reg_domains ) < floor( $retLic->max_allowed_domains ) ) {
					foreach ( $reg_domains as $reg_domain ) {
						if ( isset( $_REQUEST['migrate_from'] ) && ( trim( $_REQUEST['migrate_from'] ) == $reg_domain->registered_domain ) ) {
							$wpdb->update( $reg_table, array( 'registered_domain' => $fields['registered_domain'] ), array( 'registered_domain' => trim( sanitize_text_field( $_REQUEST['migrate_from'] ) ) ) );
							$args = ( array(
								'result'  => 'success',
								'message' => '注册域名已更新',
							) );
							WLM_API_Utility::output_api_response( $args );
						}
						if ( $fields['registered_domain'] == $reg_domain->registered_domain ) {
							$args = ( array(
								'result'     => 'error',
								'message'    => '许可证密钥已在上使用 ' . $reg_domain->registered_domain,
								'error_code' => WLM_Error_Codes::LICENSE_IN_USE,
							) );
							WLM_API_Utility::output_api_response( $args );
						}
					}
					$fields['lic_key_id'] = $retLic->id;
					$wpdb->insert( $reg_table, $fields );

					$wlm_debug_logger->log_debug( '将许可证密钥状态更新为活动.' );
					$data    = array( 'lic_status' => 'active' );
					$where   = array( 'id' => $retLic->id );
					$updated = $wpdb->update( $tbl_name, $data, $where );

					$args = ( array(
						'result'  => 'success',
						'message' => '许可证密钥已激活',
					) );
					WLM_API_Utility::output_api_response( $args );
				} else {

					//让我们遍历域，看看它是否正在现有域上使用。
					foreach ( $reg_domains as $reg_domain ) {
						if ( $fields['registered_domain'] == $reg_domain->registered_domain ) {
							//未在现有域上使用。返回错误：LICENSE_IN_USE_ON_DOMAIN_AND_MAX_REACHED
							$args = ( array(
								'result'     => 'error',
								'message'    => '已达到最大激活值。许可证密钥已在上使用 ' . $reg_domain->registered_domain,
								'error_code' => WLM_Error_Codes::LICENSE_IN_USE_ON_DOMAIN_AND_MAX_REACHED,
							) );
							WLM_API_Utility::output_api_response( $args );
						}
					}

					//未在现有域上使用。返回错误：REACHED_MAX_DOMAINS
					$args = ( array(
						'result'     => 'error',
						'message'    => '已达到允许的最大域数',
						'error_code' => WLM_Error_Codes::REACHED_MAX_DOMAINS,
					) );
					WLM_API_Utility::output_api_response( $args );
				}
			} else {
				$args = ( array(
					'result'     => 'error',
					'message'    => 'Invalid license key',
					'error_code' => WLM_Error_Codes::LICENSE_INVALID,
				) );
				WLM_API_Utility::output_api_response( $args );
			}
		}
	}

	function deactivation_api_listener() {
		if ( isset( $_REQUEST['wlm_action'] ) && trim( $_REQUEST['wlm_action'] ) == 'wlm_deactivate' ) {
			//处理许可证停用API查询
			global $wlm_debug_logger;

			WLM_API_Utility::verify_secret_key(); //Verify the secret key first.

			$wlm_debug_logger->log_debug( 'API - license deactivation (wlm_deactivate) request received.' );

			//Action hook
			do_action( 'wlm_api_listener_wlm_deactivate' );

			if ( empty( $_REQUEST['registered_domain'] ) ) {
				$args = ( array(
					'result'     => 'error',
					'message'    => '缺少注册域名信息',
					'error_code' => WLM_Error_Codes::DOMAIN_MISSING,
				) );
				WLM_API_Utility::output_api_response( $args );
			}
			$registered_domain = trim( wp_unslash( sanitize_text_field( $_REQUEST['registered_domain'] ) ) );
			$license_key       = WLM_Utility::sanitize_strip_trim_wlm_text( $_REQUEST['license_key'] );
			$wlm_debug_logger->log_debug( 'License key: ' . $license_key . ' Domain: ' . $registered_domain );

			global $wpdb;
			$registered_dom_table = WLM_TBL_LICENSE_DOMAIN;
			$sql_prep             = $wpdb->prepare( "DELETE FROM $registered_dom_table WHERE lic_key=%s AND registered_domain=%s", $license_key, $registered_domain );
			$delete               = $wpdb->query( $sql_prep );
			if ( $delete === false ) {
				$wlm_debug_logger->log_debug( 'Error - failed to delete the registered domain from the database.' );
			} elseif ( $delete == 0 ) {
				$args = ( array(
					'result'     => 'error',
					'message'    => 'The license key on this domain is already inactive',
					'error_code' => WLM_Error_Codes::DOMAIN_ALREADY_INACTIVE,
				) );
				WLM_API_Utility::output_api_response( $args );
			} else {
				$args = ( array(
					'result'  => 'success',
					'message' => 'The license key has been deactivated for this domain',
				) );
				WLM_API_Utility::output_api_response( $args );
			}
		}
	}

	function check_api_listener() {
		if ( isset( $_REQUEST['wlm_action'] ) && trim( $_REQUEST['wlm_action'] ) == 'wlm_check' ) {
			//处理许可证检查API查询
			global $wlm_debug_logger;

			WLM_API_Utility::verify_secret_key(); //请先验证密钥。

			$wlm_debug_logger->log_debug( 'API - license check (wlm_check) request received.' );

			$fields            = array();
			$fields['lic_key'] = WLM_Utility::sanitize_strip_trim_wlm_text( $_REQUEST['license_key'] );
			$wlm_debug_logger->log_debug( 'License key: ' . $fields['lic_key'] );

			//Action hook
			do_action( 'wlm_api_listener_wlm_check' );

			global $wpdb;
			$tbl_name  = WLM_TBL_LICENSE_KEYS;
			$reg_table = WLM_TBL_LICENSE_DOMAIN;
			$key       = $fields['lic_key'];
			$sql_prep1 = $wpdb->prepare( "SELECT * FROM $tbl_name WHERE license_key = %s", $key );
			$retLic    = $wpdb->get_row( $sql_prep1, OBJECT );

			$sql_prep2   = $wpdb->prepare( "SELECT * FROM $reg_table WHERE lic_key = %s", $key );
			$reg_domains = $wpdb->get_results( $sql_prep2, OBJECT );
			if ( $retLic ) {//许可证密钥存在
				$args = apply_filters(
					'wlm_check_response_args',
					array(
						'result'              => 'success',
						'message'             => '检索到许可证密钥详细信息。',
						'license_key'         => $retLic->license_key,
						'status'              => $retLic->lic_status,
						'max_allowed_domains' => $retLic->max_allowed_domains,
						'email'               => $retLic->email,
						'registered_domains'  => $reg_domains,
						'date_created'        => $retLic->date_created,
						'date_renewed'        => $retLic->date_renewed,
						'date_expiry'         => $retLic->date_expiry,
                                                'date'                => date("Y-m-d"),
						'product_ref'         => $retLic->product_ref,
						'first_name'          => $retLic->first_name,
						'last_name'           => $retLic->last_name,
						'company_name'        => $retLic->company_name,
						'txn_id'              => $retLic->txn_id,
						'subscr_id'           => $retLic->subscr_id,
					)
				);
				//输出许可证详细信息
				WLM_API_Utility::output_api_response( $args );
			} else {
				$args = ( array(
					'result'     => 'error',
					'message'    => '许可证密钥无效',
					'error_code' => WLM_Error_Codes::LICENSE_INVALID,
				) );
				WLM_API_Utility::output_api_response( $args );
			}
		}
	}

}
