<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-10 14:26:23
 $ @ 最后修改: 2024-11-13 17:44:17
 $ @ 文件路径: \wml-license-manager\inc\wlm-api-utility.php
 $ @ 简要说明: 由Japhia开发用于WordPress主题/插件通用的授权许可管理系统。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

class WLM_API_Utility {
	/*
	 * args数组可以包含以下内容：
	 * result (success or error)
	 * message（描述操作结果的消息）
	 */

	static function output_api_response( $args ) {
		//记录到调试文件（如果启用）
		global $wlm_debug_logger;
		$wlm_debug_logger->log_debug( 'API Response - Result: ' . $args['result'] . ' Message: ' . $args['message'] );

		$args = apply_filters( 'wlm_ap_response_args', $args );//TODO - delete this (has a typo). Use the following filter instead.
		$args = apply_filters( 'wlm_api_response_args', $args );

		//发送响应
		header( 'Content-Type: application/json' );
		echo json_encode( $args );
		exit( 0 );
	}

	static function verify_secret_key() {
		$wlm_options         = get_option( 'wlm_plugin_options' );
		$right_secret_key    = $wlm_options['lic_verification_secret'];
		$received_secret_key = sanitize_text_field( $_REQUEST['secret_key'] );
		if ( $received_secret_key != $right_secret_key ) {
			$args = ( array(
				'result'     => 'error',
				'message'    => '验证API密钥无效',
				'error_code' => WLM_Error_Codes::VERIFY_KEY_INVALID,
			) );
			self::output_api_response( $args );
		}
	}

	static function verify_secret_key_for_creation() {
		$wlm_options         = get_option( 'wlm_plugin_options' );
		$right_secret_key    = $wlm_options['lic_creation_secret'];
		$received_secret_key = sanitize_text_field( $_REQUEST['secret_key'] );
		if ( $received_secret_key != $right_secret_key ) {
			$args = ( array(
				'result'     => 'error',
				'message'    => '许可证创建API密钥无效',
				'error_code' => WLM_Error_Codes::CREATE_KEY_INVALID,
			) );
			self::output_api_response( $args );
		}
	}

	static function insert_license_data_internal( $fields ) {
		/* 字段数组应具有以下键的值
		  //$fields['license_key']
		  //$fields['lic_status']
		  //$fields['first_name']
		  //$fields['last_name']
		  //$fields['email']
		  //$fields['company_name']
		  //$fields['txn_id']
		  //$fields['max_allowed_domains']
		 */
		global $wpdb;
		$tbl_name = WLM_TBL_LICENSE_KEYS;
		$fields   = array_filter( $fields );//删除所有空值。
		$result   = $wpdb->insert( $tbl_name, $fields );
	}

}
