<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-10 14:26:23
 $ @ 最后修改: 2024-11-10 14:58:30
 $ @ 文件路径: \wml-license-manager\inc\wlm-debug-logger.php
 $ @ 简要说明: 由Japhia开发用于WordPress主题/插件通用的授权许可管理系统。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

/*
 * 将调试数据记录到“Logs”文件夹中的调试文件中。示例用法如下：
 *
 * global $wlm_debug_logger;
 * $wlm_debug_logger->log_debug("Some debug message");
 *
 * OR
 *
 * WLM_Debug_Logger::log_debug_st("Some debug message");
 */

class WLM_Debug_Logger {

	protected static $instance;
	protected $log_folder_path;
	protected $default_log_file = 'log.txt';
	protected $overwrite        = false;
	var $default_log_file_cron  = 'log-cron-job.txt';
	var $debug_enabled          = false;
	var $debug_status           = array( 'SUCCESS', 'STATUS', 'NOTICE', 'WARNING', 'FAILURE', 'CRITICAL' );
	var $section_break_marker   = "\n----------------------------------------------------------\n\n";
	var $log_reset_marker       = "-------- Log File Reset --------\n";

	function __construct() {
		self::$instance        = $this;
		$this->log_folder_path = WP_LICENSE_MANAGER_PATH . '/logs';
		//检查配置，如果启用了调试，则将启用标志设置为true
		$options = get_option( 'wlm_plugin_options' );
		if ( ! empty( $options['enable_debug'] ) ) {//调试已启用
			$this->debug_enabled = true;
		}
		$this->init_default_log_file();
	}

	public static function get_instance() {
		return empty( self::$instance ) ? new self() : self::$instance;
	}

	function init_default_log_file() {
		$options = get_option( 'wlm_plugin_options' );
		if ( empty( $options['default_log_file'] ) ) {
			$this->default_log_file      = uniqid() . '-log.txt';
			$options['default_log_file'] = $this->default_log_file;
			update_option( 'wlm_plugin_options', $options );
			$this->reset_log_file();
		} else {
			$this->default_log_file = $options['default_log_file'];
		}
	}


	function get_debug_timestamp() {
		return '[' . date( 'm/d/Y g:i A' ) . '] - ';
	}

	function get_debug_status( $level ) {
		$size = count( $this->debug_status );
		if ( $level >= $size ) {
			return 'UNKNOWN';
		} else {
			return $this->debug_status[ $level ];
		}
	}

	function view_log( $file_name = '' ) {
		if ( empty( $file_name ) ) {
			$file_name = $this->default_log_file;
		}
		$log_file = $this->log_folder_path . '/' . $file_name;
		if ( ! file_exists( $log_file ) ) {
			echo '日志文件为空';
			exit();
		}
		$logfile = fopen( $log_file, 'rb' );
		if ( ! $logfile ) {
			wp_die( '无法打开日志文件。' );
		}
		header( 'Content-Type: text/plain' );
		fpassthru( $logfile );
		exit();
	}

	function get_section_break( $section_break ) {
		if ( $section_break ) {
			return $this->section_break_marker;
		}
		return '';
	}

	function reset_log_file( $file_name = '' ) {
		if ( empty( $file_name ) ) {
			$file_name = $this->default_log_file;
		}
		$content = $this->get_debug_timestamp() . $this->log_reset_marker;

		$this->overwrite = true;
		$this->append_to_file( $content, $file_name );
	}

	function append_to_file( $content, $file_name ) {
		if ( empty( $file_name ) ) {
			$file_name = $this->default_log_file;
		}
		$debug_log_file = $this->log_folder_path . '/' . $file_name;
		$f_opts         = $this->overwrite ? 'w' : 'a';
		$fp             = fopen( $debug_log_file, $f_opts );
		fwrite( $fp, $content );
		fclose( $fp );
	}

	function log_debug( $message, $level = 0, $section_break = false, $file_name = '' ) {
		if ( ! $this->debug_enabled ) {
			return;
		}
		$content  = $this->get_debug_timestamp();//Timestamp
		$content .= $this->get_debug_status( $level );//Debug status
		$content .= ' : ';
		$content .= $message . "\n";
		$content .= $this->get_section_break( $section_break );
		$this->append_to_file( $content, $file_name );
	}

	function log_debug_cron( $message, $level = 0, $section_break = false ) {
		if ( ! $this->debug_enabled ) {
			return;
		}
		$content  = $this->get_debug_timestamp();//Timestamp
		$content .= $this->get_debug_status( $level );//Debug status
		$content .= ' : ';
		$content .= $message . "\n";
		$content .= $this->get_section_break( $section_break );
		//$file_name = $this->default_log_file_cron;
		$this->append_to_file( $content, $this->default_log_file_cron );
	}

	static function log_debug_st( $message, $level = 0, $section_break = false, $file_name = '' ) {
		$options = get_option( 'wlm_plugin_options' );
		if ( empty( $options['enable_debug'] ) ) {//Debugging is disabled
			return;
		}
		self::get_instance();
		$content        = '[' . date( 'm/d/Y g:i A' ) . '] - STATUS : ' . $message . "\n";
		$debug_log_file = self::get_instance()->log_folder_path . '/' . self::get_instance()->default_log_file;
		$fp             = fopen( $debug_log_file, 'a' );
		fwrite( $fp, $content );
		fclose( $fp );
	}

}
