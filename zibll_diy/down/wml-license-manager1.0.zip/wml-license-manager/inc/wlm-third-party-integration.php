<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-10 14:26:23
 $ @ 最后修改: 2024-11-15 09:21:27
 $ @ 文件路径: \wml-license-manager\inc\wlm-third-party-integration.php
 $ @ 简要说明: 由Japhia开发用于WordPress主题/插件通用的授权许可管理系统。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

/* * ********************************* */
/* * * WP 商店插件集成               ** */
/* * ********************************* */
add_filter( 'eStore_notification_email_body_filter', 'wlm_handle_estore_email_body_filter', 10, 3 ); //标准销售通知电子邮件
add_filter( 'eStore_squeeze_form_email_body_filter', 'wlm_handle_estore_email_body_filter', 10, 3 ); //压缩表单电子邮件

function wlm_handle_estore_email_body_filter( $body, $payment_data, $cart_items ) {
	global $wlm_debug_logger, $wpdb;
	$wlm_debug_logger->log_debug( 'WP eStore集成-检查是否需要为此事务创建许可证密钥。' );
	$products_table_name = $wpdb->prefix . 'wp_eStore_tbl';
	$wlm_data            = '';

	//检查这是否是定期付款。
	if ( function_exists( 'is_paypal_recurring_payment' ) ) {
		$recurring_payment = is_paypal_recurring_payment( $payment_data );
		if ( $recurring_payment ) {
			$wlm_debug_logger->log_debug( '这是一笔经常性付款。无需创建新的许可证密钥.' );
			do_action( 'wlm_estore_recurring_payment_received', $payment_data, $cart_items );
			return $body;
		}
	}

	foreach ( $cart_items as $current_cart_item ) {
		$prod_id   = $current_cart_item['item_number'];
		$item_name = $current_cart_item['item_name'];
		$quantity  = $current_cart_item['quantity'];
		if ( empty( $quantity ) ) {
			$quantity = 1;
		}
		$wlm_debug_logger->log_debug( 'License Manager - Item Number: ' . $prod_id . ', Quantity: ' . $quantity . ', Item Name: ' . $item_name );

		$retrieved_product = $wpdb->get_row( "SELECT * FROM $products_table_name WHERE id = '$prod_id'", OBJECT );
		$package_product   = eStore_is_package_product( $retrieved_product );
		if ( $package_product ) {
			$wlm_debug_logger->log_debug( 'Checking license key generation for package/bundle product.' );
			$product_ids = explode( ',', $retrieved_product->product_download_url );
			foreach ( $product_ids as $id ) {
				$id                                = trim( $id );
				$retrieved_product_for_specific_id = $wpdb->get_row( "SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT );
				//$wlm_data .= wlm_estore_check_and_generate_key($retrieved_product_for_specific_id, $payment_data, $cart_items, $item_name);
				$wlm_data .= wlm_estore_check_and_create_key_for_qty( $retrieved_product_for_specific_id, $payment_data, $cart_items, $item_name, $quantity );
			}
		} else {
			$wlm_debug_logger->log_debug( 'Checking license key generation for single item product.' );
			$wlm_data .= wlm_estore_check_and_create_key_for_qty( $retrieved_product, $payment_data, $cart_items, $item_name, $quantity );
		}
	}

	$body = str_replace( '{wlm_data}', $wlm_data, $body );
	return $body;
}

function wlm_estore_check_and_create_key_for_qty( $retrieved_product, $payment_data, $cart_items, $item_name, $quantity ) {
	$prod_key_data = '';
	for ( $i = 0; $i < $quantity; $i++ ) {
		$prod_key_data .= wlm_estore_check_and_generate_key( $retrieved_product, $payment_data, $cart_items, $item_name );
	}
	return $prod_key_data;
}

function wlm_estore_check_and_generate_key( $retrieved_product, $payment_data, $cart_items, $item_name ) {
	global $wlm_debug_logger;
	$license_data = '';

	if ( $retrieved_product->create_license == 1 ) {
		$wlm_debug_logger->log_debug( 'Need to create a license key for this product (' . $retrieved_product->id . ')' );
		$wlm_key      = wlm_estore_create_license( $retrieved_product, $payment_data, $cart_items, $item_name );
		$license_data = "\n" . __( 'Item Name: ', 'wlm' ) . $retrieved_product->name . ' - ' . __( 'License Key: ', 'wlm' ) . $wlm_key;
		$wlm_debug_logger->log_debug( 'Liense data: ' . $license_data );
		$license_data = apply_filters( 'wlm_estore_item_license_data', $license_data );
	}
	return $license_data;
}

function wlm_estore_create_license( $retrieved_product, $payment_data, $cart_items, $item_name ) {
	global $wlm_debug_logger;
	global $wpdb;
	$product_meta_table_name = WP_ESTORE_PRODUCTS_META_TABLE_NAME;

	//检索默认设置值。
	$options        = get_option( 'wlm_plugin_options' );
	$lic_key_prefix = $options['lic_prefix'];
	$max_domains    = $options['default_max_domains'];

	//让我们检查任何特定于产品的配置。
	$prod_id      = $retrieved_product->id;
	$product_meta = $wpdb->get_row( "SELECT * FROM $product_meta_table_name WHERE prod_id = '$prod_id' AND meta_key='wlm_max_allowed_domains'", OBJECT );
	if ( $product_meta ) {
		//找到了特定于产品的WLM配置数据。
		$max_domains = $product_meta->meta_value;
	} else {
		//使用设置中的默认值（$max_domains变量已经包含默认值）。
	}
        
        //使用默认值（从今天起1年）。如果设置了特定于产品的选项，则稍后将覆盖该选项。
        $current_date_plus_1year = date( 'Y-m-d', strtotime( '+1 year' ) );
        $wlm_date_of_expiry      = $current_date_plus_1year;

	//让我们检查是否设置了任何特定于产品的到期日期
	$product_meta = $wpdb->get_row( "SELECT * FROM $product_meta_table_name WHERE prod_id = '$prod_id' AND meta_key='wlm_date_of_expiry'", OBJECT );       
	if ( $product_meta ) {
		//找到了特定于产品的WLM配置数据。使用特定于产品的配置覆盖到期日期。
		$num_days_before_expiry = $product_meta->meta_value;
		$wlm_date_of_expiry     = date( 'Y-m-d', strtotime( '+' . $num_days_before_expiry . ' days' ) );
	}

        //从自定义字段获取内存ID（如果可用）
        $customvariables = isset($payment_data['custom']) ? eStore_get_payment_custom_var($payment_data['custom']) : array();
        $emember_id = isset($customvariables['eMember_id']) ? $customvariables['eMember_id'] : '';

        //创建字段数组
	$fields                        = array();
	$fields['license_key']         = $lic_key_prefix.md5(uniqid( $lic_key_prefix ));//使用md5+随机生成的密钥，默认：uniqid( $lic_key_prefix )
	$fields['lic_status']          = 'pending';
	$fields['first_name']          = $payment_data['first_name'];
	$fields['last_name']           = $payment_data['last_name'];
	$fields['email']               = $payment_data['payer_email'];
	$fields['company_name']        = $payment_data['company_name'];
	$fields['txn_id']              = $payment_data['txn_id'];
	$fields['max_allowed_domains'] = $max_domains;
	$fields['date_created']        = date( 'Y-m-d' ); //Today's date
	$fields['date_expiry']         = $wlm_date_of_expiry;
	$fields['product_ref']         = $prod_id;//WP eStore product ID
	$fields['subscr_id']           = isset( $payment_data['subscr_id'] ) ? $payment_data['subscr_id'] : '';
        $fields['user_ref']            = $emember_id;//WP eMember member ID (if available)

	$wlm_debug_logger->log_debug( 'Inserting license data into the license manager DB table.' );
	$fields = array_filter( $fields ); //删除所有空值。

	$tbl_name = WLM_TBL_LICENSE_KEYS;
	$result   = $wpdb->insert( $tbl_name, $fields );
	if ( ! $result ) {
		$wlm_debug_logger->log_debug( 'Notice! initial database table insert failed on license key table (User Email: ' . $fields['email'] . '). Trying again by converting charset', true );
		//将默认的PayPal IPN字符集转换为UTF-8格式
		$first_name             = mb_convert_encoding( $fields['first_name'], 'UTF-8', 'windows-1252' );
		$fields['first_name']   = esc_sql( $first_name );
		$last_name              = mb_convert_encoding( $fields['last_name'], 'UTF-8', 'windows-1252' );
		$fields['last_name']    = esc_sql( $last_name );
		$company_name           = mb_convert_encoding( $fields['company_name'], 'UTF-8', 'windows-1252' );
		$fields['company_name'] = esc_sql( $company_name );

		$result = $wpdb->insert( $tbl_name, $fields );
		if ( ! $result ) {
			$wlm_debug_logger->log_debug( 'Error! Failed to update license key table. DB insert query failed.', false );
		}
	}
	//WLM_API_Utility::insert_license_data_internal($fields);

	$prod_args = array(
		'estore_prod_id'   => $prod_id,
		'estore_item_name' => $item_name,
	);
	do_action( 'wlm_estore_license_created', $prod_args, $payment_data, $cart_items, $fields );

	return $fields['license_key'];
}

/* 用于处理eStore产品添加/编辑界面以进行WLM特定产品配置的代码 */
add_filter( 'eStore_addon_product_settings_filter', 'wlm_estore_product_configuration_html', 10, 2 ); //渲染产品添加/编辑HTML
add_action( 'eStore_new_product_added', 'wlm_estore_new_product_added', 10, 2 ); //在添加产品后处理DB插件。
add_action( 'eStore_product_updated', 'wlm_estore_product_updated', 10, 2 ); //处理产品编辑后的数据库更新。
add_action( 'eStore_product_deleted', 'wlm_estore_product_deleted' ); //处理产品删除后的数据库删除。

function wlm_estore_product_configuration_html( $product_config_html, $prod_id ) {
	global $wpdb;
	$product_meta_table_name = WP_ESTORE_PRODUCTS_META_TABLE_NAME;

	if ( empty( $prod_id ) ) {
		//新产品添加
		$wlm_max_allowed_domains = '';
		$wlm_date_of_expiry      = '';
	} else {
		//现有产品编辑

		//检索最大域值
		$product_meta = $wpdb->get_row( "SELECT * FROM $product_meta_table_name WHERE prod_id = '$prod_id' AND meta_key='wlm_max_allowed_domains'", OBJECT );
		if ( $product_meta ) {
			$wlm_max_allowed_domains = $product_meta->meta_value;
		} else {
			$wlm_max_allowed_domains = '';
		}

		//检索到期日期值
		$product_meta = $wpdb->get_row( "SELECT * FROM $product_meta_table_name WHERE prod_id = '$prod_id' AND meta_key='wlm_date_of_expiry'", OBJECT );
		if ( $product_meta ) {
			$wlm_date_of_expiry = $product_meta->meta_value;
		} else {
			$wlm_date_of_expiry = '';
		}
	}

	$product_config_html .= '<div class="msg_head">软件许可证管理器插件（单击展开）</div><div class="msg_body"><table class="form-table">';

	$product_config_html .= '<tr valign="top"><th scope="row">允许的最大域数</th><td>';
	$product_config_html .= '<input name="wlm_max_allowed_domains" type="text" id="wlm_max_allowed_domains" value="' . $wlm_max_allowed_domains . '" size="10" />';
	$product_config_html .= '<p class="description">可以使用此许可证的域/安装数。如果要使用许可证管理器插件设置中设置的默认值，请留空。</p>';
	$product_config_html .= '</td></tr>';

	$product_config_html .= '<tr valign="top"><th scope="row">到期前天数</th><td>';
	$product_config_html .= '<input name="wlm_date_of_expiry" type="text" id="wlm_date_of_expiry" value="' . $wlm_date_of_expiry . '" size="10" /> 天';
	$product_config_html .= '<p class="description">到期前的天数。许可证的到期日期将根据此值设置。例如，如果您希望密钥在6个月后过期，请输入值180.</p>';
	$product_config_html .= '</td></tr>';

	$product_config_html .= '</table></div>';

	return $product_config_html;
}

function wlm_estore_new_product_added( $prod_dat_array, $prod_id ) {
	global $wpdb;
	$product_meta_table_name = WP_ESTORE_PRODUCTS_META_TABLE_NAME;

	//保存最大域值
	$fields               = array();
	$fields['prod_id']    = $prod_id;
	$fields['meta_key']   = 'wlm_max_allowed_domains';
	$fields['meta_value'] = $prod_dat_array['wlm_max_allowed_domains'];
	$result               = $wpdb->insert( $product_meta_table_name, $fields );
	if ( ! $result ) {
		//插入查询失败
	}

	//保存到期日期值
	$fields               = array();
	$fields['prod_id']    = $prod_id;
	$fields['meta_key']   = 'wlm_date_of_expiry';
	$fields['meta_value'] = $prod_dat_array['wlm_date_of_expiry'];
	$result               = $wpdb->insert( $product_meta_table_name, $fields );
	if ( ! $result ) {
		//插入查询失败
	}

}

function wlm_estore_product_updated( $prod_dat_array, $prod_id ) {
	global $wpdb;
	$product_meta_table_name = WP_ESTORE_PRODUCTS_META_TABLE_NAME;

	//查找最大域字段的现有值（对于给定的产品）
	$product_meta = $wpdb->get_row( "SELECT * FROM $product_meta_table_name WHERE prod_id = '$prod_id' AND meta_key='wlm_max_allowed_domains'", OBJECT );
	if ( $product_meta ) {
		//已找到现有值，因此让我们更新它
		//最好进行特定的更新（这样其他元值（例如“download_limit_count”）就不会设置为空）。
		$meta_key_name = 'wlm_max_allowed_domains';
		$meta_value    = $prod_dat_array['wlm_max_allowed_domains'];
		$update_db_qry = "UPDATE $product_meta_table_name SET meta_value='$meta_value' WHERE prod_id='$prod_id' AND meta_key='$meta_key_name'";
		$results       = $wpdb->query( $update_db_qry );

	} else {
		//此字段没有值，所以让我们插入一个。
		$fields               = array();
		$fields['prod_id']    = $prod_id;
		$fields['meta_key']   = 'wlm_max_allowed_domains';
		$fields['meta_value'] = $prod_dat_array['wlm_max_allowed_domains'];
		$result               = $wpdb->insert( $product_meta_table_name, $fields );
	}

	//查找到期日期字段的现有值（对于给定的产品）
	$product_meta = $wpdb->get_row( "SELECT * FROM $product_meta_table_name WHERE prod_id = '$prod_id' AND meta_key='wlm_date_of_expiry'", OBJECT );
	if ( $product_meta ) {
		//已找到现有值，因此让我们更新它
		//最好进行特定的更新（这样其他元值（例如“download_limit_count”）就不会设置为空）。
		$meta_key_name = 'wlm_date_of_expiry';
		$meta_value    = $prod_dat_array['wlm_date_of_expiry'];
		$update_db_qry = "UPDATE $product_meta_table_name SET meta_value='$meta_value' WHERE prod_id='$prod_id' AND meta_key='$meta_key_name'";
		$results       = $wpdb->query( $update_db_qry );

	} else {
		//此字段没有值，所以让我们插入一个。
		$fields               = array();
		$fields['prod_id']    = $prod_id;
		$fields['meta_key']   = 'wlm_date_of_expiry';
		$fields['meta_value'] = $prod_dat_array['wlm_date_of_expiry'];
		$result               = $wpdb->insert( $product_meta_table_name, $fields );
	}

}

function wlm_estore_product_deleted( $prod_id ) {
	global $wpdb;
	$product_meta_table_name = WP_ESTORE_PRODUCTS_META_TABLE_NAME;

	$result = $wpdb->delete(
		$product_meta_table_name,
		array(
			'prod_id'  => $prod_id,
			'meta_key' => 'wlm_max_allowed_domains',
		)
	);
	$result = $wpdb->delete(
		$product_meta_table_name,
		array(
			'prod_id'  => $prod_id,
			'meta_key' => 'wlm_date_of_expiry',
		)
	);
}

/************************************/
/*** End of WP eStore integration ***/
/************************************/


/*********************************************/
/*** WP eMember Plugin Integration Related ***/
/*********************************************/

add_shortcode( 'emember_show_wlm_license_key', 'handle_emember_show_wlm_license_key');

function handle_emember_show_wlm_license_key( $args ){
    if ( !class_exists('Emember_Auth')) {
        return "Error! WP eMember plugin is not active";
    }

    $emember_auth = Emember_Auth::getInstance();
    if ( !$emember_auth->isLoggedIn() ) {
        return "You are not logged into the site. Please log in.";
    }
    global $wpdb;
    $output = "";

    //成员已登录。查找WP eMember ID。
    $member_id = $emember_auth->getUserInfo('member_id');
    $lk_table = WLM_TBL_LICENSE_KEYS;
    $sql_prep = $wpdb->prepare( "SELECT * FROM $lk_table WHERE user_ref = %s", $member_id );
    $record = $wpdb->get_row( $sql_prep, OBJECT );

    if ( $record ){
        $license_key = $record->license_key;
        $output .= '<div class="emember_wlm_license_key">Your license key is: ' . $license_key . '</div>';
    } else {
        //Could not find a record
        $output .= '<div class="emember_wlm_license_key_not_found">Could not find a key for your account.</div>';
    }

    return $output;
}