<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-10 14:26:23
 $ @ 最后修改: 2024-11-16 02:46:31
 $ @ 文件路径: \wml-license-manager\inc\wlm-utility.php
 $ @ 简要说明: 由Japhia开发用于WordPress主题/插件通用的授权许可管理系统。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

/*
 * 包含插件的一些实用函数。
 */
class WLM_Utility {

	static function do_auto_key_expiry() {
		global $wpdb;
		$current_date = ( date( 'Y-m-d' ) );
		$tbl_name     = WLM_TBL_LICENSE_KEYS;

		$sql_prep = $wpdb->prepare( "SELECT * FROM $tbl_name WHERE lic_status !=%s", 'expired' );//加载未过期的密钥
		$licenses = $wpdb->get_results( $sql_prep, OBJECT );
		if ( ! $licenses ) {
			WLM_Debug_Logger::log_debug_st( 'do_auto_key_expiry() - no license keys found.' );
			return false;
		}

		foreach ( $licenses as $license ) {
			$key         = $license->license_key;
			$expiry_date = $license->date_expiry;
			if ( $expiry_date == '0000-00-00' ) {
				WLM_Debug_Logger::log_debug_st( 'This key (' . $key . ") doesn't have a valid expiry date set. The expiry of this key will not be checked." );
				continue;
			}

			$today_dt  = new DateTime( $current_date );
			$expire_dt = new DateTime( $expiry_date );
			if ( $today_dt > $expire_dt ) {
				//此密钥已过期。因此，请使此密钥过期。
				WLM_Debug_Logger::log_debug_st( 'This key (' . $key . ') has expired. Expiry date: ' . $expiry_date . '. Setting license key status to expired.' );
				$data    = array( 'lic_status' => 'expired' );
				$where   = array( 'id' => $license->id );
				$updated = $wpdb->update( $tbl_name, $data, $where );
				do_action( 'wlm_license_key_expired', $license->id );//触发许可证过期操作挂钩。
			}
		}
	}

	/*
	 * 从许可证表中删除许可证密钥
	 */
	static function delete_license_key_by_row_id( $key_row_id ) {
		global $wpdb;
		$license_table = WLM_TBL_LICENSE_KEYS;

		//首先删除此密钥的注册域条目（如果有的话）。
		WLM_Utility::delete_registered_domains_of_key( $key_row_id );

		//现在，从许可证表中删除密钥。
		$wpdb->delete( $license_table, array( 'id' => $key_row_id ) );

	}

	/*
	 * 从域表中删除给定键的行id的所有已注册域信息。
	 */
	static function delete_registered_domains_of_key( $key_row_id ) {
		global $wlm_debug_logger;
		global $wpdb;
		$reg_table   = WLM_TBL_LICENSE_DOMAIN;
		$sql_prep    = $wpdb->prepare( "SELECT * FROM $reg_table WHERE lic_key_id = %s", $key_row_id );
		$reg_domains = $wpdb->get_results( $sql_prep, OBJECT );
		foreach ( $reg_domains as $domain ) {
			$row_to_delete = $domain->id;
			$wpdb->delete( $reg_table, array( 'id' => $row_to_delete ) );
			//$wlm_debug_logger->log_debug（“已删除行id为（“.$row_to_delete.”）的注册域。”）；
		}
	}
	/**
	 * 获取远程IP地址。
	 * @link /questions/1634782/what-is-the-most-accurate-way-to-retrieve-a-users-correct-ip-address-in-php
	 *
	 * @param bool $ignore_private_and_reserved忽略属于私有或保留IP范围的IP。
	 * @return mixed 如果无法确定（或忽略）远程IP地址，则IP地址为字符串或null。
	 */
	static function get_ip_address( $ignore_private_and_reserved = false ) {
		$flags = $ignore_private_and_reserved ? ( FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) : 0;
		foreach ( array( 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR' ) as $key ) {
			if ( array_key_exists( $key, $_SERVER ) === true ) {
				foreach ( explode( ',', $_SERVER[ $key ] ) as $ip ) {
					$ip = trim( $ip ); // 只是为了安全

					if ( filter_var( $ip, FILTER_VALIDATE_IP, $flags ) !== false ) {
						return $ip;
					}
				}
			}
		}
		return '';
	}

	static function sanitize_strip_trim_wlm_text( $text ) {
		$text = strip_tags( $text );
		$text = htmlspecialchars( $text );
		$text = sanitize_text_field( $text );
		$text = trim( $text );
		return $text;
	}
}

