<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-10 14:26:23
 $ @ 最后修改: 2024-11-10 17:56:07
 $ @ 文件路径: \wml-license-manager\inc\wlm-init-time-tasks.php
 $ @ 简要说明: 由Japhia开发用于WordPress主题/插件通用的授权许可管理系统。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

class WLM_Init_Time_Tasks {

	function __construct() {
		$this->load_scripts();

		//在此处添加其他初始化时间操作
		add_action( 'wlm_daily_cron_event', array( &$this, 'wlm_daily_cron_event_handler' ) );

		//View debug log
		if ( ! empty( $_REQUEST['wlm_view_log'] ) ) {
			check_admin_referer( 'wlm_view_debug_log', 'wlm_view_debug_log_nonce' );
			WLM_Debug_Logger::get_instance()->view_log();
		}
	}

	function load_scripts() {
		//仅加载所有常用脚本和样式
		wp_enqueue_script( 'jquery' );

		//仅加载所有管理端脚本和样式
		if ( is_admin() ) {
			wp_enqueue_script( 'jquery-ui-datepicker' );
			wp_enqueue_script( 'wplm-custom-admin-js', WP_LICENSE_MANAGER_URL . '/js/wplm-custom-admin.js', array( 'jquery-ui-dialog' ) );//仅限管理员自定义js代码

			if ( isset( $_GET['page'] ) && $_GET['page'] == 'wlm_lic_addedit' ) {//仅在许可证添加/编辑界面中包含
				wp_enqueue_style( 'jquery-ui-style', WP_LICENSE_MANAGER_URL . '/css/jquery-ui.css' );
			}
			//wp_enqueue_style('dialogStylesheet', includes_url().'css/jquery-ui-dialog.css');
		}
	}

	function wlm_daily_cron_event_handler() {
		$options = get_option( 'wlm_plugin_options' );

		do_action( 'wlm_daily_cron_event_triggered' );

		if ( isset( $options['enable_auto_key_expiry'] ) && $options['enable_auto_key_expiry'] == '1' ) {
			//执行自动密钥到期任务
			WLM_Debug_Logger::log_debug_st( 'WLM daily cronjob - auto expiry of license key is enabled.' );
			WLM_Utility::do_auto_key_expiry();
		}

		//完成任何其他日常任务。

	}

}//End of class
