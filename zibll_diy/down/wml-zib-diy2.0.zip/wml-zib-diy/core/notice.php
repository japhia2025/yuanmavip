<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-09 11:46:22
 $ @ 最后修改: 2024-11-14 16:12:32
 $ @ 文件路径: \wml-zib-diy\core\notice.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化在增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (! defined('ABSPATH')) {
	die;
}
//授权通知
function wml_aut_notice()
{
    if (!WmlAut::is_aut()) {
        echo '
        <div class="notice notice-warning">
        <p style="color:#ff2f86"><span class="dashicons-before dashicons-heart"></span></p>
        <b style="font-size: 1.2em;color:#ff2f86;">欢迎使用外贸DIY增强美化插件</b>
        <p>当前插件还未授权，部分功能无法使用，请在插件设置中进行授权验证</p><p><a class="button button-primary" href="/wp-admin/admin.php?page=wml_zib_diy#tab=%e6%ac%a2%e8%bf%8e%e4%bd%bf%e7%94%a8/%e6%8f%92%e4%bb%b6%e6%8e%88%e6%9d%83">立即授权</a><a style="margin-left: 10px;" class="button" href="https://waimao.la/">访问作者官网</a></p><p></p>
        </div>';
    }
}
add_action('admin_notices', 'wml_aut_notice');


//更新提示
/* function wml_update_notice()
{
    // if (isset($_GET['page']) && 'user_ban' == $_GET['page']) {
    //     return;
    // }
    echo '<div class="notice notice-info is-dismissible">
    <p style="color:#ff2f86"><span class="dashicons-before dashicons-cloud"></span></p>
    <b>Zibll子比主题：</b>检测到主题更新
    <p>当前主题版本：V7.9_beta2，可更新到最新版本：V8.0 </p>
    <p>全新网址导航功能，更强的性能优化，超多的细节优化及bug修复，推荐更新！</p>
    <p><a class="button button-primary" href="https://cs.yuanmavip.com/wp-admin/admin.php?page=zibll_options#tab=%e6%96%87%e6%a1%a3%e6%9b%b4%e6%96%b0">查看更新日志</a></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">忽略此通知。</span></button></div>';
}
add_action('admin_notices', 'wml_update_notice'); */

//功能受限提示
function wml_get_admin_aut_notice(){
    echo '<div class="notice notice-warning"><h2 style="color:#fd4c73;">请完成插件授权后继续使用此功能</h2><p><a class="button button-primary" style="margin: 5px;" href="/wp-admin/admin.php?page=wml_zib_diy#tab=%e6%ac%a2%e8%bf%8e%e4%bd%bf%e7%94%a8/%e6%8f%92%e4%bb%b6%e6%8e%88%e6%9d%83">立即授权</a><a style="margin: 5px;" class="button" href="https://waimao.la/">访问作者官网</a></p></div>';
}

//安装自动授权
function wml_auto_aut()
{
    $auto_key     = '7_7';
    $option       = get_option('wml_auto_aut');
    $option_index = !empty($option[$auto_key]) ? $option[$auto_key] : 0;
    $index        = 1 + 2; //自动尝试的次数

    if (wml_aut_required() && $option_index < $index) {
        $ajax_url = admin_url('admin-ajax.php', 'relative');
        $con      = '<script type="text/javascript">
        (function ($, window, document) {
            $(document).ready(function ($) {
                console.log("开始自动授权验证");
                var html = \'<div><div style="position: fixed;top: 0;right: 0;z-index: 9999999;width: 100%;height: 100%;background: rgba(0, 0, 0, 0.6);"></div><div style="position: fixed;top: 6em;right: -1px;z-index: 10000000;"><div style="background: linear-gradient(135deg,rgb(255, 163, 180),rgb(253, 54, 110));margin-bottom: .6em;color: #fff;padding: 1em 3em;box-shadow: -3px 3px 15px rgba(0, 0, 0, 0.2);" class="a-bg"><i><i class="fa fa-spinner fa-spin fa-fw" style="position: absolute;left: 10px;top: 24px;font-size: 20px;"></i></i><div style="font-size: 1.1em;margin-bottom: 6px;">感谢您使用外贸DIY增强插件</div><div class="a-text">正在为您自动授权，请稍后...</div></div></div></div>\';
                var _html = $(html);
                $("body").append(_html);
                $.post("' . $ajax_url . '", {
                    action: "wml_curl_aut"
                }, function (n) {
                    var msg = n.msg;
                    var error = n.error;
                    _html.find(".a-text").html(msg);
                    if (!error) {
                        _html.find(".a-bg").css("background", "linear-gradient(135deg,rgb(124, 191, 251),rgb(10, 105, 227))");
                    }
                    setTimeout(function () {
                        location.reload();
                    }, 100);
                }, "json");
            });
        })(jQuery, window, document);
        </script>';
        echo $con;
        update_option('wml_auto_aut', [$auto_key => ($option_index + 1)]);
    }
}
add_action('admin_notices', 'wml_auto_aut', 99);

//检查自动授权
function wml_aut_required(){
    if(empty(get_option('wml_aut'))){
        return true;
    }else{
        return false;
    }
}

// 底部添加版权信息，授权后消除
if (!WmlAut::is_aut()) {
    function wml_aut_notices_footer() {
    ?>
    <style>
        .xiaoacao_footer{
            height: 30px;
            line-height: 35px;
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            background-color: darkslategrey;
            color: #fff;
            font-family: Arial;
            font-size: 14px;
            letter-spacing: 1px;
        }
    </style>
    <div class="xiaoacao_footer">
    <!-- <p>Copyright©2024-2025  waimao.la  .All Rights Reserved</p> -->
    <p>本站由  <a href="https://waimao.la" style="color:red;">WaiMao.La</a>  美化强化插件提供支持，正版授权后可去掉该提示。</p>
    </div>
    <?php
    }
    add_action('wp_footer', 'wml_aut_notices_footer');
}

//更新未授权提示
add_action( 'in_plugin_update_message-'.WML_ZIB_DIY_INDEX, 'misha_update_message', 10, 2 );
function misha_update_message( $plugin_info_array, $plugin_info_object ) {
	if( empty( $plugin_info_array[ 'package' ] ) ) {
		echo '<font style="color:#fd4c73;">请进行授权后以获取在线更新的权限。您可以在插件设置中一键授权或输入许可证密钥激活</font>';
	}
}

?>