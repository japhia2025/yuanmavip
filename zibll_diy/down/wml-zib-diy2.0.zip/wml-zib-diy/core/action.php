<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-09 07:35:48
 $ @ 最后修改: 2024-11-14 15:55:37
 $ @ 文件路径: \wml-zib-diy\core\action.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (! defined('ABSPATH')) {
	die;
}

//  在线更新
function wml_detect_update()
{
    // 检查当前用户是否为超级管理员
    if (!current_user_can('manage_options')) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足'));
        wp_die(); // 结束执行
    }
    //echo json_encode(array('error' => true, 'msg' => '已经是最新版本'));//无需更新
    echo json_encode(array('error' => 0, 'reload' => true, 'msg' => '检测到有新版插件更新：'.WML_VERSION.''));//检测到新版本，刷新
    wp_die(); // 结束执行

}
add_action('wp_ajax_wml_detect_update', 'wml_detect_update');

//  授权
function wml_curl_aut()//一键授权/输入授权码
{
    // 检查当前用户是否为超级管理员
    if (!current_user_can('manage_options')) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足'));
        wp_die(); // 结束执行
    }
    global $wpdb;
    $domain=preg_replace('#^(http(s?))?(://)#','', home_url());//域名
    $lickey=$_POST['cut_code']?$_POST['cut_code']:'';
    //请求API接口
    $postdata = array('type'=>'aut','vkey'=>$wpdb->wml_aut_vkey,'domain'=>$domain,'lickey'=>$lickey);
    $ch = curl_init ($wpdb->wml_aut_api);
    curl_setopt ($ch, CURLOPT_POST, true);
    curl_setopt ($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec ($ch);// TODO 执行操作
    //捕抓异常
    if (curl_errno($ch)) {
        echo json_encode(array('error' => true,'ys' => "danger", 'msg' => 'Errno'.curl_error($curl)));
        exit();
    }
    curl_close($ch);// 关闭CURL会话
    if($res){
        $res=json_decode($res);//true数组/对象
        if(empty($res->error)&&!empty($res->license_key)){
            //激活成功，写入数据库
            $key=$res->license_key;
            $t_key=md5('active');
            $s_key=md5('wml_'.$wpdb->wml_aut_vkey.$domain.$res->license_key);
            update_option('wml_aut', ['key' => $key,'t_key' => $t_key,'s_key' => $s_key,'post_key' => 1,'act_date' => time()]);
            echo json_encode(array('error' => 0, 'reload' => true, 'msg' => '恭喜您，授权验证成功'));
        }else{
            echo json_encode($res);
        }
    }else{
        echo json_encode(array('error' => true, 'msg' => '授权验证失败，有问题请联系客服'));
    }
    exit();
}
add_action('wp_ajax_wml_curl_aut', 'wml_curl_aut');

//  撤销授权
function wml_delete_aut()
{
    // 检查当前用户是否为超级管理员
    if (!current_user_can('manage_options')) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足'));
        wp_die(); // 结束执行
    }
    update_option('wml_aut', ['post_key' => 0]);
    echo json_encode(array('error' => 0, 'reload' => true, 'msg' => '授权信息已删除，请刷新页面'));
    wp_die(); // 结束执行

}
add_action('wp_ajax_wml_delete_aut', 'wml_delete_aut');

//备份插件设置
function wml_ajax_options_backup()
{
    $type   = !empty($_REQUEST['type']) ? $_REQUEST['type'] : '手动备份';
    $backup = wml_options_backup($type);
    echo (json_encode(array('error' => 0, 'reload' => 1, 'msg' => '当前配置已经备份')));
    exit();
}
add_action('wp_ajax_wml_options_backup', 'wml_ajax_options_backup');
//删除备份设置
function wml_ajax_options_backup_delete()
{

    if (!is_super_admin()) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足')));
        exit();
    }
    if (empty($_REQUEST['key'])) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '参数传入错误')));
        exit();
    }

    $prefix = 'wml_zib_diy';
    if ('wml_options_backup_delete_all' == $_REQUEST['action']) {
        update_option($prefix . '_backup', false);
        echo (json_encode(array('error' => 0, 'reload' => 1, 'msg' => '已删除全部备份数据')));
        exit();
    }

    $options_backup = get_option($prefix . '_backup');

    if ('wml_options_backup_delete_surplus' == $_REQUEST['action']) {
        if ($options_backup) {
            $options_backup = array_reverse($options_backup);
            update_option($prefix . '_backup', array_reverse(array_slice($options_backup, 0, 3)));
            echo (json_encode(array('error' => 0, 'reload' => 1, 'msg' => '已删除多余备份数据，仅保留最新3份')));
            exit();
        }
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '暂无可删除的数据')));
    }

    if (isset($options_backup[$_REQUEST['key']])) {
        unset($options_backup[$_REQUEST['key']]);

        update_option($prefix . '_backup', $options_backup);
        echo (json_encode(array('error' => 0, 'reload' => 1, 'msg' => '所选备份已删除')));
    } else {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '此备份已删除')));
    }
    exit();
}
add_action('wp_ajax_wml_options_backup_delete', 'wml_ajax_options_backup_delete');
add_action('wp_ajax_wml_options_backup_delete_all', 'wml_ajax_options_backup_delete');
add_action('wp_ajax_wml_options_backup_delete_surplus', 'wml_ajax_options_backup_delete');

//恢复备份设置
function wml_ajax_options_backup_restore()
{
    if (!is_super_admin()) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足')));
        exit();
    }
    if (empty($_REQUEST['key'])) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '参数传入错误')));
        exit();
    }

    $prefix         = 'wml_zib_diy';
    $options_backup = get_option($prefix . '_backup');
    if (isset($options_backup[$_REQUEST['key']]['data'])) {
        update_option($prefix, $options_backup[$_REQUEST['key']]['data']);
        echo (json_encode(array('error' => 0, 'reload' => 1, 'msg' => '主题设置已恢复到所选备份[' . $_REQUEST['key'] . ']')));
    } else {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '备份恢复失败，未找到对应数据')));
    }
    exit();
}
add_action('wp_ajax_wml_options_backup_restore', 'wml_ajax_options_backup_restore');

//导入插件设置
function wml_ajax_options_import()
{
    if (!is_super_admin()) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足')));
        exit();
    }

    $data = !empty($_REQUEST['import_data']) ? $_REQUEST['import_data'] : '';

    if (!$data) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请粘贴需导入配置的json代码')));
        exit();
    }

    $import_data = json_decode(wp_unslash(trim($data)), true);

    if (empty($import_data) || !is_array($import_data)) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => 'json代码格式错误，无法导入')));
        exit();
    }

    wml_options_backup('导入配置 自动备份');

    $prefix = 'wml_zib_diy';
    update_option($prefix, $import_data);
    echo (json_encode(array('error' => 0, 'reload' => 1, 'msg' => '插件设置已导入，请刷新页面')));
    exit();
}
add_action('wp_ajax_wml_options_import', 'wml_ajax_options_import');

//备份插件数据
function wml_options_backup($type = '自动备份')
{
    $prefix  = 'wml_zib_diy';
    $options = get_option($prefix);

    $options_backup = get_option($prefix . '_backup');
    if (!$options_backup) {
        $options_backup = array();
    }

    $time                  = current_time('Y-m-d H:i:s');
    $options_backup[$time] = array(
        'time' => $time,
        'type' => $type,
        'data' => $options,
    );

    //保留20次数据，删除多余的
    if (count($options_backup) > 20) {
        $options_backup = array_slice($options_backup, -20);
    }
    return update_option($prefix . '_backup', $options_backup);
}
function wml_csf_reset_to_backup()
{
    wml_options_backup('重置全部 自动备份');
}
add_action('csf_wml_zib_diy_reset_before', 'wml_csf_reset_to_backup');

function wml_csf_reset_section_to_backup()
{
    wml_options_backup('重置选区 自动备份');
}
add_action('csf_wml_zib_diy_reset_section_before', 'wml_csf_reset_section_to_backup');
//定期自动备份
function wml_csf_save_section_to_backup()
{
    $prefix         = 'wml_zib_diy';
    $options_backup = get_option($prefix . '_backup');
    $time           = false;

    if ($options_backup) {
        $options_backup = array_reverse($options_backup);
        foreach ($options_backup as $key => $val) {
            if ('定期自动备份' == $val['type']) {
                $time = $key;
                break;
            }
        }
    }
    if (!$time || (floor((strtotime(current_time("Y-m-d H:i:s")) - strtotime($time)) / 3600) > 600)) {
        wml_options_backup('定期自动备份');
    }
}
add_action('csf_wml_zib_diy_saved', 'wml_csf_save_section_to_backup');

//插件更新自动备份
function wml_new_to_backup()
{
    $prefix         = 'wml_zib_diy';
    $options_backup = get_option($prefix . '_backup');
    $time           = false;

    if ($options_backup) {
        $options_backup = array_reverse($options_backup);
        foreach ($options_backup as $key => $val) {
            if ('更新插件 自动备份' == $val['type']) {
                $time = $key;
                break;
            }
        }
    }
    if (!$time || (floor((strtotime(current_time("Y-m-d H:i:s")) - strtotime($time)) / 3600) > 240)) {
        wml_options_backup('更新插件 自动备份');
        //更新插件刷新所有缓存
        wp_cache_flush();
    }
}
add_action('wml_update_notices', 'wml_new_to_backup');

function wml_update_cache_flush()
{
    //在线更新插件前，先刷新全部缓存
    wp_cache_flush();
}
add_action('wp_ajax_wml_update_file', 'wml_update_cache_flush', 5);


//  短信部分代码替换
function wml_zib_sms_plugin()
{
    // 检查当前用户是否为超级管理员
    if (!current_user_can('manage_options')) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足'));
        wp_die(); // 结束执行
    }

    // 定义原始文件路径和目标文件路径
    $original_file_path = WML_ZIB_BEAUT_DIR_PATH  . '/core/coppy/sms-class.php';
    $target_file_path = get_template_directory() . '/inc/class/sms-class.php';

    // 尝试替换文件
    if (file_exists($original_file_path) && copy($original_file_path, $target_file_path)) {
        // 刷新所有缓存
        wp_cache_flush();
        echo json_encode(array('error' => 0, 'msg' => '已替换 sms-class.php 验证码功能可用'));
    } else {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '无法替换，存在异常'));
    }

    wp_die(); // 结束执行
}
add_action('wp_ajax_wml_zib_sms', 'wml_zib_sms_plugin');

//  底部页脚功能文件替换
function wml_zib_footer_plugin()
{
    // 检查当前用户是否为超级管理员
    if (!current_user_can('manage_options')) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足'));
        wp_die(); // 结束执行
    }

    //备份原文件
    $bakpath = get_template_directory().'/footer_bak.php';
    if (!file_exists($bakpath)) {
        rename(get_template_directory().'/footer.php',get_template_directory().'/footer_bak.php');
    }

    // 定义原始文件路径和目标文件路径
    $original_file_path = WML_ZIB_BEAUT_DIR_PATH  . '/core/coppy/footer.php';
    $target_file_path = get_template_directory() . '/footer.php';

    // 尝试替换文件
    if (file_exists($original_file_path) && copy($original_file_path, $target_file_path)) {
        // 刷新所有缓存
        wp_cache_flush();
        echo json_encode(array('error' => 0, 'msg' => '已替换 footer.php 页角功能可用'));
    } else {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '无法替换，存在异常'));
    }

    wp_die(); // 结束执行
}
add_action('wp_ajax_wml_zib_footer', 'wml_zib_footer_plugin');

//  底部页脚功能恢复默认
function wml_zib_footers_plugin()
{
    // 检查当前用户是否为超级管理员
    if (!current_user_can('manage_options')) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足'));
        wp_die(); // 结束执行
    }

    //备份原文件
    $bakpath = get_template_directory().'/footer_bak.php';
    if (!file_exists($bakpath)) {
       echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '未作任何改变'));
       wp_die(); // 结束执行
    }

    // 定义原始文件路径和目标文件路径
    $original_file_path = get_template_directory().'/footer_bak.php';
    $target_file_path = get_template_directory() . '/footer.php';

    // 尝试替换文件
    if (file_exists($original_file_path) && copy($original_file_path, $target_file_path)) {
        // 刷新所有缓存
        wp_cache_flush();
        echo json_encode(array('error' => 0, 'msg' => '恢复生效，已使用默认页脚'));
    } else {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '无法恢复，存在异常'));
    }

    wp_die(); // 结束执行
}
add_action('wp_ajax_wml_zib_footers', 'wml_zib_footers_plugin');

//  GO文件替换
function wml_zib_go_plugin()
{
    // 检查当前用户是否为超级管理员
    if (!current_user_can('manage_options')) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足'));
        wp_die(); // 结束执行
    }
    // 检查是否开启
    if (!wml_zib('link_go')) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '功能未开启，请先保存设置再执行此操作'));
        wp_die(); // 结束执行
    }

    $gol=wml_zib('link_go_select');
    if($gol==4){
        $myfile = fopen(WML_ZIB_BEAUT_DIR_PATH.'/core/coppy/go4.php', "w") or die("无法打开文件!");
        $txt = wml_zib('link_go_diy');
        fwrite($myfile, $txt);
        fclose($myfile);
    }

    //备份原文件
    $bakpath = get_template_directory().'/go_bak.php';
    if (!file_exists($bakpath)) {
        rename(get_template_directory().'/go.php',get_template_directory().'/go_bak.php');
    }
    // 定义原始文件路径和目标文件路径
    $original_file_path = WML_ZIB_BEAUT_DIR_PATH . '/core/coppy/go'.$gol.'.php';
    $target_file_path = get_template_directory() . '/go.php';

    // 尝试替换文件
    if (file_exists($original_file_path) && copy($original_file_path, $target_file_path)) {
        // 刷新所有缓存
        wp_cache_flush();
        echo json_encode(array('error' => 0, 'msg' => '已替换成功并生效'));
    } else {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '无法替换，存在异常'));
    }

    wp_die(); // 结束执行
}
add_action('wp_ajax_wml_zib_go', 'wml_zib_go_plugin');

//  GO恢复默认文件
function wml_zib_gos_plugin()
{
    // 检查当前用户是否为超级管理员
    if (!current_user_can('manage_options')) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足'));
        wp_die(); // 结束执行
    }

    //检查原文件是否存在，不存在则无操作
    $bakpath = get_template_directory().'/go_bak.php';
    if (!file_exists($bakpath)) {
       echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '已是系统默认，无需恢复'));
       wp_die(); // 结束执行
    }

    // 定义原始文件路径和目标文件路径
    $original_file_path = get_template_directory().'/go_bak.php';
    $target_file_path = get_template_directory() . '/go.php';

    // 尝试替换文件
    if (file_exists($original_file_path) && copy($original_file_path, $target_file_path)) {
        // 刷新所有缓存
        wp_cache_flush();
        echo json_encode(array('error' => 0, 'msg' => '恢复成功，已使用默认页脚'));
    } else {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '无法恢复，存在异常'));
    }

    wp_die(); // 结束执行
}
add_action('wp_ajax_wml_zib_gos', 'wml_zib_gos_plugin');
?>