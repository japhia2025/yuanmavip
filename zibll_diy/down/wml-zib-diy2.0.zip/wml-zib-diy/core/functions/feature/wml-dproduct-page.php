<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-11 06:35:57
 $ @ 最后修改: 2024-11-11 18:27:59
 $ @ 文件路径: \wml-zib-diy\core\functions\feature\wml-dproduct-page.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

wp_enqueue_style('pay_page', WML_ZIB_BEAUT_DIR_ASSETS.'/css/pay-page.css');

get_header();
global $post;
$pay_mate = get_post_meta($post->ID, 'posts_zibpay', true);

$paybox_args = array(
    'post_id'            => $post->ID,
    'pay_type'           => '15',
    'product_id'         => $post->ID,
    'pay_price'          => $pay_mate['pay_price'],
    'pay_original_price' => $pay_mate['pay_original_price'],
    'pay_download'       => $pay_mate['pay_download'],
    'pay_doc'            => $pay_mate['pay_doc'],
    'pay_slides'         => $pay_mate['pay_slides'],
    'pay_button'         => $pay_mate['pay_button'],
    //'order_name'         => $pay_mate['order_name'],
    'pay_title'          => $pay_mate['pay_title'],
    'pay_details'        => $pay_mate['pay_details'],
    'pay_extra_hide'     => $pay_mate['pay_extra_hide'],
    'rebate_discount'    => '',
);

// 推荐返佣、让利功能
if (_pz('pay_rebate_s')) {
    $referrer_id = zibpay_get_referrer_id();
    if ($referrer_id) {
        //查询到推荐人
        //返利规则
        $rebate_ratio = zibpay_get_user_rebate_rule($referrer_id);
        if (
            !empty($pay_mate['pay_rebate_discount'])
            && $rebate_ratio['type']
            && is_array($rebate_ratio['type'])
            && (in_array('all', $rebate_ratio['type']) || in_array($pay_mate['pay_type'], $rebate_ratio['type']))
        ) {
            // 设置标签文案
            $referrer_data                  = get_userdata($referrer_id);
            $discount_tag                   = _pz('pay_rebate_text_discount');
            $discount_tag                   = str_replace('%discount%', $pay_mate['pay_rebate_discount'], $discount_tag);
            $discount_tag                   = str_replace('%referrer_name%', $referrer_data->display_name, $discount_tag);
            $paybox_args['rebate_discount'] = '<div class="badg badg-lg payvip-icon">' . $discount_tag . '</div>';
        };
    }
}
//echo json_encode($paybox_args);

//倒计时活动标题
//停止时间


function zibllpay_countdown_activity()
{
    global $post, $pay_mate;

    if (empty($pay_mate['stop_time']) || (empty($pay_mate['countdown_activity_title']) && empty($pay_mate['countdown_activity_desc']))) {
        return;
    }

    //对比时间
    $new_time = current_time('Y-m-d H:i:s');
    if (strtotime($new_time) > strtotime($pay_mate['stop_time'])) {
        return;
    }

    $end_time = date("m/d/Y H:i:s", strtotime($pay_mate['stop_time']));

    $html = '<div class="countdown-activity flex jc">';
    $html .= '<div class="activity-content flex ac">';
    $html .= !empty($pay_mate['countdown_activity_title']) ? '<div class="activity-title mr10">' . $pay_mate['countdown_activity_title'] . '</div>' : '';
    $html .= !empty($pay_mate['countdown_activity_desc']) ? '<div class="activity-desc">' . $pay_mate['countdown_activity_desc'] . '</div>' : '';
    $html .= '</div>';

    $html .= '<div class="countdown-content badg jb-yellow radius flex jc">';
    $html .= '<div class="countdown-desc">活动倒计时</div>';
    $html .= '<div class="countdown-time flex0 em09-sm badg jb-vip2 radius" data-over-text="活动已结束" data-newtime="' . $new_time . '" data-countdown="' . $end_time . '">';
    $html .= 'X天X小时X分X秒';
    $html .= '</div>';
    $html .= '</div>';
    $html .= '</div>';
    return $html;
}

/**页面头部卡片 */
function zibllpay_paypage_product_box()
{

    global $post;
    $pay_mate = get_post_meta($post->ID, 'posts_zibpay', true);

    /**初始化默认参数 */
    $defaults = array(
        'post_id'            => '',
        'pay_type'           => '',
        'product_id'         => $post->ID,
        'pay_price'          => 0.01,
        'pay_original_price' => 0,
        'pay_button'         => '',
        'pay_slides'         => '',
        'pay_download'       => '',
        'pay_doc'            => '',
        'order_name'         => '产品购买-' . get_bloginfo('name'),
        'rebate_discount'    => '',
        'pay_title'          => '',
        'pay_details'        => '',
        'pay_extra_hide'     => '',
    );

    $args = wp_parse_args((array) $pay_mate, $defaults);

    /**当前登录用户 */
    $user_id    = get_current_user_id();
    $pay_button = zibpay_get_pay_form_but($pay_mate);

    /**如果未登录则显示登录按钮 */
    $is_pad          = '';
    $rebate_discount = zibpay_get_rebate_discount_tag($post->ID); //推广优惠标签
    $rebate_discount = $rebate_discount ? '<div class="badg badg-lg payvip-icon">' . $rebate_discount . '</div>' : '';

    if (!$user_id) {
        $pay_button = '<a href="javascript:;" class="but jb-red signin-loader"><i class="fa fa-angle-right" aria-hidden="true"></i>登录购买</a>';
    } else {
        /**如果已经登录检测是否已经购买 */
        $is_pad = zibllpay_is_pid_zibll($user_id, $args['product_id']);
    }

    if ($is_pad) {
        /**如果已经购买，购买按钮变为查看订单 */
        $rebate_discount = '';
        $down0=$pay_mate['down0'];
        $down1=$pay_mate['down1'];
        $down2=$pay_mate['down2'];
        $down3=$pay_mate['down3'];
        $pay_button      = '
        <a href="'.$down1.'" class="but jb-yellow"><i class="fa fa-angle-right" aria-hidden="true"></i>'.$down0.'</a>
        <a id="button2" href="'.$down3.'" class="but jb-yellow"><i class="fa fa-angle-right" aria-hidden="true"></i>'.$down2.'</a>
        <span class="but c-white opacity5">已购买</span>       
';
}


if ($args['down4']){} else
{?>
<style>#button2{display:none}</style>
<?php }
    /**幻灯片 */
    $slides_args = array(
    'class'       => 'pay-slides',
    'type'        => '',
    'lazy'        => true,
    'pagination'  => true,
    'effect'      => 'slide',
    'button'      => true,
    'loop'        => true,
    'auto_height' => false,
    'echo'        => false,
);

$slides_args['slides'] = array();
if ($args['pay_slides']) {
    $slides_obj = explode(",", $args['pay_slides']);
    foreach ($slides_obj as $id) {
        if (!$id) {
            continue;
        }
        $url = wp_get_attachment_url($id);  // 通过ID获取图片URL
        if($url){
            $slide = array('image' => $url);  // 用URL替代ID传入数组
            $slides_args['slides'][] = $slide;
        }
    }
}
$slides_con = zib_get_img_slider($slides_args);



/**幻灯片下方按钮 */
$s_button = '';
if ($args['pay_button']) {
    foreach ($args['pay_button'] as $button) {
        $b_link    = $button['button_link'];
        $b_name    = !empty($button['button_text']) ? $button['button_text'] : $b_link;

        $s_button .= '<a target="_self" class="but hollow c-white" href="' . $b_link . '">' . $b_name . '</a>';
    }
}


    /**开始创建html内容 */
    $con = '';

    $price_html = zibpay_get_show_price($pay_mate);

    $con .= '<div class="product-container" style="opacity: 0;">';
    
    if ($args['pay_countdown_price']){
    $con .= zibllpay_countdown_activity();
    }
    $con .= '<div class="product-box relative">';
    $con .= '<div class="product-background absolute" style="background:var(--linear-bg-' . (mt_rand(1, 10)) . (wp_is_mobile() ? 'm' : '') . '); "></div>';
    $con .= '<div class="product-row relative">';
    $con .= '<div class="payrow-6 payrow-left">';
    $con .= $slides_con;
    $con .= '<div class="more-but text-center">';
    $con .= $s_button;
    $con .= '</div>';

    $con .= '</div>';

    $con .= '<div class="payrow-6 payrow-right">';
    $con .= '<div class="pay-content">';

    $con .= '<div class="product-header">' . $args['pay_title'] . '</div>';
    $con .= '<div class="product-doc">' . $args['pay_doc'] . '</div>';

    $con .= $price_html;
    $con .= $rebate_discount;

    $con .= '<form class="pay-form">
            <div class="product-pay">' . $pay_button . '
            </div>
            </form>';
    $con .= '<div class="product-details box-body radius8">' . $args['pay_details'] . '</div>';

    $con .= '</div>';
    $con .= '</div>';

    $con .= '</div>';
    $con .= '</div>';
    $con .= '</div>';

    return $con;
}

?>
<main role="main">
    <?php echo zibllpay_paypage_product_box($paybox_args) ?>
    <div class="container">
        <?php while (have_posts()) : the_post(); ?>
            <div class="theme-box article-content">
                <article class="article wp-posts-content">
                    <?php the_content(); ?>
                </article>
            </div>
        <?php endwhile; ?>

    </div>
</main>

<?php

get_footer();