<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-11 06:30:17
 $ @ 最后修改: 2024-11-12 17:34:14
 $ @ 文件路径: \wml-zib-diy\core\functions\feature\wml-dproduct.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (wml_zib('dproduct',false)) {

    add_filter( 'plugin_action_links', 'zibllpay_plugins', 10, 5 );
    function zibllpay_plugins( $actions, $plugin_file ) 
    {
       static $plugin;
       if (!isset($plugin))
            $plugin = plugin_basename(__FILE__);
       if ($plugin == $plugin_file) {
       }
       return $actions;
    }
    
    define('zibllpay_url', plugins_url('', __FILE__));
    
    //添加页面meta
    function zibllpay_add_meta_box_meta($meta)
    {
        $meta['post_type'] = array('post', 'page');
        return $meta;
    }
    add_filter('zib_add_pay_meta_box_meta', 'zibllpay_add_meta_box_meta');
    function zibllpay_add_meta_box_args($args)
    {
        $post_id   = !empty($_GET['post']) ? $_GET['post'] : '';
        $post_type = !empty($_GET['post_type']) ? $_GET['post_type'] : get_post_type($post_id);
        if ($post_type == 'page') {
            $args[0] = array(
                'title'   => '页面购买',
                'id'      => 'pay_type',
                'type'    => 'radio',
                'default' => 'no',
                'desc' => '仿子比主题购买页面，开启后上方设置的页面内容将显示在购买区块下方',
                'inline'  => true,
                'options' => array(
                    'no' => __('关闭', 'zib_language'),
                    15    => __('开启', 'zib_language'),
                ),
            );
            $args[] = array(
                'dependency' => array('pay_type', '==', '15'),
                'title'      => __('', 'zib_language'),
                'id'         => 'product_id1',
                'type'       => 'submessage',
                'class'      => 'mini pay-hide',
                'content' => '<h4>内容配置</h4>
                    <p style="color:#fb2121;background:undefined">商品名称、介绍、更多详情为必填项，请务必填写</p>',
            );
            $args[] = array(
                'dependency' => array('pay_type', '==', '15'),
                'title'      => __('幻灯片', 'zib_language'),
                'id'         => 'pay_slides',
                'desc'       => __('并注意保持图片尺寸一致', 'zib_language'),
                'class'      => 'pay-hide',
                'default'    => '',
                'type'       => 'gallery',
            );
            $args[] = array(
                'dependency' => array('pay_type', '==', '15'),
                'title'      => __('幻灯片下方按钮', 'zib_language'),
                'id'         => 'pay_button',
                'desc'       => __('幻灯片底部按钮', 'zib_language'),
                'class'      => 'pay-hide',
                'default'    => '',
                'type'       => 'group',
                'fields'       => array(
                    array(
                        'title'       => __('文字', 'zib_language'),
                        'id'          => 'button_text',
                        'placeholder' => '输入按钮文字',
                        'preview'     => false,
                        'type'        => 'text',
                    ),
                    array(
                        'title'       => __('链接', 'zib_language'),
                        'id'          => 'button_link',
                        'placeholder' => '输入链接',
                        'preview'     => false,
                        'type'        => 'text',
                    ),
                    ),
            );
            $args[] = array(
                'dependency' => array('pay_type', '==', '15'),
                'id'         => 'pay_countdown_price',
                'title'      => __('限时活动', 'zib_language'),
                'desc'       => __('可开启限时活动折扣倒计时', 'zib_language'),
                'default'    => '',
                'type'       => 'switcher',
            );
            $args[] = array(
                'dependency' => array('pay_countdown_price',  '!=', ''),
                'title'      => __(' ', 'zib_language'),
                'subtitle'   => __('限时活动标题', 'zib_language'),
                'id'         => 'countdown_activity_title',
                'class'      => 'pay-hide',
                'default'    => '',
                'type'       => 'text',
            );
            $args[] = array(
                'dependency' => array('pay_countdown_price', '!=', ''),
                'title'      => ' ',
                'subtitle'   => __('限时活动简介', 'zib_language'),
                'id'         => 'countdown_activity_desc',
                'class'      => 'pay-hide compact',
                'default'    => '',
                'type'       => 'textarea',
            );
            $args[] = array(
                'dependency' => array('pay_countdown_price', '!=', ''),
                'title'      => ' ',
                'subtitle'   => __('限时结束时间', 'zib_language'),
                'class'      => 'pay-hide compact',
                'id'         => 'stop_time',
                'type'       => 'date',
                'default'    => '',
                'settings'   => array(
                    'dateFormat'  => 'yy-mm-dd 23:59:59',
                    'changeMonth' => true,
                    'changeYear'  => true,
                ),
            );
            $args[] = array(
                'title'   => __('按钮一文字', 'zib_language'),
                'dependency' => array('pay_type', '==', '15'),
                'desc'       => __('请填写按钮一文字，如：“授权管理”，用户支付成功后方可显示', 'zib_language'),
                'class'      => 'pay-hide',
                'id'         => 'down0',
                'type'       => 'text',
                'default'    => '授权管理',
            );
            $args[] = array(
                'title'   => __('按钮一链接', 'zib_language'),
                'dependency' => array('pay_type', '==', '15'),
                'desc'       => __('请填写按钮一链接，用户支付成功后方可显示', 'zib_language'),
                'class'      => 'pay-hide compact',
                'id'         => 'down1',
                'type'       => 'text',
                'default'    => '',
            );
            $args[] = array(
                'title'   => __('开启第二个按钮', 'zib_language'),
                'dependency' => array('pay_type', '==', '15'),
                'desc'       => __('开启后请配置第二个要显示的按钮', 'zib_language'),
                'class'      => 'pay-hide compact',
                'id'         => 'down4',
                'type'       => 'switcher',
                'default'    => '',
            );
            $args[] = array(
                'title'   => __('按钮二文字', 'zib_language'),
                'dependency' => array('down4', '!=', ''),
                'desc'       => __('请填写按钮二文字，如：“点击授权”，用户支付成功后方可显示', 'zib_language'),
                'class'      => 'pay-hide compact',
                'id'         => 'down2',
                'type'       => 'text',
                'default'    => '资源下载',
            );
            $args[] = array(
                'title'   => __('按钮二链接', 'zib_language'),
                'dependency' => array('down4', '!=', ''),
                'desc'       => __('请填写按钮二链接，用户支付成功后方可显示', 'zib_language'),
                'class'      => 'pay-hide compact',
                'id'         => 'down3',
                'type'       => 'text',
                'default'    => '',
            );
        }
        return $args;
    }
    //添加文章付费参数
    add_filter('zib_add_pay_meta_box_args', 'zibllpay_add_meta_box_args', 99999);
    
    
    function zibllpay_add_bodyclass($class)
    {
        $class .= ' order-pay';
        return $class;
    }
    
    /** 加载模板页面 */
    add_action('template_redirect', 'zibllpay_page_template_1', 5);
    function zibllpay_page_template_1($original_template)
    {
        global $post;
        if (!empty($post->ID) && is_page()) {
            $pay_mate = get_post_meta($post->ID, 'posts_zibpay', true);
            if ($pay_mate && 15 == $pay_mate['pay_type']) {
                add_filter('zib_add_bodyclass', 'zibllpay_add_bodyclass', 10, 2);
                add_filter('template_include', 'zibllpay_page_template');
            }
        }
    }
    
    function zibllpay_page_template($original_template)
    {
        return dirname(__FILE__).'/wml-dproduct-page.php';
    }
    
    /**判断是否购买 */
    function zibllpay_is_pid_zibll($user_id, $product_id)
    {
        if (!$user_id || !$product_id) {
            return false;
        }
    
        global $wpdb;
        $db_order = $wpdb->get_results("SELECT * FROM $wpdb->zibpay_order WHERE `status` = 1 and `user_id` = $user_id  and `post_id` = $product_id ");
    
        if ($db_order) {
            return $db_order;
        } else {
            return false;
        }
    }
}

//用户中心
include 'wml-dproduct-user.php';

?>