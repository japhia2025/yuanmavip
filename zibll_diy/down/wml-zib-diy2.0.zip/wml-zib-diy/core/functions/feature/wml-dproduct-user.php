<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-12 16:28:48
 $ @ 最后修改: 2024-11-14 14:24:20
 $ @ 文件路径: \wml-zib-diy\core\functions\feature\wml-dproduct-user.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (WmlAut::is_aut()) {//正版授权可用

//是否开启接口
if (wml_zib('dproduct_api', false)&&wml_zib('dproduct',false)){
    add_action('zibpay_initiate_pay', 'wml_zibpay_initiate_pay');//支付成功触发
}
function wml_zibpay_initiate_pay($initiate_pay)//支付成功触发
{
    if (!empty($initiate_pay)&&$initiate_pay['payok']==1) {
        $postdata = $initiate_pay;
        $postdata['type'] = 'pay';
        $postdata['key'] = wml_zib('dproduct_api_key');
        $order_num=$postdata['order_num'];

        //获取订单的商品文章ID和标题
        global $wpdb;
        $db_order = $wpdb->get_row("SELECT post_id FROM $wpdb->zibpay_order WHERE `order_num` = $order_num");
        if (false !== $db_order) {
            echo json_encode(array('error' => true, 'ys' => 'danger', 'msg' => '订单不存在，非法操作'));
        }
        $postdata['product_ref'] = get_the_title($db_order->post_id);

        $ch = curl_init (wml_zib('dproduct_api_url'));
        curl_setopt ($ch, CURLOPT_POST, true);
        curl_setopt ($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
        $res = curl_exec ($ch);// !执行操作
        //捕抓异常
        if (curl_errno($ch)) {
            echo json_encode(array('error' => true,'ys' => "danger", 'msg' => 'Errno'.curl_error($curl)));
        }
        curl_close($ch);// 关闭CURL会话
        if($res){
            echo $res;//返回错误信息
        }
    }
}

//用户中心
if(wml_zib('dproduct_user',false)){
    add_filter( 'user_center_page_sidebar', 'wml_user_center_page_sidebar'); //会员页面添加授权按钮
    add_filter( 'user_ctnter_main_tabs_array', 'wml_user_ctnter_main_tabs_array'); //用户中心授权TAB，99优先在前面
    add_filter('main_user_tab_content_product', 'zib_main_user_tab_content_product');//用户中心显示认证页面内容
}
function wml_user_center_page_sidebar()//会员页面添加授权按钮
{
    $url="data-onclick=\"[data-target='#user-tab-product']\"";
    $cont='<div class="colorful-bg jb-cyan zib-widget mb10-sm" '.$url.'><div class="colorful-make" style="transform: rotate(-28deg) scale(.8);"></div><div class="flex ab c jsb"><div class=""><div class="flex ac"><b class="em14">'.wml_zib('dproduct_user_name').'</b></div><div style="" class="em09 opacity8">'.wml_zib('dproduct_user_info').'</div><a href="javascript:;" class="mt6 but radius  jb-cyan px12 p2-10">'.wml_zib('dproduct_user_button').'<i style="margin:0 0 0 6px;" class="fa fa-angle-right em12"></i></a></div><span class="avatar-img mr10 mt3" style="--this-size: 59px;"><img alt="'.wml_zib('dproduct_user_name').'" src="'.wml_zib('dproduct_user_logo').'" class="avatar"></span></div></div>';
    return $cont;
}

//用户中心授权TAB
function wml_user_ctnter_main_tabs_array($tabs_array)
{
    $tabs = array();
    $tabs['product'] = array(
        'title'    => wml_zib('dproduct_user_button'),
        'nav_attr' => 'drawer-title="'.wml_zib('dproduct_user_button').'"',
        'loader'   => '<div class="zib-widget"><i class="placeholder s1"></i><p class="placeholder t1"></p>
        <p style="height: 110px;" class="placeholder k1"></p><p class="placeholder k2"></p><p style="height: 110px;" class="placeholder k1"></p><p class="placeholder t1"></p><i class="placeholder s1"></i><i class="placeholder s1 ml10"></i></div>',
    );
    if ($tabs) {
        return $tabs + $tabs_array;
    }
    return $tabs_array;
}

//用户中心显示认证页面内容
function zib_main_user_tab_content_product()
{
    global $wpdb;
    $user_id=get_current_user_id();//用户ID
    $post_id=wml_zib('dproduct_user_sid');//指定文章ID
    $db_order = $wpdb->get_row("SELECT * FROM $wpdb->zibpay_order where `status` = 1 and `user_id` = $user_id and `post_id` = $post_id");
    if ($db_order) {
        $pay_mate = get_post_meta($post_id, 'posts_zibpay', true);
        $get_permalink = get_permalink($post_id);
        $posts_title = get_the_title($post_id);
        $pay_title = !empty($pay_mate['pay_title']) ? $pay_mate['pay_title'] : $posts_title;
        $order_num=$db_order->order_num;//订单号

        $html='<div class="zib-widget pay-box">';
        $html.='<div class="pay-tag abs-center" style="left: auto;right: 0;border-radius: 0 var(--main-radius) 0 var(--main-radius);">订单信息</div>';
        $html.='<div>';
        $html.='<div class="mb6"><b><a target="_blank" href="'.$get_permalink.'">'.$pay_title.'</a></b></div>';
        $html.='<div class="meta-time em09 muted-2-color" title="点击复制订单号" data-clipboard-text="'.$order_num.'" data-clipboard-tag="订单号">订单号：<i class="fa fa-files-o mr3"></i>'.$order_num.'</div>';
        $html.=' <dd class="meta-time em09 muted-2-color">付款时间：'.$db_order->pay_time.'<span class="pull-right em12"><span class="pay-mark">价格：￥</span>'.$pay_mate['pay_original_price'].'<span class="pay-mark ml10">实付金额：</span><span class="pay-mark">￥</span>'.$db_order->order_price.'</span></dd>';
        $html.='</div>';
        $html.='</div>';
    }else{
        return zib_get_ajax_ajaxpager_one_centent('<div class="zib-widget">暂无订单和相关信息</div>');
    }
    //授权信息
    if(wml_zib('dproduct_user_aut',false)){
        //请求API接口
        $postdata = array('type'=>'info','key'=>wml_zib('dproduct_api_key'),'user_id'=>$user_id,'order_num'=>$order_num);
        $ch = curl_init (wml_zib('dproduct_api_url'));
        curl_setopt ($ch, CURLOPT_POST, true);
        curl_setopt ($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
        $res = curl_exec ($ch);// TODO 执行操作
        //捕抓异常
        if (curl_errno($ch)) {
            echo json_encode(array('error' => true,'ys' => "danger", 'msg' => 'Errno'.curl_error($curl)));
            exit();
        }
        curl_close($ch);// 关闭CURL会话
        if($res){
            //获取成功
            $res=json_decode($res);//true数组/对象
            if(!empty($res->error)){
                //获取失败
                echo zib_get_ajax_ajaxpager_one_centent('<div class="zib-widget">'.$res->msg.'</div>');
            }else{
                $html .='<script type=\'text/javascript\' src=\''.WML_ZIB_BEAUT_DIR_ASSETS.'/js/pay-api.js\'></script>';
                $html .= '<div class="zib-widget pay-box">';
                $html .= '<div class="pay-tag abs-center" style="left: auto;right: 0;border-radius: 0 var(--main-radius) 0 var(--main-radius);">授权信息</div>';
                $html .= '<div>';
                $html .= '<div class="box-body theme-box"><div class="c-red mb10"><i class="fa fa-diamond em12 mr10"></i><b>正版授权</b></div><div class="muted-2-color em09">您当前可授权<span class="badg c-red badg-sm">'.$res->max_allowed_domains.'</span>个域名，已授权<span class="badg badg-sm c-red">'.$res->dom_count.'</span>个域名，如需更多域名授权，请与客服联系</div></div>';
                
                $html .= '<form class="abs-right" style="top: 10px;right: 77px;"><a href="javascript:;" style="padding: 5px 10px 2px;border-radius: 0 0 8px 8px;--this-bg: rgba(77, 130, 249, .1);" class="but c-blue-2 em09 refresh-autordery" title="" data-original-title="刷新授权数据"><i class="fa fa-refresh" aria-hidden="true"></i>刷新授权</a><input type="hidden" name="aut_code" value="'.$res->license_key.'"><input type="hidden" name="order_num" value="'.$order_num.'"></form>';//javascript:location.reload();
    
                $html .= '<div class="mb10"><div class="author-set-left">授权码</div><div class="author-set-right"><b data-clipboard-tag="授权码" data-clipboard-text="c0619fa29e5aa189c6d1bf5a604786d4" class="but c-red clip-aut mr10 mb6">'.$res->license_key.'</b><a data-clipboard-tag="授权码" data-clipboard-text="'.$res->license_key.'" class="clip-aut mb6 but c-yellow">复制授权码</a></div></div>';
                if($res->lic_status=='pending'){
                    $lic_status='<font color="green">正在空闲</font>';
                }elseif($res->lic_status=='active'){
                    $lic_status='<font color="blue">正在使用</font>';
                }elseif($res->lic_status=='blocked'){
                    $lic_status='<font color="red">已被封锁</font>';
                }elseif($res->lic_status=='expired'){
                    $lic_status='<del><font color="gray">过期失效</font></del>';
                }
                $html .= '<div class="mb10"><div class="author-set-left">当前状态</div><div class="author-set-right"><span class="badg">'.$lic_status.'</span></div></div>';
                $html .= '<div class="mb10"><div class="author-set-left">有效时间</div><div class="author-set-right"><span class="badg">'.$res->date_expiry.'</span></div></div>';
                $html .= '<div class="mb10"><div class="author-set-left">验证类型</div><div class="author-set-right"><span class="badg">授权码+域名验证</span></div></div>';
                $html .= '<div class="mb10"><div class="author-set-left">授权域名</div><div class="author-set-right">';
                //绑定域名列表
                if(!empty($res->registered_domain)){
                    foreach($res->registered_domain as $val) {
                        $html .= '<span class="badg mr6 mb6 c-blue">'.$val.'</span>';
                    }
                }
                $html .= '</div></div><div class="text-center mt10 mb10">';
                $html .= '<a mobile-bottom="true" data-height="400" data-remote="/wp-admin/admin-ajax.php?action=wml_aut_replace_modal&amp;order_num='.$order_num.'" class="but mm3 padding-lg jb-yellow" href="javascript:;" data-toggle="RefreshModal">更换授权域名</a>';
                $html .= '<a mobile-bottom="true" data-height="400" data-remote="/wp-admin/admin-ajax.php?action=wml_aut_add_modal&amp;order_num='.$order_num.'" class="but mm3 padding-lg jb-blue" href="javascript:;" data-toggle="RefreshModal">添加授权域名</a>';
                $html .= '</div></div></div>';
            }
        }else{
            //获取失败
            echo zib_get_ajax_ajaxpager_one_centent('<div class="zib-widget">获取授权信息出错</div>');
        }
    }
    
    //底部信息
    $html .= '<div class="zib-widget pay-box">';
    $html .= '<div class="pay-tag abs-center" style="left: auto;right: 0;border-radius: 0 var(--main-radius) 0 var(--main-radius);">资源下载</div>';
    //下载信息
    $html .= '<div class="theme-box"><div><div class="flex ac hh">';
    if(wml_zib('dproduct_user_down')){
        foreach(wml_zib('dproduct_user_down') as $val) {
            $html .= '<div class="but-download flex ac"><a target="'.$val['link']['target'].'" href="'.$val['link']['url'].'" class="mr10 but jb-cyan"><i class="fa fa-download" aria-hidden="true"></i>'.$val['name'].'</a><span class="badg">'.$val['info'].'</span></div>';
        }
    }
    $html .= '</div></div></div>';
    //使用说明
    $html .= '<div class="pay-extra-hide"><div class="flex hh ac jsa">';
    $html .= '<div class="mt10 mr20">';
    $html .= '<div class="ml20">';
    $html .= wml_zib('dproduct_user_text');
    $html .= '</div>';
    //扫码加群
    if(wml_zib('dproduct_user_kf')){
        foreach(wml_zib('dproduct_user_kf') as $val) {
            $html .= '<div class="text-center mt20 flex0">';
            $html .= '<div class="c-yellow "><img src="'.$val['img'].'" style="width: 100px"></div>';
            $html .= '<div class="mt10">'.$val['name'].'<div class=""><a target="'.$val['link']['target'].'" class="c-yellow" href="'.$val['link']['url'].'">'.$val['link']['text'].'</a></div>';
            $html .= '</div>';
            $html .= '</div>';
        }
    }

    $html .= '</div></div>';
    $html .= '</div>';

    return zib_get_ajax_ajaxpager_one_centent($html);
}

//刷新授权
function zib_ajax_wml_refresh_autordery()
{
    //$html = '{"msg":"操作过于频繁，请60秒后再试","key":"api_replace_aut","args":39398,"error":true,"ys":"danger"}';

    //请求API接口
    $order_num=$_POST['order_num'];$aut_code=$_POST['aut_code'];$user_id=get_current_user_id();
    $postdata = array('type'=>'reload','key'=>wml_zib('dproduct_api_key'),'user_id'=>$user_id,'order_num'=>$order_num,'aut_code'=>$aut_code);
    $ch = curl_init (wml_zib('dproduct_api_url'));
    curl_setopt ($ch, CURLOPT_POST, true);
    curl_setopt ($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec ($ch);// TODO 执行操作
    //捕抓异常
    if (curl_errno($ch)) {
        echo json_encode(array('error' => true,'ys' => "danger", 'msg' => 'Errno'.curl_error($curl)));
        exit();
    }
    curl_close($ch);// 关闭CURL会话
    if($res){
        echo $res;
    }else{
        echo json_encode(array('error' => true, 'ys' => 'danger', 'msg' => '请求出错，非法操作'));
    }
    exit(); // 结束执行
}
add_action('wp_ajax_wml_refresh_autordery', 'zib_ajax_wml_refresh_autordery');

//添加域名前检测
function wml_aut_add_modal(){
    //请求API接口
    $order_num=$_GET['order_num'];$user_id=get_current_user_id();
    $postdata = array('type'=>'addins','key'=>wml_zib('dproduct_api_key'),'user_id'=>$user_id,'order_num'=>$order_num);
    $ch = curl_init (wml_zib('dproduct_api_url'));
    curl_setopt ($ch, CURLOPT_POST, true);
    curl_setopt ($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec ($ch);// TODO 执行操作
    //捕抓异常
    if (curl_errno($ch)) {
        echo json_encode(array('error' => true,'ys' => "danger", 'msg' => 'Errno'.curl_error($curl)));
        exit();
    }
    curl_close($ch);// 关闭CURL会话
    if($res){
        $res=json_decode($res);//true数组/对象
        if(empty($res->error)){
            $html='<div class="mb10 touch"><div class="mr10 inflex em12"><svg class="em14 mr10" aria-hidden="true"><use xlink:href="#icon-vip_2"></use></svg><b>添加授权</b></div>';
            $html.='<button class="close" data-dismiss="modal"><svg class="ic-close" aria-hidden="true"><use xlink:href="#icon-close"></use></svg></button></div>';
            $html.='<div class="padding-10">';
            $html.='<p class="muted-2-color">添加授权域名前，请先阅读详细</p>';
            $html.='<ul class="muted-2-color theme-box">';
            $html.='<li class="c-red" style="--this-color: #f737a3;"><i class="fa fa-info-circle mr6"></i>授权仅限本人使用，添加非本人名下域名将做封号处理</li>';
            $html.='<li class="c-red"><i class="fa fa-info-circle mr6"></i>添加后的域名不能删除，但支持不限次数免费更换</li>';
            $html.='<li class="c-red" style="--this-color: #ff6643;"><i class="fa fa-info-circle mr6"></i>如考虑到可能会更换域名请注意在域名过期前提前更换</li>';
            $html.='</ul>';
            $html.='<div class="muted-color">域名示例:</div>';
            $html.='<ul class="muted-2-color theme-box"><li>授权顶级域名：waimao.la</li><li>授权二级域名：blog.waimao.la</li><li>如果是中文域名，请输入转码后的域名</li><li>如果有任何疑问，请与客服联系</li></ul>';
            $html.='<form><div class="mb10">';
            $html.='<input class="form-control" name="add_domain" type="text" placeholder="请输入授权域名">';
            $html.='</div><div class="box-body text-center nobottom">';
            $html.='<input type="hidden" name="action" value="wml_add_api_aut">';
            $html.='<input type="hidden" name="user_id" value="'.$user_id.'">';
            $html.='<input type="hidden" name="order_num" value="'.$order_num.'">';
            $html.='<button type="button" zibajax="submit" class="but jb-blue radius btn-block padding-lg" name="submit">';
            $html.='<i class="fa fa-check mr10"></i>确认提交</button>';
            $html.='</div></form>';
            $html.='</div>';
        }else{
            $html='<div class="mr10 inflex em12"><svg class="em14 mr10" aria-hidden="true"><use xlink:href="#icon-vip_2"></use></svg><b>'.$res->msg.'</b></div>';
        }
    }else{
        $html='<div class="mr10 inflex em12"><svg class="em14 mr10" aria-hidden="true"><use xlink:href="#icon-vip_2"></use></svg><b>非法操作，请联系客服</b></div>';
    }
    echo $html;
    exit(); // 结束执行
}
add_action('wp_ajax_wml_aut_add_modal', 'wml_aut_add_modal');

//添加域名
function wml_add_api_aut(){
    //请求API接口
    $add_domain=$_POST['add_domain'];
    if(empty($add_domain)||wml_CheckUrl($add_domain)===false){
        echo json_encode(array('error' => true, 'msg' => '域名为空或格式不对，请重新输入'));
        exit(); // 结束执行
    }
    $order_num=$_POST['order_num'];
    $user_id=get_current_user_id();
    $postdata = array('type'=>'add','key'=>wml_zib('dproduct_api_key'),'user_id'=>$user_id,'order_num'=>$order_num,'add_domain'=>$add_domain,'item'=>wml_zib('dproduct_user_name'));
    $ch = curl_init (wml_zib('dproduct_api_url'));
    curl_setopt ($ch, CURLOPT_POST, true);
    curl_setopt ($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec ($ch);// TODO 执行操作
    //捕抓异常
    if (curl_errno($ch)) {
        echo json_encode(array('error' => true,'ys' => "danger", 'msg' => 'Errno'.curl_error($curl)));
        exit(); //结束执行
    }
    curl_close($ch);// 关闭CURL会话
    if($res){
        $html=$res;
    }else{
        $html=json_encode(array('error' => true, 'msg' => '参数错误，有问题请联系客服'));
    }
    echo $html;
}
add_action('wp_ajax_wml_add_api_aut', 'wml_add_api_aut');

//更换域名
function wml_aut_replace_modal()
{
    //请求API接口
    $order_num=$_GET['order_num'];$user_id=get_current_user_id();
    $postdata = array('type'=>'replaceins','key'=>wml_zib('dproduct_api_key'),'user_id'=>$user_id,'order_num'=>$order_num);
    $ch = curl_init (wml_zib('dproduct_api_url'));
    curl_setopt ($ch, CURLOPT_POST, true);
    curl_setopt ($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec ($ch);// TODO 执行操作
    //捕抓异常
    if (curl_errno($ch)) {
        echo json_encode(array('error' => true,'ys' => "danger", 'msg' => 'Errno'.curl_error($curl)));
        exit();
    }
    curl_close($ch);// 关闭CURL会话
    if($res){
        $res=json_decode($res);//true数组/对象
        if(empty($res->error)){
            $rhtml='<div class="c-red mb10"><i class="fa fa-info-circle mr6"></i>抱歉，您当前还有<span style="min-width: 1.5em;" class="badg badg-sm c-yellow">'.$res->msg.'</span>个授权名额未使用，请先添加使用</div><div style="max-width: 300px;margin: auto"><a mobile-bottom="true" data-height="400" data-remote="/wp-admin/admin-ajax.php?action=wml_aut_add_modal&#038;order_num='.$order_num.'" class="but jb-blue radius btn-block padding-lg" href="javascript:;" data-toggle="RefreshModal">添加授权域名</a></div>';
        }else{
            $rhtml='<div class="c-red mb10"><i class="fa fa-info-circle mr6"></i>'.$res->msg.'</div>';
        }
    }else{
        $rhtml='<div class="c-red mb10"><i class="fa fa-info-circle mr6"></i>抱歉，暂不支持在线更换域名功能，请联系客服辅助更换。</div>';
    }
    $html='<div class="mb10 touch"><div class="mr10 inflex em12"><svg class="em14 mr10" aria-hidden="true"><use xlink:href="#icon-vip_2"></use></svg><b>更换授权</b></div>';
    $html.='<button class="close" data-dismiss="modal"><svg class="ic-close" aria-hidden="true"><use xlink:href="#icon-close"></use></svg></button></div>';
    $html.='<div class="padding-10"><div class="muted-color">更换要求及说明:</div><ul class="muted-2-color theme-box">';
    $html.='<li class="c-red" style="--this-color: #f737a3;"><i class="fa fa-info-circle mr6"></i>授权域名名额添加完之后才能更换域名</li>';
    $html.='<li class="c-red"><i class="fa fa-info-circle mr6"></i>更换前域名和新域名所有人为同一人</li>';
    $html.='<li class="c-red" style="--this-color: #ff6643;"><i class="fa fa-info-circle mr6"></i>或者更换前域名和新域名拥有者为同一人</li>';
    $html.='<li class="mb10 em09">如果系统自动审核失败，请准备相关截图及待更换的域名与QQ客服联系</li>';
    $html.='<li class=""><div class="text-center hide-sm" style="width: 120px;"><img src="https://assets.waimao.la/img/kf_qq.jpg"><div class="px12">扫码联系QQ客服</div></div>';
    $html.='<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=181682245&site=qq&menu=yes" class="but c-blue show-sm"><i class="fa fa-wechat"></i>点击联系QQ客服</a></li></ul>';
    $html.='<div class="">';
    $html.=$rhtml;
    $html.='</div></div>';
    echo $html;
    exit(); // 结束执行
}
add_action('wp_ajax_wml_aut_replace_modal', 'wml_aut_replace_modal');

//检测域名格式
function wml_CheckUrl($C_url){
    $str="/^\w+[^\s]+(\.[^\s]+){1,}$/";
    //$str="/^(?=^.{3,255}$)[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+$/";
    if (!preg_match($str,$C_url)){
        return false;
    }else{
	    return true;
    }
}
}
?>