<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 19:49:46
 $ @ 文件路径: \wml-zib-diy\core\functions\feature\wml-language.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

//翻译总开关
if (wml_zib('language_switch', false)) {

    // 注册翻译头部
    add_action('wp_head', 'fy_head');
    function fy_head(){?>
        <style>
            /*css样式*/
            .ignore:hover{color:var(--theme-color);transition:color .2s,transform .3s;}#translate {display:none;}.dropdown-menu a:hover{
            /*翻译鼠标移动缩进*/
           transform: translateX(5px);}
       </style>
        <script src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS.'/js/translate.min.js' ?>"></script>
    <?php }

    // 注册翻译底部
    add_action('wp_footer', 'fy_footer');
    function fy_footer(){?>
        <script>
            translate.setAutoDiscriminateLocalLanguage(); 
            translate.language.setLocal('chinese_simplified'); 
            translate.service.use('client.edge'); 
            function executeTranslation() {
                translate.execute();
            }
            executeTranslation();
            $(document).ajaxComplete(function() {
                executeTranslation();
            });
        </script>
    <?php }

    function wml_zib_language_switch($original_content, $user_id){?>
        <?php
        $new_button='';
        //按钮图标
        if (wml_zib('language_icon_c', false)) {
            $icon=wml_zib('language_icon_c');
        }elseif(wml_zib('language_icon', false)){
            $icon='<i class="'.wml_zib('language_icon').'"></i>';
        }else{
            $icon='<i class="fa fa-language"></i>';
        }
        $new_button.='
            <span class="hover-show inline-block ml10">
            <a href="javascript:translate.changeLanguage(\''.wml_zib('language_default').'\');" rel="external nofollow"  rel="external nofollow"  class="toggle-radius">
            '.$icon.'
            </a>
            <div class="hover-show-con dropdown-menu drop-newadd">';
        $list=wml_zib('language');
        if(!empty($list)){
            $l_list=CSF_Module_Wml_Zib::language();
            //遍历数组
            foreach($l_list as $vo) {
                $l_v[$vo['id']]['name']=$vo['name'];
                $l_v[$vo['id']]['value']=$vo['value'];
                $l_v[$vo['id']]['serviceid']=$vo['serviceId'];
            }
            //print_r($v);
            foreach($list as $value) {
                if(!empty($value['language_id_switch'])){
                    //语言图标
                    if (!empty($value['language_svg'])) {
                        $svg=$value['language_svg'];
                    }elseif(!empty($value['language_img'])){
                        $svg='<img src="'.$value['language_img'].'" width="22" height="22">';
                    }
                    $new_button.='
                    <a rel="nofollow" class="btn-newadd" href="javascript:translate.changeLanguage(\''.$value['language_id'].'\');" rel="external nofollow" >
                    <icon class="c-red">'.$svg.'
                    </icon>
                    <text class="ignore">'.$l_v[$value['language_id']]['name'].'</text>
                    </a>';
                }
                //$language[$value['id']]=$value['name'].'('.$value['value'].')';//创建新数组
            }
        }
        $new_button.='
          </div>
        </span>';
        // 将原始内容和新按钮结合
        $modified_content = $original_content . $new_button;

        // 返回修改后的内容
        return $modified_content;
    }
    //add_action('wp_footer', 'wml_zib_language_switch');
    add_filter('zib_nav_radius_button', 'wml_zib_language_switch', 10, 2);//翻译结束
    //add_filter('wp_kses_allowed_html', 'zib_allow_html_precode_attributes', 99, 2);
}
