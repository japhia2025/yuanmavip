<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 21:42:45
 $ @ 文件路径: \wml-zib-diy\core\functions\beautify\wml-all.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

//门铃声
if (wml_zib('myaudio', false)) {
    function wml_zib_myaudio()
    {
        $type = wml_zib('myaudio_t'); //样式
        if($type=='1'){
        ?>
        <script>
            const shToneurl = "<?php echo WML_ZIB_BEAUT_DIR_ASSETS;?>/audio/myaudio1.mp3";
            document.addEventListener("DOMContentLoaded", function () {
            const shToneaudio = new Audio(shToneurl);
                shToneaudio.play();
            });
        </script>
    <?php }else{ ?>
        <!--自动一声-->
        <audio id="myaudio" src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS;?>/audio/myaudio2.mp3" acontrols="controls" autoplay="autoplay" hidden="true"></audio>
    <?php }
    }
    add_action('wp_footer', 'wml_zib_myaudio');
}

//纵向滚动条
if (wml_zib('scrollbar', false)) {
    function wml_zib_scrollbar()
    {
        $type = wml_zib('scrollbar_r'); //样式
        if ($type=='1') {//红色滚动条 ?>
            <style>
                 ::-webkit-scrollbar-thumb{background-color:#FF6666;height:50px;outline-offset:-2px;outline:2px solid #fff;-webkit-border-radius:4px;border: 2px solid #fff;}::-webkit-scrollbar{width:8px;height:8px;}::-webkit-scrollbar-track-piece{background-color:#fff;-webkit-border-radius:0;}
            </style>
        <?php }
        elseif ($type=='2') {//双色滚动条 ?>
            <style>
                 ::-webkit-scrollbar {width: 10px;height: 1px;}::-webkit-scrollbar-thumb {background-color: #12b7f5;background-image: -webkit-linear-gradient(45deg, rgba(255, 93, 143, 1) 25%, transparent 25%, transparent 50%, rgba(255, 93, 143, 1) 50%, rgba(255, 93, 143, 1) 75%, transparent 75%, transparent);}::-webkit-scrollbar-track {-webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);background: #f6f6f6;}
            </style>
        <?php }
        elseif ($type=='3') {//彩色滚动条 ?>
            <style>::-webkit-scrollbar{width:6px;height:1px}::-webkit-scrollbar-thumb{background-color:#07e6f6;background-image:-webkit-linear-gradient(45deg,rgb(236,174,6)25%,transparent 25%,transparent 50%,rgb(10,77,246)50%,rgb(241,9,28)75%,transparent 75%,transparent)}::-webkit-scrollbar-track{background:white;border-radius:20px}</style>
        <?php }
    }
    add_action('wp_footer', 'wml_zib_scrollbar');
}

//右侧悬浮按钮图片
if (wml_zib('suspension', false))
{
    function wml_zib_suspension() { ?>
        <style>
            span.float-btn.more-btn.hover-show.nowave {margin-top: 0 }.float-right.round.position-bottom {background: #fff;border-radius: var(--main-radius);transition: 0s;right: 1px;bottom: 170px;border-radius: 20px 0 0 20px;box-shadow: -5px 3px 10px 0 rgb(5 5 5 / 15%) }.float-right.round .float-btn {border-radius: 8px 0 0 17px }.float-right .float-btn {background: #fff }.float-right.round.position-bottom::before {content: '';width: 30px;height: 60px;background: url(<?php echo wml_zib('suspension_img') ?>);background-size: cover;display: block;margin: 5px 3px 0 7px;}.dark-theme .float-right.round.position-bottom {background: #414141;border: 1px solid #4a4a4a;transition: 0s }.dark-theme .float-right .float-btn {background: #414141 }.dark-theme .float-right.round.position-bottom a:hover {background: #505255;--this-color: var(--muted-2-color) }.dark-theme .float-right.round.position-bottom span:hover {background: #505255;--this-color: var(--muted-2-color) }span.newadd-btns.hover-show.float-btn.add-btn .hover-show-con.dropdown-menu.drop-newadd>a:hover {background-color: #d8d8d836;border-radius: 8px }a.float-btn.ontop.fade {display: none }
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_suspension');
}

// 顶部横向彩色滚动条
if (wml_zib('level_scrollbar', false))
{
    function wml_zib_level_scrollbar() { ?>
        <style>#percentageCounter{position:fixed; left:0; top:0; height:3px; z-index:99999; background-image: linear-gradient(to right, #339933,#FF6666);border-radius:5px;}</style>
        <script>$('head').before('<div id="percentageCounter"></div>');$(window).scroll(function() {var a = $(window).scrollTop(),c = $(document).height(),b = $(window).height();scrollPercent = a / (c - b) * 100;scrollPercent = scrollPercent.toFixed(1);$("#percentageCounter").css({width: scrollPercent + "%"});}).trigger("scroll");</script>
    <?php }
    add_action('wp_footer', 'wml_zib_level_scrollbar');
}

// 翻页按钮美化
if (wml_zib('fanye', false))
{
    function wml_zib_fanye() { ?>
        <style>
            /*翻页按钮*/
            .pagenav .current {
                background: linear-gradient(90deg, #7de4d7 0%, #ff89ee 100%);
                color: #fff !important;
            }
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_fanye');
}

//开屏元神动画
if (wml_zib('yuanshen', false))
{
    function wml_zib_yuanshen() { ?>
        <style>
            body:after {content: " ";position: fixed;inset: 0;background-color: white;z-index: 999;background-image: url(<?php echo wml_zib('yuanshen_img') ?>);background-repeat: no-repeat;background-position: center;background-size: 30%;animation: fadeOut 3s;animation-fill-mode: forwards;-webkit-transition: fadeOut 3s;transition: fadeOut 3s;pointer-events: none;}@keyframes fadeOut {50% {opacity: 1;}100% {opacity: 0;}}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_yuanshen');
}

//会员购买弹窗底部小图
if (wml_zib('bilibili', false))
{
    function wml_zib_bilibili() { ?>
        <style>
            .payvip-modal {background-image: url(<?php echo WML_ZIB_BEAUT_DIR_ASSETS . 'img/index/22_open.png' ?>), url(<?php echo WML_ZIB_BEAUT_DIR_ASSETS . 'img/index/33_open.png' ?>);background-position: 0 100%, 100% 100%;background-repeat: no-repeat, no-repeat;background-size: 20%;}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_bilibili');
}

//浪漫樱花特效
if (wml_zib('drift_down', false)) {
    function wml_zib_drift_down()
    {
        $type = wml_zib('drift_down_r'); //样式
        if ($type=='1') {//浪漫樱花特效 ?>
            <script src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/js/yinghua.js' ?>"></script>
        <?php }
        elseif ($type=='2') {//枫叶飘落特效 ?>
            <script src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/js/fengye.js' ?>"></script>
        <?php }
        elseif ($type=='3') {//雪花飘落特效 ?>
            <script src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/js/xuehua.js' ?>"></script>
        <?php }
    }
    add_action('wp_footer', 'wml_zib_drift_down');
}

//浪漫樱花特效
if (wml_zib('dynamic_bj', false)) {
    function wml_zib_dynamic_bj()
    {
        $type = wml_zib('dynamic_bj_r'); //样式
        if ($type=='1') {//浪漫樱花特效 ?>
            <div id="bubble"><canvas width="1494" height="815" style="display: block; position: fixed; top: 0px; left: 0px; z-index: -2;"></canvas></div>
            <script>
                class BGBubble{constructor(i){this.defaultOpts={id:"",num:20,start_probability:.1,radius_min:1,radius_max:2,radius_add_min:.3,radius_add_max:.5,opacity_min:.3,opacity_max:.5,opacity_prev_min:.003,opacity_prev_max:.005,light_min:40,light_max:70,is_same_color:!1,background:"#f1f3f4"},"[object Object]"==Object.prototype.toString.call(i)?this.userOpts={...this.defaultOpts,...i}:this.userOpts={...this.defaultOpts,id:i},this.color=this.random(0,360),this.bubbleNum=[],this.requestAnimationFrame=window.requestAnimationFrame||window.mozRequestAnimationFrame||window.webkitRequestAnimationFrame||window.msRequestAnimationFrame,this.cancelAnimationFrame=window.cancelAnimationFrame||window.mozCancelAnimationFrame}random(i,t){return Math.random()*(t-i)+i}initBubble(i,t){const a=window.innerWidth,s=window.innerHeight,n=this.userOpts,e=this.random(n.light_min,n.light_max);this.bubble={x:this.random(0,a),y:this.random(0,s),radius:this.random(n.radius_min,n.radius_max),radiusChange:this.random(n.radius_add_min,n.radius_add_max),opacity:this.random(n.opacity_min,n.opacity_max),opacityChange:this.random(n.opacity_prev_min,n.opacity_prev_max),light:e,color:`hsl(${t?i:this.random(0,360)},100%,${e}%)`}}bubbling(i,t,a){!this.bubble&&this.initBubble(t,a);const s=this.bubble;i.fillStyle=s.color,i.globalAlpha=s.opacity,i.beginPath(),i.arc(s.x,s.y,s.radius,0,2*Math.PI,!0),i.closePath(),i.fill(),i.globalAlpha=1,s.opacity-=s.opacityChange,s.radius+=s.radiusChange,s.opacity<=0&&this.initBubble(t,a)}createCanvas(){this.canvas=document.createElement("canvas"),this.ctx=this.canvas.getContext("2d"),this.canvas.style.display="block",this.canvas.width=window.innerWidth,this.canvas.height=window.innerHeight,this.canvas.style.position="fixed",this.canvas.style.top="0",this.canvas.style.left="0",this.canvas.style.zIndex="-1",document.getElementById(this.userOpts.id).appendChild(this.canvas),window.onresize=(()=>{this.canvas.width=window.innerWidth,this.canvas.height=window.innerHeight})}start(){const i=window.innerWidth,t=window.innerHeight;this.color+=.1,this.ctx.fillStyle=this.defaultOpts.background,this.ctx.fillRect(0,0,i,t),this.bubbleNum.length<this.userOpts.num&&Math.random()<this.userOpts.start_probability&&this.bubbleNum.push(new BGBubble),this.bubbleNum.forEach(i=>i.bubbling(this.ctx,this.color,this.userOpts.is_same_color));const a=this.requestAnimationFrame;this.myReq=a(()=>this.start())}destory(){(0,this.cancelAnimationFrame)(this.myReq),window.onresize=null}}const bubbleDemo=new BGBubble("bubble");function nofind(){var i=event.srcElement;i.src="",i.onerror=null}bubbleDemo.createCanvas(),bubbleDemo.start();
            </script>
        <?php }
        elseif ($type=='2') {//枫叶飘落特效 ?>
            <div class="mouse-cursor cursor-outer"></div><div class="mouse-cursor cursor-inner"></div>
        <script src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/js/lizi_shubiao.js' ?>"></script>
        <style>.mouse-cursor{position:fixed;left:0;top:0;pointer-events:none;border-radius:50%;-webkit-transform:translateZ(0);transform:translateZ(0);visibility:hidden}.cursor-inner{margin-left:-3px;margin-top:-3px;width:6px;height:6px;z-index:10000001;background:transparent;-webkit-transition:width.3s ease-in-out,height.3s ease-in-out,margin.3s ease-in-out,opacity.3s ease-in-out;transition:width.3s ease-in-out,height.3s ease-in-out,margin.3s ease-in-out,opacity.3s ease-in-out}.cursor-inner.cursor-hover{margin-left:-18px;margin-top:-18px;width:36px;height:36px;background:transparent;opacity:.3}.cursor-outer{margin-left:-15px;margin-top:-15px;width:30px;height:30px;border:2px solid transparent;-webkit-box-sizing:border-box;box-sizing:border-box;z-index:10000000;opacity:.5;-webkit-transition:all.08s ease-out;transition:all.08s ease-out}.cursor-outer.cursor-hover{opacity:0}.main-wrapper[data-magic-cursor=hide].mouse-cursor{display:none;opacity:0;visibility:hidden;position:absolute;z-index:-1111}</style><script src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/js/lizi.js' ?>"></script>
        <?php }
        elseif ($type=='3') {//雪花飘落特效 ?>
            <link rel="stylesheet" href="<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/css/yuansufuhao.css' ?>" />
            <script>
                $('head').before('<div class="container1"><div class="inner-container1"><div class="shape"></div></div><div class="inner-container1"><div class="shape"></div></div></div>');
            </script>
            <script src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/js/yuansufuhao.min.js' ?>"></script>
            <script>
                $(document).ready(function() {
                    var html = '';
                    for (var i = 1; i <= 50; i++) {
                        html += '<div class="shape-container--' + i + ' shape-animation"><div class="random-shape"></div></div>'
                    }
                    document.querySelector('.shape').innerHTML += html
                });
            </script>
            </script>
        <?php }
    }
    add_action('wp_footer', 'wml_zib_dynamic_bj');
}

// 全局灰色主题
if (wml_zib('site_gray'))
{
    function wml_zib_site_gray() { ?>
        <style>
            html {
                -webkit-filter: grayscale(100%);
                filter: grayscale(100%);
            }
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_site_gray');
}

// 网站时段问候语
if (wml_zib('wml_Togreet'))
{
    function wml_zib_wml_Togreet() { ?>
        <div class="dimmer"></div>
        <style>
            #landlord .landlord-close {opacity: 0;visibility: hidden;width: 20px;height: 20px;line-height: 20px;background: rgb(0, 0, 0);text-align: center;color: #fff;position: absolute;top: 3px;right: 0;border-radius: 50%;font-size: 10px;cursor: pointer;z-index: 1;transition: .2s;}#landlord {user-select: none;position: fixed;left: 30px;bottom: 150px;z-index: 10000;font-size: 0;transition: all .3s ease-in-out;}#landlord .message {opacity: 0;width: 172px;height: auto;margin: auto;padding: 7px;top: -200px;left: -20px;text-align: center;color: #fff;border-radius: 12px;background-color: #0005;box-shadow: 0 3px 15px 2px #eae6e6;font-size: 13px;font-weight: 400;text-overflow: ellipsis;text-transform: uppercase;overflow: hidden;position: absolute;}@media (max-width: 767px) {#landlord .message {display: none;}}
            </style>
            <div id="landlord" style="display: block;">
                <span class="landlord-close iconfont icon-guanbi"
                    onclick="$(&#39;#landlord&#39;).hide();$(&#39;#flost-landlord&#39;).show();"></span>
                <div class="message" style="opacity: 1;"><?php echo wml_zib('wml_huanying_text'); ?></div>
            </div>
            <script type="text/javascript">
            jQuery(function () {
                var text;
                var now = (new Date()).getHours();
                if (now > 24 || now <= 5) {
                    text = '<?php echo wml_zib('wml_wuye_text'); ?>';
                } else if (now > 5 && now <= 10) {
                    text = '<?php echo wml_zib('wml_zaoshang_down'); ?>';
                } else if (now > 10 && now <= 12) {
                    text = '<?php echo wml_zib('wml_shangwu_down'); ?>';
                } else if (now > 12 && now <= 14) {
                    text = '<?php echo wml_zib('wml_zhongwu_down'); ?>';
                } else if (now > 14 && now <= 17) {
                    text = '<?php echo wml_zib('wml_xiawu_down'); ?>';
                } else if (now > 17 && now <= 19) {
                    text = '<?php echo wml_zib('wml_bangwan_texte'); ?>';
                } else if (now > 19 && now <= 21) {
                    text = '<?php echo wml_zib('wml_yewan_link'); ?>';
                } else if (now > 21 && now <= 24) {
                    text = '<?php echo wml_zib('wml_xiuxi_down'); ?>';
                }
                showMessage(text, 12000);
            });
            function showMessage(text, timeout) {
                if (Array.isArray(text)) text = text[Math.floor(Math.random() * text.length + 1) - 1];
                //console.log('showMessage', text);
                $('.message').stop();
                if (text != undefined) {
                     $('.message').html(text).fadeTo(200, 1);
                }
                if (timeout === null) timeout = 6000;
                hideMessage(timeout);
            }
            function hideMessage(timeout) {
                $('.message').stop().css('opacity', 1);
                if (timeout === null) timeout = 6000;
                $('.message').delay(timeout).fadeTo(200, 0);
            }
        </script>
    <?php }
    add_action('wp_footer', 'wml_zib_wml_Togreet');
}

//自定义背景图片
if (wml_zib('wml_diy_bg', false))
{
    function wml_diy_bg() { ?>
        <style>
            /***日间主题模式***/
            body {
                background-image: url("<?php echo wml_zib('wml_diy_bg_r');?>");/**这里改为你自己的图片地址**/
                background-position-x: center;
                background-position-y: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }
            /***夜间主题模式***/
            .dark-theme {
                background-image: url("<?php echo wml_zib('wml_diy_bg_y');?>");/**这里改为你自己的图片地址**/
                background-position-x: center;
                background-position-y: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }
        </style>
    <?php }
    add_action('wp_footer', 'wml_diy_bg');
}