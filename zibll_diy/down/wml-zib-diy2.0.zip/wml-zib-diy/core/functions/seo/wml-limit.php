<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-17 00:02:09
 $ @ 最后修改: 2024-11-14 18:48:01
 $ @ 文件路径: \wml-zib-diy\core\functions\seo\wml-limit.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

function wml_zib_regxz() {
    //注册用户名限制总开关
    if (wml_zib('regxz_is', false)){
        $username = $_POST['name'];//用户名
        if(wml_zib('regxz_type')==1){//禁用模式
            $type = wml_zib('regxz_jz'); //功能
            if($type){
                if (in_array("kg", $type)) {//空格
                    if (preg_match("/\s/", $username)) {
                        echo (json_encode(array('error' => 1, 'msg' => '用户名不允许包含空格')));
                        exit();
                    }
                }
                if (in_array("zw", $type)) {//中文
                    if (preg_match('/[\x{4e00}-\x{9fa5}]+/u', $username)) {// /[\x7f-\xff]/
                        echo (json_encode(array('error' => 1, 'msg' => '用户名不允许包含中文')));
                        exit();
                    }
                }
                if (in_array("dx", $type)) {//大写
                    if (preg_match('/[A-Z]/', $username)) {
                        echo (json_encode(array('error' => 1, 'msg' => '用户名不允许包含大写')));
                        exit();
                    }
                }
                if (in_array("xh", $type)) {//下划线
                    if(str_replace("_", "", $username) != $username) {
                        echo (json_encode(array('error' => 1, 'msg' => '用户名不允许下划线')));
                        exit();
                    }
                }
                if (in_array("fh", $type)) {//特殊符号
                    if (preg_match("/\/|\~|\!|\@|\#|\\$|\%|\^|\&|\*|\(|\)|\（|\）|\_|\+|\{|\}|\:|\<|\>|\?|\[|\]|\,|\.|\/|\;|\'|\`|\-|\=|\\\|\||\s+/", $username)) {
                        echo (json_encode(array('error' => 1, 'msg' => '用户名不允许包含特殊符号')));
                        exit();
                    }
                }
            }
        }else{
            $type = wml_zib('regxz_yx'); //功能
            if ($type==1) {//字母
                if (!preg_match('/^[a-zA-Z]*$/', $username)) {
                    echo (json_encode(array('error' => 1, 'msg' => '用户名只允许字母')));
                    exit();
                }
            }elseif ($type==2) {//字母+数字
                if (!preg_match('/^[a-zA-Z0-9]*$/', $username)) {
                    echo (json_encode(array('error' => 1, 'msg' => '用户名只允许字母+数字')));
                    exit();
                }
            }elseif ($type==3) {//字母+数字+下划线
                if (!preg_match('/^[A-Za-z0-9_]+$/u', $username)) {
                    echo (json_encode(array('error' => 1, 'msg' => '用户名只允许字母+数字+下划线')));
                    exit();
                }
            }elseif ($type==4) {//字母+数字+下划线+中文
                if (!preg_match('/^[\x{4e00}-\x{9fa5}A-Za-z0-9_]+$/u', $username)) {
                    echo (json_encode(array('error' => 1, 'msg' => '用户名只允许字母+数字+下划线+中文')));
                    exit();
                }
            }elseif ($type==5) {//小写字母
                if (!preg_match('/^[a-z]*$/', $username)) {
                    echo (json_encode(array('error' => 1, 'msg' => '用户名只允许小写字母')));
                    exit();
                }
            }elseif ($type==6) {//小写字母+数字
                if (!preg_match('/^[a-z0-9]*$/', $username)) {
                    echo (json_encode(array('error' => 1, 'msg' => '用户名只允许小写字母+数字')));
                    exit();
                }
            }elseif ($type==7) {//小写字母+数字+下划线
                if (!preg_match('/^[a-z0-9_]+$/u', $username)) {
                    echo (json_encode(array('error' => 1, 'msg' => '用户名只允许小写字母+数字+下划线')));
                    exit();
                }
            }elseif ($type==8) {//小写字母+数字+下划线+中文
                if (!preg_match('/^[\x{4e00}-\x{9fa5}a-z0-9_]+$/u', $username)) {
                    echo (json_encode(array('error' => 1, 'msg' => '用户名只允许小写字母+数字+下划线+中文')));
                    exit();
                }
            }elseif ($type==9) {//仅中文
                if (!preg_match('/^[\x{4e00}-\x{9fa5}]+$/u', $username)) {
                    echo (json_encode(array('error' => 1, 'msg' => '用户名只允许中文')));
                    exit();
                }
            }
        }
        //判断首个字母
        if (wml_zib('regxz_szm', false)){
            if (!preg_match('/^[a-zA-Z]*$/', substr($username, 0, 1))) {
                echo (json_encode(array('error' => 1, 'msg' => '首字字符必须字母')));
                exit();
            }
        }
        //自定义保留的用户名关键词
        if (wml_zib('regxz_diy')){
            $regxz_diy = wml_zib('regxz_diy');
            $regxz_diy = preg_split("/,|，|\s|\n/", $regxz_diy);
            if ($regxz_diy && $username) {
                foreach ($regxz_diy as $keyword) {
                    if ($keyword && (stristr($username, $keyword) || $keyword == $username)) {
                        echo (json_encode(array('error' => 1, 'msg' => '用户名含保留或非法字符')));
                        exit();
                    }
                }
            }
        }
    }
    //密码限制
    if (wml_zib('regxz_p_is', false)){
        $password = $_POST['password2'];
        if ( strlen( $password ) < wml_zib('regxz_p_length') ) {
            echo (json_encode(array('error' => 1, 'msg' => '密码长度至少为 '.wml_zib('regxz_p_length').' 位。')));
            exit();
        }
        
        $type = wml_zib('regxz_p_jz'); //功能
        if($type){
            if(in_array("dx", $type)){
                if (! preg_match( '/[A-Z]/', $password ) ) {
                    echo (json_encode(array('error' => 1, 'msg' => '密码必须包含大写字母。')));
                    exit();
                }
            }
            if(in_array("xx", $type)){
                if (! preg_match( '/[a-z]/', $password ) ) {
                    echo (json_encode(array('error' => 1, 'msg' => '密码必须包含小写字母。')));
                    exit();
                }
            }
            if(in_array("sz", $type)){
                if (! preg_match( '/[0-9]/', $password ) ) {
                    echo (json_encode(array('error' => 1, 'msg' => '密码必须包含数字。')));
                    exit();
                }
            }
            if(in_array("fh", $type)){
                if (! preg_match( '/[^a-zA-Z0-9]/', $password ) ) {
                    echo (json_encode(array('error' => 1, 'msg' => '密码必须包含特殊字符。')));
                    exit();
                }
            }
        }
        //自定义保留的用户名关键词
        if (wml_zib('regxz_p_diy')){
            $regxz_diy = wml_zib('regxz_p_diy');
            $regxz_diy = preg_split("/,|，|\s|\n/", $regxz_diy);
            if ($regxz_diy && $password) {
                foreach ($regxz_diy as $keyword) {
                    if ($keyword && $keyword == $password) {
                        echo (json_encode(array('error' => 1, 'msg' => '无法使用不安全的密码，请重新输入')));
                        exit();
                    }
                }
            }
        }
    }
}
add_action('wp_ajax_user_signup', 'wml_zib_regxz', 9, 3);
add_action('wp_ajax_nopriv_user_signup', 'wml_zib_regxz', 9, 3);

//游客搜索限制
if (wml_zib('so_youke_is', false)){
    if(wml_zib('so_youke_type')==1){
        //禁止游客身份使用搜索功能
        function disable_search_for_guests() {
            if (!is_user_logged_in() && is_search()) {
                //wp_redirect(home_url());//跳转到首页
                //exit;
                // 获取 WordPress 头部
                get_header();        
                // 显示错误消息
                echo '<div class="class="zib-widget ajaxpager search-content type-post">';
                echo '<div class="text-center ajax-item " style="padding:140px 0;">';
                echo '<img style="width:380px;opacity: .7;" src="/wp-content/themes/zibll/img/null-search.svg">';
                echo '<div style="padding:10px 0;"><h1>搜索限制</h1></div>';               
                echo '<p style="margin-top:20px;" class="em09 muted-3-color separator">禁止游客使用该功能，请登陆后操作</p>';
                echo '</div>';        
                echo '</div>';    
                // 获取 WordPress 尾部
                get_footer();
                exit; // 确保后续代码不被执行
            }
        }
        add_action('template_redirect', 'disable_search_for_guests');
    }else{
        //设限游客身份5分钟使用一次搜索功能
        function limit_search_for_guests() {
            if (!is_user_logged_in() && is_search()) {
                $last_search_time = get_transient('last_search_time');
                $current_time = time();
                
                if (!$last_search_time || ($current_time - $last_search_time) > wml_zib('so_youke_time')*60) {
                    set_transient('last_search_time', $current_time, wml_zib('so_youke_time')*60);
                } else {
                    //wp_redirect(home_url());//跳转到首页
                    //exit();
                    // 获取 WordPress 头部
                    get_header();        
                    // 显示错误消息
                    echo '<div class="class="zib-widget ajaxpager search-content type-post">';
                    echo '<div class="text-center ajax-item " style="padding:140px 0;">';
                    echo '<img style="width:380px;opacity: .7;" src="/wp-content/themes/zibll/img/null-search.svg">';
                    echo '<div style="padding:10px 0;"><h1>搜索限制</h1></div>';               
                    echo '<p style="margin-top:20px;" class="em09 muted-3-color separator">限制游客每 '.wml_zib('so_youke_time').' 分钟只能使用1次，请登陆后操作</p>';
                    echo '</div>';        
                    echo '</div>';    
                    // 获取 WordPress 尾部
                    get_footer();
                    exit; // 确保后续代码不被执行
                }
            }
        }
        add_action('template_redirect', 'limit_search_for_guests');
    }
}

//搜索伪静态
if (wml_zib('so_whtml_is', false)){
    function wml_plugin_modify_search_link() {
        if (is_search() && !empty($_GET['s'])) {
            $search_query = urlencode(get_query_var('s'));
            $url = home_url("/search/{$search_query}");
            wp_redirect($url);
            exit();
        }
    }
    add_action('template_redirect', 'wml_plugin_modify_search_link');
}

//防止外部恶意搜索
if (wml_zib('so_feyi_is', false)){
    function wml_so_redirect_to_baidu() {
        if (isset($_GET['wd'])) {
            wp_redirect('https://www.baidu.com/s?wd=' . urlencode($_GET['wd']));
            exit;
        }
    }
    add_action('init', 'wml_so_redirect_to_baidu');
}

//自定义屏蔽关键字
if (wml_zib('so_ban_is', false)){
    add_action('template_redirect', 'wml_so_search_ban');
    function wml_so_search_ban() {
        if (is_search()) {
            if (wml_zib('so_ban_diy')){
                global $wp_query;
                $BanKey = preg_split("/,|，|\s|\n/", wml_zib('so_ban_diy'));
                $S_Key = $wp_query->query_vars;
                if ($BanKey) {
                    foreach ($BanKey as $Key) {
                        if (stristr($S_Key['s'], $Key) != false) {
                            wp_die('请不要搜索非法关键字，请返回重新输入 <a href="/">返回首页</a>');
                            exit();
                        }
                    }
                }
            }
        }
    }
}

if (wml_zib('so_pinlv_is', false)){
    /** 限制的搜索频次  */
    function limit_search_frequency() {
        // 如果当前页面不是搜索页面，则不进行频次限制
        if (!is_search()) {
            return;
        }

        // 设置限制的搜索频次
        $search_frequency = wml_zib('so_pinlv_cs'); // 每分钟允许的搜索请求次数

        // 检查用户角色
        $user = wp_get_current_user();
        $user_roles = $user->roles;

        // 如果用户角色包含管理员角色，则不进行频次限制
        if (in_array('administrator', $user_roles)) {
            return;
        }

        // 获取当前时间戳
        $current_time = time();

        // 获取存储搜索请求次数和时间戳的 cookie 键名
        $cookie_name = 'search_frequency';
        $cookie_data = isset($_COOKIE[$cookie_name]) ? json_decode(stripslashes($_COOKIE[$cookie_name]), true) : array();

        // 如果没有 cookie 数据，则创建一个新的
        if (empty($cookie_data)) {
            $cookie_data = array(
                'timestamp' => $current_time,
                'count' => 1
            );
            $count = 1;
            setcookie($cookie_name, json_encode($cookie_data), $current_time + 60, '/');
        } else {
            // 如果存在 cookie 数据，则更新时间戳和搜索请求次数
            $timestamp = $cookie_data['timestamp'];
            $count = $cookie_data['count'];

            // 如果当前时间戳与上次搜索的时间戳之差大于 60 秒，则重置搜索请求次数为 1，并更新时间戳
            if (($current_time - $timestamp) > 60) {
                $count = 1;
                $timestamp = $current_time;
            } else {
                // 否则，递增搜索请求次数
                $count++;
            }

            // 更新 cookie 数据
            $cookie_data = array(
                'timestamp' => $timestamp,
                'count' => $count
            );
            setcookie($cookie_name, json_encode($cookie_data), $current_time + 60, '/');
        }

        // 搜索请求次数超过限制，则显示错误信息
        if ($count > $search_frequency) {
            // 获取 WordPress 头部
            get_header();        
            // 显示错误消息
            echo '<div class="class="zib-widget ajaxpager search-content type-post">';
            echo '<div class="text-center ajax-item " style="padding:140px 0;">';
            echo '<img style="width:380px;opacity: .7;" src="/wp-content/themes/zibll/img/null-search.svg">';
            echo '<div style="padding:10px 0;"><h1>搜索限制</h1></div>';               
            echo '<p style="margin-top:20px;" class="em09 muted-3-color separator">搜索频率为每分钟 '.wml_zib('so_pinlv_cs').' 次，请 60 秒后再尝试其他操作</p>';
            echo '</div>';        
            echo '</div>';    
            // 获取 WordPress 尾部
            get_footer();
            exit; // 确保后续代码不被执行
        }
    }
    // 在 WordPress 的"wp"挂钩上执行搜索频率限制检查
    add_action('wp', 'limit_search_frequency');
}
?>