<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 19:56:56
 $ @ 文件路径: \wml-zib-diy\core\functions\diy\wml-diy.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

// 压缩 CSS 的函数
function minify_css($css) {
    $css = preg_replace('#/\*.*?\*/#s', '', $css);
    $css = preg_replace('/\s*([{}|:;,])\s*/', '$1', $css);
    $css = preg_replace('/\s\s+(.*)/', '$1', $css);
    return trim($css);
}

// 输出自定义 CSS 和 JS 代码
add_action('wp_enqueue_scripts', 'wml_enqueue_custom_css_js');
function wml_enqueue_custom_css_js() {
    $options = get_option('wml_zib_diy');
    $custom_css = '';
    
    // 处理 CSS 代码
    if (isset($options['css_group']) && !empty($options['css_group'])) {
        foreach ($options['css_group'] as $css) {
            if (isset($css['css_switcher']) && $css['css_switcher'] && !empty($css['css_code'])) {
                $custom_css .= minify_css($css['css_code']) . "\n";
            }
        }
        if (!empty($custom_css)) {
            wp_register_style('custom-inline-css', false);
            wp_enqueue_style('custom-inline-css');
            wp_add_inline_style('custom-inline-css', $custom_css);
        }
    }
}

// 输出自定义 JS 和 HTML 代码
add_action('wp_footer', 'wml_output_custom_js_html', 100);
function wml_output_custom_js_html() {
    $options = get_option('wml_zib_diy');
    
    // 处理 JS 代码
    if (isset($options['javascript_group']) && !empty($options['javascript_group'])) {
        echo '<script>';
        foreach ($options['javascript_group'] as $js) {
            if (isset($js['javascript_switcher']) && $js['javascript_switcher'] && !empty($js['javascript_code'])) {
                echo html_entity_decode(wp_kses_post($js['javascript_code'])) . "\n";
            }
        }
        echo '</script>';
    }

    // 处理位于 footer 的 HTML 代码
    if (isset($options['html_group']) && !empty($options['html_group'])) {
        foreach ($options['html_group'] as $html) {
            if (isset($html['html_switcher']) && $html['html_switcher'] && $html['html_locate'] === 'footer' && !empty($html['html_code'])) {
                echo html_entity_decode(wp_kses_post($html['html_code'])) . "\n";
            }
        }
    }
}

// 输出位于 head 的 HTML 代码
add_action('wp_head', 'wml_output_html_code_head');
function wml_output_html_code_head() {
    $options = get_option('wml_zib_diy');
    
    if (isset($options['html_group']) && !empty($options['html_group'])) {
        foreach ($options['html_group'] as $html) {
            if (isset($html['html_switcher']) && $html['html_switcher'] && $html['html_locate'] === 'head' && !empty($html['html_code'])) {
                echo html_entity_decode(wp_kses_post($html['html_code'])) . "\n";
            }
        }
    }
}