<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-01 15:52:49
 $ @ 最后修改: 2024-11-14 08:48:40
 $ @ 文件路径: \wml-zib-diy\core\functions\page\wml-thumbnail.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (WmlAut::is_aut()) {//正版授权可用
// 获取链接列表
get_header();
$header_style = zib_get_page_header_style();
?>
<main class="container">
    <div class="content-wrap">
        <div class="content-layout">
            <?php while (have_posts()) : the_post(); ?>
                <?php if ($header_style != 1) {
                    echo zib_get_page_header();
                } ?>
                <?php endwhile;  ?>
                <div class="box-body theme-box radius8 main-bg main-shadow">
                    <?php if ($header_style == 1) {
                        echo zib_get_page_header();
                    } ?>
                <!--主体开始-->
                <?php if(wml_zib('page_thumbnail_dl')&&!is_user_logged_in()){ ?>
                        <div class="comment-signarea text-center box-body radius8">
                        <h3 class="text-muted em12 theme-box muted-3-color">请登录后使用</h3>
                        <p>
                            <a href="javascript:;" class="signin-loader but c-blue padding-lg"><i class="fa fa-fw fa-sign-in mr10" aria-hidden="true"></i>登录</a>
                            <?php echo !is_user_logged_in() ? '<a href="javascript:;" class="signup-loader ml10 but c-yellow padding-lg">' . zib_get_svg('signup',null,'icon mr10') . '注册</a>' : ''; ?>
                        </p>
                        <?php zib_social_login(); ?>
                        </div>
                <?php }elseif(wml_zib('page_thumbnail_rz')&&!zib_is_user_auth()){
                        echo '<div class="mb20 wp-posts-content"><div class="hide-post mt6"><div class=""><i class="fa fa-unlock-alt mr6"></i>该功能仅对内部特定认证人员开放</div><div class="text-center em09 mt20"><p class="separator muted-3-color mb20">以下用户组可查看</p><p><a class="but mm3" href="/user/auth"><svg class="mr6 em12" aria-hidden="true"><use xlink:href="#icon-user-auth"></use></svg>认证用户</a></p></div></div></div>';
                        echo '</div>';
                    }else{ ?>
                        <div class="wp-block-zibllblock-iframe wp-block-embed is-type-video mb20"><div class="" style="padding-bottom:56%"><iframe class="" data-aspect="56%" framespacing="0" border="0" width="100%" frameborder="no" src="<?php echo WML_ZIB_BEAUT_DIR_URL;?>/page/thumbnail"></iframe></div></div>
                <?php }?>
                <!--主体结束-->
                </div>
                <?php comments_template('/template/comments.php', true); ?>
        </div>
    </div>
    <?php get_sidebar(); ?>
</main>
<?php
get_footer();
}