<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-18 21:27:06
 $ @ 最后修改: 2024-11-14 19:03:59
 $ @ 文件路径: \wml-zib-diy\core\functions\page\wml-weiyu.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

// 获取链接列表
get_header();
$header_style = zib_get_page_header_style();
?>
<main class="container">
    <div class="content-wrap">
        <div class="content-layout">
            <?php while (have_posts()) : the_post(); ?>
                <?php if ($header_style != 1) {
                    echo zib_get_page_header();
                } ?>
                <?php endwhile;  ?>
                <div class="box-body theme-box radius8 main-bg main-shadow">
                    <?php if ($header_style == 1) {
                        echo zib_get_page_header();
                    } ?>
                <!--主体开始-->
                <style type="text/css">
                #weiyu_content{padding: 10px; /*min-height: 500px;*/} /* shuo */ body.theme-dark .cbp_tmtimeline::before{background: RGBA(255, 255, 255, 0.06);} ul.cbp_tmtimeline{padding: 0;} div class.cdp_tmlabel > li .cbp_tmlabel{margin-bottom: 0;} .cbp_tmtimeline{margin: 30px 0 0 0; padding: 0; list-style: none; position: relative;} /* The line */ .cbp_tmtimeline:before{/*content: '';*/ position: absolute; top: 0; bottom: 0; width: 4px; background: RGBA(0, 0, 0, 0.02); left: 80px; margin-left: 10px;} /* The date/time */ .cbp_tmtimeline > li .cbp_tmtime{display: block; /* width: 29%; */ /* padding-right: 110px; */ max-width: 70px; position: absolute;} .cbp_tmtimeline > li .cbp_tmtime span{display: block; text-align: right;} .cbp_tmtimeline > li .cbp_tmtime span:first-child{font-size: 0.9em; color: #bdd0db;} .cbp_tmtimeline > li .cbp_tmtime span:last-child{font-size: 1.2em; color: #9BCD9B;} .cbp_tmtimeline > li:nth-child(odd) .cbp_tmtime span:last-child{color: RGBA(255, 125, 73, 0.75);} div.cbp_tmlabel > p{margin-bottom: 0;} /* Right content */ .cbp_tmtimeline > li .cbp_tmlabel{margin: 0 0 45px 65px; background: #9BCD9B; color: #fff; padding: .8em 1.2em .4em 1.2em; /* font-size: 1.2em; */ font-weight: 300; line-height: 1.4; position: relative; border-radius: 5px; transition: all 0.3s ease 0s; box-shadow: 0 1px 2px rgba(0, 0, 0, 0.15); cursor: pointer; display: block;} .cbp_tmlabel:hover{transform:scale(1.05); transform: translateY(-3px); z-index: 1; -webkit-box-shadow: 0 15px 32px rgba(0, 0, 0, 0.15) !important} .cbp_tmtimeline > li:nth-child(odd) .cbp_tmlabel{background: RGBA(255, 125, 73, 0.75);} /* The triangle */ .cbp_tmtimeline > li .cbp_tmlabel:after{right: 100%; border: solid transparent; content: " "; height: 0; width: 0; position: absolute; pointer-events: none; border-right-color: #9BCD9B; border-width: 10px; top: 4px;} .cbp_tmtimeline > li:nth-child(odd) .cbp_tmlabel:after{border-right-color: RGBA(255, 125, 73, 0.75);} p.weiyu_time{margin-top: 10px; border-top: 1px dashed #fff; padding-top: 5px;} /* Media */ @media screen and (max-width: 65.375em){.cbp_tmtimeline > li .cbp_tmtime span:last-child{font-size: 1.2em;} } .weiyu_author_img img{border: 1px solid #ddd; padding: 2px; float: left; border-radius: 64px; transition: all 1.0s;} .avatar{-webkit-border-radius: 100% !important; -moz-border-radius: 100% !important; box-shadow: inset 0 -1px 0 #3333sf; -webkit-box-shadow: inset 0 -1px 0 #3333sf; -webkit-transition: 0.4s; -webkit-transition: -webkit-transform 0.4s ease-out; transition: transform 0.4s ease-out; -moz-transition: -moz-transform 0.4s ease-out;} .zhuan{transform: rotateZ(720deg); -webkit-transform: rotateZ(720deg); -moz-transform: rotateZ(720deg);}
                </style>
                </head>
                <body>
                <div id="primary" class="content-area" style="">
                    <main id="main" class="site-main" role="main">
                        <div id="weiyu_content">
                            <ul class="cbp_tmtimeline">
                                <?php query_posts("post_type=weiyu&post_status=publish&posts_per_page=-1");if (have_posts()) : while (have_posts()) : the_post(); ?>
                                <li> <span class="weiyu_author_img"><img src="https://q1.qlogo.cn/g?b=qq&nk=<?php echo wml_zib('page_weiyu_qq');?>&s=640" class="avatar avatar-48" style="width:48px;height:48px"></span>
                                    <a class="cbp_tmlabel" href="javascript:void(0)">
                                        <h4><?php the_title();   ?></h4>
                                        <p><?php the_content(); ?></p>
                                        <p></p>
                                        <p class="weiyu_time"><i class="fa fa-clock-o"></i>
                                            <?php the_time('Y年n月j日G:i'); ?>
                                        </p>
                                    </a>
                                    <?php endwhile;endif; ?>
                                </li>
                            </ul>
                        </div>
                    </main>
                </div>
                <script type="text/javascript">
                    $(function () {
                        var oldClass = "";
                        var Obj = "";
                        $(".cbp_tmtimeline li").hover(function () {
                            Obj = $(this).children(".weiyu_author_img");
                            Obj = Obj.children("img");
                            oldClass = Obj.attr("class");
                            var newClass = oldClass + " zhuan";
                            Obj.attr("class", newClass);
                        }, function () {
                            Obj.attr("class", oldClass);
                        })
                    })
                </script>
                <!--主体结束-->
                </div>
                <?php comments_template('/template/comments.php', true); ?>
        </div>
    </div>
    <?php get_sidebar(); ?>
</main>
<?php
get_footer();