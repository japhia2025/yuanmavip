<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 12:58:52
 $ @ 文件路径: \wml-zib-diy\core\admin\admin.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (! defined('ABSPATH')) {
	die;
}
if (class_exists('CSF')) {
    $prefix = 'wml_zib_diy';
    $img = WML_ZIB_BEAUT_DIR_ASSETS.'img/';
    // 开始构建主菜单
    CSF::createOptions($prefix,array(
            'menu_title' => '子比DIY',
            'framework_title' => '子比DIY',
            'menu_slug' => $prefix,
            'theme' => 'light',
            'show_in_customizer' => true,
            'footer_text'        => CSF_Module_Wml::footer_text(),
            'footer_credit' => '<i class="fa fa-fw fa-heart-o" aria-hidden="true"></i> ',
            'menu_icon' =>'dashicons-analytics',
        )
    );
    
    // 载入核心文件
    $include_once = array(
        'options/welcome',//欢迎
        'options/seo',//seo组件
        'options/beautify',//美化组件
        'options/feature',//功能组件
        'options/page',//页面组件
        'options/admins',//后台组件
        'options/widgets',//小工具组件
        'options/diy',//diy代码组件
    );
    foreach ($include_once as $inc) {
        include_once $inc . '.php';
    }
}


