<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 15:35:27
 $ @ 最后修改: 2024-11-14 21:52:57
 $ @ 文件路径: \wml-zib-diy\core\admin\options\beautify.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

CSF::createSection(
    $prefix,
    array(
        'id' => 'beautify',
        'title' => '美化组件',
        'icon' => 'fa fa-fw fa-adjust',
    )
);


CSF::createSection(
    $prefix,
    array(
        'parent' => 'beautify',
        'title' => 'LOGO',
        'icon' => 'fa fa-fw fa-flag',
        'description' => '',
        'fields' => array(
            array(
                'title' => '网站LOGO扫光',
                'label' => '开启后,网站LOGO会有扫光的效果。',
                'id' => 'logoflash',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'title' => 'LOGO色彩渐变',
                'label' => '开机后，网站LOGO会有渐变效果。',
                'id' => 'logogradient',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'title' => 'LOGO反色',
                'label' => '开启后，网站LOGO会有反色效果。',
                'id' => 'logo2',
                'default' => false,
                'type' => 'switcher'
            ),
            array(
                'title' => 'LOGO夜间反色',
                'label' => '开启后，网站LOGO会有夜间反色效果。',
                'id' => 'logo4',
                'default' => false,
                'type' => 'switcher'
            ),
            array(
                'title' => 'LOGO淡绿色阴影',
                'label' => '开启后，网站LOGO会有淡绿色柔光效果。',
                'id' => 'logo3',
                'default' => false,
                'type' => 'switcher'
            ),
        )
    )
);
    CSF::createSection(
        $prefix,
        array(
            'parent' => 'beautify',
            'title' => '提示',
            'icon' => 'fa fa-fw fa-info-circle',
            'description' => '',
            'fields' => array(
                array(
                    'title' => '日间、夜间模式切换提示',
                    'label' => '开启后可在切换日间、夜间主题时，弹出提示框。',
                    'id' => 'ryqiehuan',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => '复制提示',
                    'label' => '开启后可在用户复制时弹出提示框。',
                    'id' => 'copy_prompt0',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'id' => 'copy_prompt',
                    'dependency' => array('copy_prompt0', '!=', ''),
                    'title' => ' ',
                    'default' => '1',
                    'inline' => true,
                    'type' => 'radio',
                    'options' => array(
                        '1' => __('样式(1)', 'zib_language'),
                        '2' => __('样式(2)', 'zib_language'),
                        '3' => __('样式(3)', 'zib_language'),
                    ),
                ),
                array(
                    'title' => '网站动态切换标题栏',
                    'label' => '启用后如果切换到另一个页面会显示《你别走吖 Σ(っ °Д °;)っ》如果切换回来则显示《(/≧▽≦/)你又回来啦！》',
                    'id' => 'dt_title',
                    'type' => 'switcher',
                    'default' => false,
                ),
                array(
                    'dependency' => array('dt_title', '!=', ''),
                    'title' => ' ',
                    'subtitle' => '动态标题进入窗口文字',
                    'id' => 'dt_title_text_1',
                    'class' => 'compact',
                    'default' => '(/≧▽≦/)你又回来啦！',
                    'type' => 'text',
                ),
                array(
                    'dependency' => array('dt_title', '!=', ''),
                    'title' => ' ',
                    'subtitle' => '动态标题切换窗口文字',
                    'id' => 'dt_title_text_2',
                    'class' => 'compact',
                    'default' => '你别走吖 Σ(っ °Д °;)っ',
                    'type' => 'text',
                ),
                array(
                    'title' => '自定义标题栏轮播',
                    'label' => '启用后，网站标签的title会显示一段轮播文字，注意，不能和“切换标签”混用',
                    'id' => 'dt_title_diy',
                    'class' => 'compact',
                    'type' => 'switcher',
                    'default' => false,
                ),
                array(
                    'dependency' => array('dt_title_diy', '!=', ''),
                    'title' => ' ',
                    'subtitle' => '动态标题进入窗口文字',
                    'id' => 'dt_title_diy1',
                    'class' => 'compact',
                    'default' => false,
                    'type' => 'text',
                    'desc' => '填写内容后，网站标签将会显示该内容的字幕，不填则不显示',
                ),
                array(
                    'title' => '右下角付费记录滚动弹幕',
                    'label' => '在页面右下角显示网站付费弹幕，移动端不显示',
                    'id' => 'pay_danmu',
                    'default' => false,
                    'type' => 'switcher',
                ),
            )
        )
    );
    CSF::createSection(
        $prefix,
        array(
            'parent' => 'beautify',
            'title' => '右键',
            'icon' => 'fa fa-hand-o-right',
            'description' => '',
            'fields' => array(
                array(
                    'title' => '右键菜单',
                    'label' => '开启后右键替换浏览器的菜单。',
                    'id' => 'rbutton_is',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'dependency' => array('rbutton_is', '!=', ''),
                    'id'      => 'rbutton_zt_c',
                    'type'    => 'color',
                    'title'   => '字体颜色',
                    'default'      => '#666',
                ),
                array(
                    'dependency' => array('rbutton_is', '!=', ''),
                    'id'      => 'rbutton_xt_c',
                    'title'   => '悬停背景',
                    'class'      => 'compact skin-color',
                    'default'    => 'c-cyan',
                    'type'       => 'palette',
                    'options'  => CSF_Module_Wml_Zib::zib_palette(array(), array('t','c', 'b')),
                ),
                array(
                    'dependency' => array('rbutton_is', '!=', ''),
                    'title'      => '阴影背景',
                    'subtitle'   => ' ',
                    'id'         => 'rbutton_yy_c',
                    'class'      => 'compact skin-color',
                    'default'    => 'c-cyan',
                    'type'       => 'palette',
                    'options'  => CSF_Module_Wml_Zib::zib_palette(array(), array('t','c', 'b')),
                ),
                array(
                    'dependency' => array('rbutton_is', '!=', ''),
                    'title'   => '功能开关',
                    'id'      => 'rbutton_gn',
                    'type'    => "checkbox",
                    'inline'  => true,
                    'help'    => '选择开启鼠标点击的特效（可多选）',
                    'options' => array(
                        'copy'   => '复制',
                        'refresh'   => '刷新',
                        'index'   => '首页',
                        'forward'   => '前进',
                        'retreat'   => '后退',
                        'search'   => '搜索',
                    ),
                    'default' => array('copy', 'refresh', 'index', 'forward', 'retreat', 'search'),
                ),
                array(
                    'dependency' => array('rbutton_is', '!=', ''),
                    'title'                  => '扩展菜单',
                    'subtitle'               => '',
                    'id'                     => 'rbutton_an',
                    'type'                   => 'group',
                    'accordion_title_number' => '1',
                    'sanitize'               => false,
                    'button_title'           => '添加按钮',
                    'default'                => array(
                        array(
                            'name'      => '成为邻居',
                            'icon'      => 'fa fa-meh-o fa-fw',
                            'link'      => array(
                                'url' => '/links',
                                'target' => '_blank',
                            ),
                        ),
                        array(
                            'name'      => '给我留言',
                            'icon'      => 'fa fa-pencil fa-fw',
                            'link'      => array(
                                'url' => '/lam',
                                'target' => '_blank',
                            ),
                        ),
                        array(
                            'name'      => '免责声明',
                            'icon'      => 'fa fa-copyright',
                            'link'      => array(
                                'url' => '/disclaimers',
                                'target' => '_blank',
                            ),
                        ),
                    ),
                    'fields'=> array(
                        array(
                            'title'   => '按钮名称',
                            'id'      => 'name',
                            'type'    => 'text',
                            'default' => '',
                            'class' => 'mini-input',
                        ),
                        array(
                            'id'           => 'icon',
                            'type'         => 'icon',
                            'desc'         => '按钮默认显示的图标，可以选择内置图标',
                            'title'        => '按钮默认图标',
                            'button_title' => '选择预置图标',
                            'default'      => 'fa fa-meh-o fa-fw',
                        ),
                        array(
                            'id'           => 'link',
                            'type'         => 'link',
                            'title'        => '跳转链接',
                            'default'      => array(),
                            'add_title'    => '添加链接',
                            'edit_title'   => '编辑链接',
                            'remove_title' => '删除链接',
                        ),
                    ),
                ),
            )
        )
    );

    CSF::createSection(
        $prefix,
        array(
            'parent' => 'beautify',
            'title' => '头像',
            'icon' => 'fa fa-fw fa-user',
            'description' => '',
            'fields' => array(
                array(
                    'title' => '头像美化',
                    'label' => '开启后，头像彩色呼吸光环+悬停放大。',
                    'id' => 'avatar_mh',
                    'default' => false,
                    'type' => 'switcher'
                ),
                array(
                    'title' => '彩色昵称',
                    'label' => '开启后,用户的昵称会变成彩色的。',
                    'id' => 'csnc',
                    'default' => false,
                    'type' => 'switcher'
                ),
                array(
                    'title' => '头像摇摆',
                    'label' => '开启后,刷新页面用户的头像会左右摇摆。',
                    'id' => 'avatar_yb',
                    'default' => false,
                    'type' => 'switcher'
                ),
            )
        )
    );

    CSF::createSection(
        $prefix,
        array(
            'parent' => 'beautify',
            'title' => '字体',
            'icon' => 'fa fa-fw fa-font',
            'description' => '',
            'fields' => array(
                array(
                    'title' => '网站字体',
                    'label' => '开启改变网站字体',
                    'id' => 'font_switch',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'dependency' => array('font_switch', '!=', ''),
                    'title'       => ' ',
                    'id'          => 'font_select_t',
                    'type'        => 'select', 
                    'options'     => array(
                        '1'      => '预设字体',
                        '2'      => '自定义字体',
                    ),
                    'default'     => '1',
                ),
                array(
                    'dependency' => array(
                        array('font_switch', '!=', ''),
                        array('font_select_t', '==', '1'),
                    ),
                    'title' => ' ',
                    'id' => 'font_select',
                    'default' => '1',
                    'inline' => true,
                    'type' => 'radio',
                    'options' => array(
                        '1' => '抖音美好体(1.03M)',
                        '2' => '阿里妈妈方圆体(2.29M)',
                    ),
                ),
                array(
                    'dependency' => array(
                        array('font_switch', '!=', ''),
                        array('font_select_t', '==', '2'),
                    ),
                    'title' => ' ',
                    'desc' => '请填写自定义的网站字体链接地址',
                    'id' => 'font_select_diy',
                    'default' => false,
                    'type' => 'text',
                ),
            )
        )
    );

    CSF::createSection(
        $prefix,
        array(
            'parent' => 'beautify',
            'title' => '鼠标',
            'icon' => 'fa fa-fw fa-mouse-pointer',
            'description' => '',
            'fields' => array(
                array(
                    'title' => '鼠标皮肤选择',
                    'label' => '开启可选择鼠标皮肤样式',
                    'id' => 'mouse',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => ' ',
                    'id' => 'mouse_select',
                    'dependency' => array('mouse', '!=', ''),
                    'default' => '0',
                    'type' => 'image_select',
                    'options' => array(
                        '1' => $img . '/mouse/mouse1.png',
                        '2' => $img . '/mouse/mouse2.png',
                        '3' => $img . '/mouse/mouse3.png',
                        '4' => $img . '/mouse/mouse4.png',
                        '5' => $img . '/mouse/mouse5.png',
                        '6' => $img . '/mouse/mouse6.png',
                        '7' => $img . '/mouse/mouse7.png',
                    ),
                ),
                array(
                    'title'   => '鼠标点击特效',
                    'id'      => 'mouse_click',
                    'type'    => "checkbox",
                    'inline'  => true,
                    'help'    => '选择开启鼠标点击的特效（可多选）',
                    'options' => array(
                        'mouse_click_explosion'   => __('【五彩斑斓爆炸】', 'zib_language'),
                        'mouse_click_funny'       => __('【搞笑文字】', 'zib_language'),
                        'mouse_click_socialism'   => __('【社会主义核心价值观】', 'zib_language'),
                        'mouse_click_particle'    => __('【彩色粒子】', 'zib_language'),
                    ),
                ),
                array(
                    'title' => '鼠标跟随光圈',
                    'label' => '开启后，将会有一个鼠标光圈实时跟随鼠标移动',
                    'id' => 'mouse_follow',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => ' ',
                    'id' => 'mouse_follow_select',
                    'dependency' => array('mouse_follow', '!=', ''),
                    'default' => '1',
                    'inline' => true,
                    'type' => 'radio',
                    'options' => array(
                        '1' => __('【蓝色】', 'zib_language'),
                        '2' => __('【绿色】', 'zib_language'),
                        '3' => __('【粉色】', 'zib_language'),
                    ),
                ),
            )
        )
    );

    CSF::createSection(
        $prefix,
        array(
            'parent' => 'beautify',
            'title' => '左侧',
            'icon' => 'fa fa-fw fa-arrow-left',
            'description' => '',
            'fields' => array(
                array(
                    'title' => '左侧显示文章热榜',
                    'label' => '启用后会在网站的左侧显示文章热榜按钮',
                    'id' => 'article_hot_list',
                    'type' => 'switcher',
                    'default' => false,
                ),
                array(
                    'title' => '自定义热榜图片',
                    'dependency' => array('article_hot_list', '!=', ''),
                    'desc' => '请填写左侧图片(根据高度)',
                    'id' => 'article_hot_list_img',
                    'default' => $img . 'left/rank.png',
                    'preview' => true,
                    'library' => 'image',
                    'type' => 'upload',
                ),
                array(
                    'title' => '自定义后退图片',
                    'dependency' => array('article_hot_list', '!=', ''),
                    'desc' => '请填写左侧图片(根据高度)',
                    'id' => 'article_hot_lists_img',
                    'default' => $img . 'left/back.png',
                    'preview' => true,
                    'library' => 'image',
                    'type' => 'upload',
                ),
                array(
                    'title' => '左侧显示联系站长按钮',
                    'label' => '启用后会在网站的左侧显示联系站长按钮',
                    'id' => 'qq',
                    'type' => 'switcher',
                    'default' => false,
                ),
                array(
                    'dependency' => array('qq', '!=', ''),
                    'title' => ' ',
                    'subtitle' => '联系站长按钮文字',
                    'id' => 'qq_text',
                    'class' => 'compact',
                    'default' => '联系站长',
                    'type' => 'text',
                ),
                array(
                    'dependency' => array('qq', '!=', ''),
                    'title' => ' ',
                    'subtitle' => '联系站长按钮链接',
                    'desc' => '如果你使用QQ跳转到聊天页面可以使用http://wpa.qq.com/msgrd?v=3&uin=QQ号&site=qq&menu=yes作为链接',
                    'id' => 'qq_url',
                    'class' => 'compact',
                    'default' => 'http://wpa.qq.com/msgrd?v=3&uin= &site=qq&menu=yes',
                    'type' => 'text',
                ),
            )
        )
    );

    CSF::createSection(
        $prefix,
        array(
            'parent' => 'beautify',
            'title' => '右侧',
            'icon' => 'fa fa-fw fa-arrow-right',
            'description' => '',
            'fields' => array(
                array(
                    'title' => '右侧悬浮按钮图片',
                    'label' => '右侧悬浮按钮美化——欢迎光临',
                    'id' => 'suspension',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'dependency' => array('suspension', '!=', ''),
                    'title' => __('图片', 'zib_language'),
                    'id' => 'suspension_img',
                    'class' => 'compact',
                    'default' => $img . 'right/aa1.gif',
                    'preview' => true,
                    'library' => 'image',
                    'type' => 'upload',
                ),
                array(
                    'title' => '可爱调皮小猫',
                    'label' => '开启后侧边会出现可爱的调皮小猫，具体效果可以自行开启后体验',
                    'id' => 'cat',
                    'type' => 'switcher',
                    'default' => false,
                ),
                array(
                    'title' => '调皮小萝莉',
                    'label' => '调皮小猫的修改版',
                    'id' => 'tiaopill',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => '悬浮按钮美化',
                    'label' => '开启后侧边悬浮按钮会变成美色渐变',
                    'id' => 'xfan',
                    'type' => 'switcher',
                    'default' => false,
                ),
                array(
                    'title' => '悬浮按钮美化-新',
                    'label' => '开启后侧边悬浮按钮会变成美色渐变',
                    'id' => 'xfanx',
                    'type' => 'switcher',
                    'default' => false,
                ),
                array(
                    'dependency' => array('xfanx', '!=', ''),
                    'title' => __('图片', 'zib_language'),
                    'id' => 'suspension_imgss',
                    'class' => 'compact',
                    'default' => '',
                    'preview' => true,
                    'library' => 'image',
                    'type' => 'upload',
                ),
            )
        )
    );

    CSF::createSection(
        $prefix,
        array(
            'parent' => 'beautify',
            'title' => '顶部',
            'icon' => 'fa fa-fw fa-arrow-up',
            'description' => '',
            'fields' => array(
                array(
                    'title' => '导航字体加粗',
                    'label' => '让你的导航栏更加醒目！',
                    'id' => 'navbarb',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => '标题样式美化',
                    'label' => '导航栏标题将简化主题自带的标题hover效果',
                    'id' => 'navbiaoti',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => '禁用搜索功能',
                    'label' => '禁用导航栏顶部的搜索功能',
                    'id' => 'nosearch',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => __('FPS帧率显示'),
                    'id' => 'show_fps',
                    'type' => 'switcher',
                    'default' => false,
                    'label' => '启用后会在所有页面左上角加个帧率显示可以实时观察网站帧率，非常的哇塞！',
                ),
                array(
                    'dependency' => array('show_fps', '!=', ''),
                    'title' => ' ',
                    'id' => 'show_fps_t',
                    'default' => '1',
                    'inline' => true,
                    'type' => 'radio',
                    'options' => array(
                        '1' => __('【样式1】', 'zib_language'),
                        '2' => __('【样式2】', 'zib_language'),
                    ),
                ),
                array(
                    'dependency' => array(
                        array('show_fps', '!=', ''),
                        array('show_fps_t', '==', '2'),
                    ),
                    'title' => 'fps帧率位置',
                    'id' => 'show_fps_wz',
                    'default' => 30,
                    'min' => 0,
                    'max' => 100,
                    'step' => 1,
                    'type' => 'spinner',
                ),
                array(
                    'dependency' => array(
                        array('show_fps', '!=', ''),
                        array('show_fps_t', '==', '2'),
                    ),
                    'title' => 'fps帧率大小',
                    'id' => 'show_fps_dx',
                    'default' => 15,
                    'min' => 0,
                    'max' => 20,
                    'step' => 1,
                    'unit' => 'px',
                    'type' => 'spinner',
                    'class' => 'compact',
                ),
                array(
                    'dependency' => array(
                        array('show_fps', '!=', ''),
                        array('show_fps_t', '==', '2'),
                    ),
                    'title' => 'fps帧率显示颜色',
                    'id' => 'show_fps_color',
                    'default' => '#e44033',
                    'class' => 'compact',
                    'type' => "color",
                ),
                array(
                    'title' => '新年网站对联',
                    'label' => '启用后会在网站的两侧添加对联，对联的图片也可以自己修改，新年的时候可以启用冲冲节气(建议屏幕大小设置为1200px)',
                    'id' => 'duilian',
                    'type' => 'switcher',
                    'default' => false,
                ),
                array(
                    'dependency' => array('duilian', '!=', ''),
                    'title' => __('左侧对联图片设置'),
                    'id' => 'duilian_img_1',
                    'default' => $img . 'top/duilian-zuo.png',
                    'preview' => true,
                    'class' => 'compact',
                    'library' => 'image',
                    'type' => 'upload',
                ),
                array(
                    'dependency' => array('duilian', '!=', ''),
                    'title' => __('右侧对联图片设置'),
                    'id' => 'duilian_img_2',
                    'default' => $img . 'top/duilian-you.png',
                    'preview' => true,
                    'class' => 'compact',
                    'library' => 'image',
                    'type' => 'upload',
                ),
                array(
                    'title' => '元旦灯笼',
                    'label' => '启用后，网站右上角将呈现元旦灯笼特效',
                    'id' => 'chunjie',
                    'default' => false,
                    'type' => 'switcher'
                ),
                array(
                    'title' => '导航栏皮肤',
                    'label' => '启用后，将在顶部导航栏显示背景',
                    'desc' => '注：该项不能与自定义导航栏皮肤混用',
                    'id' => 'navbg',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => ' ',
                    'id' => 'navbg_radio',
                    'dependency' => array('navbg', '!=', ''),
                    'default' => '1',
                    'inline' => true,
                    'type' => 'radio',
                    'options' => array(
                        '1' => __('【童年飞机】', 'zib_language'),
                        '2' => __('【紫色薰衣】', 'zib_language'),
                        '3' => __('【三生桃花】', 'zib_language'),
                        '4' => __('【万里山河】', 'zib_language'),
                        '5' => __('【环游动漫】', 'zib_language'),
                        '6' => __('【浪漫爱心】', 'zib_language'),
                        '7' => __('【蜜桔海滩】', 'zib_language'),
                    ),
                ),
                array(
                    'title' => '自定义导航栏皮肤',
                    'label' => '开启后可自定义导航栏皮肤',
                    'id' => 'navbgdiy',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => ' ', 
                    'desc' => '请上传自定义导航栏背景图片或填写图片地址，注意尺寸为：1800px*80px', 
                    'dependency' => array('navbgdiy', '!=', ''), 
                    'id' => 'navbg_diy', 
                    'class' => 'compact', 
                    'default' => false, 
                    'preview' => true, 
                    'library' => 'image', 
                    'type' => 'upload'
                ),
            ),
        )
    );

    CSF::createSection(
        $prefix,
        array(
            'parent' => 'beautify',
            'title' => '底部',
            'icon' => 'fa fa-fw fa-arrow-down',
            'description' => '',
            'fields' => array(
                array(
                    'title' => '底部二维码滤镜一',
                    'label' => 'hue-rotate 色相旋转',
                    'id' => 'erweima1',
                    'default' => false,
                    'type' => 'switcher'
                ),
                array(
                    'title' => '底部二维码滤镜二',
                    'label' => 'invert 反色',
                    'id' => 'erweima2',
                    'default' => false,
                    'type' => 'switcher'
                ),
                array(
                    'title' => '底部二维码滤镜三',
                    'label' => 'drop-shadow 阴影',
                    'id' => 'erweima3',
                    'default' => false,
                    'type' => 'switcher'
                ),
                array(
                    'title' => '底部收藏本站',
                    'label' => '开启后将在网站底部显示Ctrl+D收藏本站提示',
                    'id' => 'dixian',
                    'default' => false,
                    'type' => 'switcher'
                ),
                array(
                    'title' => '底部动画',
                    'label' => '启用后会在所有页面底部下面添加动画效果！',
                    'id' => 'wave',
                    'type' => 'switcher',
                    'default' => false,
                ),
                array(
                    'dependency' => array('wave', '!=', ''),
                    'title' => ' ',
                    'id' => 'wave_type',
                    'default' => '1',
                    'inline' => true,
                    'type' => 'radio',
                    'options' => array(
                        '1' => __('【蓝色波浪】', 'zib_language'),
                        '2' => __('【鱼群跳跃】', 'zib_language'),
                    ),
                    'class' => 'compact',
                ),
                array(
                    'title' => '右下角蒲公英',
                    'label' => '开启后网站底部将显示动态蒲公英特效',
                    'id' => 'plbj5',
                    'default' => false,
                    'type' => 'switcher'
                ),
                array(
                    'title' => '右下角MySSL认证',
                    'label' => '开启后网站右下角显示MySSL认证',
                    'id' => 'myssl',
                    'type' => 'switcher',
                    'default' => false,
                ),
                array(
                    'dependency' => array('myssl', '!=', ''),
                    'title' => __('MySSL图标'),
                    'id' => 'myssl_id',
                    'class' => 'compact',
                    'default' => $img . 'footer/myssl-id.png',
                    'preview' => true,
                    'library' => 'image',
                    'type' => 'upload',
                ),
                array(
                    'dependency' => array('myssl', '!=', ''),
                    'title' => __('你的域名'),
                    'id' => 'myssl_url',
                    'class' => 'compact',
                    'default' => 'waimao.la',
                    'class' => 'compact',
                    'type' => 'text',
                ),
                array(
                    'title' => '网站运行时间',
                    'label' => '开启后可在网站底部显示彩色运行时间',
                    'id' => 'timeauthor',
                    'default' => false,
                    'type' => 'switcher'
                ),
                array(
                    'title' => ' ',
                    'desc' => '请填写您的建站时间，如：2022-20-25',
                    'id' => 'timeauthor1',
                    'default' => false,
                    'type' => 'text',
                    'dependency' => array(
                        'timeauthor',
                        '!=',
                        ''
                    ),
                    'class' => 'compact'
                ),
            )
        )
    );

    CSF::createSection(
        $prefix,
        array(
            'parent' => 'beautify',
            'title' => '首页',
            'icon' => 'fa fa-fw fa-home',
            'description' => '',
            'fields' => array(
                array(
                    'title' => '首页灰色主题',
                    'label' => '启用后，网站首页变灰,适合国家公祭日等纪念日使用',
                    'id' => 'grey_page',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => '隐藏首页文章发布时间',
                    'label' => '开启后用户将不能在首页看到文章的发布时间,文章页面还是可以看到的',
                    'id' => 'zibll_post_public_date',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => '首页文章列表悬停上浮',
                    'label' => '开启后给网站首页文章赋予悬停上浮特效',
                    'id' => 'posts_item',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => '首页文章列表水波上浮',
                    'label' => '开启后给网站首页文章赋予悬停上浮特效',
                    'id' => 'posts_item2',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => '首页文章点击更多美化',
                    'label' => '启用后，美化文章的“点击更多”按钮',
                    'id' => 'dianjigengduo',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => '首页搜索框边缘透明',
                    'label' => '启用后，使首页搜索框边缘透明',
                    'id' => 'search_form',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => '文章图片聚焦',
                    'label' => '开启后当鼠标指到部分位置的文章缩略图上时，将会出现小圆圈',
                    'id' => 'st',
                    'type' => 'switcher',
                    'default' => false,
                ),
                array(
                    'dependency' => array('st', '!=', ''),
                    'title' => __('自定义图片聚焦'),
                    'id' => 'st_img',
                    'class' => 'compact',
                    'default' => $img . 'index/st.png',
                    'preview' => true,
                    'library' => 'image',
                    'type' => 'upload',
                ),
            )
        )
    );

    CSF::createSection(
        $prefix,
        array(
            'parent' => 'beautify',
            'title' => '文章',
            'icon' => 'fa fa-fw fa-book',
            'description' => '',
            'fields' => array(
                array(
                    'title' => '文章外部标签随机彩色',
                    'label' => '开启后，除文章页外标签显示随机彩色，如首页，列表页，标签页和主题页。',
                    'id' => 'tag_w_color',
                    'type' => 'switcher',
                    'default' => false,
                ),
                array(
                    'title' => '文章内下部标签随机彩色',
                    'label' => '开启后，文章页内部底下标签显示彩色。',
                    'id' => 'tag_n_color',
                    'type' => 'switcher',
                    'default' => false,
                ),
                array(
                    'title' => '文章底部添加转载声明',
                    'label' => '开启后，为网站文章底部添加一个转载声明。',
                    'id' => 'posts_zhuanzai',
                    'default' => false,
                    'type' => 'switcher',

                ),
                array(
                    'title' => '文章底部添加过期提示',
                    'label' => '开启后，为网站文章底部添加一个过期提示。',
                    'id' => 'posts_gqts',
                    'default' => false,
                    'type' => 'switcher',

                ),
                array(
                    'dependency' => array('posts_gqts', '!=', ''),
                    'id' => 'posts_gqts_text',
                    'type' => 'textarea',
                    'title' => '过期提示内容',
                    'class' => 'compact',
                    'attributes' => array(
                        'rows' => 3,
                    ),
                    'default' => '某些文章具有时效性，若有错误或已失效，请在下方<a href="#comment">留言</a>或联系<a target="_blank" title="' . get_bloginfo('name') . '" href="' . get_bloginfo('url') . '"><b>' . get_bloginfo('name') . '</b></a>。',
                ),
                array(
                    'title' => '文章内页提示条',
                    'label' => '开启后写文章内页显示彩色提示条。',
                    'desc' => '',
                    'id' => 'post_tooltip',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'dependency' => array('post_tooltip', '!=', ''),
                    'title' => '显示内容',
                    'id' => 'post_tooltip_text',
                    'default' => '<span>支持 macOS</span> Ventura 12.x',
                    'type' => 'text',
                    'sanitize'   => false,//关闭HTML过滤器
                ),
                array(
                    'dependency' => array('post_tooltip', '!=', ''),
                    'title' => '显示位置',
                    'id' => 'post_tooltip_t',
                    'default' => '1',
                    'inline' => true,
                    'type' => 'radio',
                    'options' => array(
                        '1' => __('【文章头部】', 'zib_language'),
                        '2' => __('【文章尾部】', 'zib_language'),
                    ),
                ),
                array(
                    'dependency' => array('post_tooltip', '!=', ''),
                    'title' => '显示样式',
                    'id' => 'post_tooltip_r',
                    'default' => '1',
                    'inline' => true,
                    'type' => 'radio',
                    'type' => 'image_select',
                    'options' => array(
                        '1' => $img . '/post/tooltip_bj1.png',
                        '2' => $img . '/post/tooltip_bj2.png',
                        '3' => $img . '/post/tooltip_bj3.png',
                    ),
                ),
                array(
                    'title' => '文章标题鼠标悬停划线',
                    'label' => '开启后，鼠标指针指在文章标题上会进行动态划线，移开又取消划线。',
                    'id' => 'xthx',
                    'type' => 'switcher',
                    'default' => false,
                ),
                array(
                    'title' => '文章内页H标题美化（图标）',
                    'label' => '开启后写文章用的H小标题将以美化后的效果展现出来，非常的好看哇塞。',
                    'id' => 'subtitle',
                    'type' => 'switcher',
                    'default' => false,
                ),
                array(
                    'dependency' => array('subtitle', '!=', ''),
                    'title' => __('小标题h1图片'),
                    'id' => 'subtitle_h1',
                    'class' => 'compact',
                    'default' => $img . 'post/h1.svg',
                    'preview' => true,
                    'library' => 'image',
                    'type' => 'upload',
                ),
                array(
                    'dependency' => array('subtitle', '!=', ''),
                    'title' => __('小标题h2图片'),
                    'id' => 'subtitle_h2',
                    'class' => 'compact',
                    'default' => $img . 'post/h2.svg',
                    'preview' => true,
                    'library' => 'image',
                    'type' => 'upload',
                ),
                array(
                    'dependency' => array('subtitle', '!=', ''),
                    'title' => __('小标题h3图片'),
                    'id' => 'subtitle_h3',
                    'class' => 'compact',
                    'default' => $img . 'post/h3.svg',
                    'preview' => true,
                    'library' => 'image',
                    'type' => 'upload',
                ),
                array(
                    'dependency' => array('subtitle', '!=', ''),
                    'title' => __('小标题h4图片'),
                    'id' => 'subtitle_h4',
                    'class' => 'compact',
                    'default' => $img . 'post/h4.svg',
                    'preview' => true,
                    'library' => 'image',
                    'type' => 'upload',
                ),
                array(
                    'title' => '文章内页H标题美化（颜色）',
                    'label' => '开启后写文章用的H小标题将以美化后的效果展现出来，非常的好看哇塞。',
                    'desc' => '注：该项不能与文章内页小标题美化（图标）混用',
                    'id' => 'subtitle_color',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => ' ',
                    'id' => 'subtitle_color_r',
                    'dependency' => array('subtitle_color', '!=', ''),
                    'default' => '1',
                    'inline' => true,
                    'type' => 'radio',
                    'options' => array(
                        '1' => __('【纯色风格】', 'zib_language'),
                        '2' => __('【彩色风格】', 'zib_language'),
                        '3' => __('【灰色阴影】', 'zib_language'),
                    ),
                ),
                array(
                    'title' => '文章绿色阴影边缘',
                    'label' => '启用后，文章页将会添加一个淡绿色柔光边框',
                    'id' => 'post_box_shadow',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => '文章内图片边框光效',
                    'label' => '开启后，当鼠标移向文章页面内的图片时，图片周围会有绿色柔光显示。',
                    'id' => 'post_page_img_shadow',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => '文章内代码高亮美化',
                    'label' => '开启后，高亮代码增加3个点',
                    'id' => 'bianjiqi',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => '文章页版权声明',
                    'label' => '启用后，文章末尾会有版权声明',
                    'id' => 'posts_bq',
                    'default' => false,
                    'type' => 'switcher'
                ),
                array(
                    'dependency' => array('posts_bq', '!=', ''),
                    'id' => 'posts_bq_sm',
                    'type' => 'fieldset',
                    'title' => ' ',
                    'fields' => array(
                        array(
                            'type' => 'notice',
                            'style' => 'success',
                            'content' => '启用插件版权声明之前请先关闭子比的版权声明 如果不关闭会显示两个哦',
                        ),
                        array(
                            'id' => 'yangshi',
                            'title' => '显示样式',
                            'default' => '0',
                            'inline' => true,
                            'type' => 'radio',
                            'options' => array(
                                '0' => __('子比默认', 'zib_language'),
                                '1' => __('样式(1)', 'zib_language'),
                                '2' => __('样式(2)', 'zib_language'),
                                '3' => __('样式(3)', 'zib_language'),
                            ),
                        ),
                        array(
                            'id' => 'title',
                            'type' => 'text',
                            'title' => '标题',
                            'default' => '文章版权声明',
                        ),
                        array(
                            'title' => '版权声明',
                            'subtitle' => '添加更多自定义按钮',
                            'id' => 'sm',
                            'type' => 'group',
                            'button_title' => '添加声明',
                            'fields' => array(
                                array(
                                    'id' => 'id',
                                    'type' => 'text',
                                    'title' => '序号',
                                ),
                                array(
                                    'id' => 'text',
                                    'type' => 'textarea',
                                    'title' => '内容',
                                ),
                            ),
                        ),
                    ),
                ),
                array(
                    'title' => '文章商用声明',
                    'label' => '开启后文章底部会有商用声明提示',
                    'id' => 'sy_copyright',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'dependency' => array('sy_copyright', '!=', ''),
                    'title' => '自定义文字',
                    'id' => 'sy_copyright_text',
                    'class' => 'compact',
                    'default' => '本站代码模板仅供学习交流使用请勿商业运营，严禁从事违法，侵权等任何非法活动，否则后果自负！',
                    'type' => 'text',
                ),
            )
        )
    );

    CSF::createSection(
        $prefix,
        array(
            'parent' => 'beautify',
            'title' => '评论',
            'icon' => 'fa fa-fw fa-comments',
            'description' => '',
            'fields' => array(
                array(
                    'title' => '评论区UID',
                    'label' => '评论区显示用户的ID',
                    'id' => 'comment_uid',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'dependency' => array('comment_uid', '==', 'true'),
                    'class' => 'compact',
                    'id' => 'comment_uid_type',
                    'default' => 'id',
                    'type' => 'radio',
                    'title' => '显示信息',
                    'inline' => true,
                    'options' => array(
                        'random' => '随机',
                        'id' => '用户ID',
                        'ip' => '用户IP',
                        'city' => '用户所在城市',
                    ),
                ),
                array(
                    'title' => ' ',
                    'desc' => '预留位，例如你网站有100用户预留5位则第一百位用户ID显示为<code style="color:red;">00100</code>',
                    'id' => 'comment_uid_s',
                    'default' => 5,
                    'unit' => '位',
                    'max' => 30,
                    'min' => 3,
                    'step' => 1,
                    'type' => 'spinner',
                    'dependency' => array('comment_uid', '!=', ''),
                    'class' => 'compact',
                ),
                array(
                    'title' => '首页评论美化',
                    'label' => '首页评论会以圆角虚线形式输出',
                    'id' => 'index_comments',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => '评论框背景图片',
                    'label' => '启用后，文章末尾评论框会有背景图片',
                    'id' => 'comments_bj',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => ' ',
                    'id' => 'comments_bj_r',
                    'dependency' => array('comments_bj', '!=', ''),
                    'default' => '1',
                    'inline' => true,
                    'type' => 'radio',
                    'options' => array(
                        '1' => __('【背景图片1】', 'zib_language'),
                        '2' => __('【背景图片2】', 'zib_language'),
                    ),
                ),
                array(
                    'title' => '评论区列表美化',
                    'label' => '评论区红、蓝背景轮询切换',
                    'id' => 'acgpl',
                    'default' => false,
                    'type' => 'switcher',
                ),
            )
        )
    );

    CSF::createSection(
        $prefix,
        array(
            'parent' => 'beautify',
            'title' => '全局',
            'icon' => 'fa fa-th',
            'description' => '',
            'fields' => array(
                array(
                    'title' => '门铃声',
                    'label' => '开启后进来网站可听到门铃声',
                    'id' => 'myaudio',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => ' ',
                    'id' => 'myaudio_t',
                    'dependency' => array('myaudio', '!=', ''),
                    'default' => '1',
                    'inline' => true,
                    'type' => 'radio',
                    'options' => array(
                        '1' => __('【声音1】', 'zib_language'),
                        '2' => __('【声音2】', 'zib_language'),
                    ),
                ),
                array(
                    'title' => '纵向滚动条',
                    'label' => '开启后美化右边纵向滚动条',
                    'id' => 'scrollbar',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => ' ',
                    'id' => 'scrollbar_r',
                    'dependency' => array('scrollbar', '!=', ''),
                    'default' => '1',
                    'inline' => true,
                    'type' => 'radio',
                    'options' => array(
                        '1' => __('【红色滚动条】', 'zib_language'),
                        '2' => __('【双色滚动条】', 'zib_language'),
                        '3' => __('【彩色滚动条】', 'zib_language'),
                    ),
                ),
                array(
                    'title' => '横向滚动条',
                    'label' => '启用后，网站顶部将显示一个彩色的进度条',
                    'id' => 'level_scrollbar',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => '开屏原神动画',
                    'label' => '开屏动画变成原神启动时的样子',
                    'id' => 'yuanshen',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'dependency' => array('yuanshen', '!=', ''),
                    'title' => ' ',
                    'subtitle' => '自定义网站启动图片',
                    'id' => 'yuanshen_img',
                    'class' => 'compact',
                    'default' => $img . 'index/1154045358.svg',
                    'preview' => true,
                    'library' => 'image',
                    'type' => 'upload',
                ),
                array(
                    'title' => '全局飘落特效',
                    'label' => '启用后，网站全局显示飘落特效',
                    'id' => 'drift_down',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => ' ',
                    'id' => 'drift_down_r',
                    'dependency' => array('drift_down', '!=', ''),
                    'default' => '1',
                    'inline' => true,
                    'type' => 'radio',
                    'options' => array(
                        '1' => __('【浪漫樱花】', 'zib_language'),
                        '2' => __('【枫叶飘落】', 'zib_language'),
                        '3' => __('【雪花飘落】', 'zib_language'),
                    ),
                ),
                array(
                    'title' => '全局动态背景',
                    'label' => '启动后，将会显示动态网站背景',
                    'id' => 'dynamic_bj',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => ' ',
                    'id' => 'dynamic_bj_r',
                    'dependency' => array('dynamic_bj', '!=', ''),
                    'default' => '1',
                    'inline' => true,
                    'type' => 'radio',
                    'options' => array(
                        '1' => __('【五彩斑斓】', 'zib_language'),
                        '2' => __('【粒子连线】', 'zib_language'),
                        '3' => __('【符号元素】', 'zib_language'),
                    ),
                ),
                array(
                    'title' => '全局灰色主题',
                    'label' => '启用后，网站全局变灰,适合国家公祭日等纪念日使用',
                    'id' => 'site_gray',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'id' => 'fanye',
                    'type' => 'switcher',
                    'label' => '开启后翻页按钮会出现渐变颜色',
                    'default' => false,
                    'title' => '翻页按钮美化',
                ),
                array(
                    'title' => '会员购买弹窗底部小图',
                    'label' => '给会员购买弹窗添加B站登陆弹窗底部小图',
                    'id' => 'bilibili',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'id' => 'wml_Togreet',
                    'type' => 'switcher',
                    'title' => '网站时段问候语',
                    'label' => '开启感觉萌萌哒',
                    'default' => false,
                ),
                array(
                    'dependency' => array('wml_Togreet', '==', 'true'),
                    'id' => 'wml_huanying_text',
                    'type' => 'text',
                    'title' => '欢迎语',
                    'dsec' => '进入网站时的欢迎语',
                    'default' => '欢迎访问本站<br>您的访问时本站的荣幸<br>希望您能在本站<br>找到您想要的资源',
                ),
                array(
                    'dependency' => array('wml_Togreet', '==', 'true'),
                    'id' => 'wml_wuye_text',
                    'type' => 'text',
                    'title' => '时段问候语午夜',
                    'dsec' => '时段问候语午夜文本',
                    'default' => '外贸啦提示您 午夜骚年，快睡觉去，妹纸等你太久了会不耐烦的哦！',
                ),
                array(
                    'dependency' => array('wml_Togreet', '==', 'true'),
                    'id' => 'wml_zaoshang_down',
                    'type' => 'text',
                    'title' => '时段问候语早上',
                    'dsec' => '时段问候语早上文本',
                    'default' => '早上好~今天又是元气满满的一天哦！先去尝尝鲜</a>~',
                ),
                array(
                    'dependency' => array('wml_Togreet', '==', 'true'),
                    'id' => 'wml_shangwu_down',
                    'type' => 'text',
                    'title' => '时段问候语上午',
                    'dsec' => '时段问候语上午文本',
                    'default' => '最难的任务适合在上午时段攻克哦，期待您的订单~',
                ),
                array(
                    'dependency' => array('wml_Togreet', '==', 'true'),
                    'id' => 'wml_zhongwu_down',
                    'type' => 'text',
                    'title' => '时段问候语中午',
                    'dsec' => '时段问候语中午文本',
                    'default' => '中午拿什么填补我空虚的胃和心灵？<br />停下手中的工作，快去吃饭吧，晚了就没的吃了',
                ),
                array(
                    'dependency' => array('wml_Togreet', '==', 'true'),
                    'id' => 'wml_xiawu_down',
                    'type' => 'text',
                    'title' => '时段问候语下午',
                    'dsec' => '时段问候语下午文本',
                    'default' => '下午时段外贸啦正在优化细节，力求做一个人见人爱的“细节控”哦~',
                ),
                array(
                    'dependency' => array('wml_Togreet', '==', 'true'),
                    'id' => 'wml_bangwan_texte',
                    'type' => 'text',
                    'title' => '时段问候语傍晚',
                    'dsec' => '时段问候语傍晚文本',
                    'default' => '快要下班了吧？休息会扒根烟喝杯茶~',
                ),
                array(
                    'dependency' => array('wml_Togreet', '==', 'true'),
                    'id' => 'wml_yewan_link',
                    'type' => 'text',
                    'title' => '时段问候语夜晚',
                    'dsec' => '时段问候语夜晚文本',
                    'default' => '晚安~音乐、运动、阅读，睡前时间放松一下，灵感也许会悄悄到来！',
                ),
                array(
                    'dependency' => array('wml_Togreet', '==', 'true'),
                    'id' => 'wml_xiuxi_down',
                    'type' => 'text',
                    'title' => '时段问候语该休息了',
                    'dsec' => '时段问候语该休息了文本',
                    'default' => '累了就早点休息~<br />晚间22：00-5:00是最佳睡眠时间哦',
                ),
                array(
                    'title'   => '自定义背景',
                    'id'      => 'wml_diy_bg' ,
                    'default' => false,
                    'type'    => 'switcher',
                ),
                array(
                    'dependency' => array('wml_diy_bg', '==', 'true'),
                    'title' => '日间背景',
                    'id' => 'wml_diy_bg_r',
                    'preview' => true,
                    'library' => 'image',
                    'default' => ' ',
                    'type' => 'upload',
                    'class' => 'compact',
                ),
                array(
                    'dependency' => array('wml_diy_bg', '==', 'true'),
                    'title' => '夜间背景',
                    'id' => 'wml_diy_bg_y',
                    'preview' => true,
                    'library' => 'image',
                    'default' => ' ',
                    'type' => 'upload',
                    'class' => 'compact',
                ),
            ),
        )
    );

    CSF::createSection(
        $prefix,
        array(
            'parent' => 'beautify',
            'title' => '页脚',
            'icon' => 'fa fa-minus-square-o',
            'description' => '',
            'fields' => array(
                array(
                    'content' => '
                    <div class="options-notice"><div style="color:#ff2153;"><i class="fa fa-fw fa-info-circle fa-fw"></i>若您需要使用页角功能，需每次子比更新后在此处替换文件</div>
                    <div class="explain"><ajaxform class="ajax-form" ajax-url="' . admin_url("admin-ajax.php") . '"><div class="ajax-notice"></div>
                    <div><a href="javascript:;" data-confirm="点击确认后开始替换文件" class="but jb-yellow ajax-submit"><i class="fa fa-floppy-o"></i> 立即替换</a></div>
                     <input type="hidden" ajax-name="action" value="wml_zib_footer"></ajaxform>
                     <ajaxform class="ajax-form" ajax-url="' . admin_url("admin-ajax.php") . '"><div class="ajax-notice"></div>
                    <div><a href="javascript:;" data-confirm="点击确认后开始恢复默认" class="but jb-blue ajax-submit"><i class="fa fa-repeat"></i> 恢复默认</a></div>
                     <input type="hidden" ajax-name="action" value="wml_zib_footers"></ajaxform></div></div>', 
                    'style' => 'warning',
                    'type' => 'submessage',
                ),
                array(
                    'title' => '页角美化',
                    'label' => '打开后自定义页脚从才会生效',
                    'id' => 'footer',
                    'default' => false,
                    'type' => 'switcher',
                ),
                array(
                    'title' => '简约页脚',
                    'id' => 'foot_men',
                    'type' => 'fieldset',
                    'fields' => array(
                        array(
                            'title' => '简约页脚设置',
                            'id' => 'wml_foot',
                            'type' => 'switcher',
                            'default' => false,
                        ),
                        array(
                            'dependency' => array('wml_foot', '!=', ''),
                            'title' => '底部样式',
                            'placeholder' => '底部简约样式(建议为友情链接，或者站内链接)',
                            'default' => '
        <a href="https://waimao.la">友链申请</a>
        <a href="https://waimao.la">免责声明</a>
        <a href="https://waimao.la">广告合作</a>
        <a href="https://waimao.la">关于我们</a>',
                            'id' => 'foot_html',
                            'class' => 'compact',
                            'type' => 'textarea',
                            'attributes' => array(
                                'rows' => 5,
                            ),
                        ),
                        array(
                            'dependency' => array('wml_foot', '!=', ''),
                            'title' => '开启显示ICP备案号',
                            'after' => '如果您有ICP备案号可以开启此项，如果没有可以关闭将不会显示ICP备案',
                            'id' => 'icp_foot',
                            'type' => 'switcher',
                            'default' => true,
                        ),
                        array(
                            'dependency' => array('wml_foot|icp_foot', '!=|!=', ''),
                            'title' => __('工信部备案图标'),
                            'id' => 'wml_icp_foot_img',
                            'default' => $img . '/footer/icp.svg',
                            'preview' => true,
                            'class' => 'compact',
                            'library' => 'image',
                            'type' => 'upload',
                        ),
                        array(
                            'dependency' => array('wml_foot|icp_foot', '!=|!=', ''),
                            'title' => ' ',
                            'subtitle' => '工信部备案号',
                            'id' => 'wml_icp_foot_text',
                            'class' => 'compact',
                            'default' => '津ICP备2023009737号-1',
                            'type' => 'text',
                        ),
                        array(
                            'dependency' => array('wml_foot', '!=', ''),
                            'title' => '开启显示公安备案号',
                            'after' => '如果您有公安备案号可以开启此项，如果没有可以关闭将不会显示公安备案',
                            'id' => 'beian_foot',
                            'type' => 'switcher',
                            'default' => true,
                        ),
                        array(
                            'dependency' => array('wml_foot|beian_foot', '!=|!=', ''),
                            'title' => __('公安备案图标'),
                            'id' => 'wml_beian_foot_img',
                            'default' => $img . '/footer/gongan.svg',
                            'preview' => true,
                            'class' => 'compact',
                            'library' => 'image',
                            'type' => 'upload',
                        ),
                        array(
                            'dependency' => array('wml_foot|beian_foot', '!=|!=', ''),
                            'title' => ' ',
                            'subtitle' => '公安备案号',
                            'id' => 'wml_beian_foot_text',
                            'class' => 'compact',
                            'default' => '津公网安备12011602300104号',
                            'type' => 'text',
                        ),
                        array(
                            'dependency' => array('wml_foot', '!=', ''),
                            'title' => __('小组件图1设置'),
                            'id' => 'copyright_foot_img_3',
                            'default' => $img . '/footer/footer.svg',
                            'preview' => true,
                            'class' => 'compact',
                            'library' => 'image',
                            'type' => 'upload',
                        ),
                        array(
                            'dependency' => array('wml_foot', '!=', ''),
                            'title' => ' ',
                            'subtitle' => '小组件图1点击Url设定',
                            'default' => '/',
                            'id' => 'copyright_foot_url_1',
                            'class' => 'compact',
                            'type' => 'text',
                        ),
                        array(
                            'dependency' => array('wml_foot', '!=', ''),
                            'title' => ' ',
                            'subtitle' => '小组件第二排文字设定',
                            'default' => 'Copyright © 2023-2024 <a href="https://www.nengdo.cn" target="_blank">外贸啦</a>版权所有',
                            'id' => 'copyright_foot_html_2',
                            'class' => 'compact',
                            'type' => 'textarea',
                        ),
                        array(
                            'dependency' => array('wml_foot', '!=', ''),
                            'title' => ' ',
                            'default' => '本站由 <a href="http://www.xixincn.com/" target="_blank">西信数据</a> 提供计算支持 | 由 <a href="https://waimao.la/" target="_blank">外贸啦DIY</a> 强力驱动',
                            'id' => 'copyright_foot_html_3',
                            'class' => 'compact',
                            'type' => 'textarea',
                        ),
                        array(
                            'dependency' => array('wml_foot', '!=', ''),
                            'title' => '是否显示当前日期+时间',
                            'after' => '开启后将在小组件第三排右侧开启时间显示',
                            'id' => 'copyright_foot_time',
                            'class' => 'compact',
                            'type' => 'switcher',
                            'default' => true,
                        ),
                        array(
                            'dependency' => array('wml_foot', '!=', ''),
                            'title' => ' ',
                            'subtitle' => '小组件第四排文字设定',
                            'default' => '<a href="https://www.qinglangtianjin.com/" target="_blank">天津市互联网违法和不良信息举报中心</a>',
                            'id' => 'copyright_foot_html_4',
                            'class' => 'compact',
                            'type' => 'textarea',
                        ),
                        array(
                            'dependency' => array('wml_foot', '!=', ''),
                            'title' => __('小组件第四排图片设置'),
                            'id' => 'copyright_foot_img_4',
                            'default' => $img . '/footer/footer4.gif',
                            'preview' => true,
                            'class' => 'compact',
                            'library' => 'image',
                            'type' => 'upload',
                        ),
                    ),
                ),
                array(
                    'title' => '高级页脚',
                    'id' => 'footers_men',
                    'type' => 'fieldset',
                    'fields' => array(
                        array(
                            'title' => '高级页脚设置',
                            'id' => 'wml_footers',
                            'type' => 'switcher',
                            'default' => false,
                        ),
                        array(
                            'title' => '是否显示网站信息统计',
                            'id' => 'wml_footers_tj',
                            'type' => 'switcher',
                            'default' => false,
                        ),
                        array(
                            'dependency' => array('wml_footers_tj', '!=', ''),
                            'title' => '建站时间',
                            'class' => 'pay-hide compact',
                            'id' => 'wml_footers_time',
                            'type' => 'date',
                            'default' => '2023-01-01 00:00:00',
                            'settings' => array(
                                'dateFormat' => 'yy-mm-dd 00:00:00',
                                'changeMonth' => true,
                                'changeYear' => true,
                            )
                        ),
                        array(
                            'dependency' => array('wml_footers', '!=', ''),
                            'title' => '申请友情链接地址',
                            'id' => 'wml_footers_url',
                            'class' => 'compact',
                            'type' => 'text',
                        ),
                        array(
                            'dependency' => array('wml_footers', '!=', ''),
                            'title' => '博客简介',
                            'after' => '介绍、描述您的网站，建议字数在40-70之间',
                            'id' => 'description',
                            'type' => 'textarea',
                            'default' => '外贸啦为大家提供绿色软件、单机游戏、游戏源码、软件源码、技术教程、网站模板、Japhia主题、子比主题子主题等等网络资源分享,提供技术攻略教程、App软件游戏资源下载,,一切尽在waimao.la!',
                            'attributes' => array(
                                'rows' => 4,
                            ),
                        ),
                        array(
                            'dependency' => array('wml_footers', '!=', ''),
                            'title' => '关于我们',
                            'id' => 'about',
                            'type' => 'textarea',
                            'default' => '<div class="navi"><h2 class="title">关于我们</h2><ul>
                                        <li><a href="/protocol" target="_blank">用户协议</a></li>
                                        <li><a href="/statement" target="_blank">免责声明</a></li>
                                        <li><a href="/privacy" target="_blank">隐私政策</a></li>
                                        <li><a target="_blank" href="/about">关于我们</a></li>
                                        <li><a href="/sitemap.xml" target="_blank">站点地图</a></li>
                                    </ul></div>',
                            'attributes' => array(
                                'rows' => 8,
                            ),
                        ),
                        array(
                            'dependency' => array('wml_footers', '!=', ''),
                            'title' => '特色功能',
                            'id' => 'function',
                            'type' => 'textarea',
                            'default' => '<div class="navi"><h2 class="title">关于我们</h2><ul>
                                        <li><a href="/protocol" target="_blank">用户协议</a></li>
                                        <li><a href="/statement" target="_blank">免责声明</a></li>
                                        <li><a href="/privacy" target="_blank">隐私政策</a></li>
                                        <li><a target="_blank" href="/about">关于我们</a></li>
                                        <li><a href="/sitemap.xml" target="_blank">站点地图</a></li>
                                    </ul></div>',
                            'attributes' => array(
                                'rows' => 8,
                            ),
                        ),
                        array(
                            'dependency' => array('wml_footers', '!=', ''),
                            'title' => '用户服务',
                            'id' => 'user',
                            'type' => 'textarea',
                            'default' => '<div class="navi"><h2 class="title">关于我们</h2><ul>
                                        <li><a href="/protocol" target="_blank">用户协议</a></li>
                                        <li><a href="/statement" target="_blank">免责声明</a></li>
                                        <li><a href="/privacy" target="_blank">隐私政策</a></li>
                                        <li><a target="_blank" href="/about">关于我们</a></li>
                                        <li><a href="/sitemap.xml" target="_blank">站点地图</a></li>
                                    </ul></div>',
                            'attributes' => array(
                                'rows' => 8,
                            ),
                        ),
                        array(
                            'dependency' => array('wml_footers', '!=', ''),
                            'title' => '右侧标识一',
                            'id' => 'wml_footers_text1',
                            'class' => 'compact',
                            'default' => '每日新闻',
                            'type' => 'text',
                        ),
                        array(
                            'dependency' => array('wml_footers', '!=', ''),
                            'title' => '跳转链接',
                            'id' => 'wml_footers_text1_url',
                            'class' => 'compact',
                            'type' => 'text',
                        ),
                        array(
                            'dependency' => array('wml_footers', '!=', ''),
                            'title' => ' ',
                            'id' => 'wml_footers_img1',
                            'default' => $img . 'footer/03.png',
                            'preview' => true,
                            'class' => 'compact',
                            'library' => 'image',
                            'type' => 'upload',
                        ),
                        array(
                            'dependency' => array('wml_footers', '!=', ''),
                            'title' => '右侧标识二',
                            'id' => 'wml_footers_text2',
                            'class' => 'compact',
                            'default' => '每日新闻',
                            'type' => 'text',
                        ),
                        array(
                            'dependency' => array('wml_footers', '!=', ''),
                            'title' => '跳转链接',
                            'id' => 'wml_footers_text2_url',
                            'class' => 'compact',
                            'type' => 'text',
                        ),
                        array(
                            'dependency' => array('wml_footers', '!=', ''),
                            'title' => ' ',
                            'id' => 'wml_footers_img2',
                            'default' => $img . 'footer/02.png',
                            'preview' => true,
                            'class' => 'compact',
                            'library' => 'image',
                            'type' => 'upload',
                        ),
                        array(
                            'dependency' => array('wml_footers', '!=', ''),
                            'title' => '右侧标识三',
                            'id' => 'wml_footers_text3',
                            'class' => 'compact',
                            'default' => '每日新闻',
                            'type' => 'text',
                        ),
                        array(
                            'dependency' => array('wml_footers', '!=', ''),
                            'title' => '跳转链接',
                            'id' => 'wml_footers_text3_url',
                            'class' => 'compact',
                            'type' => 'text',
                        ),
                        array(
                            'dependency' => array('wml_footers', '!=', ''),
                            'title' => ' ',
                            'id' => 'wml_footers_img3',
                            'default' => $img . 'footer/01.png',
                            'preview' => true,
                            'class' => 'compact',
                            'library' => 'image',
                            'type' => 'upload',
                        ),
                        array(
                            'dependency' => array('wml_footers', '!=', ''),
                            'title' => '底部版权',
                            'id' => 'wml_footers_copyright',
                            'class' => 'compact',
                            'default' => 'Copyright © 2022 - 2023</a> <a href="/" style="font-size:12px">外贸啦 </a> All Rights Reserved. <a rel="nofollow" target="_blank" href="https://beian.miit.gov.cn" style="font-size:12px">津ICP备2023009737号-1</a>・<a rel="nofollow" target="_blank" href="http://www.beian.gov.cn/" style="font-size:12px">津公网安备12011602300104号</a>',
                            'type' => 'textarea',
                            'attributes' => array(
                                'rows' => 8,
                            ),
                        ),
                    ),
                ),
                array(
                    'title' => '自定义页脚',
                    'id' => 'footer_custom',
                    'type' => 'fieldset',
                    'fields' => array(
                        array(
                            'title' => '自定义页脚设置',
                            'id' => 'custom_footer',
                            'type' => 'switcher',
                            'default' => false,
                        ),
                        array(
                            'dependency' => array('custom_footer', '!=', ''),
                            'title' => '更多详情',
                            'after' => '位于footer之前，直接写页脚代码，不用添加footer标签',
                            'id' => 'foot_custom',
                            'type' => 'textarea',
                            'default' => '',
                            'attributes' => array(
                                'rows' => 8,
                            ),
                        ),
                    ),
                ),
            )
        )
    );