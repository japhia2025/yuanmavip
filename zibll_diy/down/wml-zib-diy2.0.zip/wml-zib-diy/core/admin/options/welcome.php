<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 14:28:26
 $ @ 最后修改: 2024-11-14 21:55:14
 $ @ 文件路径: \wml-zib-diy\core\admin\options\welcome.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

 CSF::createSection(
    $prefix,
    array(
        'id' => 'welcome',
        'title' => '欢迎使用',
        'icon' => 'fa fa-star',
    )
);
 CSF::createSection($prefix,array(
        'parent' => 'welcome',
        'title' => '公告&说明',
        'icon' => 'fa fa-fw fa-bell',
        'fields' => CSF_Module_Wml::thank(),
    )
);
CSF::createSection($prefix, array(
    'parent' => 'welcome',
    'title'       => '系统&环境',
    'icon'        => 'fa fa-fw fa-windows',
    'fields' => array(
        array(
            'type' => 'content',
            'content' => CSF_Module_Wml::system(),
        ),
    )
));

//定制服务
CSF::createSection($prefix, array(
    'parent' => 'welcome',
    'title' => '定制&服务',
    'icon'  => 'fa fa-fw fa-th',
    'fields'      => array(
        array(
            'content' => CSF_Module_Wml::customized(),
            'type'    => 'content',
        ),

  )
));

CSF::createSection($prefix, array(
    'parent' => 'welcome',
    'title'  => '插件&授权',
    'icon'   => 'fa fa-fw fa-gitlab',
    'fields' => array(
        array(
            'type'    => 'submessage',
            'style'   => 'warning',
            'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 感谢您使用子比DIY增强插件</h3>
            <div><b>首次使用请在下方进行授权验证</b></div>
            <p>子比DIY增强插件是一款良心、厚道的好产品！创作不易，支持正版，从我做起！</p>
            <p>请确认已获取授权码，授权码激活后将与域名绑定<badge class="c-red">' . preg_replace('#^(http(s?))?(://)#','', home_url()). '</badge></p>
            <div style="margin:10px 14px;">
            <li>购买授权码：<a target="_blank" href="https://waimao.la/">https://waimao.la/user/product</a></li>
            <li>作者官网参考：<a target="_bank" href="https://waimao.la/">https://waimao.la</a></li>
            <li>作者联系方式：<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&amp;uin=181682233&amp;site=qq&amp;menu=yes">QQ 181682233 </a>或加QQ群：870461997 共同学习交流！</li>
            </div>',
        ),
        CSF_Module_Wml::aut(),
    ),
));

CSF::createSection($prefix, array(
    'parent' => 'welcome',
    'title'  => '备份&恢复',
    'icon'   => 'fa fa-fw fa-clipboard',
    'fields' => CSF_Module_Wml::backup(),
));

?>