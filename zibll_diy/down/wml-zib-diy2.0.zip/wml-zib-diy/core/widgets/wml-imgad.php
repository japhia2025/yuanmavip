<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-18 03:44:19
 $ @ 最后修改: 2024-11-14 18:30:04
 $ @ 文件路径: \wml-zib-diy\core\widgets\wml-imgad.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (wml_zib('imgad_switch', false)) {
    //注册钩子
    add_action('widgets_init', 'register_imgad');
    function register_imgad()
    {
        register_widget('wml_imgad');
    }
    class wml_imgad extends WP_Widget
    {
        public function __construct()
        {
            //定义小工具
            $widget = array(
                'w_id'        => 'wml_imgad',
                'w_name'      => 'WML - 横屏图文广告位',
                'classname'   => '',
                'description' => '首页图文广告，彩色广告，文字栏目广告',
            );
            parent::__construct($widget['w_id'], $widget['w_name'], $widget);
        }

        public function widget($args, $instance)
        {
            if (!zib_widget_is_show($instance)) {
                return;
            }
            extract($args);
            
            ?>
            <style>
            .card-head { justify-content: space-between; align-items: center; } .d-flex { display: -ms-flexbox; display: flex; } .text-sms { font-size: 14px; } .vc-yellow { color: #fff6f0; padding: 2px 10px 2px 10px; border-radius: 6px; background: #ff5c00; font-size: 14px; } .gutters-5 { display: flex; flex-flow: row wrap; padding: 5px; } .gutters-5>* { padding: 5px; } .col-sm-2 { width: 50%; } .graphicad { text-shadow: 0 0 5px rgba(0,0,0,.2); height: 60px; color: #fff; position: relative; overflow: hidden; background-size: 100% 60px; padding: 0; } .row-xs { display: -ms-flexbox; display: flex; -ms-flex-wrap: wrap; flex-wrap: wrap; } .col-md-6a { -webkit-box-flex: 0; -ms-flex: 0 0 16.666667%; flex: 0 0 16.666667%; max-width: 16.666667%; padding: 6px; } .col-md-6a a:hover { color:var(--focus-color); text-decoration: blink; } .auto-url-list { background: rgba(114, 114, 114, 0.2); padding: 10px; } .text-sm { font-size: 14px; }
            </style>
            <div class="zib-widget">
            <div class="card-head d-flex">
            <div class="text-sms">
            <i class="<?php echo wml_zib('imgad_icon');?>"></i> <b><?php echo wml_zib('imgad_name');?></b></div> 
            <a href="<?php echo wml_zib('imgad_rz_link')['url'];?>" target="<?php echo wml_zib('imgad_rz_link')['target'];?>" class="vc-yellow" data-modal_type="overflow-hidden">
                入驻说明</a>
            </div>
            <div class="gutters-5">
            <?php 
                if(wml_zib('imgad_tp')){
                    foreach(wml_zib('imgad_tp') as $val) {
                        echo '<div class="col-sm-2"> <a href="'.$val['link']['url'].'" target="'.$val['link']['target'].'">
                        <div class="graphicad" style="background-image: url(\''.$val['img'].'\');">
                        </div></a></div>';
                    }
                }
            ?>
        </div>
            <div class="row-xs">
                <?php 
                if(wml_zib('imgad_wz')){
                    foreach(wml_zib('imgad_wz') as $val) {
                        echo '<div class="col-md-6a">
                        <a href="'.$val['link']['url'].'" class="d-flex auto-url-list" target="'.$val['link']['target'].'" rel="external">
                        <div class="text-sm" style="color:'.$val['color'].';">'.$val['name'].'</div></a></div>';
                    }
                }
                ?>
            </div>
        </div>
        <?php
        }
    }
}
