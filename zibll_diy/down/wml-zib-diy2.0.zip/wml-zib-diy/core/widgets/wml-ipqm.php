<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-06 22:54:16
 $ @ 最后修改: 2024-11-14 18:24:52
 $ @ 文件路径: \wml-zib-diy\core\widgets\wml-ipqm.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (wml_zib('ipqm_switch', false)) {
    //注册钩子
    add_action('widgets_init', 'register_ipqm');
    function register_ipqm()
    {
        register_widget('wml_ipqm');
    }
    class wml_ipqm extends WP_Widget
    {
        public function __construct()
        {
            //定义小工具
            $widget = array(
                'w_id'        => 'wml_ipqm',
                'w_name'      => 'WML - IP签名档',
                'classname'   => '',
                'description' => '天气预报，侧边IP签名档',
            );
            parent::__construct($widget['w_id'], $widget['w_name'], $widget);
        }

        public function widget($args, $instance)
        {
            if (!zib_widget_is_show($instance)) {
                return;
            }
            extract($args);
            
            ?>
            <div class="zib-widget"><img class="fit-cover ls-is-cached lazyloaded lazyloadafter" data-src="<?php echo WML_ZIB_BEAUT_DIR_URL;?>/page/ipqm/ipqm.php" src="<?php echo WML_ZIB_BEAUT_DIR_URL;?>/page/ipqm/ipqm.php" alt="图片-WML"></div>
        <?php
        }
    }
}
