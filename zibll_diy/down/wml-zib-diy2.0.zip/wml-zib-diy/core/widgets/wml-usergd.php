<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-21 02:55:35
 $ @ 最后修改: 2024-11-14 21:00:14
 $ @ 文件路径: \wml-zib-diy\core\widgets\wml-usergd.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (wml_zib('usergd_switch', false)) {
    //注册钩子
    add_action('widgets_init', 'register_usergd');
    function register_usergd()
    {
        register_widget('wml_usergd');
    }
    class wml_usergd extends WP_Widget
    {
        public function __construct()
        {
            //定义小工具
            $widget = array(
                'w_id'        => 'wml_usergd',
                'w_name'      => 'WML - 首页用户滚动',
                'classname'   => '',
                'description' => '新用户注册，消费消费，评论滚动',
            );
            parent::__construct($widget['w_id'], $widget['w_name'], $widget);
        }

        public function widget($args, $instance)
        {
            if (!zib_widget_is_show($instance)) {
                return;
            }
            $width='calc(33.33333% - 8px)';//模块默认宽度
            if (wp_is_mobile()){//手机端
                if(wml_zib('usergd_mobile', false)){
                    $width='100%';
                    $mtype=wml_zib('usergd_mobile_type');
                }else{
                    return;
                }
            }
            extract($args);
            
            ?>
            <link rel="stylesheet" id="swiper-css" href="https://lib.baomitu.com/Swiper/5.4.5/css/swiper.min.css" type="text/css" media="">
            <script type="text/javascript" src="https://lib.baomitu.com/Swiper/5.4.5/js/swiper.min.js" id="swiper-js"></script>
            <style>
            .wrapper { width: 1170px; max-width: 100%; margin: 0 auto;}.home_row { position: relative;  /* border-bottom:1px dashed rgba(255, 255, 255, 0.3); */;}.home_row > div { display: flex; margin: 0 auto; max-width: 100%; position: relative;}#jitheme_new.plate-news { width: 100%; justify-content: space-between;}#jitheme_new.plate-news .swiper-container { margin: 0;}#jitheme_new.plate-news .swiper-container { width: <?php echo $width;?>; height: 80px;  display: flex;}.swiper-container { margin-left: auto; margin-right: auto; position: relative; overflow: hidden; list-style: none; padding: 0; z-index: 1;}.swiper-wrapper { position: relative; width: 100%; height: 100%; z-index: 1; display: flex; transition-property: transform,-webkit-transform; box-sizing: content-box;}#jitheme_new .news-item.orange { background: rgba(230,125,97,0.08);}#jitheme_new .news-item.blue { background: rgba(63,140,255,0.08);}#jitheme_new .news-item.green { background: rgba(70,198,158,0.08);}#jitheme_new .news-item { height: 80px !important; overflow: hidden; border-radius: 12px; display: flex; padding: 16px; float: left;}.swiper-slide { -webkit-flex-shrink: 0; -ms-flex-negative: 0; flex-shrink: 0; width: 100%; height: 100%; position: relative; -webkit-transition-property: -webkit-transform; transition-property: -webkit-transform; -o-transition-property: transform; transition-property: transform; transition-property: transform,-webkit-transform;}.swiper-container .swiper-notification { position: absolute; left: 0; top: 0; pointer-events: none; opacity: 0; z-index: -1000;}#jitheme_new .news-item h6 { font-size: 16px; line-height: 22px; display: flex; font-weight: normal;}.swiper-slide .author-name { font-size: 15px; margin-bottom: 5px; display: flex; white-space: nowrap;}.swiper-slide .author-name .uname { font-weight: bold; font-size: 15px; margin-right: 10px; max-width: 110px; overflow: hidden; text-overflow: ellipsis;}.lv-icon { font-size: 12px; font-weight: 400; color: #797C80; height: 18px; line-height: 18px; border-radius: 3px; margin-right: 3px;}.b2timeago { overflow: hidden; text-overflow: ellipsis; white-space: nowrap;}#jitheme_new .news-item h6 i { font-size: 12px; color: #91929E; line-height: 22px; right: 20px; position: absolute;}#jitheme_new .news-item p, #jitheme_new .news-item a { font-size: 12px; color: #91929E; line-height: 17px; width: 280px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; display: inline-block;}.swiper-slide>img { height: 45px; width: 45px; border-radius: 10px; margin-right: 10px;}#jitheme_new .news-item p, #jitheme_new .news-item a { font-size: 12px; color: #91929E; line-height: 17px; width: 280px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; display: inline-block;}.red { padding: 0px 5px; color: #ff3355;}dfn, cite, em, i { font-style: unset;}h6 { border: 0; font-family: inherit; font-size: 100%; font-style: inherit; font-weight: inherit; margin: 0; outline: 0; padding: 0; vertical-align: baseline; word-wrap:break-word; box-sizing: border-box;}.lv-icon-s{height: 20px;}
            </style>
            <div class="zib-widget">
            <!-- 轮播消息样式2 -->
            <div class="wrapper home_row">
                <!-- 轮播消息 -->
                <div id="jitheme_new" class="plate-news">
                    <?php 
                    if(!wp_is_mobile()||$mtype==1){
                    ?>
                    <div class="swiper-container swiper-container-vertical" id="newsOrange">
                        <div class="swiper-wrapper" style="transform: translate3d(0px, -400px, 0px); transition-duration: 0ms;">
                            <?php
                            // 执行查询    
                            $users = CSF_Module_Wml_Count::new_user();
                            // 遍历结果集并生成HTML代码    
                            if ($users) {
                                $slide = '';
                                foreach ($users as $user) {    
                                    //$link  = zib_get_user_home_url($user->ID);//用户链接
                                    $slide .= '<div class="swiper-slide news-item orange" data-swiper-slide-index="5" style="height: 80px;">';
                                    $slide .= zib_get_data_avatar($user->ID,45);//头像
                                    $slide .= '<span style="width: 25px;height: 25px;position: absolute;left: 47px;bottom: 13px;">'.zib_get_user_auth_badge($user->ID).'</span>';//认证标识
                                    $slide .= '<div class="new_fl">';
                                    $slide .= '<h6><span class="author-name"><span class="uname">'.$user->display_name.'</span>';
                                    $vip_level = zib_get_user_vip_level($user->ID);
                                    if($vip_level){//查询是否VIP
                                        $vip_img_src = zibpay_get_vip_icon_img_url($vip_level);
                                        $slide .= '<span class="lv-icon user-vip b2-vip2"><img src="'.$vip_img_src.'" style="height: 20px;" title="'._pz('pay_user_vip_'.$vip_level.'_name').'"></span>';
                                    }
                                    $slide .= '<span class="lv-icon user-lv b2-lv1">'.zib_get_user_level_badge($user->ID,'lv-icon-s').'</span>';//等级徽章
                                    $reg_date = date('Y-m-d H:i:s', strtotime($user->user_registered));//注册时间
                                    $slide .= '<i class="fr"><time class="b2timeago" datetime="'.$reg_date.'" itemprop="datePublished" timeago-id="28">'.zib_get_time_ago($reg_date).'</time></i></span></h6>';//加入时间
                                    $slide .= '<a class="txt-nowrap-ellipsis">欢迎新用户加入本站<em class="red">热烈欢迎！</em> </a>';//头像
                                    $slide .= '</div></div>';
                                }
                                echo $slide;
                            }
                            ?>
                        </div>
                    </div>
                    <?php
                    }if(!wp_is_mobile()||$mtype==2){
                    ?>
                    <!-- 购买记录 -->
                    <div class="swiper-container swiper-container-vertical swiper-container-initialized swiper-no-swiping" id="newsBlue">
                        <div class="swiper-wrapper" style="transform: translate3d(0px, -320px, 0px); transition-duration: 0ms;">
                            <?php
                            global $wpdb;
                            $total_trade = $wpdb->get_results("SELECT * FROM $wpdb->zibpay_order WHERE `status` = 1 ORDER BY $wpdb->zibpay_order . `id` DESC LIMIT 0 , ".wml_zib('cheat_xfjl')." ");
                            if($total_trade){
                                $user_vip_name = array(
                                    'vip_1' => _pz('pay_user_vip_1_name'),
                                    'vip_2' => _pz('pay_user_vip_2_name'),
                                );
                                $playtypename = array(
                                    'upgrade' => '升级了',
                                    'pay' => '购买了',
                                    'renew' => '续费了',
                                );
                                $slide = '';
                                foreach ($total_trade as $item) 
                                {
                                    $pay_mark = _pz('pay_mark');
                                    switch($item->pay_type){
                                        case 'balance':
                                            $pay_type= $pay_mark;//自定义币
                                            break;
                                        case 'card_pass':
                                            $pay_type = '充值卡充值';
                                            break;
                                        case 'points':
                                            $pay_type = '积分';
                                            break;
                                        default:
                                            $pay_type = '金额';
                                    }
                                    $slide .= '<div class="swiper-slide news-item blue" data-swiper-slide-index="5" style="height: 80px;">';
                                    $slide .= zib_get_data_avatar($item->user_id,45);//头像
                                    $slide .= '<span style="width: 25px;height: 25px;position: absolute;left: 47px;bottom: 13px;">'.zib_get_user_auth_badge($item->user_id).'</span>';//认证标识
                                    $slide .= '<div class="new_fl">';
                                    $slide .= '<h6><span class="author-name"><span class="uname">'.get_userdata($item->user_id)->display_name.'</span>';
                                    $vip_level = zib_get_user_vip_level($item->user_id);
                                    if($vip_level){//查询是否VIP
                                        $vip_img_src = zibpay_get_vip_icon_img_url($vip_level);
                                        $slide .= '<span class="lv-icon user-vip b2-vip2"><img src="'.$vip_img_src.'" style="height: 20px;" title="'._pz('pay_user_vip_'.$vip_level.'_name').'"></span>';
                                    }
                                    $slide .= '<span class="lv-icon user-lv b2-lv1">'.zib_get_user_level_badge($item->user_id,'lv-icon-s').'</span>';//等级徽章
                                    $reg_date = date('Y-m-d H:i:s', strtotime($item->pay_time));//消费时间
                                    $slide .= '<i class="fr"><time class="b2timeago" datetime="'.$reg_date.'" itemprop="datePublished" timeago-id="28">'.zib_get_time_ago($reg_date).'</time></i></span></h6>';//加入时间

                                    //金额
                                    $psy_price = maybe_unserialize($item->order_price);
                                    $product_id = $item->product_id; //vip_1_0_pay
                                    if ($product_id) {
                                        if(strstr($product_id, 'points')){
                                            $slide .= '<a class="txt-nowrap-ellipsis">'.$psy_price.$pay_type.'<em class="red">充值了积分</em> </a>';//消费记录
                                        }else{
                                            $playtype = substr($product_id, strripos($product_id, "_") + 1);
                                            $playtype = $playtypename[$playtype];
                                            $vipname = substr($product_id, 0, strrpos($product_id, "_") - 2);
                                            $vipname = $user_vip_name[$vipname];
                                            $psy_content = '<span>'.$psy_price.$pay_type.'</span>'.$playtype . '&nbsp' . $vipname;
                                            $slide .= '<a class="txt-nowrap-ellipsis">'.$psy_price.$pay_type.'<em class="red">'.$playtype.'&nbsp'. $vipname.'</em> </a>';//消费记录
                                        }
                                    } elseif (!empty($item->post_id)) {
                                        if (!get_permalink($item->post_id)) {
                                            $psy_content = '已删除资源';
                                        } else {
                                            $psy_content = get_the_title($item->post_id);
                                        }
                                        $slide .= '<a class="txt-nowrap-ellipsis">'.$psy_price .$pay_type.'&nbsp购买了&nbsp<em class="red">'.$psy_content.'</em> </a>';//消费记录
                                    }else{
                                        $psy_content = $pay_type.maybe_unserialize($item->order_price).$pay_mark ;
                                    }
                                    $slide .= '</div></div>';
                                }
                                echo $slide;
                            }
                            ?>
                        </div>
                    </div>
                    <?php
                    }if(!wp_is_mobile()||$mtype==3){
                    ?>
                    <div class="swiper-container swiper-container-vertical swiper-container-initialized swiper-no-swiping" id="newsGreen">
                        <div class="swiper-wrapper" style="transform: translate3d(0px, -240px, 0px); transition-duration: 300ms;">
                        <?php
                            // 执行查询
                            global $wpdb;
                            $args = array(
                                'orderby'        => 'comment_date',
                                'number'         => wml_zib('cheat_zjpl'),//显示数量
                                'status'         => 'approve',
                                'author__not_in' => preg_split("/,|，|\s|\n/", wml_zib('cheat_zjpl_pc')),//排除ID
                                //'post__not_in'   => preg_split("/,|，|\s|\n/", $outpost),//排除文章
                            );
                            $list = get_comments($args);
                            // 遍历结果集并生成HTML代码    
                            if ($list) {
                                $slide = '';
                                foreach ($list as $vo) {    
                                    $slide .= '<div class="swiper-slide news-item green" data-swiper-slide-index="5" style="height: 80px;">';
                                    $slide .= zib_get_data_avatar($vo->user_id,45);//头像
                                    $slide .= '<span style="width: 25px;height: 25px;position: absolute;left: 47px;bottom: 13px;">'.zib_get_user_auth_badge($vo->user_id).'</span>';//认证标识
                                    $slide .= '<div class="new_fl">';
                                    $slide .= '<h6><span class="author-name"><span class="uname">'.get_userdata($vo->user_id)->display_name.'</span>';
                                    $vip_level = zib_get_user_vip_level($vo->user_id);
                                    if($vip_level){//查询是否VIP
                                        $vip_img_src = zibpay_get_vip_icon_img_url($vip_level);
                                        $slide .= '<span class="lv-icon user-vip b2-vip2"><img src="'.$vip_img_src.'" style="height: 20px;" title="'._pz('pay_user_vip_'.$vip_level.'_name').'"></span>';
                                    }
                                    $slide .= '<span class="lv-icon user-lv b2-lv1">'.zib_get_user_level_badge($vo->user_id,'lv-icon-s').'</span>';//等级徽章
                                    $reg_date = date('Y-m-d H:i:s', strtotime($vo->comment_date));//注册时间
                                    $slide .= '<i class="fr"><time class="b2timeago" datetime="'.$reg_date.'" itemprop="datePublished" timeago-id="28">'.zib_get_time_ago($reg_date).'</time></i></span></h6>';//加入时间
                                    $slide .= '<a class="txt-nowrap-ellipsis">发言说<em class="red">'.$vo->comment_content.'</em> </a>';//头像
                                    $slide .= '</div></div>';
                                }
                                echo $slide;
                            }
                            ?>
                        </div>
                    </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
            <script>
                /*消息列表-----start*/
                var swiperOrange = new Swiper('#newsOrange', {
                    direction: 'vertical',  // 垂直轮播
                    loop : true,    //切换效果 循环
                    autoplay: {
                        delay: 2000,//1秒切换一次
                    },
                    // mousewheel: {
                    //     eventsTarged: '#newsOrange',
                    //     // eventsTarged: 'body', 鼠标在页面中任意地方都可控制swiper
                    // }
                    autoplayPauseOnMouseEnter: true,
                    autoplayDisableOnInteraction: false,
                });
                
                    
                var swiperBlue = new Swiper('#newsBlue', {
                    direction: 'vertical',
                    loop : true,    //切换效果 循环
                    autoplay: {
                        delay: 3000,//1秒切换一次
                    },
                    autoplayPauseOnMouseEnter: true,
                    autoplayDisableOnInteraction: false,
                });
                    
                var swiperGreen = new Swiper('#newsGreen', {
                    direction: 'vertical',
                    loop : true,    //切换效果 循环
                    autoplay: {
                        delay: 2500,//1秒切换一次
                    },
                    // mousewheel: {
                    //     eventsTarged: '#newsGreen',
                    //     // eventsTarged: 'body', 鼠标在页面中任意地方都可控制swiper
                    // }
                    autoplayPauseOnMouseEnter: true,
                    autoplayDisableOnInteraction: false,
                });
                
                /* 消息列表-----end */
            </script>
        </div>
        <?php
        }
    }
}
