<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-16 05:36:13
 $ @ 最后修改: 2024-11-14 18:32:00
 $ @ 文件路径: \wml-zib-diy\core\widgets\wml-hyweather.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (wml_zib('hyweather_switch', false)) {
    //注册钩子
    add_action('widgets_init', 'register_hyweather');
    function register_hyweather()
    {
        register_widget('wml_hyweather');
    }
    class wml_hyweather extends WP_Widget
    {
        public function __construct()
        {
            //定义小工具
            $widget = array(
                'w_id'        => 'wml_hyweather',
                'w_name'      => 'WML - 欢迎天气横条',
                'classname'   => '',
                'description' => '欢迎横条，天气预报',
            );
            parent::__construct($widget['w_id'], $widget['w_name'], $widget);
        }

        public function widget($args, $instance)
        {
            if (!zib_widget_is_show($instance)) {
                return;
            }
            extract($args);
            
            if(wml_zib('hyweather_theme')=='transparent'){
                $background='var(--main-bg-color)';
            }else{
                $palette=CSF_Module_Wml_Zib::zib_palette();
                $background=$palette[wml_zib('hyweather_theme')][0];
            }
            if(wml_zib('hyweather_color')){
                $color=wml_zib('hyweather_color');
            }else {$color='var(--focus-color)';}
            ?>
            <style>
                 .light-red-gradient-text {
                /* 浅红到深红的线性渐变背景 */
                background: <?php echo $background;?>; /* 从浅红到深红渐变 */
                color: <?php echo $color;?>; /* 文本颜色为白色 */
                text-align: center; /* 文本居中对齐 */
                padding: 10px; /* 内边距 */
                border-radius: 8px; /* 边框圆角 */
                width: 100%; /* 宽度 */
                margin: -5px auto; /* 外边距自动居中 */
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* 轻微的阴影效果 */
                font-size: <?php echo wml_zib('hyweather_size');?>px; /* 字体大小 */
                line-height: 1.5; /* 行高 */
            }
            </style>
            <div class="theme-box">
                <div class="light-red-gradient-text">
                <span><i class="fa fa-gitlab"></i>  <span id="weatherInfo"></span></span>
                <!--<div id="weatherInfo"></div>-->
                </div>
            </div>
            
            <script>
                eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('7 $1=$1||{};$1.n={};$1.o=2(a){4 a.8=a};$1.p=2(a,d){a.8=d;4 a};q("r://9.s.t/9/u").e(2(a){4 a.v()}).e(2(a){7 d=5.f("g"),b=a.w,c=a.x;a="\\y\\z\\0\\A\\B"+a.C+"\\D\\E\\F\\0\\G\\3\\H"+b.I+" "+b.J+"\\0\\3\\6"+b.K+"\\0\\L\\h"+b.M+"\\0\\N\\h"+b.O;c=5.P(c?a+("\\0"+c):a+"\\i");d.Q(c)}).R(2(a){S.T("\\j\\k\\3\\6\\l\\m\\U\\V\\W:",a);5.f("g").X="\\Y\\Z\\j\\k\\3\\6\\l\\m\\0\\10\\11\\12\\13\\14\\i"});',62,67,'uff0c|jscomp|function|u5929|return|document|u6c14|var|raw|api|||||then|getElementById|weatherInfo|u6e29|u3002|u83b7|u53d6|u4fe1|u606f|scope|createTemplateTagFirstArg|createTemplateTagFirstArgWithRaw|fetch|https|vvhan|com|weather|json|data|tip|u4f60|u597d|u6765|u81ea|city|u7684|u670b|u53cb|u4eca|u662f|date|week|type|u4f4e|low|u9ad8|high|createTextNode|appendChild|catch|console|error|u65f6|u51fa|u9519|textContent|u65e0|u6cd5|u8bf7|u7a0d|u540e|u518d|u8bd5'.split('|'),0,{}))
            </script>
        <?php
        }
    }
}
