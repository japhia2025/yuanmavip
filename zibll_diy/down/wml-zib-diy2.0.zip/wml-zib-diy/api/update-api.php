<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-14 10:08:02
 $ @ 最后修改: 2024-11-14 14:20:45
 $ @ 文件路径: \wml-zib-diy\api\update-api.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

$update = array(
	'name' => '子比主题-最强扩展DIY插件',
	'slug' => 'wml-zib-diy',
	'homepage' => 'https://waimao.la/',
	//'download_url' => 'https://assets.waimao.la/zibll_diy/down/WaiMaoLa_Diy.zip',
	'download_url' => '',
	'version' => '2.1',
	'requires' => '6',
	'tested' => '6.6.2',
	"requires_php" => "7.2",
	'last_updated' => '2024-11-8 08:47:45',
	'upgrade_notice' => '有新版本请及时更新',
	'author' => 'Japhia',
	'author_homepage' => 'https://waimao.la/',
	'sections' => array(
		'description' => '由Japhia整理开发的子比主题增强插件，为子比主题提供更多的扩展功能。打造子比主题最全最强最完美的插件,不改动内核文件。<br>有问题联系QQ:181682233。',
		"installation" => "将插件上传到您的网站，激活它，就是这样！",
		"changelog" => "<h4>1.1 –  January 17, 2020</h4><ul><li>Some bugs are fixed.</li><li>Release date.</li></ul>"
	),
	"banners" => array(
		"low" => "https://assets.waimao.la/zibll_diy/img/1.jpg",
		"high" => "https://assets.waimao.la/zibll_diy/img/2.jpg"
	),
	'rating' => '99',//评分
	'ratings' => array(
		5 => 663,
		4 => 14,
		3 => 8,
		2 => 3,
		1 => 1
	),//5星评价中各个星级的得分次数
	'num_ratings' => '689',//总票数
	'contributors' => array(//贡献者
		'rudrastyh' => 'https://profiles.wordpress.org/samxo2025/',
		'contributer' => 'https://profiles.wordpress.org/samxo2025/'
	),

	'donate_link' => 'https://assets.waimao.la/zibll_diy/img/wechatpay.jpg',//捐赠链接的URL
	"screenshots" => "<ol><li><a href='IMG_URL' target='_blank'><img src='IMG_URL' alt='CAPTION' /></a><p>CAPTION</p></li></ol>"
);

//判断是否授权
if(!empty($_GET['license_key' ] ) && !empty( $_GET['domain' ] ) ) {
    $logic=wml_license_check_logic($_GET['license_key'],$_GET['domain']);
    if($logic){
        $update[ 'download_url' ] = 'https://assets.waimao.la/zibll_diy/down/WaiMaoLa_Diy.zip';
    }
}
// //license_check_logic()只是您的自定义函数，用于检查许可证密钥是否有效，并相应地返回 true 或 false。
function wml_license_check_logic( $license_key, $domain) {
    global $wpdb;//开启全局
    $tab_key=$wpdb->prefix.'wlm_key';
    $tab_dom=$wpdb->prefix.'wlm_reg_domain';//注册域表名
    $db_key = $wpdb->get_row("SELECT id FROM $tab_key where `license_key` = '$license_key' and `lic_status` = 'active'");//查询KEY是否正常存在
    if($db_key){
        if($wpdb->get_var("SELECT COUNT(IF(registered_domain = '$domain', 1, NULL)) FROM $tab_dom")){
            return true;
        }
    }
}

/* if(!empty( $_GET['license_key' ] ) && wml_license_check_logic( $_GET['license_key'],$_GET['domain']) ) {
    $update[ 'download_url' ] = 'pass the URL to plugin ZIP archive here';
} */
header( 'Content-Type: application/json' );
echo json_encode( $update );

?>