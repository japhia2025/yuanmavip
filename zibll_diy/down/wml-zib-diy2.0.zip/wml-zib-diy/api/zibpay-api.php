<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-11 09:13:52
 $ @ 最后修改: 2024-11-14 06:49:44
 $ @ 文件路径: \wml-zib-diy\api\zibpay-api.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if(!isset($_POST)||empty($_POST)){
    echo json_encode(array('error' => true, 'ys' => 'danger', 'msg' => '参数传入错误'));
    exit(); //结束执行
}
//KEY验证
$key='f320618d4cd5198f3fc68ea82d17563e';
if($_POST["key"]!=$key){
    echo json_encode(array('error' => true, 'ys' => 'danger', 'msg' => '非法操作'));
    exit(); //结束执行
}
//是否允许跨域提交
if (wml_zib('dproduct_api_origin', false)){
    header('Access-Control-Allow-Origin: *');
}
header('Content-type:application/json; charset=utf-8');
//检索默认设置值
global $wpdb;//开启全局连接
$tab_key=$wpdb->prefix.'wlm_key';//KEY表名
$tab_dom=$wpdb->prefix.'wlm_reg_domain';//注册域表名
$zibpay_order=$wpdb->prefix.'zibpay_order';//子比订单表
$user_id=$_POST['user_id'];//用户ID
$order_num=$_POST['order_num'];//订单号

if (false === $wpdb->get_var("SELECT COUNT(IF(order_num = $order_num, 1, NULL)) FROM $zibpay_order")) {
    echo json_encode(array('error' => true, 'ys' => 'danger', 'msg' => '订单不存在，非法操作'));
    exit(); //结束执行
}

//检查API接口类型
/* if(isset($_POST["type"])){
    $type=$_POST["type"];
    $types=array();
    $types['pay']='pay';//支付成功
    $types['info']='info';//查询授权信息
    $types['addins']='addins';//添加域名前检测
    $types['reload']='reload';//刷新授权
    if($types[$type]){
        $fun='wml_authorize_api_'.$type;//函数设置
        $fun($_POST);//执行可变函数
    }else{
        echo json_encode(array('error' => true, 'ys' => 'danger', 'msg' => '参数无效，非法操作'));
    }
}else{
    echo json_encode(array('error' => true, 'ys' => 'danger', 'msg' => '参数无效，非法操作'));
} */

if($_POST["type"]=='pay'){//支付成功
    if($_POST["payok"]==1){//成功支付
        //global $wlm_debug_logger;//开日志出错无效
        $db_key = $wpdb->get_row("SELECT * FROM $tab_key where `txn_id` = $order_num and `subscr_id` = $user_id");//查询单KEY信息
        if(!empty($db_key)){
            echo json_encode(array('error' => true, 'ys' => 'danger', 'msg' => '许可证已存在，请勿重复提交'));
            exit(); //结束执行
        }
        //检索默认设置值。
        $options = get_option( 'wlm_plugin_options' );//获取option数据
        $lic_prefix = $options['lic_prefix'];//密钥前缀
        $max_domains = $options['default_max_domains'];//可绑定域名数
        $date_expiry=$_POST['date_expiry'];

        //让我们检查是否设置了任何特定于产品的到期日期
        if ( ! empty ( $_POST["date_expiry"] ) ) {
            //找到了特定于产品的wLM配置数据。
            $date_expiry = date( 'Y-m-d', strtotime( '+' .$_POST["date_expiry"] . ' days' ) );
        } else {
            //使用默认值，永久（从今天起101年）。
            $date_expiry = date( 'Y-m-d', strtotime( '+101 year' ) );
        }

        //用户信息
        $user = get_userdata($user_id);

        //创建密钥数据
        $fields = array();
        $fields['license_key'] = $lic_prefix.md5( $order_num.$options['lic_creation_secret'] );//前缀+密钥订单号+创建密钥，默认uniqid( $lic_prefix )
        $fields['lic_status'] = 'pending';//默认未激活
        $fields['first_name'] = $user->user_login;//名字/用户名
        $fields['last_name'] = !empty($user->user_nicename) ? $user->user_nicename: '';//姓氏/昵称
        $fields['email'] = !empty ( $user->user_email ) ? $user->user_email : '';//邮箱
        $fields['company_name'] = ''; // 公司名称，未实行
        $fields['txn_id'] = $order_num;//交易订单号
        $fields['max_allowed_domains'] = $max_domains;//最大可绑定域名数量
        $fields['date_created'] = date( "Y-m-d" ); //创建时间
        $fields['date_expiry'] = $date_expiry;//到期时间
        $fields['product_ref'] = $_POST["product_ref"]; //订单名字
        $fields['subscr_id'] = $user_id;//用户ID

        //$wlm_debug_logger->log_debug( '将许可证数据插入到许可证管理器数据库表中。' );//开日志出错无效
        //关联WLM插件执行创建动作
        //\WLM_API_Utility::insert_license_data_internal( $fields );//反斜杠保留
        $fields   = array_filter( $fields );//删除所有空值。
        $result   = $wpdb->insert( $tab_key, $fields );
    }
}elseif($_POST["type"]=='info'){//查询授权信息
    if(!empty($_POST["order_num"])){
        $db_key = $wpdb->get_row("SELECT * FROM $tab_key where `txn_id` = $order_num and `subscr_id` = $user_id");//查询单KEY信息
        if(!empty($db_key)){
            $db_dom = $wpdb->get_results("SELECT * FROM $tab_dom WHERE `lic_key_id` = $db_key->id order by id DESC");//查询KEY绑定的域名列表
            $dom_count=$wpdb->get_var("SELECT COUNT(IF(lic_key_id = $db_key->id, 1, NULL)) FROM $tab_dom");//查询KEY绑定的域名数量
            $res=array();
            $res['max_allowed_domains']=$db_key->max_allowed_domains;//域名总个数
            $res['dom_count']=$dom_count?$dom_count:0;//已绑定域名个数
            $res['license_key']=$db_key->license_key;//授权码
            $res['date_expiry']=$db_key->date_expiry;//有效期
            $res['lic_status']=$db_key->lic_status;//当前状态
            if($db_dom){//绑定的域名列表
                $i=0;
                foreach($db_dom as $val) {
                    $res['registered_domain'][$i]=$val->registered_domain;
                    $i++;
                }
            }
            echo json_encode($res);
        }
    }
}elseif($_POST["type"]=='reload'){//刷新授权
    if(!empty($_POST["order_num"])&&!empty($_POST["aut_code"])){
        $aut_code=$_POST["aut_code"];
        $db_key = $wpdb->get_row("SELECT id,max_allowed_domains FROM $tab_key where `txn_id` = $order_num and `subscr_id` = $user_id and `license_key` = '$aut_code'");//查询单KEY信息
        if(!empty($db_key)){
            $dom_count=$wpdb->get_var("SELECT COUNT(IF(lic_key_id = $db_key->id, 1, NULL)) FROM $tab_dom");//查询KEY绑定的域名数量
            if(!$dom_count){
                echo json_encode(array('error' => true, 'ys' => 'danger', 'msg' => '您还未绑定域名，请先添加'));
            }elseif($db_key->max_allowed_domains>$dom_count){//总域名数量小于已绑定域名数量
                echo json_encode(array('error' => 0));//信息已更新，正在刷新页面
                //{"error":0,"data":{"id":5469,"product_id":1,"product_name_code":"zibll_theme","order_num":"订单号","order_price":599,"order_type":"0","user_id":39398,"operator_user_id":0,"authorization_code":"授权码","authorization_url":["waimao.la","17zfy.cn"],"authorization_type":"1","authorized_url":{"waimao.la":{"time":"2024-11-09 08:51:58","url":"waimao.la"},"17zfy.cn":{"time":"2024-11-06 13:21:45","url":"17zfy.cn"}},"authorization_validity_time":"","create_time":"2024-10-08 12:08:16","update_time":"2024-11-06 11:28:18","status":"","other":"","result":true}}
            }else{
                echo json_encode(array('error' => true, 'ys' => 'danger', 'msg' => '绑定域名已满额'));
            }
        }else{
            echo json_encode(array('error' => true, 'ys' => 'danger', 'msg' => '授权码无效或非法操作'));
        }
    }else{
        echo json_encode(array('error' => true, 'ys' => 'danger', 'msg' => '参数无效，非法操作'));
    }
}elseif($_POST["type"]=='addins'){//添加域名前检测
    if(!empty($_POST["order_num"])){
        $db_key = $wpdb->get_row("SELECT id,max_allowed_domains FROM $tab_key where `txn_id` = $order_num and `subscr_id` = $user_id");//查询单KEY信息
        if(!empty($db_key)){
            $dom_count=$wpdb->get_var("SELECT COUNT(IF(lic_key_id = $db_key->id, 1, NULL)) FROM $tab_dom");//查询KEY绑定的域名数量
            if(empty($dom_count)||$db_key->max_allowed_domains>$dom_count){
                echo json_encode(array('error' => 0, 'msg' => 'success'));
            }else{
                echo json_encode(array('error' => true, 'msg' => '绑定域名已满额，无法新增域名'));
            }
        }else{
            echo json_encode(array('error' => true, 'msg' => '未查询到有效的授权码'));
        }
    }else{
        echo json_encode(array('error' => true, 'msg' => '参数错误，非法操作'));
    }
}elseif($_POST["type"]=='add'){//添加域名
    if(!empty($_POST["order_num"])&&!empty($_POST["add_domain"])){
        $db_key = $wpdb->get_row("SELECT id,license_key,max_allowed_domains FROM $tab_key where `txn_id` = $order_num and `subscr_id` = $user_id");//查询单KEY信息
        if(!empty($db_key)){
            $dom_count=$wpdb->get_var("SELECT COUNT(IF(lic_key_id = $db_key->id, 1, NULL)) FROM $tab_dom");//查询KEY绑定的域名数量
            if(empty($dom_count)||$db_key->max_allowed_domains>$dom_count){
                $add_domain=$_POST["add_domain"];
                $domain_count=$wpdb->get_var("SELECT COUNT(IF(registered_domain = '$add_domain', 1, NULL)) FROM $tab_dom");//查询域名是否已经绑定
                if(!empty($domain_count)){
                    echo json_encode(array('error' => true,'msg' => '域名已绑定，请勿重复添加'));
                    exit(); // 结束执行
                }
                //执行新增
                $dom_data = array();
                $dom_data['lic_key_id'] = $db_key->id;
                $dom_data['lic_key'] = $db_key->license_key;
                $dom_data['registered_domain'] = $add_domain;
                $dom_data['item_reference'] = $_POST["item"];
                if (false !== $wpdb->insert($tab_dom, $dom_data)) {
					//将许可证密钥状态更新为活动
					$key_data    = array( 'lic_status' => 'active' );
					$where   = array( 'id' => $db_key->id );
					$updated = $wpdb->update( $tab_key, $key_data, $where );
                    echo json_encode(array('error' => 0, 'reload' => 1, 'msg' => '添加域名成功'));
                }
            }else{
                echo json_encode(array('error' => true, 'msg' => '绑定域名已满额，无法添加'));
            }
        }else{
            echo json_encode(array('error' => true, 'msg' => '未查询到有效的授权码'));
        }
    }else{
        echo json_encode(array('error' => true, 'msg' => '参数错误，非法操作'));
    }
}elseif($_POST["type"]=='replaceins'){//更换域名检测
    if(!empty($_POST["order_num"])){
        $db_key = $wpdb->get_row("SELECT id,max_allowed_domains FROM $tab_key where `txn_id` = $order_num and `subscr_id` = $user_id");//查询单KEY信息
        if(!empty($db_key)){
            $dom_count=$wpdb->get_var("SELECT COUNT(IF(lic_key_id = $db_key->id, 1, NULL)) FROM $tab_dom");//查询KEY绑定的域名数量
            if(empty($dom_count)||$db_key->max_allowed_domains>$dom_count){
                $msg=$db_key->max_allowed_domains-$dom_count;
                echo json_encode(array('error' => 0, 'msg' => $msg));
            }else{
                echo json_encode(array('error' => true, 'msg' => '抱歉，暂不支持在线更换域名功能，请联系客服辅助更换'));
            }
        }else{
            echo json_encode(array('error' => true, 'msg' => '未查询到有效的授权码'));
        }
    }else{
        echo json_encode(array('error' => true, 'msg' => '参数错误，非法操作'));
    }
}
?>