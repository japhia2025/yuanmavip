<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-13 18:16:41
 $ @ 最后修改: 2024-11-14 13:25:15
 $ @ 文件路径: \wml-zib-diy\api\wmlaut-api.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/
if(!isset($_POST)){
    echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '参数传入错误'));
    exit(); 
}
//检索默认设置值
global $wpdb;//开启全局连接
$tab_key=$wpdb->prefix.'wlm_key';//KEY表名
$tab_dom=$wpdb->prefix.'wlm_reg_domain';//注册域表名
$options = get_option( 'wlm_plugin_options' );//获取option数据
$vkey = $options['lic_verification_secret'];//验证KEY
$domain=$_POST["domain"];//绑定域名
$lickey=!empty($_POST["lickey"])?$_POST["lickey"]:'';//授权码
//VKEY验证
if($_POST["vkey"]!=$vkey){
    echo json_encode(array('error' => 1, 'msg' => '非法操作'));
    exit();
}
//允许跨域提交
header('Access-Control-Allow-Origin: *');
header('Content-type:application/json; charset=utf-8');

if($_POST["type"]=='aut'){//激活
    if(!empty($domain)){
        //$domain_count=$wpdb->get_var("SELECT COUNT(IF(registered_domain = '$domain', 1, NULL)) FROM $tab_dom");//查询域名是否已经绑定
        $db_dom = $wpdb->get_row("SELECT * FROM $tab_dom where `registered_domain` = '$domain'");//查询单KEY信息
        if(!empty($db_dom)){
            $db_key = $wpdb->get_row("SELECT id,license_key,lic_status FROM $tab_key where `id` = '$db_dom->lic_key_id'");//查询单KEY信息
            if($db_key->lic_status=='blocked'){
                echo json_encode(array('error' => 1,'lic_status' => 'blocked', 'msg' => '授权码已被封锁，有问题请联系客服'));
            }elseif($db_key->lic_status=='expired'){
                echo json_encode(array('error' => 1,'lic_status' => 'expired', 'msg' => '授权码已过期，请续费后再使用'));
            }else{
                echo json_encode(array('error' => 0, 'license_key' => $db_key->license_key));
            }
        }else{
            if(!empty($lickey)){
                $db_key = $wpdb->get_row("SELECT id,lic_status,license_key,max_allowed_domains FROM $tab_key where `license_key` = '$lickey'");//查询单KEY信息
                if(!empty($db_key)){
                    if($db_key->lic_status=='blocked'){
                        echo json_encode(array('error' => 1,'lic_status' => 'blocked', 'msg' => '授权码已被封锁，有问题请联系客服'));
                        exit();
                    }elseif($db_key->lic_status=='expired'){
                        echo json_encode(array('error' => 1,'lic_status' => 'expired', 'msg' => '授权码已过期，请续费后再使用'));
                        exit();
                    }
                    $dom_count=$wpdb->get_var("SELECT COUNT(IF(lic_key_id = $db_key->id, 1, NULL)) FROM $tab_dom");//查询KEY绑定的域名数量
                    if(empty($dom_count)||$db_key->max_allowed_domains>$dom_count){
                        //执行新增
                        $dom_data = array();
                        $dom_data['lic_key_id'] = $db_key->id;
                        $dom_data['lic_key'] = $db_key->license_key;
                        $dom_data['registered_domain'] = $domain;
                        $dom_data['item_reference'] = '远程激活';
                        if (false !== $wpdb->insert($tab_dom, $dom_data)) {
                            //将许可证密钥状态更新为活动
                            $key_data    = array( 'lic_status' => 'active' );
                            $where   = array( 'id' => $db_key->id );
                            $updated = $wpdb->update( $tab_key, $key_data, $where );
                        }
                        echo json_encode(array('error' => 0,'license_key' => $db_key->license_key));
                    }else{
                        echo json_encode(array('error' => 1, 'msg' => '绑定域名已满额，无法新增域名'));
                    }
                }else{
                    echo json_encode(array('error' => 1, 'msg' => '授权验证失败，未找到您的授权信息'));
                }
            }else{
                echo json_encode(array('error' => 1, 'msg' => '授权验证失败，请输入授权码重试'));
            }
        }
    }else{
        echo json_encode(array('error' => 1, 'msg' => '参数错误，非法操作'));
    }
    exit();
}



?>