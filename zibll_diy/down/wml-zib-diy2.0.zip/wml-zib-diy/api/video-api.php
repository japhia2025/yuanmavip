<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-24 07:04:32
 $ @ 最后修改: 2024-11-11 09:05:18
 $ @ 文件路径: \wml-zib-diy\api\video-api.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

header('Content-type:application/json; charset=utf-8');

//是否开启游客使用
if (wml_zib('page_video_login', false)) {
    if (!is_user_logged_in()) {
        echo (json_encode(array('error' => 1, 'msg' => '请先登录')));
        exit();
    }
}
//是否开启次数限制
if (wml_zib('page_video_cs', false)) {
    //检测COOKIE是否存在
    if (!isset($_COOKIE['wml_video_down'])) {
        echo (json_encode(array('error' => 1, 'msg' => 'COOKIE异常')));
        exit();
    }
    $stime=strtotime('23:59:59')-time();//当天剩余时间
    if (!is_user_logged_in()) {//未登录
        $down=wml_zib('page_video_cs0');//游客次数
         $vip_name='游客';
        if($down<$_COOKIE['wml_video_down']){
            echo (json_encode(array('error' => 1, 'msg' => '免费次数已用完')));
            exit();
        }
    }else{
        $user_id=get_current_user_id();//获取用户ID
        $vip_level = zib_get_user_vip_level($user_id);//获取用户VIP等级
        if($vip_level==1){
            $down=wml_zib('page_video_cs1');//一级会员
            $vip_name=_pz('pay_user_vip_'.$vip_level.'_name');
        }elseif($vip_level==2){
            $down=wml_zib('page_video_cs2');//二级会员
            $vip_name=_pz('pay_user_vip_'.$vip_level.'_name');
        }else{
            $down=wml_zib('page_video_cs9');//普通会员
            $vip_name='普通会员';
        }
        if($down<$_COOKIE['wml_video_down']){
            echo (json_encode(array('error' => 1, 'msg' => '您是'.$vip_name.'，当天次数已用完')));
            exit();
        }
    }
}

!empty($_GET['url']) ? $url = $_GET['url'] : exit(json_encode(['code'=>202,"msg"=>"网址参数错误"],JSON_UNESCAPED_UNICODE));
if($_GET['type']==1){
    $api = file_get_contents(wml_zib('page_video_vapi').$url);
}else{
    $api = file_get_contents(wml_zib('page_video_papi').$url);
}
$data = json_decode($api,true);

if($_GET['type']==1&&empty($data['data']['author'])){
    exit(json_encode(['code'=>202,"msg"=>"网址参数错误"],JSON_UNESCAPED_UNICODE));
}

if (wml_zib('page_video_cs', false)) {
    $data['msg']='解析成功，您今日还有'.$down-$_COOKIE['wml_video_down'].'次';
    //增加一次
    setcookie('wml_video_down', $_COOKIE['wml_video_down']+1, time()+$stime, COOKIEPATH, COOKIE_DOMAIN, false);
}else{
    $data['msg']='解析成功，您拥有无限解析次数';
}

echo json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);