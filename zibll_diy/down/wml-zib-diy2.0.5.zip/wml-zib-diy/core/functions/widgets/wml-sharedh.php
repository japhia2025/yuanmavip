<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-12 19:53:31
 $ @ 最后修改: 2024-11-14 16:17:31
 $ @ 文件路径: \wml-zib-diy\core\widgets\wml-sharedh.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (wml_zib('sharedh_switch', false)) {
    //注册钩子
    add_action('widgets_init', 'register_sharedh');
    function register_sharedh()
    {
        register_widget('wml_sharedh');
    }
    class wml_sharedh extends WP_Widget
    {
        public function __construct()
        {
            //定义小工具
            $widget = array(
                'w_id'        => 'wml_sharedh',
                'w_name'      => 'WML - 分享导航',
                'classname'   => '',
                'description' => '侧边分享导航，联系方式',
            );
            parent::__construct($widget['w_id'], $widget['w_name'], $widget);
        }

        public function widget($args, $instance)
        {
            if (!zib_widget_is_show($instance)) {
                return;
            }
            extract($args);
            
            ?>
            <style>
                .webmaster-widget {background-color: var(--box-background-color);border-radius: 10px;}.webmaster-widget .webmaster-header {background-size: cover;height: 78px;background-repeat: no-repeat;padding: 10px;display: flex;gap: 10px;border-radius: 10px;color: var(--widget-webmaster-color);}.introduce-block-list .instance-card {display: flex;justify-content: space-between;align-items: center;padding: 15px 10px;flex-wrap: wrap;}.introduce-block-list .instance-card a {font-size: 12px;background-color: #fff;padding: 2px 5px;border-radius: 10px;}.introduce-block-list .instance-card .instance-left {display: flex;gap: 10px;}.introduce-block-list .instance-card {display: flex;justify-content: space-between;align-items: center;padding: 15px 10px;flex-wrap: wrap;}.introduce-block-list .instance-card a {font-size: 12px;background-color: #fff;padding: 2px 5px;border-radius: 10px;}.introduce-block-list .instance-card .instance-left {display: flex;gap: 10px;}.introduce-item-list {display: grid;grid-template-columns: 1fr 1fr;grid-column-gap: 10px;}.introduce-item-list .instance-card {padding: 10px;}.introduce-item-list .instance-url {display: none;}.introduce-item-list .instance-card:nth-child(2n) .instance-bg-1 {top: -100px;left: 40px;}.instance-card {color: var(--widget-webmaster-color);border-radius: 10px;font-weight: 500;margin-top: 10px;position: relative;overflow: hidden;}.instance-card .instance-bg-1 {position: absolute;top: -100px;left: -20px;z-index: 1;}.instance-card .instance-left {z-index: 2;position: relative;}.instance-card .instance-value {overflow: hidden;text-overflow: ellipsis;white-space: nowrap;}.introduce-block-list .instance-card .instance-left {display: flex;gap: 10px;}.instance-card .instance-left {z-index: 2;position: relative;}.instance-card .instance-value {overflow: hidden;text-overflow: ellipsis;white-space: nowrap;}.instance-card .instance-bg-1 {position: absolute;top: -100px;left: -20px;z-index: 1;}.introduce-item-list {display: grid;grid-template-columns: 1fr 1fr;grid-column-gap: 10px;}.czs-link-l:before {content: "\e9bc";}.posts-item.card .item-heading {position: relative;line-height: 1.4em;min-height: 1.8em;max-height: 1.8em;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;}.author-tag .but {margin: 1px;}body.nav-fixed {padding-top: 75px;}@media (max-width: 640px) {body.nav-fixed {padding-top: 55px;}}.posts-item .item-heading>a {font-weight: bold;color: unset;}.pagenav {padding: 15px 0 0 0;}.header-slider-search-more.before {margin-bottom: 0.2em;}.header-slider-search {top: calc(50% - 40px);}.filter-blur .header-slider-card .zib-widget {background: rgb(255 255 255 / 50%);}.header-slider-card {margin-top: -15px;z-index: 1;}.swiper-scroll .swiper-slide {margin-right: 19px;}.payvip-icon:before {content: '\f143';}
            </style>
            <div class="zib-widget">
            <div class="webmaster-widget">
            <?php
            $palette=CSF_Module_Wml_Zib::zib_palette();//颜色表
            //导航一
            $list=wml_zib('sharedh_dh1');
            if(!empty($list)){
                $i=1;
                foreach($list as $val) {
                    empty($val['name_color'])?$name_color='':$name_color='style="color:'.$val['name_color'].';"';//默认名字颜色
                    empty($val['info_color'])?$info_color='':$info_color='style="color:'.$val['info_color'].';"';//默认介绍颜色
                    
                    $i==1?$mb='margin-bottom: 10px;':$mb='';
                    echo '<div class="webmaster-header" style="background: '.$palette[$val['bg_color']][0].';'.$mb.'">
                        <img class="webmaster-avatar" src="'.$val['logo_url'].'" height="50" width="50">
                        <div>
                        <div '.$name_color.'>'.$val['name'].'</div>
                        <div class="webmaster-description" '.$info_color.'>'.$val['info'].'</div>
                        </div>
                        </div>';
                    $i++;
                }
            }
            ?>

            <div class="introduce-block-list">
            <?php
            //导航二
            $list=wml_zib('sharedh_dh2');
            if(!empty($list)){
                foreach($list as $val) {
                    empty($val['name_color'])?$name_color='':$name_color='style="color:'.$val['name_color'].';"';//默认名字颜色
                    empty($val['info_color'])?$info_color='':$info_color='style="color:'.$val['info_color'].';"';//默认介绍颜色
                    echo '<div class="instance-card" style="background-color: '.$palette[$val['bg_color']][0].'">
                    <div class="instance-left">
                    <div class="instance-name" '.$name_color.'>'.$val['name'].':</div>
                    <div class="instance-value" '.$info_color.'>'.$val['info'].'</div>
                    </div>
                    <div class="instance-url">
                    <a href="'.$val['link']['url'].'" target="'.$val['link']['target'].'" title="'.$val['link']['text'].'" style="color:'.$palette[$val['bg_color']][0].' ">
                    <i class="fa fa-linkedin-square"></i> 去看看</a>
                    </div>
                    <img src="'.WML_ZIB_BEAUT_DIR_ASSETS.'/img/widgets/sharedh_bs.png " class="instance-bg-1">
                    </div>';
                }
            }
            ?>
            </div>

            <div class="introduce-item-list">
            <?php
            //导航三
            $list=wml_zib('sharedh_dh3');
            if(!empty($list)){
                foreach($list as $val) {
                    empty($val['name_color'])?$name_color='':$name_color='style="color:'.$val['name_color'].';"';//默认名字颜色
                    empty($val['info_color'])?$info_color='':$info_color='style="color:'.$val['info_color'].';"';//默认介绍颜色
                    echo '<div class="instance-card" style="background-color: '.$palette[$val['bg_color']][0].'">
                    <div class="instance-left">
                    <div class="instance-name" '.$name_color.'>'.$val['name'].':</div>
                    <div class="instance-value" title="'.$val['info'].'" '.$info_color.'>'.$val['info'].'</div>
                    </div>
                    <img src="'.WML_ZIB_BEAUT_DIR_ASSETS.'/img/widgets/sharedh_bs.png " class="instance-bg-1">
                    </div>';
                }
            }
            ?>
            </div>
            
            </div>
            </div>
        <?php
        }
    }
}
