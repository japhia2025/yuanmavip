<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 21:42:10
 $ @ 文件路径: \wml-zib-diy\core\functions\beautify\wml-bottom.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/


//  底部二维码滤镜一
if (wml_zib('erweima1', false))
{
    function wml_zib_erweima1() { ?>
        <style>
            .footer-miniimg {filter: hue-rotate(80deg);}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_erweima1');
}

// 底部二维码滤镜二
if (wml_zib('erweima2', false))
{
    function wml_zib_erweima2() { ?>
        <style>
            .footer-miniimg {filter: invert(1);}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_erweima2');
}

// 底部二维码滤镜三
if (wml_zib('erweima3', false))
{
    function wml_zib_erweima3() { ?>
        <style>
            .footer-miniimg {filter: drop-shadow(0 0 10px dodgerblue);}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_erweima3');
}

// 底部收藏本站
if (wml_zib('dixian', false))
{
    function wml_zib_dixian() { ?>
        <script>
            $('footer').before('<img id="dixian" src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/img/footer/dixian2.gif' ?>"/><style>#dixian{width:1000px;height:70px;margin-left:19%;}@media screen and (max-width: 800px){#dixian{width:1000px;height:50px;margin-left:6%;}}</style>');
        </script>
        <?php }
    add_action('wp_footer', 'wml_zib_dixian');
}

// 底部添加蓝色波浪
if (wml_zib('wave', false))
{
    function wml_zib_wave() {
        if (!is_page('user-sign')) {
            if(wml_zib('wave_type')==1){
            ?>
                <div class="ape_layout"><svg class="editorial" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 24 150 28" preserveAspectRatio="none">
                        <defs>
                            <path id="gentle-wave" d="M-160 44c30 0
                            58-18 88-18s
                            58 18 88 18
                            58-18 88-18
                            58 18 88 18
                            v44h-352z" />
                        </defs>
                        <g class="parallax">
                            <use xlink:href="#gentle-wave" x="50" y="0" fill="#4579e2" />
                            <use xlink:href="#gentle-wave" x="50" y="3" fill="#3461c1" />
                            <use xlink:href="#gentle-wave" x="50" y="6" fill="#2d55aa" />
                        </g>
                    </svg></div>
                <style type='text/css'>
                    .parallax>use {animation: move-forever 12s linear infinite }.parallax>use:nth-child(1) {animation-delay: -2s }.parallax>use:nth-child(2) {animation-delay: -2s;animation-duration: 5s }.parallax>use:nth-child(3) {animation-delay: -4s;animation-duration: 3s }@keyframes move-forever {0% {transform: translate(-90px, 0%) }100% {transform: translate(85px, 0%) }}.ape_layout {width: 100%;height: 40px;position: relative;overflow: hidden;z-index: 1;background: var(--footer-bg) }.editorial {display: block;width: 100%;height: 40px;margin: 0 }
                </style>
            <?php
            }else{ ?>
                <div id="jsi-flying-fish-container"></div>
                <script src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS.'/js/yuqun.js' ?>"></script>
            <?php }
        }
    }
    add_action('wp_footer', 'wml_zib_wave');
}

// 右下角蒲公英
if (wml_zib('plbj5', false))
{
    function wml_zib_plbj5() { ?>
        <link rel="stylesheet" href="<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/css/pugongying.css' ?>">
        <div class="dandelion"><span class="smalldan"></span><span class="bigdan"></span></div>
    <?php }
    add_action('wp_footer', 'wml_zib_plbj5');   
}

// 右下角MySSL认证
if (wml_zib('myssl', false))
{
    function wml_zib_myssl() { ?>
        <div id="cc-myssl-id" style="position: fixed;right: 0;bottom: 0;width: 65px;height: 65px;z-index: 99;">
            <a href="https://myssl.com/<?php echo wml_zib('myssl_url') ?>?from=mysslid" target="_blank"><img src="<?php echo wml_zib('myssl_id') ?>" alt="" style="width:100%;height:100%"></a>
        </div>
    <?php }
    add_action('wp_footer', 'wml_zib_myssl');
}

// 网站运行时间
if (wml_zib('timeauthor', false))
{
    function wml_zib_timeauthor() { ?>
        <script>
            $('footer').before('<span id="bottomtime"></span>');
            function NewDate(str) {
                str = str.split('-');
                var date = new Date();
                date.setUTCFullYear(str[0], str[1] - 1, str[2]);
                date.setUTCHours(0, 0, 0, 0);
                return date;
            }
            function momxc() {
                var birthDay = NewDate("<?php
                                        echo wml_zib('timeauthor1');
                                        ?>");
                var today = new Date();
                var timeold = today.getTime() - birthDay.getTime();
                var sectimeold = timeold / 1000
                var secondsold = Math.floor(sectimeold);
                var msPerDay = 24 * 60 * 60 * 1000;
                var e_daysold = timeold / msPerDay;
                var daysold = Math.floor(e_daysold);
                var e_hrsold = (daysold - e_daysold) * -24;
                var hrsold = Math.floor(e_hrsold);
                var e_minsold = (hrsold - e_hrsold) * -60;
                var minsold = Math.floor((hrsold - e_hrsold) * -60);
                var seconds = Math.floor((minsold - e_minsold) * -60).toString();
                seconds = seconds > 9 ? seconds : "0" + seconds; //秒数补全
                minsold = minsold > 9 ? minsold : "0" + minsold; //分数补全
                hrsold = hrsold > 9 ? hrsold : "0" + hrsold; //时数补全
                document.getElementById("bottomtime").innerHTML = "本站已安全运行" + daysold + "天 " + hrsold + "时 " + minsold + "分 " + seconds + "秒";
                setTimeout(momxc, 1000);
            }
            momxc();
            $(document).ready(function() {
                if (window.screen.width < window.screen.height) {
                    $("#bottomtime").hide();
                } else {
                    $("#bottomtime").show();
                }
            })
        </script>
        <style>
            #bottomtime {z-index: 99999;animation: change 10s infinite;font-size: 11px;color: cornflowerblue;display: block;bottom: 7px;left: 34%;width: 250px;position: fixed;}@keyframes change {0% {color: #5cb85c;}25% {color: #556bd8;}50% {color: #e40707;}75% {color: #66e616;}100% {color: #67bd31;}}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_timeauthor');
}
