<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 19:48:31
 $ @ 文件路径: \wml-zib-diy\core\functions\feature\wml-message.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

    // 文章发布时通知全站用户
    function wml_zib_new_post_emal_send($post_ID)
    {
        if (wml_zib('post_emal_send')) {
            if (wp_is_post_revision($post_ID)) return;
            global $wpdb;
            $blogurl   = get_bloginfo('url');
            $get_post_info = get_post($post_ID);
            if ($get_post_info->post_status == 'publish' && $_POST['original_post_status'] != 'publish') {
                $wp_user_email = $wpdb->get_results("SELECT DISTINCT * FROM $wpdb->users");
                foreach ($wp_user_email as $email) {
                    $user_id = $email->ID;
                    if (!zib_msg_is_allow_receive($user_id, 'posts')) return;
                    $fsemail = $email->user_email;
                    $subject = '' . get_bloginfo('name') . '更新啦！';
                    $message = '尊敬的 ' . $email->display_name . ' :<br>您关注的' . get_bloginfo('name') . '更新了一篇新文章：<h2>' . get_the_title($post_ID) . '</h2><p style="padding: 10px 15px; border-radius: 8px; background: rgba(141, 141, 141, 0.05); line-height: 1.7;">' . zib_get_excerpt() . '</p><br><br>您可以点击下方按钮查看更新内容<br><a target="_blank" style="margin-top: 20px;padding:5px 20px" class="but jb-blue"  href="' . get_permalink($post_ID) . '" rel="noopener">立即查看</a><br><br>如有打扰在<a href="' . $blogurl . '/user" rel="noopener" target="_blank">消息通知</a>中关闭掉文章评论选项即可';
                    wp_mail($fsemail, $subject, $message);
                }
            }
        }
    }
    add_action('publish_post', 'wml_zib_new_post_emal_send');

    // 文章更新通知评论过的用户
    function wml_zib_update_emal_send($post_ID, $post_after, $post_before)
    {
        if (wml_zib('post_emal_update')) {

            // 检查文章是否确实被更新（不是新建立的）
            if ($post_after->post_date == $post_after->post_modified) return;

            // 获取评论过的用户的电子邮件
            $args = array(
                'post_id' => $post_ID,
                'status' => 'approve'
            );
            $comments = get_comments($args);
            $notified_users = array(); // 存储已经发送过通知邮件的用户的电子邮件
            foreach ($comments as $comment) {
                if (!empty($comment->comment_author_email) && !in_array($comment->comment_author_email, $notified_users) && filter_var($comment->comment_author_email, FILTER_VALIDATE_EMAIL)) {
                    array_push($notified_users, $comment->comment_author_email);
                }
            }

            // 邮件主题和内容
            $subject = '我们更新了您评论过的文章!';
            $message = '您好，' . "\r\n\r\n";
            $message .= '一篇您之前评论过的文章《' . $post_after->post_title . '》已经有了更新。' . "\r\n";
            $message .= '您可以点击以下链接查看文章的最新内容：' . "\r\n";
            $message .= get_permalink($post_ID) . "\r\n\r\n";
            $message .= '谢谢您的参与，期待您再次光临！' . "\r\n";
            $message .= get_bloginfo('name') . "\r\n";

            // 发送邮件
            foreach ($notified_users as $email) {
                wp_mail($email, $subject, $message);
            }
        }
    }
    add_action('post_updated', 'wml_zib_update_emal_send', 10, 3);

    // 用户登陆提醒
    function wml_zib_user_login_email_send($user_login, $user)
    {
        if (wml_zib('user_login')) {
            // 检查是否已发送过登录提醒
            if (get_user_meta($user->ID, 'sent_login_email', true)) {
                // 如果已发送过，不再发送
                return;
            }

            // 获取用户上一次登录的信息
            $last_login = get_user_meta($user->ID, 'last_login', true);

            $last_login_info = '';
            if (!empty($last_login)) {
                $last_login_info = "上次登录时间：{$last_login['time']}\n上次登录IP：{$last_login['ip']}\n上次登录浏览器：{$last_login['browser']}\n\n";
            }

            // 更新用户元数据，存储当前登录的信息
            $current_login = array(
                'time' => current_time('mysql'),
                'ip' => $_SERVER['REMOTE_ADDR'],
                'browser' => $_SERVER['HTTP_USER_AGENT']
            );
            update_user_meta($user->ID, 'last_login', $current_login);

            // 设置登录提醒已发送的标记
            update_user_meta($user->ID, 'sent_login_email', true);

            // 邮件内容
            $subject = '您已成功登录网站';
            $message = "您已在 " . $current_login['time'] . " 通过 IP： " . $current_login['ip'] . " 使用浏览器： " . $current_login['browser'] . " 登录了网站。\n\n" . $last_login_info;

            // 发送邮件给用户
            wp_mail($user->user_email, $subject, $message);
        }
    }
    add_action('wp_login', 'wml_zib_user_login_email_send', 10, 2);

    // 用户登出时清除登录提醒标记
    function clear_login_notification_flag($user_id)
    {
        if (wml_zib('user_login_emal')) {
            delete_user_meta($user_id, 'sent_login_email');
        }
    }
    add_action('clear_auth_cookie', 'clear_login_notification_flag');

    //用户资料变更提醒
    function wml_zib_user_profile_update_email_send($user_id, $old_user_data)
    {
        if (wml_zib('Wml_zib_user_update')) {
            $user = get_userdata($user_id);

            // 用户电子邮件地址
            $to = $user->user_email;

            // 邮件标题
            $subject = '您的账户资料已更新';

            // 设置邮件消息内容
            $message = "尊敬的 " . $user->display_name . ",\n\n" .
                "您的账户资料已经在 " . get_bloginfo('name') . " 上成功更新。\n\n" .
                "如果您没有请求此变更，请尽快联系我们。\n\n" .
                "此致\n\n" .
                get_bloginfo('name') . " 团队";

            // 邮件头部信息
            $headers = array('Content-Type: text/plain; charset=UTF-8');

            // 发送邮件
            wp_mail($to, $subject, $message, $headers);
        }
    }
    // 添加动作钩子，当用户资料更新时触发
    add_action('profile_update', 'wml_zib_user_profile_update_email_send', 10, 2);

    function notify_referrer_on_new_registration($new_user_id)
    {
        if (wml_zib('Wml_zib_user_reg')) {
            // 获取新注册用户的数据
            $new_user_data = get_userdata($new_user_id);

            // 假设我们在用户注册时，通过某种方式保存了推荐人的ID
            // 例如，可能保存在用户的meta数据中
            $referrer_id = get_user_meta($new_user_id, 'referrer_id', true);

            if (!empty($referrer_id)) {
                // 获取推荐人的数据
                $referrer_data = get_userdata($referrer_id);
                if ($referrer_data) {
                    // 设置邮件标题和内容
                    $blog_name = get_bloginfo('name');
                    $subject = '您推广的好友已成功注册';
                    $message = "亲爱的 {$referrer_data->display_name},\n\n";
                    $message .= "您推广的好友 {$new_user_data->display_name} 已经成功在 {$blog_name} 网站上注册。\n\n";
                    $message .= "访问下面的链接查看您的推广成果：\n";
                    $message .= site_url('/referrer-area'); // 替换为您的推荐区域URL

                    // 设置邮件头部信息
                    $headers = array('Content-Type: text/plain; charset=UTF-8');

                    // 发送邮件
                    wp_mail($referrer_data->user_email, $subject, $message, $headers);

                    // 这里，您也可以执行其他相关逻辑，例如更新推荐人的统计数据、奖励积分等
                }
            }
        }
    }
    // 当新用户注册时触发此函数
    add_action('user_register', 'notify_referrer_on_new_registration', 10, 1);

