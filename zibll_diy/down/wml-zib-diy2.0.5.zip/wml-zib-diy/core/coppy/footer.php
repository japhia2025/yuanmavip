<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 21:43:19
 $ @ 文件路径: \wml-zib-diy\core\coppy\footer.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

?>
<?php if (wml_zib('footer', false)) {
	do_action('wml_footer');
} else { ?>
	<footer class="footer">
		<?php if (function_exists('dynamic_sidebar')) {
			dynamic_sidebar('all_footer');
		} ?>
		<div class="container-fluid container-footer">
			<?php do_action('zib_footer_conter'); ?>
		</div>
	</footer>
<?php }
wp_footer();
?>

</body>

</html>