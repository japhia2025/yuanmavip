<?php
/**
 * 配置文件
 *
 * @package WP_REAL_PERSON_VERIFY
 */

define( 'THNBO_VERSION', '1.5' );

define( 'THNBO_ROOT_PATH', plugin_dir_path( __FILE__ ) );

define( 'THNBO_ROOT_URL', plugin_dir_url( __FILE__ ) );
