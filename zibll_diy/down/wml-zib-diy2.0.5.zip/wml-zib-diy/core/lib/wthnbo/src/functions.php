<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-24 00:57:05
 $ @ 最后修改: 2024-11-24 03:15:59
 $ @ 文件路径: \wml-zib-diy\core\lib\wthnbo\src\functions.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/
/**
 * 公共函数库
 *
 * @package THNBO
 */

use THNBO\Src\Cut_Theme;
use THNBO\Src\Cut_Type;

/**
 * 获取选项
 *
 * @param string $name 选项名，为空时返回本插件所有选项否则返回具体的选项值
 *
 * @return array|mixed
 */
function thnbo_get_option( string $name = '' ) {
    //$thnbo_options = get_option( 'thnbo_options' );
    $thnbo_options=array();
    $thnbo_options['cut_type']=wml_zib('cut_type');
    $thnbo_options['cut_theme']=wml_zib('cut_theme');
    $defaults      = array(
        'cut_type'  => Cut_Type::CENTER,
        'cut_theme' => Cut_Theme::RESOURCE,
    );

    if ( ! empty( $name ) ) {
        return wp_parse_args( $thnbo_options, $defaults )[ $name ];
    }

    return wp_parse_args( $thnbo_options, $defaults );
}
