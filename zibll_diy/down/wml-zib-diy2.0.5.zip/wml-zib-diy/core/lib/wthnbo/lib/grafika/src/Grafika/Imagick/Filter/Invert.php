<?php

namespace WTHNBO\Grafika\Imagick\Filter;

use WTHNBO\Grafika\FilterInterface;
use WTHNBO\Grafika\Imagick\Image;

/**
 * Invert the image colors.
 */
class Invert implements FilterInterface{

    /**
     * @param Image $image
     *
     * @return Image
     */
    public function apply( $image ) {

        $image->getCore()->negateImage(false);
        return $image;
    }

}