<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-23 20:33:57
 $ @ 最后修改: 2024-11-24 06:46:46
 $ @ 文件路径: \wml-zib-diy\core\lib\index.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (! defined('ABSPATH')) {
	die;
}
//if (wml_zib('imk_onOff', false)) {
	require_once 'watermark/wml-imk.php';//上传图片水印
//}
if (wml_zib('thumbnail_is', false)) {
	require_once 'wthnbo/wthnbo.php';//缩略图边框裁剪
}
?>