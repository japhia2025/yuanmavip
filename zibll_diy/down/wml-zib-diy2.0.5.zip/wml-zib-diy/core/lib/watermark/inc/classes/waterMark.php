<?php
// php 7.4
class ImageWatermark {
    private $status_info = null;
    private $img_path; // 源图片路径
    private $output_path; // 输出水印图片的路径
    private $type; // 水印类型
    private $content; // 水印文字
    private $font; // 文字水印字体路径
    private $color; // 文字水印颜色
    private $water_path; // 图片水印路径
    private $angle; // 水印倾斜角
    private $size; // 水印大小（以像素为单位）
    private $opacity; // 水印透明度（0-100）
    private $site; // 水印位置 1.九宫格 2.随机九宫格 3.铺满
    private $jgg_site; // 1-9九宫格的九个位置
    private $padding; // 水印边距
    private $spacing; // 水印间距
    private $row_height; // 水印铺满时的行高
    private $interleaving; // 水印铺满时的交错效果
    private $imagick; // Imagick 对象

    // 构造函数
    public function __construct($imk_data_args = array()) {
        
        $this->img_path = $imk_data_args['img_path'] ?? null;
        $this->output_path = $imk_data_args['output_path'] ?? null;
        $this->type = $imk_data_args['type'] ?? null;
        $this->content = $imk_data_args['content'] ?? '';
        $this->font = $imk_data_args['font'] ?? null;
        $this->color = $imk_data_args['color'] ?? '#ffffff';
        //$this->water_path = $imk_data_args['water_path'] ?? null;
        $this->water_path = wml_zib('img_url') ?? null;//水印图片路径
        $this->angle = $imk_data_args['angle'] ?? 0;
        $this->size = $imk_data_args['size'] ?? 100; // 默认大小为100像素
        $this->opacity = $imk_data_args['opacity'] ?? 50;
        $this->site = $imk_data_args['site'] ?? 1;
        $this->jgg_site = $imk_data_args['jgg_site'] ?? 1;
        $this->padding = $imk_data_args['padding'] ?? 0;
        $this->spacing = $imk_data_args['spacing'] ?? 10;
        $this->row_height = $imk_data_args['row_height'] ?? 10;
        $this->interleaving = $imk_data_args['interleaving'] ?? 10;
        
    }
    // 删除临时图片
    private function DeleteTemporaryImages($img_path) {
        $files = glob($img_path);
        foreach ($files as $file) {
            @unlink($file);
        }
    }
    // 获取图片信息
    private function getImageInfo($imagePath) {
        $image = new Imagick($imagePath);
        return [$image->getImageWidth(), $image->getImageHeight()];
    }

    // 获取水印位置
    private function getWatermarkPosition($width, $height) {
        $img_info = $this->getImageInfo($this->img_path);
        $img_width = $img_info[0];
        $img_height = $img_info[1];
        // 基线位置
        $baseline_height = $this->type == 1 ? $height * 0.2 : $height;
        $positions = [];

        if ($this->site == 3) {
            // 铺满模式
            $horizontal_spacing = $width + $this->spacing; // 水印之间的水平间距
            $vertical_spacing = $this->row_height > 0 ? ($height + $this->row_height) : ($height + $this->spacing); // 行间距
            $columns = floor(($img_width - $width) / $horizontal_spacing) + 1; // 计算每行的水印数量
            $rows = floor(($img_height - $height) / $vertical_spacing) + 1; // 计算行数
            $first_line = 0; // 首行的行高
            for ($row = 0; $row < $rows; $row++) {
                $first_line = ($row == 1) ? $this->row_height : 0;
                for ($col = 0; $col < $columns; $col++) {
                    $x = $this->spacing + $col * $horizontal_spacing;
                    $y = $this->row_height + $row * $vertical_spacing; // 第一行的y坐标需要加上初始的间距
                    // 应用交错效果，整行偏移
                    if ($this->interleaving && $row % 2 === 1) {
                        $x += $this->interleaving;
                    }
                    $positions[] = ['x' => $x, 'y' => $y];
                }
            }
        } else {
            // 九宫格或随机九宫格
            if ($this->site == 1) {
                $jgg_site = $this->jgg_site;
            } else if ($this->site == 2) {
                $jgg_site = mt_rand(1, 9);
            }

            switch ($jgg_site) {
                case 1: // 左上角
                case 4: // 左下角
                case 7: // 左中
                    $x = $this->padding;
                    break;
                case 2: // 上部居中
                case 5: // 底部居中
                case 8: // 内部居中
                    $x = ($img_width - $width) / 2;
                    break;
                case 3: // 右上角
                case 6: // 右下角
                case 9: // 右中
                    $x = $img_width - $width - $this->padding;
                    break;
            }

            switch ($jgg_site) {
                case 1: // 左上角
                case 2: // 上部居中
                case 3: // 右上角
                    $y = $this->padding + $height - $baseline_height;
                    break;
                case 4: // 左下角
                case 5: // 底部居中
                case 6: // 右下角
                    $y = $img_height / 2 + $this->padding;
                    break;
                case 7: // 左中
                case 8: // 内部居中
                case 9: // 右中
                    $y = $img_height - $baseline_height - $this->padding;
                    break;
            }

            $positions[] = ['x' => $x, 'y' => $y];
        }

        return $positions;
    }

    // 添加文字水印
    private function addTextWatermark() {
        if (!file_exists($this->font)) 
        {
            $this->status_info = array('code' => -3, 'msg' => '字体文件不存在。');
            return false;
        }
        $draw = new ImagickDraw();
        $draw->setFont($this->font);
        $draw->setFontSize($this->size);
        $draw->setFillColor($this->hex2rgb($this->color, $this->opacity / 100));
        $draw->setTextAntialias(true);
        
        // 获取文字大小
        $metrics = $this->imagick->queryFontMetrics($draw, $this->content);
        $text_width = $metrics['textWidth'];
        $text_height = $metrics['textHeight'];
        
        // 获取水印位置
        $positions = $this->getWatermarkPosition($text_width, $text_height);
        //$draw->rotate(); // 应用倾斜角度
        // 循环添加水印
        foreach ($positions as $position) {
            $this->imagick->annotateImage($draw, $position['x'], $position['y'], $this->angle, $this->content);
        }
        return true;
    }

    // 添加图片水印
    private function addImageWatermark() {
        $watermark = new Imagick($this->water_path);

        // 获取原始水印图片的宽度和高度
        $original_width = $watermark->getImageWidth();
        $original_height = $watermark->getImageHeight();

        // 计算水印的缩放比例，确保水印的宽度或高度不超过 $this->size
        $scale_width = $this->size / $original_width;
        $scale_height = $this->size / $original_height;
        $scale = min($scale_width, $scale_height);

        // 计算新的水印宽度和高度
        $new_width = $original_width * $scale * 5.6;
        $new_height = $original_height * $scale * 5.6;

        // 缩放水印图片
        $watermark->resizeImage($new_width, $new_height, Imagick::FILTER_LANCZOS, 1, false);

        // 设置水印的透明度
        $watermark->setImageAlphaChannel(Imagick::ALPHACHANNEL_ACTIVATE);
        $watermark->evaluateImage(Imagick::EVALUATE_MULTIPLY, $this->opacity / 100, Imagick::CHANNEL_ALPHA);
        $watermark->rotateImage(new ImagickPixel('transparent'), $this->angle);
        // 获取水印位置
        $positions = $this->getWatermarkPosition($new_width, $new_height);

        // 循环添加水印
        foreach ($positions as $position) {
            // 将水印图片合并到目标图片上
            $this->imagick->compositeImage($watermark, Imagick::COMPOSITE_OVER, $position['x'], $position['y']);
        }
        return true;
    }

    // 保存图片
    public function saveImage() {
        $this->imagick->writeImage($this->output_path);
        // 删除网络下载图片
        // 检查文件名是否包含 "viu-download"
        $filename = imk_get_img_info($this->img_path); // 获取文件名
        if (strpos($filename['name'], 'viu-download-') !== false) {
            // 如果包含 "viu-download"，则删除文件
            if (file_exists($this->img_path)) {
                @unlink($this->img_path);
            }
        }
        $this->status_info = array('code' => 0, 'msg' => '图片保存成功。');
        return true;
    }

    // 释放资源
    public function __destruct() {
        if ($this->imagick !== null) {
            $this->imagick->clear();
            $this->imagick->destroy();
        }
    }

    // 将十六进制颜色转换为RGBA
    private function hex2rgb($hex, $opacity) {
        list($r, $g, $b) = sscanf($hex, "#%02x%02x%02x");
        return "rgba($r, $g, $b, $opacity)";
    }

    // 添加水印并保存图片
    public function process() {
        if (!extension_loaded('imagick')) {
            return array('code' => -1, 'msg' => 'imagemagick 扩展未安装，请先安装 imagemagick 扩展。');
        }
        $this->imagick = new Imagick($this->img_path);
        // 删除临时图片
        $this->DeleteTemporaryImages(IMK_COM_DIR . 'assets/img/viu-preview-*');
        if ($this->type == 1) {
            if(!$this->addTextWatermark())
            {
                return $this->status_info;
            }
        } elseif ($this->type == 2) {
            if(!$this->addImageWatermark())
            {
                return $this->status_info;
            }
        } else {
            return array('code' => -2, 'msg' => '无效的水印类型。');
        }

        return $this->saveImage() ? $this->status_info : array('code' => -4, 'msg' => '图片保存失败。');
    }
}
