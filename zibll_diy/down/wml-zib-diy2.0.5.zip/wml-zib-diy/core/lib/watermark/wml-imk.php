<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-06 19:42:27
 $ @ 最后修改: 2024-11-14 18:43:36
 $ @ 文件路径: \wml-zib-diy\core\watermark\wml-imk.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

// 禁止直接访问
if (!defined('ABSPATH')) {
    exit;
}
// 系统分隔符
define('IMK_DEPR', DIRECTORY_SEPARATOR);
define( 'IMK_URL_INC', plugin_dir_url( __FILE__ ). 'inc/' );
define( 'IMK_DIR_INC', plugin_dir_path( __FILE__ ). 'inc/' );
define( 'IMK_COM_URL', plugins_url('',__FILE__).'/' );
define( 'IMK_COM_DIR', plugin_dir_path( __FILE__ ) );
//define( 'MALL_VERSION', 'plugin' );
// 全局数据配置名
define( 'IMK_OPTS', 'wml_zib_diy');
//引入核心变量
if (!function_exists('_imk')) {
    function _imk($option = '', $default = null)
    {
        $options = get_option(IMK_OPTS);   
        if($options) {
            return (isset($options[$option])) ? $options[$option] : $default;
        }else {
            return false;
        }
    }
}

 //获取插件信息
function _imk_ver($dete)
{
    // 获取当前插件主文件路径
    if (! function_exists('get_plugin_data')) {
        require_once(ABSPATH . 'wp-admin/includes/plugin.php');
    }
    $plugin_data = get_plugin_data(__FILE__);
    return $plugin_data[$dete];
}
/**
 * 文件加载函数，支持单文件或文件数组加载
 *
 * @param mixed $file_data 文件数据，可以是字符串或数组，字符串为单个文件名，数组为多个文件名
 * @param string|null $path 可选参数，为文件统一路径前缀
 *
 * @throws Exception 当文件不存在或读取失败时，仅输出文件名和后缀
 */
function imk_require($file_data, $path = null){
    // 检查$file_data是否为数组
    if(is_array($file_data)){
        // 遍历数组中的每个文件名
        foreach ($file_data as $file) {
            // 拼接完整路径
            $full_path = ($path !== null) ? IMK_COM_DIR . $path . '/' . $file : IMK_COM_DIR . $file;

            // 检查文件是否存在
            if (!file_exists($full_path)) {
                // 提取文件名（包括后缀），不包括路径
                $file_name = basename($full_path);
                // 输出提示信息，只包括文件名
                echo "文件 $file_name 不存在\n";
            }else{
                // 加载文件
                require $full_path;
            }
        }
    } else {
        // 拼接完整路径
        $full_path = ($path !== null) ? IMK_COM_DIR . $path . '/' . $file_data : IMK_COM_DIR . $file_data;

        // 检查文件是否存在
        if (!file_exists($full_path)) {
            // 提取文件名（包括后缀），不包括路径
            $file_name = basename($full_path);
            // 输出提示信息，只包括文件名
            echo "文件 $file_name 不存在\n";
        }else{
        // 加载文件
        require $full_path;
        }
    }
}
imk_require(array(
    'inc/functions.php',
	'inc/classes/waterMark.php',
	'inc/add-imk.functions.php',
));
