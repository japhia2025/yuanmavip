<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-11 09:13:52
 $ @ 最后修改: 2024-11-15 22:58:35
 $ @ 文件路径: \wml-zib-diy\api\zibpay-api.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if(!isset($_POST)||empty($_POST)){
    echo json_encode(array('error' => true, 'ys' => 'danger', 'msg' => '参数传入错误'));
    exit(); //结束执行
}
//KEY验证
$key='1111111111';
if($_POST["key"]!=$key){
    echo json_encode(array('error' => true, 'ys' => 'danger', 'msg' => '非法操作'));
    exit(); //结束执行
}
//是否允许跨域提交
if (wml_zib('dproduct_api_origin', false)){
    header('Access-Control-Allow-Origin: *');
}
header('Content-type:application/json; charset=utf-8');

//这里制作接口