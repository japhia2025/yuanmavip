<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 21:41:53
 $ @ 文件路径: \wml-zib-diy\core\functions\beautify\wml-comments.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

 if (wml_zib('comment_uid', false)) {
    // 评论区UID
    function wml_zib_comment_uid($info, $comment, $depth)
    {
        if (wml_zib('comment_uid')) {
            $user_ip = $comment->comment_author_IP;
            if ($user_ip) {
                $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
                $randomString = '';
                for ($i = 0; $i < 10; $i++) { // 生成10个随机字符  
                    $randomString .= $characters[rand(0, strlen($characters) - 1)];
                }
                $img_list = array(WML_ZIB_BEAUT_DIR_ASSETS . '/img/uid/?kid=' . base64_encode($randomString));
                $color_list = array(
                    "rgb(138, 154, 247)",
                    "rgb(187, 103, 138)",
                    "rgb(166, 236, 149)",
                    "rgb(172, 170, 94)",
                    "rgb(240, 88, 88)",
                    "rgb(182, 117, 243)",
                    "rgb(219, 96, 157)",
                    "rgb(245, 107, 72)",
                    "rgb(196, 167, 104)",
                    "rgb(221, 42, 42)",
                    "rgb(240, 158, 226)",
                    "rgb(243, 200, 98)",
                    "rgb(248, 155, 200)",
                    "rgb(114, 153, 238)",
                    "rgb(214, 207, 107)",
                    "rgb(192, 127, 235)",
                    "rgb(197, 184, 30)",
                    "rgb(245, 155, 210)",
                    "rgb(231, 197, 152)",
                    "rgb(98, 98, 119)",
                    "rgb(221, 200, 173)",
                    "rgb(110, 175, 187)",
                    "rgb(137, 141, 190)",
                    "rgb(166, 152, 238)",
                    "rgb(104, 192, 207)",
                    "rgb(216, 124, 152)"
                );
                $img_res = array_rand($img_list);
                $color_res = array_rand($color_list);
                $comment_uid_type = wml_zib('comment_uid_type');
                if ($comment_uid_type == 'id') {
                    $uid_type = $comment->user_id;
                    $uid_type_desc = 'ID';
                } elseif ($comment_uid_type == 'ip') {
                    $uid_type = $user_ip;
                    $uid_type_desc = 'IP';
                } elseif ($comment_uid_type == 'city') {
                    $uid_type = $weizhi;
                    $uid_type_desc = '位置';
                } elseif ($comment_uid_type == 'random') {
                    // 生成一个包含可能值的数组  
                    $possibleValues = [$comment->user_id, $user_ip, $weizhi];
                    // 使用array_rand函数从数组中随机选择一个值  
                    $randomIndex = array_rand($possibleValues);
                    $uid_type = $possibleValues[$randomIndex];

                    // 根据随机值设置相应的描述  
                    if ($uid_type == $comment->user_id) {
                        $uid_type_desc = 'ID';
                    } elseif ($uid_type == $user_ip) {
                        $uid_type_desc = 'IP';
                    } elseif ($uid_type == $weizhi) {
                        $uid_type_desc = '城市';
                    }
                }

                $bill_html = '<div class="bili-dyn-item__ornament" data-clipboard-tag="' . $uid_type_desc . '" data-clipboard-text="' . str_pad($uid_type, STR_PAD_LEFT) . '"><div class="bili-dyn-ornament"><div class="bili-dyn-ornament__type--3"><img  src="' . $img_list[$img_res] . '" alt="' . $uid_type_desc . '"><span style="color:' . $color_list[$color_res] . '">' . str_pad($uid_type, wml_zib('comment_uid_s'), "0", STR_PAD_LEFT) . '</span></div></div></div>';

                $info = $info . $bill_html;
            }
            return $info;
        }
    }
    add_filter('comment_footer_info', 'wml_zib_comment_uid', 10, 3);
 }
// 首页评论美化
if (wml_zib('index_comments', false))
{
    function wml_zib_index_comments() { ?>
        <style>
            .comment-mini-lists>div.posts-mini {
                border: 1px dashed #999999;
                border-radius: 10px;
                margin-top: 10px;
            }
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_index_comments');
}

//评论框背景图片
if (wml_zib('comments_bj', false)) {
    function wml_zib_comments_bj()
    {
        $type = wml_zib('comments_bj_r'); //样式
        if ($type=='1') {//背景图片1 ?>
            <style> textarea#comment {background-color:transparent;background:linear-gradient(rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05)),url("<?php echo WML_ZIB_BEAUT_DIR_ASSETS;?>img/comments/comment_bg.gif") right 30px bottom 0px no-repeat;-moz-transition:ease-in-out 0.45s;background-size:35%;-webkit-transition:ease-in-out 0.45s;-o-transition:ease-in-out 0.45s;-ms-transition:ease-in-out 0.45s;transition:ease-in-out 0.45s;}textarea#comment:focus {background-position-y:789px;-moz-transition:ease-in-out 0.45s;-webkit-transition:ease-in-out 0.45s;-o-transition:ease-in-out 0.45s;-ms-transition:ease-in-out 0.45s;transition:ease-in-out 0.45s;}';</style>
        <?php }
        elseif ($type=='2') {//背景图片2 ?>
            <style>textarea#comment {background-color:transparent;background:linear-gradient(rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05)),url(<?php echo WML_ZIB_BEAUT_DIR_ASSETS;?>img/comments/comment_bg2.png) right 10px bottom 10px no-repeat;-moz-transition:ease-in-out 0.45s;-webkit-transition:ease-in-out 0.45s;-o-transition:ease-in-out 0.45s;-ms-transition:ease-in-out 0.45s;transition:ease-in-out 0.45s;}
            textarea#comment:focus {background-position-y:789px;-moz-transition:ease-in-out 0.45s;-webkit-transition:ease-in-out 0.45s;-o-transition:ease-in-out 0.45s;-ms-transition:ease-in-out 0.45s;transition:ease-in-out 0.45s;}</style>
        <?php }
    }
    add_action('wp_footer', 'wml_zib_comments_bj');
}

// 评论区红、蓝背景轮询切换
if (wml_zib('acgpl', false))
{
    function wml_zib_acgpl() { ?>
        <style>
            body {--acg-color: #fff8fa;--acg-color2: #f8fdff;}.dark-theme {--acg-color: #323335;--acg-color2: #323335;}#postcomments .commentlist .comment {border-top: 1px solid rgb(50 50 50 / 0%);border-radius: 15px;margin: 0 15px 15px;border: 1px solid;display: flow-root;background-image: url(<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/img/comments/shading_blue.png' ?>);border-color: #71baff80;background-color: var(--acg-color2);}#postcomments .commentlist .comment+.comment {border-top: 1px solid rgb(50 50 50 / 0%);padding: 0 0 15px 0;border-radius: 15px;margin: 0 15px 15px;border: 1px solid;display: flow-root;padding: 10px;}#postcomments .commentlist .comment+.comment:nth-child(odd) {background-image: url(<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/img/comments/shading_red.png' ?>);border-color: #ff8bb5;background-color: var(--acg-color);}#postcomments .commentlist .comment+.comment:nth-child(even) {background-image: url(<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/img/comments/shading_blue.png' ?>);border-color: #71baff80;background-color: var(--acg-color2);}#postcomments .children {background: rgb(116 116 116 / 0%);margin-bottom: 6px;border-radius: 15px;display: flow-root;}#postcomments .children:nth-child(even) {background-image: url(<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/img/comments/shading_blue.png' ?>);border-color: #71baff80;}#postcomments .children:nth-child(odd) {background-image: url(<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/img/comments/shading_red.png' ?>);border-color: #ff8bb5;background-color: var(--acg-color);}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_acgpl');
}