<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 19:53:31
 $ @ 文件路径: \wml-zib-diy\core\functions\feature\wml-down.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

    if (wml_zib('down')) {
        // 引入需要的CSS
        function wml_zib_down_pay_box_scripts()
        {
            wp_enqueue_style('ceo-pay-box', WML_ZIB_BEAUT_DIR_ASSETS . '/css/ceo-pay-box.css', array(), '1.0.0');
        }
        add_action('wp_enqueue_scripts', 'wml_zib_down_pay_box_scripts');

        function wml_zib_is_mobile()
        {
            if (wp_is_mobile()) {
                return true;
            }
            return false;
        }
        //  移除主题自带的付费下载区块
        function wml_zib_remove_theme_pay_content()
        {
            // 定义所有可能的挂钩
            $positions = array(
                'zib_single_before',
                'zib_single_box_content_before',
                'zib_article_content_after',
                'zib_single_after'
            );

            // 遍历并移除每个挂钩上的函数
            foreach ($positions as $position) {
                $removed = remove_action($position, 'zibpay_posts_pay_content', 1);
            }
        }

        // 在初始化时移除主题的付费下载区块
        add_action('init', 'wml_zib_remove_theme_pay_content', 20); // 数字 20 是确保在优先级更高时执行

        // 免费内容-需要登录才能查看
        function wml_zib_zibpay_posts_free_logged_show_box($pay_mate, $post_id = '')
        {
            if (!$pay_mate) {
                if (!$post_id) {
                    $post_id = get_the_ID();
                }

                $pay_mate = get_post_meta($post_id, 'posts_zibpay', true);
            }

            if (empty($pay_mate['pay_type']) || 'no' == $pay_mate['pay_type']) {
                return;
            }

            $order_type_name = zibpay_get_pay_type_name($pay_mate['pay_type'], true);
            $order_type_name = str_replace("付费", "免费", $order_type_name);

            $cuont = '';
            $cuont_volume = zibpay_get_sales_volume($pay_mate, $post_id);
            if (_pz('pay_show_paycount', true) && $cuont_volume) {
                $cuont = '<badge class="img-badge hot jb-blue px12">已售 ' . $cuont_volume . '</badge>';
            }
            $mark = zibpay_get_pay_mark();
            $mark = '<span class="pay-mark">' . $mark . '</span>';

            //会员价格
            $vip_price = zibpay_get_posts_vip_price($pay_mate);

            //标题
            $pay_title = zibpay_get_post_pay_title($pay_mate, $post_id);
            //价格
            $price = zibpay_get_show_price($pay_mate, $post_id, 'c-red');

            //更多内容
            $pay_details = !empty($pay_mate['pay_details']) ? '<div class="pay-details">' . $pay_mate['pay_details'] . '</div>' : '';

            //商品属性
            $attribute = zibpay_get_product_attributes($pay_mate, $post_id);

            //演示地址
            $demo_link = zibpay_get_demo_link($pay_mate, $post_id);
            //服务内容
            $service = zibpay_get_service('inline-block ml10');
            $service = $service ? '<div class="px12 muted-2-color mt10 text-right">' . $service . '</div>' : '';
            //付费类型
            $order_type_name = '<div class="pay-tag abs-center">' . $order_type_name . '</div>';

            //左侧图片
            $product_graphic = '';
            $post_thumbnail = '';
            if (5 != $pay_mate['pay_type']) {
                if (6 == $pay_mate['pay_type']) {
                    $lazy_attr = zib_is_lazy('lazy_other', true) ? 'class="fit-cover lazyload" src="' . zib_get_lazy_thumb() . '" data-' : 'class="fit-cover"';

                    $video_pic = !empty($pay_mate['video_pic']) ? '<img ' . $lazy_attr . 'src="' . esc_attr($pay_mate['video_pic']) . '" alt="付费视频-' . esc_attr($pay_title) . '">' : zib_post_thumbnail();
                    $post_thumbnail = $video_pic;
                    $post_thumbnail .= '<div class="absolute graphic-mask" style="opacity: 0.2;"></div>';
                    $post_thumbnail .= '<div class="abs-center text-center"><i class="fa fa-play-circle-o fa-4x opacity8" aria-hidden="true"></i></div>';
                } else {
                    $post_thumbnail = zib_post_thumbnail();
                }

                $product_graphic = '<div class="flex0 relative mr20 hide-sm pay-thumb"><div class="graphic">';
                $product_graphic .= $post_thumbnail;
                $product_graphic .= '<div class="abs-center text-center left-bottom">';
                $product_graphic .= $demo_link ? '<div class="">' . $demo_link . '</div>' : '';
                $product_graphic .= '</div>';
                $product_graphic .= '</div></div>';
            } else {
                $product_graphic = zibpay_get_posts_pay_gallery_box($pay_mate);
                $product_graphic = str_replace("请付费后", "请登录后", $product_graphic);
            }

            //登录按钮
            if (zib_is_close_sign()) {
                //是否开启登录功能
                //简介
                $pay_doc = !empty($pay_mate['pay_doc']) ? $pay_mate['pay_doc'] : '';
                $button = '<div class=""><span class="badg padding-lg btn-block c-red em09"><i class="fa fa-info-circle mr10"></i>登录功能已关闭，暂时无法查看</span></div>';
            } else {
                $pay_doc = !empty($pay_mate['pay_doc']) ? $pay_mate['pay_doc'] : '此内容为' . str_replace("付费", "免费", zibpay_get_pay_type_name($pay_mate['pay_type'])) . '，请登录后查看';
                $button = '<div class=""><a href="javascript:;" class="but signin-loader padding-lg btn-block jb-blue"><i class="fa fa-sign-in"></i> 登录查看</a></div>';
            }

            //左侧图片结束
            $order_type_class = 'order-type-' . $pay_mate['pay_type'];
            $html = '<div class="zib-widget ' . $order_type_class . '" id="posts-pay">';
            $html .= '<div class="flex pay-flexbox">';
            $html .= $product_graphic;
            $html .= '<div class="flex1 flex xx jsb">';
            $html .= '<dt class="text-ellipsis pay-title"' . ($cuont ? 'style="padding-right: 48px;"' : '') . '>' . $pay_title . '</dt>';
            $html .= '<div class="mt6 em09 muted-2-color">' . $pay_doc . '</div>';
            $html .= '<div class="price-box hide-sm">' . $price . '</div>';
            $html .= '<div class="text-right mt10">' . $button . '</div>';

            $html .= '';
            $html .= '</div>';
            $html .= '</div>';
            $html .= $service;
            $html .= $demo_link ? '<div class="mt10 visible-xs-block">' . $demo_link . '</div>' : '';
            $html .= $attribute;
            $html .= $pay_details;
            $html .= $order_type_name;
            $html .= $cuont;
            $html .= '</div>';

            return $html;
        }


        // 文章已经付费模块 
        function wml_zib_zibpay_posts_paid_box($pay_mate, $paid, $post_id = '')
        {

            if (empty($pay_mate['pay_type']) || 'no' == $pay_mate['pay_type']) {
                return;
            }

            //判断免费资源且需要登录
            if ('free' == $paid['paid_type'] && _pz('pay_free_logged_show') && !is_user_logged_in()) {
                return DearLicy_zibpay_posts_free_logged_show_box($pay_mate, $post_id);
            }

            //标题
            $pay_title = zibpay_get_post_pay_title($pay_mate, $post_id);

            //简介
            $pay_doc = !empty($pay_mate['pay_doc']) ? $pay_mate['pay_doc'] : '';

            //销售数量
            $cuont = '';
            $cuont_volume = zibpay_get_sales_volume($pay_mate, $post_id);
            if (_pz('pay_show_paycount', true) && $cuont_volume) {
                $cuont = '<badge class="img-badge hot jb-blue px12">已售 ' . $cuont_volume . '</badge>';
            }

            //更多内容
            $pay_details = !empty($pay_mate['pay_details']) ? '<div class="pay-details">' . $pay_mate['pay_details'] . '</div>' : '';

            //额外隐藏内容
            $pay_extra_hide = !empty($pay_mate['pay_extra_hide']) ? '<div class="pay-details">' . $pay_mate['pay_extra_hide'] . '</div>' : '';

            //商品属性
            $attribute = zibpay_get_product_attributes($pay_mate, $post_id);

            //演示地址
            $demo_link = zibpay_get_demo_link($pay_mate, $post_id);
            //服务内容
            $service = zibpay_get_service('inline-block ml10');
            $service = $service ? '<div class="px12 muted-2-color mt10 text-right">' . $service . '</div>' : '';
            //订单类型
            $order_type_name = zibpay_get_pay_type_name($pay_mate['pay_type'], true);

            //查看原因
            $paid_type = $paid['paid_type'];
            $paid_name = zibpay_get_paid_type_name($paid_type);

            //订单类型
            $pay_type = $pay_mate['pay_type'];
            $order_type_class = 'order-type-' . $pay_mate['pay_type'];

            $paid_box = '';
            $header_box = '';
            $down_box = '';

            switch ($pay_type) {
                    // 根据支付接口循环进行支付流程
                case 1:
                    break;
                case 2:
                    //付费阅读 //付费下载

                    //商品属性
                    $attribute = zibpay_get_product_attributes($pay_mate, $post_id);

                    if (_pz('pay_type_option', 0, 'down_alone_page')) {
                        //判断是否开启独立下载页面
                        $demo_link = zibpay_get_demo_link($pay_mate, $post_id, 'but jb-yellow padding-lg btn-block');
                        $down_link = '<a target="_blank" href="' . add_query_arg('post', $post_id, zib_get_template_page_url('pages/download.php')) . '" class="but jb-blue padding-lg btn-block"><i class="fa fa-download fa-fw" aria-hidden="true"></i>资源下载</a>';
                        $down_box = '<div class="mt10">' . $down_link . '</div>';
                        if ($demo_link) {
                            //判断是否有演示地址
                            $down_box = '<div class="but-group paid-down-group mt10">';
                            $down_box .= $demo_link;
                            $down_box .= $down_link;
                            $down_box .= '</div>';
                        }
                    } else {
                        $down_buts = zibpay_get_post_down_buts($pay_mate, $paid_type, $post_id);
                        $down_box = '<div class="hidden-box show"><div class="hidden-text"><i class="fa fa-download mr6" aria-hidden="true"></i>资源下载</div>' . $down_buts . '</div>';
                        $down_box .= zibpay_get_demo_link($pay_mate, $post_id);
                    }

                    $down_box .= $attribute;
                    break;

                case 5:
                    //付费图库
                    $gallery = '';
                    $slide = '';
                    $pay_gallery = $pay_mate['pay_gallery'];
                    if ($pay_gallery) {
                        $gallery_ids = explode(',', $pay_gallery);
                        $all_count = count($gallery_ids);
                        $i = 1;
                        $attachment = '';
                        foreach ((array) $gallery_ids as $id) {
                            $attachment = zib_get_attachment_image_src($id, _pz('thumb_postfirstimg_size'));
                            if (!empty($attachment[0])) {
                                $slide .= zibpay_get_posts_pay_gallery_box_image_slide($id, $i, $all_count, $pay_title, $attachment[0]);
                                $attachment = $attachment[0];
                                $i++;
                            }
                        }
                        $gallery .= '<div class="swiper-container swiper-scroll">';
                        $gallery .= '<div class="swiper-wrapper imgbox-container">';
                        $gallery .= $slide;
                        $gallery .= '</div>';
                        $gallery .= '<div class="swiper-button-prev"></div><div class="swiper-button-next"></div>';
                        $gallery .= '</div>';

                        $lazy_attr = zib_is_lazy('lazy_other', true) ? 'class="fit-cover lazyload" src="' . zib_get_lazy_thumb() . '" data-' : 'class="fit-cover"';

                        $header_box = '<div class="relative-h paid-gallery">';
                        $header_box .= '<div class="absolute blur-10 opacity3"><img ' . $lazy_attr . 'src="' . esc_attr($attachment) . '" alt="付费图片-' . esc_attr($pay_title) . '"></div>';
                        $header_box .= '<div style="margin-top: -20px;" class="relative mb6"><span class="badg b-theme badg-sm"> 共' . $all_count . '张图片 </span></div>';
                        $header_box .= $gallery;
                        $header_box .= '</div>';
                    } else {
                        $header_box = '<div class="b-red text-center" style="padding: 30px 10px;"><i class="fa fa-fw fa-info-circle mr10"></i>暂无图片内容，' . (is_super_admin() ? '请在后台添加' : '请与管理员联系') . '</div>';
                    }

                    break;
                case 6:
                    //付费视频
                    $video_url = $pay_mate['video_url'];
                    $video_pic = $pay_mate['video_pic'];

                    if ($video_url) {
                        $scale_height = isset($pay_mate['video_scale_height']) ? $pay_mate['video_scale_height'] : 0;

                        $header_box = zib_get_dplayer($video_url, $video_pic, $scale_height);
                        //视频剧集
                        $episode_array = isset($pay_mate['video_episode']) ? $pay_mate['video_episode'] : false;
                        $episode_lists = '';
                        $episode_index = 1;
                        if ($episode_array && is_array($episode_array)) {
                            foreach ($episode_array as $episode) {
                                if (!empty($episode['url'])) {
                                    $episode_index++;
                                    $episode_title = $episode['title'] ? $episode['title'] : '第' . $episode_index . '集';
                                    $episode_lists .= '<a href="javascript:;" class="switch-video text-ellipsis" data-index="' . $episode_index . '" video-url="' . $episode['url'] . '"><span class="mr6 badg badg-sm">' . $episode_index . '</span><i class="episode-active-icon"></i>' . $episode_title . '</a>';
                                }
                            }
                        }

                        $episode_html = '';
                        if ($episode_lists) {
                            $episode_title = $pay_mate['video_title'] ? $pay_mate['video_title'] : '第1集';
                            $episode_html = '<div class="featured-video-episode mt10">';
                            $episode_html .= '<a href="javascript:;" class="switch-video text-ellipsis active" data-index="1" video-url="' . $pay_mate['video_url'] . '"><span class="mr6 badg badg-sm">1</span><i class="episode-active-icon"></i>' . $episode_title . '</a>';
                            $episode_html .= $episode_lists;
                            $episode_html .= '</div>';
                        }
                        $pay_doc .= $episode_html;
                    } else {
                        $header_box = '<div class="b-red text-center" style="padding: 30px 10px;"><i class="fa fa-fw fa-info-circle mr10"></i>暂无视频内容，' . (is_super_admin() ? '请在后台添加' : '请与管理员联系') . '</div>';
                    }
                    break;
            }

            //已支付模块
            if ('free' == $paid_type) {
                //免费
                $paid_box = '';
                $order_type_name = str_replace("付费", "免费", $order_type_name);
            } elseif ('paid' == $paid_type) {
                //已经购买
                $mark = zibpay_get_pay_mark();
                $mark = '<span class="pay-mark">' . $mark . '</span>';
                $paid_info = '<div class="flex jsb"><span>订单号</span><span>' . zibpay_get_order_num_link($paid['order_num']) . '</span></div>';
                $paid_info .= '<div class="flex jsb"><span>支付时间</span><span>' . $paid['pay_time'] . '</span></div>';
                $paid_info .= '<div class="flex jsb"><span>支付金额</span><span>' . zibpay_get_order_pay_price($paid) . '</span></div>';

                $paid_box .= '<div class="flex ac jb-green padding-10 em09">';
                $paid_box .= '<div class="text-center flex1"><div class="mb6"><i class="fa fa-shopping-bag fa-2x" aria-hidden="true"></i></div><b class="em12">' . $paid_name . '</b></div>';
                $paid_box .= '<div class="em09 paid-info flex1">' . $paid_info . '</div>';
                $paid_box .= '</div>';
            } elseif (stristr($paid_type, 'vip')) {
                //会员免费
                $paid_box .= '<div class="flex jsb ac payvip-icon box-body vipbg-v' . $paid['vip_level'] . '">';
                $paid_box .= zibpay_get_show_price($pay_mate, $post_id);
                $paid_box .= '<div class="flex0"><b class="em12">' . zibpay_get_vip_icon($paid['vip_level'], 'mr10 em12') . $paid_name . '</b></div>';
                $paid_box .= '</div>';
            }

            //构建内容
            $html = '<div class="pay-box zib-widget paid-box ' . $order_type_class . '" id="posts-pay">';
            $html .= $header_box;
            $html .= $paid_box;

            $html .= '<div class="box-body relative' . (6 == $pay_type ? ' dplayer-featured' : '') . '">';
            $html .= $cuont;

            $html .= '<div' . ($cuont ? ' style="padding-right: 48px;"' : '') . '><span class="badg c-red hollow badg-sm mr6">' . $order_type_name . '</span><b>' . $pay_title . '</b></div>';
            $html .= $pay_doc ? '<div class="mt10">' . $pay_doc . '</div>' : '';
            $html .= $down_box;
            $html .= $pay_details;
            $html .= $pay_extra_hide;
            $html .= $service;
            $html .= '</div>';
            $html .= '</div>';
            return $html;
        }


        //文章购买模块
        function wml_zib_zibpay_posts_pay_box($pay_mate = array(), $post_id = 0)
        {
            if (!$pay_mate) {
                if (!$post_id) {
                    $post_id = get_the_ID();
                }

                $pay_mate = get_post_meta($post_id, 'posts_zibpay', true);
            }

            if (empty($pay_mate['pay_type']) || 'no' == $pay_mate['pay_type']) {
                return;
            }

            $order_type_name = zibpay_get_pay_type_name($pay_mate['pay_type'], true);

            $cuont = '';
            $cuont_volume = zibpay_get_sales_volume($pay_mate, $post_id);
            if (_pz('pay_show_paycount', true) && $cuont_volume) {
                $cuont = '<badge class="img-badge hot jb-blue px12">已售 ' . $cuont_volume . '</badge>';
            }

            //会员价格
            $vip_price = wml_zib_zibpay_get_posts_vip_price($pay_mate);

            //标题
            $pay_title = zibpay_get_post_pay_title($pay_mate, $post_id);
            //价格
            $price = zibpay_get_show_price($pay_mate, $post_id, 'c-red');

            //更多内容
            $pay_details = !empty($pay_mate['pay_details']) ? '<div class="pay-details">' . $pay_mate['pay_details'] . '</div>' : '';

            //商品属性
            $attribute = zibpay_get_product_attributes($pay_mate, $post_id);
            //购买按钮
            $pay_button = zibpay_get_pay_form_but($pay_mate, $post_id);
            //演示地址
            $demo_link = zibpay_get_demo_link($pay_mate, $post_id, $class = 'cashier-link but jb-blue ml10');
            //服务内容
            $service = wml_zib_zibpay_get_service();
            $service = $service ? $service : '';
            //付费类型
            $order_type_name = '<div class="ceo-single-tese"><div class="ceo-tese-tuijian pay-tag">' . $order_type_name . '</div></div>';

            //推广让利
            $discount_tag = zibpay_get_rebate_discount_tag($post_id);

            // 作者昵称
            $user_id = get_the_author_meta('ID');

            //左侧图片
            $product_graphic = '';
            $post_thumbnail = '';
            if (5 != $pay_mate['pay_type']) {
                if (6 == $pay_mate['pay_type']) {
                    $lazy_attr = zib_is_lazy('lazy_other', true) ? 'class="fit-cover lazyload" src="' . zib_get_lazy_thumb() . '" data-' : 'class="fit-cover"';

                    $video_pic = !empty($pay_mate['video_pic']) ? '<img ' . $lazy_attr . 'src="' . esc_attr($pay_mate['video_pic']) . '" alt="付费视频-' . esc_attr($pay_title) . '">' : zib_post_thumbnail();
                    $post_thumbnail = $video_pic;
                    $post_thumbnail .= '<div class="absolute graphic-mask" style="opacity: 0.2;"></div>';
                    $post_thumbnail .= '<div class="abs-center text-center"><i class="fa fa-play-circle-o fa-4x opacity8" aria-hidden="true"></i></div>';

                    //视频剧集
                    $episode_array = isset($pay_mate['video_episode']) ? $pay_mate['video_episode'] : false;
                    if (is_array($episode_array)) {
                        $episode_count = count($episode_array) + 1;
                        if ($episode_count > 1) {
                            $pay_title = '<span class="badg badg-sm b-theme mr6"><i class="fa fa-play-circle mr3" aria-hidden="true"></i>共' . $episode_count . '集</span>' . $pay_title;
                        }
                    }
                } else {
                    $post_thumbnail = zib_post_thumbnail();
                }
                // 是否开启左侧幻灯片
                if (wml_zib('down_img')) {
                    $product_graphic = '<div class="bannerL"><div class="course-img">';
                    $product_graphic .= $post_thumbnail;
                }
                $product_graphic .= '</div>';
                $product_graphic .= '<div class="main_info_top_b">';
                $product_graphic .= '<div class="main_info_top_item">';
                $product_graphic .= '<span class="item_titles">最近更新</span>';
                $product_graphic .= '<span class="item_content1">' . get_the_modified_time('Y年m月d日', $post_id) . '</span>';
                $product_graphic .= '</div>';
                $product_graphic .= '<div class="main_info_top_item2">';
                $product_graphic .= '<span class="item_titles">资源编号</span>';
                $product_graphic .= '<span class="item_content2">' . get_the_ID() . '</span>';
                $product_graphic .= '</div>';
                $product_graphic .= '</div>';
                $product_graphic .= '<div class="risktips report" style="cursor:pointer;">
                <i class="fa fa-bell-o" aria-hidden="true"></i><span><a href="http://wpa.qq.com/msgrd?v=3&amp;uin=88888888&amp;site=qq&amp;menu=yes" target="_blank">当前信息若含有黄赌毒等违法违规不良内容，请点此举报！</a></span>
            </div>';
                $product_graphic .= '</div>';
            } else {
                $product_graphic = zibpay_get_posts_pay_gallery_box($pay_mate);
            }

            // 分类获取
            $category = get_the_category();
            $cat = '';
            if (!empty($category[0])) {
                $ii = 0;
                foreach ($category as $category1) {
                    $ii++;
                    $cat .= '<a title="查看更多分类文章" href="' . get_category_link($category1->term_id) . '">' . $before . $category1->cat_name . $after . '</a>';
                    if ($count && $ii == $count) {
                        break;
                    }
                }
            }

            //左侧图片结束
            if (!wml_zib_is_mobile()) {
                $order_type_class = 'order-type-' . $pay_mate['pay_type'];
                $html = '<div class="zib-widget ceo-shop1-zl ' . $order_type_class . '" id="posts-pay">';
                $html .= '<div style="overflow: hidden;padding-bottom: 20px;">';
                $html .= $product_graphic;
                $html .= '<div class="bannerMid">';
                $html .= '<dt class="midTitle"' . ($cuont ? 'style="padding-right: 48px;"' : '') . '><h1>' . $order_type_name . $pay_title . '</h1></dt>';
                $html .= '<div class="article-tags opacity8">
    <span class="ml10">' . zib_get_svg('user') . ' ' . get_the_author_meta('nickname', $user_id) . '</span>
    <span class="ml10">' . zib_get_svg('time') . ' ' . get_the_time('Y-m-d', $post_id) . '</span>
    <span class="ml10"><i class="fa fa-folder-open-o" aria-hidden="true"></i> ' . $cat . '</span>
    <span class="ml10">' . zib_get_svg('view') . ' ' . get_post_view_count('', '', $post_id) . '</span>
    <span class="ml10">' . zib_get_svg('like') . ' ' . (zib_get_post_like('', $post_id, '', true) ?: '0') . '</span>
    </div>';
                $html .= '<div class="main_info_price">
                <div class="main_info_price_r" style="background: url(' . WML_ZIB_BEAUT_DIR_ASSETS . '/img/post/ceo-back.png);background-size: 100% 100%;">
                    <b>郑重承诺</b>丨本站提供安全交易、信息保真!
                    <div class="collection pay-vip add_collect">
                    <a href="javascript:;"><span><i class="ceofont ceoicon-vip-crown-2-line"></i>升级会员</span></a>
                    </div>
                </div>
            </div>';

                $html .= '<div class="main_info_tb">';
                $html .= '<div class="main_info_tb_items">
                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>增值服务：
                </div>';
                $html .= $service;
                $html .= '</div>';
                $html .= '<div class="priceBtn">';
                $html .= '<div class="mob">
    <span class="sellP">
    ' . $price . $vip_price . '
    <em>开通VIP尊享优惠特权</em>
    </span>
    <div class="ceo-shop1-dzsc">
    ' . zib_get_post_like('but c-red mr6') . zib_get_post_favorite('but c-blue mr6') . zib_get_post_share_btn($post_id, $class = 'but c-green mr6', $modal = true) . '
    </div>
    </div>';
                $html .= $pay_button;
                $html .= $demo_link ? $demo_link : '';
                $html .= '<a class="pay-vip cashier-link but jb-vip2 ml10" href="javascript:;">' . zib_get_svg('vip_' . 1, '0 0 1024 1024', 'mr3') . '升级会员</a>';
                $html .= '</div>';
                $html .= '';
                $html .= $discount_tag ? '<div class="visible-xs-block badg c-red px12 mb6">' . $discount_tag . '</div>' : '';
                // $html .= $vip_price ? '<div>' . $vip_price . '</div>' : '';

                $html .= '</div>';
                $lazy_attr = 'class="lazyload fit-cover" src="' . zib_get_lazy_thumb() . '" data-';
                $html .= '<div class="ceoshop-sall">';
                $html .= '<div class="user-card widget"><div class="user-cover graphic" style="padding-bottom: 50%;"><img ' . $lazy_attr . 'src="' . _pz('user_cover_img', ZIB_TEMPLATE_DIRECTORY_URI . '/img/user_t.jpg') . '"></div>
        <div class="card-content mt10 relative">
            <div class="user-content">
                ' . zib_get_user_checkin_btn('img-badge jb-yellow', '<i class="fa fa-calendar-check-o ml3 mr6"></i>签到', '<i class="ml3 mr6 fa fa-calendar-check-o"></i>已签到') . '
                <div class="user-avatar">' . zib_get_avatar_box($user_id, 'avatar-img avatar-lg') . '<div class="user-info mt20 mb10">
                    <div class="user-name flex jc">' . zib_get_user_name("id=$user_id&class=flex1 flex ac&follow=true") . '</div>
                    <div class="author-tag mt10 mini-scrollbar">' . zib_get_user_badges($user_id) . '</div>
                    <div class="user-desc mt10 muted-2-color em09">' . get_user_desc($user_id) . '</div>
                    <div class="user-btns mt20">' . zib_get_new_add_btns([$args['post']], 'but pw-1em mr6 jb-blue' . $args['创文投稿']) . zib_get_user_home_link($user_id, 'but pw-1em ml6 jb-pink' . $args['用户主页']) . '</div>
                </div>
            </div>
            
        </div>
    </div>';
                $html .= '</div>';
                $html .= '</div>';
                $html .= '</div>';
                $html .= '</div>';
            }
            // 手机端
            if (wml_zib_is_mobile()) {
                $html .= '<div class="ceo_app_shop">
  <div class="app_shop_mk" style="background: url(http://ceostyle.ceotheme.com/ceomax/images/ceo-shop3-bg.png) no-repeat center top;background-size: 100% 100%;">
    <div class="app_shop_img">
      ' . $product_graphic . '
    </div>
    <header class="app_shop_title">
      <h1 class="app_shop_title_h1" title="' . $pay_title . '">' . $pay_title . '</h1>
      <div class="p2">
        <div class="ceo-text-small ceo-text-muted ceo-flex ceo-text-truncate ceo-overflow-auto">
          <div class="ceo-flex-1 ceo-display-inline-block ceo-single-right ceo-flex ceo-flex-middle">
            <span class="ceo-flex-1 ceo-display-inline-block ceo-single-right ceo-flex ceo-flex-middle">
              ' . zib_get_svg('user') . ' ' . get_the_author_meta('nickname', $user_id) . '
            </span>
          </div>
          <span class="ceo-flex-1 ceo-display-inline-block ceo-single-right ceo-flex ceo-flex-middle">
            ' . zib_get_svg('time') . ' ' . get_the_time('Y-m-d', $post_id) . '
            </span>
          <span class="ceo-display-inline-block ceo-flex ceo-flex-middle">
            ' . zib_get_svg('view') . ' ' . get_post_view_count('', '', $post_id) . '
            </span>
          <span class="ceo-display-inline-block ceo-single-left ceo-flex ceo-flex-middle">
          </span>
        </div>
      </div>
    </header>
  </div>
  <div class="app_shop_box">
    <div class="app_shop_jg ceo-flex">
      <span class="app_shop_jg_se ceo-flex-1">
        ' . $price . '
      </span>
      <!--VIP权限-->
      <div class="discount">
        ' . $vip_price . '
      </div>
    </div>
    <div class="app_shop_an">
      <div class="xz">
        <!--下载按钮-->
          ' . $pay_button . '
        <!--升级会员-->
          <a class="pay-vip ml10" href="javascript:;">' . zib_get_svg('vip_' . 1, '0 0 1024 1024', 'mr3') . '升级会员</a>
        </div>
      <!--演示按钮-->
        <div class="mt10">' . $demo_link . '</div>
      <!--提示语-->
      <div class="hont">
        <i class="ceofont ceoicon-information-line">
        </i>下载不了？请联系网站客服提交链接错误！</div>
    </div>
    <div class="app_mother">
      <i class="ceofont ceoicon-shopping-cart-line">
      </i>增值服务：
      <div class="flex" style="overflow: hidden;">' . $service . '</div>
    </div>
  </div>
</div>';
            }
            return $html;
        }


        //获取购买的服务内容
        function wml_zib_zibpay_get_service($class = 'main_info_tb_item', $icon_class = 'c-red mr3')
        {
            $_pz = _pz('pay_service');
            if (!$_pz || !is_array($_pz)) {
                return;
            }

            $html = '';
            foreach ($_pz as $service) {
                if (empty($service['value'])) {
                    continue;
                }

                $icon = !empty($service['icon']) ? zib_get_cfs_icon($service['icon'], 'fa-fw') : '<i class="fa-fw fa fa-check-circle-o" aria-hidden="true"></i>';
                $value = $service['value'];
                $html .= '<div class="' . $class . '"><span class="left_title">' . $icon . $value . '</span></div>';
            }
            return $html;
        }

        //  获取文章付费会员价格
        function wml_zib_zibpay_get_posts_vip_price($pay_mate, $hide = 0)
        {

            if (zib_is_close_sign()) {
                return;
            }

            $mark = zibpay_get_pay_mark();
            $user_id = get_current_user_id();
            $action_class = $user_id ? '' : ' signin-loader';
            $vip_level = $user_id ? zib_get_user_vip_level($user_id) : false;
            $vip_price_con = array();
            $price = isset($pay_mate['pay_price']) ? round((float) $pay_mate['pay_price'], 2) : 0;
            $price_key_suffix = 'price'; //后缀
            if (zibpay_post_is_points_modo($pay_mate)) {
                $mark = zibpay_get_points_mark();
                $price_key_suffix = 'points'; //后缀
                $price = isset($pay_mate['points_price']) ? (int) $pay_mate['points_price'] : 0;
            }

            $mark = '<span class="px12">' . $mark . '</span>';

            for ($vi = 1; $vi <= 2; $vi++) {
                if (!_pz('pay_user_vip_' . $vi . '_s', true) || $hide == $vi) {
                    continue;
                }
                $vip_price = !empty($pay_mate['vip_' . $vi . '_' . $price_key_suffix]) ? round((float) $pay_mate['vip_' . $vi . '_' . $price_key_suffix], 2) : 0;
                //会员价格与正常价格取最小值
                if ($vip_price >= $price) {
                    continue;
                }

                $vip_price = $vip_price ? $mark . $vip_price : '免费';
                $vip_price = '<span class="em12 ml3 vip-price-text">' . $vip_price . '</span>';
                $vip_icon = zib_get_svg('vip_' . $vi, '0 0 1024 1024', 'mr3') . _pz('pay_user_vip_' . $vi . '_name');

                //action_class
                if ($user_id && (!$vip_level || $vip_level < $vi)) {
                    $action_class = ' pay-vip';
                }

                if ($action_class) {
                    $vip_price_con[] = '<li href="javascript:;" class="vip-price ' . $action_class . '" vip-level="' . $vi . '" data-toggle="tooltip" title="开通' . _pz('pay_user_vip_' . $vi . '_name') . '">' . $vip_icon . $vip_price . '</li>';
                } else {
                    $vip_price_con[] = '<li class="vip-price" vip-level="' . $vi . '">' . $vip_icon . $vip_price . '</li>';
                }
            }
            $vip_price_html = implode('', $vip_price_con);
            if (count($vip_price_con) > 1) {
                $vip_price_html = '<div class="discount"><a href="javascript:;" class="vip-pay">' . zib_get_svg('vip_' . 1, '0 0 1024 1024', 'mr3') . 'VIP折扣</a><div class="box">
                <ul>
                    <div class="title">折扣详情</div>
                ' . $vip_price_html . '</div></div>';
            }

            return $vip_price_html;
        }


        // 创建页面顶部全区块钩子
        function wml_zib_zibpay_posts_pay_head()
        {
            // 确保这是一个单篇文章页面
            if (is_singular()) {
                global $post;
                if (!$post) {
                    return;
                }

                // 获取 post_meta 数据
                $pay_mate = get_post_meta($post->ID, 'posts_zibpay', true);

                // 检查是否包含特定的元数据
                if (!empty($pay_mate) && !empty($pay_mate['pay_type']) && 'no' !== $pay_mate['pay_type']) {
                    // 获取pay_box_container选项的值
                    // 若pay_box_container打开则添加container使其宽度跟随主题
                    $pay_box_container = wml_zib('pay_box_container');

                    if ($pay_box_container) {
                        echo '<div class="container">';
                        do_action('zib_single_head', $post->ID, $pay_mate);
                        echo '</div>';
                    } else {
                        // 如果 pay_box_container 关闭，使用其他容器标签或者不使用容器标签
                        do_action('zib_single_head', $post->ID, $pay_mate);
                    }
                }
            }
        }

        // 使用 wp_head 钩子在页面头部添加自定义函数检查和触发钩子
        add_action('wp_head', 'wml_zib_zibpay_posts_pay_head');


        // 在文章页面插入产品购买模块
        function wml_zib_zibpay_posts_pay_content()
        {
            global $post;
            $pay_mate = get_post_meta($post->ID, 'posts_zibpay', true);

            if (empty($pay_mate['pay_type']) || 'no' == $pay_mate['pay_type']) {
                return;
            }

            // 查询是否已经购买
            $paid = zibpay_is_paid($post->ID);

            if ($paid) {
                // 已购买（包含免费资源在内）
                $html = apply_filters('wml_zib_zibpay_posts_paid_box', '', $pay_mate, $post->ID);
                $html = $html ? $html : wml_zib_zibpay_posts_paid_box($pay_mate, $paid, $post->ID);
                echo $html;
            } else {
                // 未购买
                $html = apply_filters('wml_zib_zibpay_posts_pay_box', '', $pay_mate, $post->ID);
                $html = $html ? $html : wml_zib_zibpay_posts_pay_box($pay_mate, $post->ID);
                echo $html;
            }
        }

        $pay_box_position = wml_zib('pay_box_position', 'head');
        $positions = array(
            'head' => 'zib_single_head',
            'box_top' => 'zib_single_before',
            'top' => 'zib_single_box_content_before',
            'bottom' => 'zib_article_content_after',
            'box_bottom' => 'zib_single_after',
        );
        $pay_box_position = isset($positions[$pay_box_position]) ? $positions[$pay_box_position] : 'zib_single_box_content_before';
        add_action($pay_box_position, 'wml_zib_zibpay_posts_pay_content');
    }

