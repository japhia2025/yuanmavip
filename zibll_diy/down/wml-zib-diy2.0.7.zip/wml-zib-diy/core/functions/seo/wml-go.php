<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-12-01 08:03:23
 $ @ 最后修改: 2024-12-01 09:25:09
 $ @ 文件路径: \wml-zib-diy\core\functions\seo\wml-go.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/
if (wml_zib('link_go', false)){
    // 移除子比主题的go跳转调用函数
    remove_action('template_redirect', 'zib_gophp_template', 5);
    // 使用插件go跳转函数
    function wml_zib_snow_gophp_template() {
        $golink = get_query_var('golink');
        //error_log("golink: " . print_r($golink, true)); // 添加调试信息
        if ($golink) {
            global $wp_query;
            $wp_query->is_home = false;
            $wp_query->is_page = true;
            $goid=wml_zib('link_go_select');
            $zib_snow_template = WML_ZIB_BEAUT_DIR_PATH . 'templates/wml-go'.$goid.'.php';
            if (file_exists($zib_snow_template)) {
                $template = $zib_snow_template;
            } else {
                $template = TEMPLATEPATH . '/go.php';
            }

            if (session_status() == PHP_SESSION_NONE) {
                session_start();
            }

            $_SESSION['GOLINK'] = $golink;
            load_template($template);
            exit;
        }
    }
    add_action('template_redirect', 'wml_zib_snow_gophp_template', 5);
}


?>