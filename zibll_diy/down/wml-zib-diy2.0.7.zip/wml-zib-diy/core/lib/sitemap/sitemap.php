<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-25 21:27:33
 $ @ 最后修改: 2024-11-25 21:28:50
 $ @ 文件路径: \wml-zib-diy\core\lib\sitemap\sitemap.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/
/**
*$Id:sitemap.php 2947864 2023-08-04 18:02:26Z auctollo$
*谷歌XML站点地图生成器
* ==============================================================================
*此生成器将为您的WordPress网站创建符合sitemaps.org标准的站点地图。
*有关安装说明等其他详细信息，请查看readme.txt和documentation.txt文件。
*玩得开心！
*WordPress信息：
 * ==============================================================================
 */


require_once trailingslashit( dirname( __FILE__ ) ) . 'class-googlesitemapgeneratorloader.php';

/**
 * Returns the file used to load the sitemap plugin
 *
 * @package sitemap
 * @since 4.0
 * @return string站点地图插件入口点的路径和文件
 */
function sm_get_init_file() {
	return __FILE__;
}
