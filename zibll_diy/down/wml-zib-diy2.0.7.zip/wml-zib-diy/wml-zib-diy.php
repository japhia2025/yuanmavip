<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-18 17:13:08
 $ @ 文件路径: \wml-zib-diy\wml-zib-diy.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/
/*
Plugin Name: WML-DIY（子比）
Plugin URI: https://waimao.la
Description: 由Japhia开发的子比主题增强插件，为子比主题提供更多的扩展功能。最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682233
Author: Japhia
Version: 2.0.7
Author URI: https://waimao.la
*/

if (!defined('ABSPATH')) {
    die('-1');
}

// 检查插件文件夹名/PHP版本/Swoole Compiler扩展/Source Guardian Compiler扩展
if(!function_exists('sg_load')){
    wp_die('本插件依赖Source Guardian Compiler扩展，请根据教程安装 <a target="_blank" href="/wp-content/plugins/wml-zib-diy/help/source-guardian-loader-helper.php">查看教程</a>');
}elseif (extension_loaded('swoole_loader')) {
    wp_die('本插件不与Swoole Compiler扩展兼容，请先完成扩展卸载');
} 

// 注册激活钩子
register_activation_hook(__FILE__, 'wml_zib_check_theme_before_activation');

if (!file_exists(get_theme_file_path('/inc/codestar-framework/codestar-framework.php'))) {
    return;
}else{
    // 定义插件常量
    define('WML_ZIB_BEAUT_DIR_PATH', plugin_dir_path(__FILE__));//插件绝对目录
    define('WML_ZIB_BEAUT_DIR_URL', plugin_dir_url(__FILE__));//插件网址目录
    define('WML_ZIB_BEAUT_DIR_ASSETS', plugin_dir_url(__FILE__).'assets/');//插件资源目录
    include_once(plugin_dir_path(__FILE__) ."/core/core.php");//核心文件
}

//插件插件设置链接
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links)
{
  $url = array('settings' => '<a style="color: green;" href="/wp-admin/admin.php?page=wml_zib_diy">配置插件</a>');
  $links = array_merge($url, $links);
  
  return $links;
});