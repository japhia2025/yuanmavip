<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 19:13:28
 $ @ 文件路径: \wml-zib-diy\core\functions\page\wml-sponsor.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

get_header();
?>
<main class="container">
    <div class="content-wrap">
        <div id="percentageCounter"></div>
        <style> .wzw-donate-cover {position: relative;width: 100%;height: 100%;border-radius: var(--main-radius);overflow: hidden;box-sizing: border-box }.wzw-donate-cover img {width: 100%;-o-object-fit: cover;object-fit: cover;cursor: pointer;-webkit-user-drag: none }.wzw-donate-programme {overflow: hidden }.wzw-donate-programme>.wzw-programme-title {text-align: center;background: linear-gradient(135deg, #16aaf7 0, #c696fc 80%);padding: 10px;font-size: 1.8em;color: #fff;}.wzw-programme-content .wzw-money-wrap {display: flex;flex-direction: row;flex-wrap: wrap }.wzw-programme-content .wzw-money-item {position: relative;width: 100%;height: 180px;margin: 10px;display: flex;flex-direction: column;align-items: center;justify-content: space-around;border: 1px solid transparent;overflow: hidden;-webkit-transition: transform .5s;transition: transform .5s;box-shadow: 8px 8px 20px 0 rgb(55 99 170 / 10%), -8px -8px 20px 0 #fff;}.wzw-programme-content .wzw-money-item:hover {border-color: #ed6d83;-webkit-transform: translateY(-8px);transform: translateY(-8px);-webkit-transition: transform .5s;transition: transform .5s }.wzw-donate-programme .wzw-money-label {width: 70px;height: 30px;line-height: 30px;background: #fe85ca;;border-radius: 0 5px 0 10px;font-weight: 700;color: var(--main-bg-color);font-size: 18px;text-align: center;position: absolute;top: -2px;right: -2px }.wzw-donate-programme .wzw-money-icon {width: 90px;height: 90px }.wzw-donate-programme .wzw-money-name {font-size: 1.6em }@media (min-width:768px) and (max-width:1023px) {.wzw-donate-cover {height: 350px }.wzw-programme-content .wzw-money-item {width: calc(100% / 2 - 20px) }}@media (min-width:1024px) {.wzw-donate-cover {height: 450px }.wzw-programme-content .wzw-money-item {width: calc(100% / 3 - 20px) }}.modal-content {overflow: hidden }.wzw-modal-body {background: var(--body-bg-color) }.wzw-donate-modal-zfm {position: relative;text-align: center;background: var(--main-bg-color);overflow: hidden;border-radius: var(--main-radius) }.wzw-donate-modal-zfm::after, .wzw-donate-modal-zfm::before {position: absolute;content: "";width: 35px;height: 35px;background: var(--body-bg-color);border-radius: 99px;top: 6.8rem }.wzw-donate-modal-zfm::before {left: -17px }.wzw-donate-modal-zfm::after {right: -17px }.wzw-donate-modal-zfm img {width: auto;height: 180px }.wzw-donate-modal-title {margin: 1rem;border-bottom: .25rem dashed var(--main-border-color) }.wzw-donate-modal-title b {font-size: 2rem }.wzw-donate-modal-ewm {padding: 1rem }.wzw-donate-modal-btn {padding: 15px }.wzw-donate-btns {display: inline-block;background: var(--main-border-color);border-radius: 99px;border: 1px solid var(--main-border-color);overflow: hidden }.btn.focus, .btn:focus, .btn:hover {color: var(--key-color) !important }.wzw-donate-btns .wzw-zf-btn {border-radius: 99px;background: 0 0;transition: all .5s }.wzw-donate-btns .wzw-zf-btn.wzw-active {background: var(--main-bg-color) }.wzw-text-title {font-size: 18px;font-weight: 200;color: #ffa0a0;}.wzw-text-title>i {padding: 0 8px 0 5px;margin-right: 5px;color: #fff;background: #feaa71;border-radius: var(--main-radius) }.wzw-text-content {padding: 0 10px }.wzw-text-content {font-size: 16px }.wzw-serve-content>.wzw-serve-item {padding-left: 1em;font-size: 16px;list-style: inside !important }.wzw-serve-content>.wzw-serve-item>b {color: var(--wp--preset--color--vivid-red) }.feature-icon img {width: 60px;height: auto }.wzwco {box-shadow: 0 0 10px rgb(227 228 228) }.jitheme-container {}.jitheme-background-default {background-color: #fff;}.jitheme_slide_ss {display: flex;-ms-flex-wrap: wrap;flex-wrap: wrap;margin-left: -20px;}.jitheme_slide_jb {position: relative;margin-bottom: 30px !important;}.jitheme_slide_n {display: flex;margin: 0 auto;padding-top: 10px;height: 60px;color: #fff;font-size: 14px;justify-content: space-between;}.jitheme_slide_n .jitheme_slide_s {position: relative;display: inline-block;padding: 0 30px;height: 40px;border-radius: 73px;background: none;vertical-align: middle;text-align: center;line-height: 40px }.jitheme_slide_n .jitheme_slide_s ul {float: left;margin: 0 auto }.jitheme_slide_n .jitheme_slide_s li {float: left;margin-right: 40px }.jitheme_slide_n .jitheme_slide_s li .first {color: var(--b2color) }.jitheme_slide_n .jitheme_slide_s li a {float: left;color: #606075;font-weight: 200;font-size: 14px;}.jitheme_slide_n .jitheme_slide_y {position: relative;display: inline-block;padding: 0 40px;height: 40px;background: none;vertical-align: middle;text-align: center;line-height: 40px;}.jitheme_slide_n .jitheme_slide_y a {margin-left: 40px;color: #ff3355;}.jitheme_slide_d {padding-left: 20px;flex: 0 0 25%;box-sizing: border-box;width: 100%;max-width: 100% }.jitheme-dt:hover {transform: translateY(-3px);-webkit-transform: translateY(-3px);-ms-transform: translateY(-3px);transform: translateY(-3px);}.jitheme_slide_d .mini-stats {position: relative;display: -ms-flexbox;display: flex;-ms-flex-direction: column;flex-direction: column;min-width: 0;word-wrap: break-word;transition: all .3s;background-color: var(--body-bg-color);background-clip: border-box;border: 1px solid rgba(0, 0, 0, .125);border: none;-webkit-box-shadow: 0 0 1.25rem rgba(108, 118, 134, 0.1);box-shadow: 0 0 1.25rem rgba(108, 118, 134, 0.1);overflow: hidden;border-radius: var(--main-radius);}.jitheme_slide_d .mini-stats:hover {transform: translateY(-3px);-webkit-transform: translateY(-3px);-ms-transform: translateY(-3px);transform: translateY(-3px);}.mini-stats .mini-stats-content {padding: 10px 15px 15px 15px !important }.jitheme_slide_d_mb4, .my-4 {margin-bottom: 15px !important }.jitheme_slide_d_right {text-align: right !important;color: rgba(255, 255, 255, .5) !important }.jitheme_slide_d_right span {margin-top: .5rem !important;background-color: #f8f9fa;margin-bottom: .5rem !important;color: #f27d7d;display: inline-block;padding: .25em .4em;font-size: 75%;font-weight: 700;line-height: 1;text-align: center;white-space: nowrap;vertical-align: baseline;border-radius: .25rem;transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out }.jitheme_slide_d_right p {color: #fff }.jitheme_slide_d_m {margin-left: 15px !important;margin-right: 15px !important;}.jitheme_slide_d_m .mini-stats-desc {display: inline-block;position: relative;bottom: 22px;height: 100%;-webkit-box-shadow: 0 0 1.25rem rgba(108, 118, 134, 0.1);box-shadow: 0 0 1.25rem rgba(108, 118, 134, 0.1);background-color: var(--body-bg-color) !important;padding: 10px !important;display: flex;-ms-flex-wrap: wrap;flex-wrap: wrap;border-radius: var(--main-radius);}.jitheme_slide_d_m .mini-stats-desc li {float: left;flex: 0 0 33.33333%;box-sizing: border-box;width: 100%;max-width: 100%;}.jitheme_slide_d_m .mini-stats-desc a {display: block;}.jitheme_slide_d_m .mini-stats-desc a:hover {color: var(--primary-color) !important }.jitheme_slide_d_m .mini-stats-desc a img {display: block;width: 58px;height: 45px;margin: 0 auto 5px }.jitheme_slide_d_m .mini-stats-desc p {display: block;height: 20px;line-height: 20px;overflow: hidden;font-size: 13px;color: #666;text-align: center;}.jitheme_slide_n ol, ul, li {list-style: none;}.widget_text.zib-widget.widget_custom_html {padding: 0px;}.mini-stats-desc.b2-radius li:not(article):hover {opacity: 1;z-index: 99;border-radius: 20px;transform: translateY(-5px);box-shadow: 0 3px 20px rgba(0, 0, 0, .25);animation: index-link-active 1s cubic-bezier(0.315, 0.605, 0.375, 0.925) forwards;}@keyframes index-link-active {0% {transform: perspective(2000px) rotateX(0) rotateY(0) translateZ(0);}16% {transform: perspective(2000px) rotateX(10deg) rotateY(5deg) translateZ(32px);}100% {transform: perspective(2000px) rotateX(0) rotateY(0) translateZ(65px);}}@media (max-width: 767px) {.jitheme_slide_d {padding-left: 20px;flex: 0 0 100%;box-sizing: border-box;width: 100%;max-width: 100%;}@media only screen and (max-width:1100px) {.textwidget.custom-html-widget {display: none !important }}</style>
        <main class="container">
            <div class="content-wrap">
                <div class="content-layout">
                    <!-- 主体 -->
                    <div class="wiui-donate-cover main-shadow mb20">
                        <img src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/bg.png'?>" draggable="false" />
                    </div>
                    &nbsp; &nbsp; &nbsp; &nbsp;
                </div>
                <div class="wzw-donate-programme mb20 main-bg main-shadow radius8">
                    <div class="wzw-programme-title">
                        <section data-id="124069" class="wzweditor style_1" powered-by="mengdo.cn" draggable="true"
                            data-md5="023bb">
                            <section style="text-align: center;" powered-by="mengdo.cn" data-md5="023bb"
                                class="style_2">
                                <section style="display: inline-block;vertical-align:middle;" powered-by="mengdo.cn"
                                    data-md5="023bb" class="style_3">
                                    <section style="display: flex;align-items: center;justify-content: space-between;"
                                        powered-by="mengdo.cn" data-md5="023bb" class="style_4">
                                        <section
                                            style="width: 7px;height: 7px;border:1px solid #ffcd59;border-radius: 50%;box-sizing: border-box;transform: translate(52px,5px);"
                                            powered-by="mengdo.cn" data-md5="023bb" class="style_5"></section>
                                        <section style="width:21px;margin: 0 -9px 8px auto;line-height:2px;"
                                            powered-by="mengdo.cn" data-md5="023bb" class="style_6"><img
                                                src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/zu3.png'?>"
                                                style="vertical-align:middle;width:100%;" class="small_image style_7"
                                                _src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/zu3.png'?>" data-isstyleimage="1"
                                                draggable="false" data-md5="023bb"></section>
                                    </section>
                                    <section style="display: flex;align-items: center;justify-content: center;"
                                        powered-by="mengdo.cn" data-md5="023bb" class="style_8">
                                        <section
                                            style="width: 28px;height: 28px;background-color: #85d6ac;border-radius: 4px;margin:0 8px;transform-origin: right bottom;transform: rotate(16deg);"
                                            powered-by="mengdo.cn" class="wzw-banone style_9" data-md5="023bb">
                                            <section class="wxqq-Color style_10"
                                                style="color: #fff;letter-spacing: 1px;line-height: 28px;text-align:center;font-size: 16px;font-weight: bold;"
                                                powered-by="mengdo.cn" data-md5="023bb">
                                                <p class="wzwbrush style_11" style="padding: 0px;margin: 0px;"
                                                    data-md5="023bb">赞</p>
                                            </section>
                                        </section>
                                        <section
                                            style="width: 28px;height: 28px;background-color: #ff8566;border-radius: 4px;margin:0 8px;transform-origin: left bottom;transform: rotate(-16deg);"
                                            powered-by="mengdo.cn" class="wzw-banone style_12" data-md5="023bb">
                                            <section class="wxqq-Color style_13"
                                                style="color: #fff;letter-spacing: 1px;line-height: 28px;text-align:center;font-size: 16px;font-weight: bold;"
                                                powered-by="mengdo.cn" data-md5="023bb">
                                                <p class="wzwbrush style_14" style="padding: 0px;margin: 0px;"
                                                    data-md5="023bb">助</p>
                                            </section>
                                        </section>
                                        <section
                                            style="width: 28px;height: 28px;background-color: #ffcd59;border-radius: 4px;transform-origin: right top;transform: rotate(16deg);"
                                            powered-by="mengdo.cn" class="wzw-banone style_15" data-md5="023bb">
                                            <section class="wxqq-Color style_16"
                                                style="color: #fff;letter-spacing: 1px;line-height: 28px;text-align:center;font-size: 16px;font-weight: bold;"
                                                powered-by="mengdo.cn" data-md5="023bb">
                                                <p class="wzwbrush style_17" style="padding: 0px;margin: 0px;"
                                                    data-md5="023bb">方</p>
                                            </section>
                                        </section>
                                        <section
                                            style="width: 28px;height: 28px;background-color: #7fceff;border-radius: 4px;margin:0 2px;transform-origin: left top;transform: rotate(-16deg);"
                                            powered-by="mengdo.cn" class="wzw-banone style_18" data-md5="023bb">
                                            <section class="wxqq-Color style_19"
                                                style="color: #fff;letter-spacing: 1px;line-height: 28px;text-align:center;font-size: 16px;font-weight: bold;"
                                                powered-by="mengdo.cn" data-md5="023bb">
                                                <p class="wzwbrush style_20" style="padding: 0px;margin: 0px;"
                                                    data-md5="023bb">案</p>
                                            </section>
                                        </section>
                                    </section>
                                    <section
                                        style="display: flex;align-items: center;justify-content: space-between;margin-top: -7px;"
                                        powered-by="mengdo.cn" data-md5="023bb" class="style_21">
                                        <section
                                            style="width: 7px;height: 7px;border:1px solid #ffab4c;border-radius: 50%;box-sizing: border-box;transform: translate(7px,-11px);"
                                            powered-by="mengdo.cn" data-md5="023bb" class="style_22"></section>
                                        <section
                                            style="width: 7px;height: 7px;border:1px solid #85d6ac;border-radius: 50%;box-sizing: border-box;transform: translate(-27px,5px);"
                                            powered-by="mengdo.cn" data-md5="023bb" class="style_23"></section>
                                    </section>
                                </section>
                            </section>
                        </section>
                    </div>
                    <div class="wzw-programme-content">
                        <ul class="wzw-money-wrap">
                            <li data-pay="10" class="wzwco wzw-money-item main-shadow radius8">
                                <span class="wzw-money-label">￥10</span>
                                <img class="wzw-money-icon" src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/1.png'?>" alt="一个鸡腿"
                                    draggable="false" />
                                <b class="wzw-money-name">一个鸡腿</b>
                            </li>
                            <li data-pay="20" class="wzwco wzw-money-item main-shadow radius8">
                                <span class="wzw-money-label">￥20</span>
                                <img class="wzw-money-icon" src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/2.png'?>" alt="一杯咖啡"
                                    draggable="false" />
                                <b class="wzw-money-name">一杯咖啡</b>
                            </li>
                            <li data-pay="30" class="wzwco wzw-money-item main-shadow radius8">
                                <span class="wzw-money-label">￥30</span>
                                <img class="wzw-money-icon" src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/4.png'?>" alt="一个汉堡"
                                    draggable="false" />
                                <b class="wzw-money-name">一个汉堡</b>
                            </li>
                            <li data-pay="50" class="wzwco wzw-money-item main-shadow radius8">
                                <span class="wzw-money-label">￥50</span>
                                <img class="wzw-money-icon" src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/5.png'?>"
                                    alt="一份肯德基套餐" draggable="false" />
                                <b class="wzw-money-name">一份肯德基套餐</b>
                            </li>
                            <li data-pay="100" class="wzwco wzw-money-item main-shadow radius8">
                                <span class="wzw-money-label">￥100</span>
                                <img class="wzw-money-icon" src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/3.png'?>" alt="一份全家桶"
                                    draggable="false" />
                                <b class="wzw-money-name">一份全家桶</b>
                            </li>
                            <li data-pay="zdy" class="wzwco wzw-money-item main-shadow radius8">
                                <span class="wzw-money-label">自定义</span>
                                <img class="wzw-money-icon" src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/6.png'?>" alt="爱心红包"
                                    draggable="false" />
                                <b class="wzw-money-name dsjb">爱心红包</b>
                            </li>
                        </ul>
                    </div>

                </div>
                <div class="wzw-donate-programme mb20 main-bg main-shadow radius8">
                    <div class="wzw-programme-title">
                        <section data-id="120340" class="wzweditor style_1" data-type="lspecial04,lspecial06"
                            powered-by="mengdo.cn" draggable="true" data-md5="997e1">
                            <section style="display: flex;align-items: center;justify-content: center;"
                                powered-by="mengdo.cn" data-md5="997e1" class="style_2">
                                <section style="width:40px;line-height:2px;" powered-by="mengdo.cn" data-md5="997e1"
                                    class="style_3"><img src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/zu1.png'?>"
                                        style="vertical-align:middle;width:100%;" class="small_image style_4"
                                        _src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/zu1.png'?>" data-isstyleimage="1"
                                        draggable="false" data-md5="997e1"></section>
                                <section style="margin: 0 10px;" powered-by="mengdo.cn" data-md5="997e1"
                                    class="style_5">
                                    <section
                                        style="display: flex;align-items: center;background: linear-gradient(to top,#FFE8E6 40% ,rgba(255, 255, 255, 0) 40%);padding: 0 0 3px 0;justify-content: center;"
                                        powered-by="mengdo.cn" class="wzw-banone style_6" data-md5="997e1">
                                        <section style="margin-right: 7px;" powered-by="mengdo.cn" data-md5="997e1"
                                            class="style_7">
                                            <section class="wxqq-Color style_8"
                                                style="color: #FF6B4D;letter-spacing: 0px;line-height: 18px;text-align:justify;font-size: 16px;font-weight: bold;"
                                                powered-by="mengdo.cn" data-md5="997e1">
                                                <p class="autosort style_9" style="padding: 0px;margin: 0px;"
                                                    data-md5="997e1">01</p>
                                            </section>
                                        </section>
                                        <section style="" powered-by="mengdo.cn" data-md5="997e1" class="style_10">
                                            <section class="wxqq-Color style_11"
                                                style="color: #FF6B4D;letter-spacing: 1.5px;line-height: 16px;text-align:justify;font-size: 16px;font-weight: bold;"
                                                powered-by="mengdo.cn" data-md5="997e1">
                                                <p class="wzwbrush style_12" style="padding: 0px;margin: 0px;"
                                                    data-md5="997e1">赞助说明</p>
                                            </section>
                                        </section>
                                    </section>
                                    <section style="" powered-by="mengdo.cn" data-md5="997e1" class="style_13">
                                        <section class="wxqq-Color style_14"
                                            style="color: #FF6B4D;letter-spacing: 1.5px;line-height: 20px;text-align:justify;font-size: 12px;font-weight: bold;"
                                            powered-by="mengdo.cn" data-md5="997e1">
                                            <p class="wzwbrush style_15" style="padding: 0px;margin: 0px;"
                                                data-md5="997e1">HAPPY HOLIDAY</p>
                                        </section>
                                    </section>
                                </section>
                                <section style="width:40px;line-height:2px;" powered-by="mengdo.cn" data-md5="997e1"
                                    class="style_16"><img src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/zu2.png'?>"
                                        style="vertical-align:middle;width:100%;" class="small_image style_17"
                                        _src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/zanzhu/zu2.png'?>" data-isstyleimage="1"
                                        draggable="false" data-md5="997e1"></section>
                            </section>
                        </section>
                    </div>
                    <div class="wzw-programme-content box-body theme-box">
                        <!--1-->
                        <section data-id="48353" class="wzweditor style_1" data-type="lspecial02,lspecial06"
                            powered-by="mengdo.cn" draggable="true" data-md5="2ece3">
                            <section style="box-sizing: border-box;padding-bottom:2px;" powered-by="mengdo.cn"
                                data-md5="2ece3" class="style_2">
                                <section style="display:-webkit-box;-webkit-box-pack:center;-webkit-box-align:end;"
                                    powered-by="mengdo.cn" data-md5="2ece3" class="style_3">
                                    <section
                                        class="wxqq-borderBottomColor wxqq-borderTopColor wxqq-borderRightColor wxqq-borderLeftColor style_4"
                                        style="box-sizing: border-box;border:2px solid #FF977B;padding:1px 0;transform:rotate(0deg);-ms-transform:rotate(0deg);-moz-transform:rotate(0deg);-webkit-transform:rotate(0deg);-o-transform:rotate(0deg);"
                                        powered-by="mengdo.cn" data-md5="2ece3">
                                        <section
                                            style="background-color:#FFDBBB;box-sizing: border-box;padding:0 5px;margin:1px -4px -6px 4px;"
                                            powered-by="mengdo.cn" class="wzw-bacolor style_5"
                                            data-bastyle="background-color:#FFDBBB;box-sizing: border-box;padding:0 5px;margin:1px -4px -6px 4px;"
                                            data-md5="2ece3">
                                            <section class="wxqq-Color style_6"
                                                style="color: #FF977B;letter-spacing: 1px;line-height: 24px;text-align:center;"
                                                powered-by="mengdo.cn" data-md5="2ece3">
                                                <p class="wzwbrush style_7"
                                                    style="padding: 0px;margin: 0px;font-size: 14px;" data-md5="2ece3">
                                                    NO.<span class="autosort style_8" data-md5="2ece3">01</span></p>
                                            </section>
                                        </section>
                                    </section>
                                    <section style="-webkit-box-flex: 1;width: 0;margin-bottom:1px;"
                                        powered-by="mengdo.cn" data-md5="2ece3" class="style_9">
                                        <section class="wxqq-Color style_10"
                                            style="color: #FF977B;letter-spacing: 1px;line-height: 21px;text-align: justify;margin-left:8px;"
                                            powered-by="mengdo.cn" data-md5="2ece3">
                                            <p class="wzwbrush style_11"
                                                style="padding: 0px;margin: 0px;font-size: 18px;" data-md5="2ece3">
                                                <?php echo wml_zib('zanzu-page-name'); ?>会努力坚持做到：</p>
                                        </section>
                                        <section class="wxqq-borderTopColor style_12"
                                            style="width:100%;height:0px;box-sizing: border-box;border-top:2px solid #FF977B;"
                                            powered-by="mengdo.cn" data-md5="2ece3"></section>
                                    </section>
                                </section>
                            </section>
                        </section>
                        <hr />
                        <div class="wzw-text-wrap">
                            <div class="wp-block-zibllblock-feature feature wzwco feature-default" data-icon="fa-flag">
                                <div class="feature-icon"><img class="icon"
                                        src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/1.svg'?>" /></div>
                                <div class="feature-title">优质教程</div>
                                <div class="feature-note">所有发布的教程不收费（不包括签到积分）</div>
                            </div>
                            <div class="wp-block-zibllblock-feature feature wzwco feature-default" data-icon="fa-flag">
                                <div class="feature-icon"><img class="icon"
                                        src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/2.svg'?>" /></div>
                                <div class="feature-title">更新维护</div>
                                <div class="feature-note">定期更新与维护文章教程</div>
                            </div>
                            <div class="wp-block-zibllblock-feature feature wzwco feature-default" data-icon="fa-flag">
                                <div class="feature-icon"><img class="icon"
                                        src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/3.svg'?>" /></div>
                                <div class="feature-title">下载提速</div>
                                <div class="feature-note">所有文件本地下载，高效提速</div>
                            </div>
                            <div class="wp-block-zibllblock-feature feature wzwco feature-default" data-icon="fa-flag">
                                <div class="feature-icon"><img class="icon"
                                        src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/4.svg'?>" /></div>
                                <div class="feature-title">永无广告</div>
                                <div class="feature-note">网站纯净无任何广告</div>
                            </div>
                        </div>
                        <!--2-->
                        <hr />
                        <section data-id="48353" class="wzweditor style_1" data-type="lspecial02,lspecial06"
                            powered-by="mengdo.cn" draggable="true" data-md5="2ece3">
                            <section style="box-sizing: border-box;padding-bottom:2px;" powered-by="mengdo.cn"
                                data-md5="2ece3" class="style_2">
                                <section style="display:-webkit-box;-webkit-box-pack:center;-webkit-box-align:end;"
                                    powered-by="mengdo.cn" data-md5="2ece3" class="style_3">
                                    <section
                                        class="wxqq-borderBottomColor wxqq-borderTopColor wxqq-borderRightColor wxqq-borderLeftColor style_4"
                                        style="box-sizing: border-box;border:2px solid #FF977B;padding:1px 0;transform:rotate(0deg);-ms-transform:rotate(0deg);-moz-transform:rotate(0deg);-webkit-transform:rotate(0deg);-o-transform:rotate(0deg);"
                                        powered-by="mengdo.cn" data-md5="2ece3">
                                        <section
                                            style="background-color:#FFDBBB;box-sizing: border-box;padding:0 5px;margin:1px -4px -6px 4px;"
                                            powered-by="mengdo.cn" class="wzw-bacolor style_5"
                                            data-bastyle="background-color:#FFDBBB;box-sizing: border-box;padding:0 5px;margin:1px -4px -6px 4px;"
                                            data-md5="2ece3">
                                            <section class="wxqq-Color style_6"
                                                style="color: #FF977B;letter-spacing: 1px;line-height: 24px;text-align:center;"
                                                powered-by="mengdo.cn" data-md5="2ece3">
                                                <p class="wzwbrush style_7"
                                                    style="padding: 0px;margin: 0px;font-size: 14px;" data-md5="2ece3">
                                                    NO.<span class="autosort style_8" data-md5="2ece3">02</span></p>
                                            </section>
                                        </section>
                                    </section>
                                    <section style="-webkit-box-flex: 1;width: 0;margin-bottom:1px;"
                                        powered-by="mengdo.cn" data-md5="2ece3" class="style_9">
                                        <section class="wxqq-Color style_10"
                                            style="color: #FF977B;letter-spacing: 1px;line-height: 21px;text-align: justify;margin-left:8px;"
                                            powered-by="mengdo.cn" data-md5="2ece3">
                                            <p class="wzwbrush style_11"
                                                style="padding: 0px;margin: 0px;font-size: 18px;" data-md5="2ece3">
                                                为什么需要赞助</p>
                                        </section>
                                        <section class="wxqq-borderTopColor style_12"
                                            style="width:100%;height:0px;box-sizing: border-box;border-top:2px solid #FF977B;"
                                            powered-by="mengdo.cn" data-md5="2ece3"></section>
                                    </section>
                                </section>
                            </section>
                        </section>
                        <hr />
                        <div class="wzw-text-content">
                            <section data-id="50923" class="wzweditor style_1" data-tools="小蚂蚁编辑器"
                                powered-by="mengdo.cn" data-md5="6a933" act="wzw">
                                <section style="padding-bottom:2px;box-sizing:border-box;" powered-by="mengdo.cn"
                                    data-md5="6a933" class="style_2">
                                    <section
                                        style="width:30px;margin:0px 0px -11px 50px;line-height:20px;transform:skew(-20deg);-webkit-transform:skew(-20deg);-moz-transform:skew(-20deg);-o-transform:skew(-20deg);"
                                        powered-by="mengdo.cn" data-md5="6a933" class="style_3">
                                        <section
                                            style="display:inline-block;vertical-align:middle;margin-right:5px;width:10px;height:20px;line-height:20px;background-color:#ffe4e4;"
                                            powered-by="mengdo.cn" class="wzw-banone style_4" data-md5="6a933">
                                        </section>
                                        <section
                                            style="display:inline-block;vertical-align:middle;width:10px;height:20px;line-height:20px;background-color:#ffe4e4;"
                                            powered-by="mengdo.cn" class="wzw-banone style_5" data-md5="6a933">
                                        </section>
                                    </section>
                                    <section style="display:-webkit-flex;display:flex;align-items:stretch;"
                                        powered-by="mengdo.cn" data-md5="6a933" class="style_6">
                                        <section style="width:20px;padding:20px 0px;box-sizing:border-box;"
                                            powered-by="mengdo.cn" data-md5="6a933" class="style_7">
                                            <section
                                                style="height:100%;width:20px;background-color:rgba(255,228,228,0.5);"
                                                powered-by="mengdo.cn" class="wzw-banone style_8" data-md5="6a933">
                                            </section>
                                        </section>
                                        <section style="flex:1;" powered-by="mengdo.cn" data-md5="6a933"
                                            class="style_9">
                                            <section
                                                style="background-color:rgba(255,228,228,0.5);padding:20px 0px;box-sizing:border-box;"
                                                powered-by="mengdo.cn" class="wzw-banone style_10" data-md5="6a933">
                                                <section
                                                    style="background-color:rgba(255,228,228,0.5);padding:20px 30px;box-sizing:border-box;"
                                                    powered-by="mengdo.cn" class="wzw-banone style_11"
                                                    data-md5="6a933">
                                                    <section class="wxqq-Color style_12"
                                                        style="color:#ff9396;letter-spacing:1px;line-height:24px;text-align:justify;"
                                                        powered-by="mengdo.cn" data-md5="6a933">
                                                        <p class="wzwbrush style_13"
                                                            style="font-size:14px;padding:0px;margin:0px;"
                                                            data-md5="6a933">
                                                            <?php echo wml_zib('zanzu-page-name'); ?>上线以来，努努力加加班定时更新一好玩的教程，几年下来也慢慢教程质量有了一些提升，加上发布教程完全免费（积分通过签到获取，即免费），能坚持这么多年也是很不容易的，随着时间的推移，维持网站的运行需要支出高昂的服务器和带宽费用。为了能继续坚持免费做下去，<?php echo wml_zib('zanzu-page-name'); ?>希望大家能够赞助<?php echo wml_zib('zanzu-page-name'); ?>，给<?php echo wml_zib('zanzu-page-name'); ?>加油打气！激励<?php echo wml_zib('zanzu-page-name'); ?>继续创作下去！谢谢！
                                                        </p>
                                                    </section>
                                                </section>
                                            </section>
                                        </section>
                                        <section style="width:20px;padding:20px 0px;box-sizing:border-box;"
                                            powered-by="mengdo.cn" data-md5="6a933" class="style_14">
                                            <section
                                                style="height:100%;width:20px;background-color:rgba(255,228,228,0.5);"
                                                powered-by="mengdo.cn" class="wzw-banone style_15" data-md5="6a933">
                                            </section>
                                        </section>
                                    </section>
                                    <section
                                        style="width:30px;margin:-11px 50px 0px auto;line-height:20px;transform:skew(-20deg);-webkit-transform:skew(-20deg);-moz-transform:skew(-20deg);-o-transform:skew(-20deg);"
                                        powered-by="mengdo.cn" data-md5="6a933" class="style_16">
                                        <section
                                            style="display:inline-block;vertical-align:middle;margin-right:5px;width:10px;height:20px;line-height:20px;background-color:#ffe4e4;"
                                            powered-by="mengdo.cn" class="wzw-banone style_17" data-md5="6a933">
                                        </section>
                                        <section
                                            style="display:inline-block;vertical-align:middle;width:10px;height:20px;line-height:20px;background-color:#ffe4e4;"
                                            powered-by="mengdo.cn" class="wzw-banone style_18" data-md5="6a933">
                                        </section>
                                    </section>
                                </section>
                            </section>
                        </div>
                        <hr />
                        <!--3-->
                        <section data-id="48353" class="wzweditor style_1" data-type="lspecial02,lspecial06"
                            powered-by="mengdo.cn" draggable="true" data-md5="2ece3">
                            <section style="box-sizing: border-box;padding-bottom:2px;" powered-by="mengdo.cn"
                                data-md5="2ece3" class="style_2">
                                <section style="display:-webkit-box;-webkit-box-pack:center;-webkit-box-align:end;"
                                    powered-by="mengdo.cn" data-md5="2ece3" class="style_3">
                                    <section
                                        class="wxqq-borderBottomColor wxqq-borderTopColor wxqq-borderRightColor wxqq-borderLeftColor style_4"
                                        style="box-sizing: border-box;border:2px solid #FF977B;padding:1px 0;transform:rotate(0deg);-ms-transform:rotate(0deg);-moz-transform:rotate(0deg);-webkit-transform:rotate(0deg);-o-transform:rotate(0deg);"
                                        powered-by="mengdo.cn" data-md5="2ece3">
                                        <section
                                            style="background-color:#FFDBBB;box-sizing: border-box;padding:0 5px;margin:1px -4px -6px 4px;"
                                            powered-by="mengdo.cn" class="wzw-bacolor style_5"
                                            data-bastyle="background-color:#FFDBBB;box-sizing: border-box;padding:0 5px;margin:1px -4px -6px 4px;"
                                            data-md5="2ece3">
                                            <section class="wxqq-Color style_6"
                                                style="color: #FF977B;letter-spacing: 1px;line-height: 24px;text-align:center;"
                                                powered-by="mengdo.cn" data-md5="2ece3">
                                                <p class="wzwbrush style_7"
                                                    style="padding: 0px;margin: 0px;font-size: 14px;" data-md5="2ece3">
                                                    NO.<span class="autosort style_8" data-md5="2ece3">03</span></p>
                                            </section>
                                        </section>
                                    </section>
                                    <section style="-webkit-box-flex: 1;width: 0;margin-bottom:1px;"
                                        powered-by="mengdo.cn" data-md5="2ece3" class="style_9">
                                        <section class="wxqq-Color style_10"
                                            style="color: #FF977B;letter-spacing: 1px;line-height: 21px;text-align: justify;margin-left:8px;"
                                            powered-by="mengdo.cn" data-md5="2ece3">
                                            <p class="wzwbrush style_11"
                                                style="padding: 0px;margin: 0px;font-size: 18px;" data-md5="2ece3">
                                                还有其他支持<?php echo wml_zib('zanzu-page-name'); ?>的渠道或者方式吗？</p>
                                        </section>
                                        <section class="wxqq-borderTopColor style_12"
                                            style="width:100%;height:0px;box-sizing: border-box;border-top:2px solid #FF977B;"
                                            powered-by="mengdo.cn" data-md5="2ece3"></section>
                                    </section>
                                </section>
                            </section>
                        </section>
                        <hr />
                        <div class="wzw-text-content">
                            <p>&nbsp;&nbsp;&nbsp;&nbsp;目前暂时没有其他渠道，如果您想以QQ支付的方式赞助<?php echo wml_zib('zanzu-page-name'); ?>可以加<?php echo wml_zib('zanzu-page-name'); ?>QQ赞助<?php echo wml_zib('zanzu-page-name'); ?>，所有赞助服务均有效。
                            </p>
                        </div>
                        <!--4-->
                        <section data-id="119931" class="wzweditor style_1" data-type="lspecial02,lspecial04"
                            powered-by="mengdo.cn" data-md5="de993">
                            <section style="text-align: center;" powered-by="mengdo.cn" data-md5="de993"
                                class="style_2">
                                <section class="wxqq-Color style_3"
                                    style="color: #FF898C;letter-spacing: 1px;margin-left: 40px; line-height:16px;text-align:justify;font-size: 16px;font-weight: bold;margin-bottom: -11px;"
                                    powered-by="mengdo.cn" data-md5="de993">
                                    <p class="wzwbrush style_4" style="padding: 0px;margin: 0px;" data-md5="de993">
                                        <?php echo wml_zib('zanzu-page-name'); ?>-<?php echo wml_zib('zanzu-page-url'); ?></p>
                                </section>
                                <section class="wzw-bacolor wxqq-bg style_5"
                                    style="box-sizing: border-box;padding:0px;background-color:#FF898C;width: 30px;height: 30px;margin-bottom: -30px;transform: rotate(0deg);"
                                    powered-by="mengdo.cn" data-md5="de993"></section>
                                <section
                                    class="wxqq-borderBottomColor wxqq-borderTopColor wxqq-borderRightColor wxqq-borderLeftColor style_6"
                                    style="box-sizing: border-box;border:10px solid #FFDCDB;padding:0; "
                                    powered-by="mengdo.cn" data-md5="de993">
                                    <section
                                        style="box-sizing: border-box;padding:20px 0;background-color:#fff;transform: rotate(0deg);"
                                        powered-by="mengdo.cn" class="wzw-banone style_7" data-md5="de993">
                                        <section class="wxqq-Color style_8"
                                            style="color: #FF898C;letter-spacing: 1.5px;margin-left: 1.5px; line-height: 28px;text-align:center;font-size: 14px;"
                                            powered-by="mengdo.cn" data-md5="de993">
                                            <p class="wzwbrush style_9" style="padding: 0px;margin: 0px;"
                                                data-md5="de993">这朵世间最美好的玫瑰，</p>
                                            <p class="wzwbrush style_10" style="padding: 0px;margin: 0px;"
                                                data-md5="de993">星尘为泥，银河滋养，永远不会枯萎，</p>
                                            <p class="wzwbrush style_11" style="padding: 0px;margin: 0px;"
                                                data-md5="de993">永远在沉静宇宙中盛放。</p>
                                            <p class="wzwbrush style_12" style="padding: 0px;margin: 0px;"
                                                data-md5="de993">这是我要给你的，宇宙级别的浪漫。</p>
                                        </section>
                                    </section>
                                </section>
                                <section
                                    style="width:30px;margin: -36.2px 0 0 auto;line-height:2px;transform: rotate(0deg);"
                                    powered-by="mengdo.cn" data-md5="de993" class="style_13"><img
                                        src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/zu4.gif'?>"
                                        style="vertical-align:middle;width:100%;" class="small_image style_14"
                                        data-isstyleimage="1" data-md5="de993"
                                        _src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/page/zu4.gif'?>"></section>
                            </section>
                        </section>
                    </div>
                </div>
            </div>
    </div>
    <!-- 支付弹窗 -->
    <div class="wp-block-zibllblock-modal wzwi-donate-modal">
        <div class="modal fade" id="wzw_donate-modal" aria-hidden="true" data-bkg1="false" aria-bkg2="false"
            role="dialog" tabindex="-1">
            <div class="modal-dialog modal-mini" data-kd="modal-mini">
                <div class="modal-content">
                    <div class="modal-header">
                        <strong class="modal-title">扫码赞助</strong>
                        <button class="close" data-dismiss="modal">
                            <div data-class="ic-close" data-svg="close" data-viewbox="0 0 1024 1024"></div>
                        </button>
                    </div>
                    <div class="wzw-modal-body modal-body">
                        <div class="wzw-donate-modal-zfm modal-body">
                            <div class="wzw-donate-modal-title dsjb">
                                <b>赞助发电❤支持<?php echo wml_zib('zanzu-page-name'); ?></b>
                                <p class="wzwi_pay-title">加载中...</p>
                            </div>
                            <div class="wzw-donate-modal-ewm">
                                <img src="" draggable="false" />
                            </div>
                            <p>长按保存支付二维码</p>
                            <div class="wzw-donate-modal-btn">
                                <div class="wzw-donate-btns">
                                    <button data-type="wx" class="btn wzw-zf-btn wzw-active">微信支付</button>
                                    <button data-type="zfb" class="btn wzw-zf-btn">支付宝支付</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        var pay_money = 'zdy', pay_type = "wx";
        function actv_zf_func(pay_ty) {
            $(".wzw-zf-btn").each(function () {
                $(this).attr("data-type") === pay_ty ? $(this).addClass('wzw-active') : $(this).removeClass('wzw-active');
            });
            $(".wzw-donate-modal-ewm>img").attr("src", "<?php echo WML_ZIB_BEAUT_DIR_ASSETS .'/img/pay/'?>" + pay_ty + "/" + pay_money + ".jpg");
        }
        $(".wzw-programme-content").on("click", ".wzw-money-item", function () {
            pay_money = $(this).attr("data-pay");
            pay_type = "wx";
            var pay_title = $(this).find('.wzw-money-name').text();
            var pay_text = pay_money === 'zdy' ? '请扫码自定义金额' : "￥ " + pay_money;
            $(".wzw-donate-modal-title>.wzwi_pay-title").html(pay_title + "（" + pay_text + "）");
            actv_zf_func(pay_type);
            $('#wzw_donate-modal').modal('show');
        });
        $(".wzwi-donate-modal").on("click", ".wzw-zf-btn", function () {
            pay_type = $(this).attr("data-type");
            actv_zf_func(pay_type);
        });
    </script>

    </div>
    </div>

    </div>
</main>

<?php
get_footer();