<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 15:27:06
 $ @ 最后修改: 2024-11-17 16:25:30
 $ @ 文件路径: \wml-zib-diy\core\admin\options\seo.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

CSF::createSection(
    $prefix,
    array(
        'id' => 'seo',
        'title' => 'SEO组件',
        'icon' => 'fa fa-fw fa-search',
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'seo',
        'title' => '标签&优化',
        'icon' => 'fa fa-fw fa-tags',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'psot_lable',
                'type' => 'switcher',
                'label' => '启用后，如果文章内容出现了已使用过的标签，那么会在发布/保存/更新文章时自动添加这些标签。',
                'default' => false,
                'title' => "自动文章添加标签",
            ),
            array(
                'dependency' => array('psot_lable', '!=', ''),
                'id' => 'post_tag',
                'default' => 'null',
                'title' => '标签处理范围',
                'type' => "select",
                'options' => array(
                    '1' => __('标题+正文前333字'),
                    '2' => __('文章内容前999字'),
                    '3' => __('仅匹配文章标题'),
                ),
            ),
            array(
                'dependency' => array('psot_lable', '!=', ''),
                'title' => __('自定义标签个数'),
                'id' => 'tag_gs',
                'default' => 16,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'type' => 'spinner',
            ),
            array(
                'id' => 'tag_link',
                'type' => 'switcher',
                'label' => '自动为文章标签添加该标签的内链接。',
                'default' => false,
                'title' => "自动添加标签链接",
            ),
            array(
                'dependency'  => array('tag_link', '!=', ''),
                'title'   => ' ',
                'subtitle'   => '一个标签少于几次不链接',
                'id'      => 'tag_link_num_from',
                'class'       => 'compact',
                'default' => '2',
                'type'    => 'number',
                'unit'    => '次',
            ),
            array(
                'dependency'  => array('tag_link', '!=', ''),
                'title'   => ' ',
                'subtitle'   => '一个标签最多链接几次',
                'id'      => 'tag_link_num_to',
                'class'       => 'compact',
                'default' => '2',
                'type'    => 'number',
                'unit'    => '次',
            ),
            array(
                'id' => 'tag_id',
                'type' => 'switcher',
                'label' => '启用后，会将标签设置为/tag/id.html格式，且原地址依然存在。',
                'default' => false,
                'title' => "标签链接格式更改",
            ),
            array(
                'id' => 'is_mate_tag',
                'type' => 'switcher',
                'label' => '启用后，为付费内容里面#开头的关键词添加标签链接',
                'default' => false,
                'title' => "付费内容标签替换",
            ),
            array(
                'dependency'  => array('is_mate_tag', '!=', ''),
                'title'   => ' ',
                'subtitle'=> '选择添加标签链接的类型',
                'id'      => 'mate_tag_c',
                'type'    => "checkbox",
                'inline'  => true,
                'options' => array(
                    'jj'  => '商品简介',
                    'gd'  => '更多详情',
                    'yc'  => '隐藏内容',
                ),
                'class' => 'compact', 
            ),array(
                'dependency'  => array('is_mate_tag', '!=', ''),
                'id' => 'mate_tag_color',
                'title' => ' ',
                'subtitle'=> '标签颜色',
                'default'=> '#f04494',
                'type'   => 'color',
                'class' => 'compact', 
            ),
            array(
                'dependency'  => array('is_mate_tag', '!=', ''),
                'id' => 'mate_tag_m',
                'type' => 'switcher',
                'label' => '启用后，为付费内容里面简介进行美化',
                'default' => false,
                'title' => " ",
                'subtitle'=> '商品简介美化',
                'class' => 'compact', 
            ),
            array(
                'dependency' => array(
                    array('is_mate_tag', '!=', ''),
                    array('mate_tag_m', '!=', ''),
                ),
                'title'      => ' ',
                'id'         => "mate_tag_m_y",
                'class'      => 'compact skin-color',
                'default'    => "c-red",
                'type'       => "palette",
                'options'  => CSF_Module_Wml_Zib::zib_palette(array(), array('t','c')),
            ),
            array(
                'dependency' => array('is_mate_tag', '!=', ''),
                'title'   => ' ',
                'subtitle'=> '显示方法',
                'type'    => "content",
                'class' => 'compact', 
                'content' => '<p>1、打开子比主题目录下的<font style="color:#fd4c73;"><code>zibpay/functions/zibpay-post.php</code></font></p>
                <p>查找<font style="color:#fd4c73;"><code>zibpay_is_paid</code></font>在这行下面添加：</p>
                <p><font style="color:#fd4c73;"><code>$pay_mate_wml=apply_filters(\'wml_zib_tag_pay_mate\',$pay_mate,$paid);</code></font></p>
                <p><font style="color:#fd4c73;"><code>$pay_mate = $pay_mate_wml ? $pay_mate_wml : $pay_mate;</code></font>两行代码</p>',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'seo',
        'title' => '禁用&防扒',
        'icon' => 'fa fa-fw fa-hand-spock-o',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'disablecopy',
                'type' => 'switcher',
                'label' => '启用后，网站用户将无法进行复制（前台无提示）。',
                'default' => false,
                'title' => '禁用复制',
            ),
            array(
                'id' => 'dismouse',
                'type' => 'switcher',
                'label' => '启用后，网站用户将无法使用鼠标进行选中（前台无提示）。',
                'default' => false,
                'title' => '禁用鼠标选中',
            ),
            array(
                'title' => '禁止图片拖放',
                'label' => '启用后，用户将不能拖放网站中图片（前台无提示）。',
                'id' => 'notuofang',
                'default' => false,
                'type' => 'switcher'
            ),
            array(
                'title' => '禁止打开控制台',
                'label' => '禁止打开控制台，网页禁止打开控制台（前台无提示）。',
                'id' => 'nodebugger',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'id' => 'disable',
                'type' => 'switcher',
                'label' => 'F12，Ctrl+U，Ctrl+S，Ctrl+Shift+I，右键等禁用并提示。',
                'default' => false,
                'title' => '禁用并提示',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title'   => ' ',
                'desc'    => '选择需要禁用的操作（可多选）',
                'id'      => 'disable_click',
                'class' => 'compact', 
                'type'    => "checkbox",
                'inline'  => true,
                'options' => array(
                    'disable_f'   => __('F12', 'zib_language'),
                    'disable_u'       => __('Ctrl+U', 'zib_language'),
                    'disable_s'   => __('Ctrl+S', 'zib_language'),
                    'disable_i'    => __('Ctrl+Shift+I', 'zib_language'),
                    'disable_r'    => __('右键', 'zib_language'),
                ),
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => 'F12提示标题', 
                'id' => 'disable_f_t', 
                'default' => '呃！别瞎按', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => 'F12提示内容', 
                'class' => 'compact', 
                'id' => 'disable_f_c', 
                'default' => '你按这个想干嘛！再按就找不到我咯', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => 'Ctrl+U提示标题', 
                'id' => 'disable_u_t', 
                'default' => '嘿！Brother', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => 'Ctrl+U提示内容', 
                'class' => 'compact', 
                'id' => 'disable_u_c', 
                'default' => '老弟，源码得换方式获取哦~', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => 'Ctrl+S提示标题', 
                'id' => 'disable_s_t', 
                'default' => '哎！你瞧瞧你', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => 'Ctrl+S提示内容', 
                'class' => 'compact', 
                'id' => 'disable_s_c', 
                'default' => '网页得换方法保存哦~', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => 'Ctrl+Shift+I提示标题', 
                'id' => 'disable_i_t', 
                'default' => '呐！这个也不行', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => 'Ctrl+Shift+I提示内容', 
                'class' => 'compact', 
                'id' => 'disable_i_c', 
                'default' => '还是按点别的吧！', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => '右键提示标题', 
                'id' => 'disable_r_t', 
                'default' => '嗯？没有右键菜单', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => '右键提示内容', 
                'class' => 'compact', 
                'id' => 'disable_r_c', 
                'default' => '复制请用键盘快捷键[Ctrl+C]', 
                'type' => 'text',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'seo',
        'title' => '统计&作弊',
        'icon' => 'fa fa-fw fa-bar-chart',
        'description' => '',
        'fields' => array(
            array(
                'title' => '会员总数',
                'desc'    => '关联插件中相关统计的组件，增加实际真实数据',
                'id' => 'cheat_hy',
                'default' => '0',
                'type' => 'text',
                'class' => 'mini-input',
            ),
            array(
                'title' => '总浏览量',
                'desc'    => '关联插件中相关统计的组件，增加实际真实数据',
                'id' => 'cheat_ll',
                'default' => '0',
                'type' => 'text',
                'class' => 'mini-input',
            ),
            array(
                'title' => '新人数量',
                'desc'    => '显示新注册会员信息的数量',
                'id' => 'cheat_xhy',
                'default' => '10',
                'type' => 'text',
                'class' => 'mini-input',
            ),
            array(
                'title' => '消费记录',
                'desc'    => '显示消费记录的数量',
                'id' => 'cheat_xfjl',
                'default' => '10',
                'type' => 'text',
                'class' => 'mini-input',
            ),
            array(
                'title' => '最近评论',
                'desc'    => '显示最近评论的数量',
                'id' => 'cheat_zjpl',
                'default' => '10',
                'type' => 'text',
                'class' => 'mini-input',
            ),
            array(
                'title'   => '排除ID',
                'id'      => 'cheat_zjpl_pc',
                'type'    => 'text',
                'desc'    => '显示排除ID的评论',
                'class' => 'mini-input compact',
                'default' => '1',
            ),
            array(
                'title' => '运行时间',
                'desc'    => '站点运行的时间，时间格式：<font style="color:#fd4c73;">2020-08-08 12:00:00</font>',
                'id' => 'cheat_yx',
                'default' => '2020-08-08 12:00:00',
                'type' => 'text',
                'class' => 'mini-input',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'seo',
        'title' => '注册&限制',
        'icon' => 'fa fa-fw fa-registered',
        'description' => '',
        'fields' => array(
            array(
                'title' => '用户限制',
                'label'    => '注册用户名限制总开关',
                'id' => 'regxz_is',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('regxz_is', '!=', ''), 
                'title' => '首个字母',
                'label'    => '注册用户名首个字符必须字母',
                'id' => 'regxz_szm',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('regxz_is', '!=', ''), 
                'id' => 'regxz_type',
                'title' => '限制模式',
                'default' => '1',
                'inline' => true,
                'type' => 'radio',
                'options' => array(
                    '1' => '禁止模式',
                    '2' => '允许模式',
                ),
                'class' => 'compact', 
            ),
            array(
                'dependency' => array(
                    array('regxz_is', '!=', ''),
                    array('regxz_type', '==', '1'),
                ),
                'title'   => '禁用选择',
                'id'      => 'regxz_jz',
                'type'    => "checkbox",
                'inline'  => true,
                'desc'    => '选择禁用用户名包含的字符（可多选）',
                'options' => array(
                    'kg'  => '空格',
                    'zw'  => '中文',
                    'dx'  => '大写',
                    'xh'  => '下划线',
                    'fh'  => '特殊符号',
                ),
                'class' => 'compact', 
                //'default' => array('kg', 'zw', 'dx', 'xh', 'fh'),
            ),
            array(
                'dependency' => array(
                    array('regxz_is', '!=', ''),
                    array('regxz_type', '==', '2'),
                ),
                'title'    => '允许选择',
                'desc'    => '选择允许的用户名包含字符',
                'id'       => 'regxz_yx',
                'default'  => '7',
                'type'     => 'select',
                'options'  => array(
                    '1' =>'字母',
                    '2' =>'字母+数字',
                    '3' =>'字母+数字+下划线',
                    '4' =>'字母+数字+下划线+中文',
                    '5' =>'小写字母',
                    '6' =>'小写字母+数字',
                    '7' =>'小写字母+数字+下划线',
                    '8' =>'小写字母+数字+下划线+中文',
                    '9' =>'中文',
                ),
                'class' => 'compact', 
            ),
            array(
                'dependency' => array('regxz_is', '!=', ''), 
                'title'    => __('自定义用户名限制', 'zib_language'),
                //'subtitle' => __('禁止的用户名关键词', 'zib_language'),
                'desc'     => __('前台注册时，不能使用包含这些关键字的用户名(请用逗号或换行分割)', 'zib_language'),
                'id'       => 'regxz_diy',
                'default'  => "admin,test,waimaola",
                'sanitize' => false,
                'type'     => 'textarea',
                'class' => 'compact', 
            ),
            array(
                'title' => '密码限制',
                'label'    => '注册密码限制总开关',
                'id' => 'regxz_p_is',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('regxz_p_is', '!=', ''),
                'id'      => 'regxz_p_length',
                'title'   => '密码长度',
                'desc'    => '',
                'default' => 6,
                'max'     => 30,
                'min'     => 6,
                'step'    => 1,
                'unit'    => '位',
                'type'    => 'slider',
            ),
            array(
                'dependency' => array('regxz_p_is', '!=', ''),
                'title'   => '包含选择',
                'id'      => 'regxz_p_jz',
                'type'    => "checkbox",
                'inline'  => true,
                'desc'    => '选择密码中必须包含的字符（可多选）',
                'options' => array(
                    'dx'  => '大写',
                    'xx'  => '小写',
                    'sz'  => '数字',
                    'fh'  => '特殊符号',
                ),
                'class' => 'compact', 

            ),
            array(
                'dependency' => array('regxz_p_is', '!=', ''), 
                'title'    => __('自定义密码限制', 'zib_language'),
                'desc'     => __('前台注册时，不能使用这些密码(请用逗号或换行分割)', 'zib_language'),
                'id'       => 'regxz_p_diy',
                'default'  => "123456,asd123,waimaola",
                'sanitize' => false,
                'type'     => 'textarea',
                'class' => 'compact', 
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'seo',
        'title' => '搜索&优化',
        'icon' => 'fa fa-fw fa-search',
        'description' => '',
        'fields' => array(
            array(
                'title' => '伪静态',
                'label'    => '开启后搜索伪静态，不再是?s=oove&type=post，类型',
                'id' => 'so_whtml_is',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'title' => '防止外部',
                'label'    => '搜索行为如果不在自己网站搜索过去的外部行为直接跳转到百度。',
                'id' => 'so_feyi_is',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'title' => '办关键词',
                'label'    => '自定义屏蔽关键字',
                'id' => 'so_ban_is',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('so_ban_is', '!=', ''), 
                'title'    => ' ',
                'desc'     => __('搜索时不能使用这些关键词(请用逗号或换行分割)', 'zib_language'),
                'id'       => 'so_ban_diy',
                'default'  => "共产党,习近平,做爱",
                'sanitize' => false,
                'type'     => 'textarea',
                'class' => 'compact', 
            ),
            array(
                'title' => '游客限制',
                'label'    => '限制游客使用搜索功能',
                'id' => 'so_youke_is',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('so_youke_is', '!=', ''), 
                'id' => 'so_youke_type',
                'title' => '限制模式',
                'default' => '1',
                'inline' => true,
                'type' => 'radio',
                'options' => array(
                    '1' => '完全禁止',
                    '2' => '限制时间',
                ),
                'class'       => 'compact',
            ),
            array(
                'dependency' => array(
                    array('so_youke_is', '!=', ''),
                    array('so_youke_type', '==', '2'),
                ),
                'title'   => ' ',
                'subtitle'   => '限制时间',
                'id'      => 'so_youke_time',
                'class'       => 'compact',
                'default' => '5',
                'type'    => 'number',
                'unit'    => '分钟/次',
            ),
            array(
                'title' => '限制频率',
                'label'    => '限制每分钟搜索频率',
                'id' => 'so_pinlv_is',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('so_pinlv_is', '!=', ''), 
                'title'   => ' ',
                'subtitle'   => '限制时间',
                'id'      => 'so_pinlv_cs',
                'class'       => 'compact',
                'default' => '5',
                'type'    => 'number',
                'unit'    => '次/分钟',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'seo',
        'title' => '链接&转换',
        'icon' => 'fa fa-fw fa-link',
        'description' => '',
        'fields' => array(
            array(
                'title' => '转换开启',
                'label'    => '开启后发布文章时别名链接自动转换为拼音或英文',
                'id' => 'seo_slug_switch',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('seo_slug_switch', '!=', ''), 
                'id' => 'seo_slug_type',
                'title' => '类型选择',
                'default' => '1',
                'inline' => true,
                'type' => 'radio',
                'options' => array(
                    '1' => '拼音',
                    '2' => '英文',
                ),
            ),
            array(
                'dependency' => array('seo_slug_switch', '!=', ''), 
                'title' => '别名长度',
                'desc'    => '默认情况下，最大别名长度设置为60个字母；超过该限制的任何内容都不会转换。',
                'id' => 'seo_slug_length',
                'default' => '30',
                'type' => 'text',
                'class' => 'mini-input',
            ),
            array(
                'dependency' => array('seo_slug_switch', '!=', ''), 
                'title' => '连接字符',
                'desc'    => '可以是：_ 或 - 或 .   默认为 “-”，如果不需要分隔符，请留空',
                'id' => 'seo_slug_divider',
                'default' => '-',
                'type' => 'text',
                'class' => 'mini-input',
            ),
            array(
                'dependency' => array(
                    array('seo_slug_switch', '!=', ''),
                    array('seo_slug_type', '==', '2'),
                ),
                'title' => '百度翻译ID',
                'desc'    => '请在百度翻译开放平台获取：https://api.fanyi.baidu.com/api/trans/product/index',
                'id' => 'seo_slug_bdid',
                'default' => '',
                'type' => 'text',
            ),
            array(
                'dependency' => array(
                    array('seo_slug_switch', '!=', ''),
                    array('seo_slug_type', '==', '2'),
                ),
                'title' => '百度翻译密钥',
                'desc'    => '请在百度翻译开放平台获取：https://api.fanyi.baidu.com/api/trans/product/index',
                'id' => 'seo_slug_bdkey',
                'default' => '',
                'type' => 'text',
            ),
        )
    )
);