<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 16:13:13
 $ @ 文件路径: \wml-zib-diy\core\core.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (! defined('ABSPATH')) {
	die;
}

//  检查主题依赖
function wml_zib_check_theme_before_activation()
{
    $active_theme = wp_get_theme();

    $required_theme_name = '子比主题';
    $required_theme_version = '7.8';

    if ($active_theme->get('Name') !== $required_theme_name) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die('本插件依赖子比主题，请先安装子比主题后再试。');
    } elseif (version_compare($active_theme->get('Version'), $required_theme_version, '<')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die('本插件依赖子比主题版本7.8及以上，请更新子比主题后再试。');
    }
}

// 去除链接协议头
function wml_replace_url($url)
{
    // 去除 http:// 和 https://
    $urlWithoutProtocol = str_replace(array('http://', 'https://'), '', $url);

    // 返回去除协议后的 URL
    return $urlWithoutProtocol;
}

// 快捷获取插件配置信息
function wml_zib($name, $default = false, $subname = '')
{
    // 声明静态变量以加速获取
    static $options = null;
    if ($options === null) {
        $options = get_option('wml_zib_diy');
    }

    if (isset($options[$name])) {
        if ($subname) {
            return isset($options[$name][$subname]) ? $options[$name][$subname] : $default;
        } else {
            return $options[$name];
        }
    }
    return $default;
}

// 引入主题框架
require_once get_theme_file_path('/inc/codestar-framework/codestar-framework.php');

// 载入核心文件
require_once 'module.php';//前后端共用数据文件
require_once 'widgets/wml-index.php';//小工具组件
require_once 'admins/wml-system.php';//后台组件
require_once 'watermark/wml-imk.php';//上传图片水印
require_once 'functions/functions.php';//前端核心文件
require_once 'admin/admin.php';//后台配置文件
