<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 16:04:15
 $ @ 最后修改: 2024-11-21 02:42:09
 $ @ 文件路径: \wml-zib-diy\core\admin\options\feature.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

 CSF::createSection(
    $prefix,
    array(
        'id' => 'feature',
        'title' => '功能组件',
        'icon' => 'fa fa-cubes',
    )
);

//在线客服
CSF::createSection(
    $prefix,
    array(
        'parent' => 'feature',
        'title' => '在线&客服',
        'icon' => 'fa fa-weixin',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'chat_crisp',
                'type' => 'switcher',
                'label' => '启用后，全局右下角显示在线客服',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('chat_crisp', '!=', ''),
                'title' => '资源加载',
                'id' => 'chat_crisp_js',
                'default' => '1',
                'inline' => true,
                'type' => 'radio',
                'options' => array(
                    '1' => __('本地加速', 'zib_language'),
                    '2' => __('官方直连', 'zib_language'),
                ),
            ),
            array(
                'dependency' => array('chat_crisp', '!=', ''),
                'id'         => 'chat_crisp_key',
                'type'       => 'text',
                'title'      => 'crisp 密钥',
                'desc'       => '<a href="'.CSF_Module_Wml_part::crisp().'" class="but jb-red">一键获取关联</a> <font style="color:#fd4c73;"><code>先保存再获取（右上角可选繁体中文）</code></font> 或者从官网自主注册申请：<a href="https://app.crisp.chat/initiate/login/" target="_blank">https://app.crisp.chat/initiate/login/</a>',
                'default'    => wml_zib('chat_crisp_key'),
            ),
            array(
                'dependency' => array('chat_crisp', '!=', ''),
                'title'   => '聊天管理',
                'type'    => "content",
                'content' => '<a href="'.esc_url("https://app.crisp.chat/website/".wml_zib('chat_crisp_key')).'" class="but jb-blue" target="_blank">💬打开聊天</a> <a href="'.esc_url("https://app.crisp.chat/settings/website/".wml_zib('chat_crisp_key')).'" class="but jb-vip2" target="_blank">⚙️功能设置</a>',
            ),
            array(
                'title'   => '推荐理由',
                'type'    => "content",
                'content' => '<div style="color:#ff2153;"><i class="fa fa-fw fa-info-circle fa-fw"></i>国外一款拥有免费计划的在线客服聊天插件，支持手机端，功能强大，可拓展多个小工具，多种风格。直连官网加载有点慢，已做本地化加速。</div>',
            ),
        )
    )
);

//翻译
CSF::createSection(
    $prefix,
    array(
        'parent' => 'feature',
        'title' => '翻译&语言',
        'icon' => 'fa fa-language',
        'description' => '',
        'fields' => array(
    array(
        'id' => 'language_switch',
        'type' => 'switcher',
        'label' => '前端翻译功能总开关',
        'default' => false,
        'title' => '翻译开关',
    ),
    array(
        'dependency' => array('language_switch', '!=', ''),
        'title'    => '默认翻译',
        'id'       => 'language_default',
        'default'  => 'english',
        'type'     => 'select',
        'options'  => CSF_Module_Wml_Zib::language_select(),
    ),
    array(
        'dependency' => array(
            array('language_switch', '!=', ''),
            array('language_icon_c', '==', '', '', 'visible'),
        ),
        'id'           => 'language_icon',
        'type'         => 'icon',
        'desc'         => '按钮默认显示的图标，可以选择内置图标，也可以自定义任意图标代码，自定义图标HTML代码，请注意代码规范',
        'title'        => '按钮默认图标',
        'button_title' => '选择预置图标',
        'default'      => '',
    ),
    array(
        'dependency' => array('language_switch', '!=', ''),
        'title'      => ' ',
        'subtitle'   => '自定义图标代码',
        'id'         => 'language_icon_c',
        'default'    => '',
        'sanitize'   => false,
        'type'       => 'textarea',
        'attributes' => array(
            'rows' => 2,
        ),
    ),  
    array(
        'dependency' => array('language_switch', '!=', ''),
        'title'   => '添加语言',
        'subtitle'   => '添加并排序翻译语言',
        'id'      => 'language',
        'type'          => 'group',
        'accordion_title_number' => '1',
        'sanitize' => false,//关闭HTML过滤器
        'button_title'  => '添加语言',
        'fields' => array(
                array(
                    'title'    => '选择语言',
                    'id'       => 'language_id',
                    'default'  => 'chinese_simplified',
                    'type'     => 'select',
                    'options'  => CSF_Module_Wml_Zib::language_select(),
                ),
                array(
                    'title'   => '是否启用',
                    'id'      => 'language_id_switch' ,
                    'default' => true,
                    'type'    => 'switcher',
                ),
                array(
                    'dependency'   => array('language_svg', '==', '', '', 'visible'),
                    'title' => '语言图标',
                    'desc' => '请填写左侧图片(根据高度)',
                    'subtitle' => '各国国旗PNG和SVG图标：<a target="_blank" href="https://www.yuanmavip.com/national-flag-icon.html">获取图标</a>',
                    'id' => 'language_img',
                    'default' => $img . 'language/svg/zh-CN.svg',
                    'preview' => true,
                    'library' => 'image',
                    'type' => 'upload',
                ),
                array(
                    'title'    => '自定义图标代码',
                    'subtitle' => '直接填写输入SVG、img、代码，图标参考：<a target="_blank" href="https://yesicon.app/">https://yesicon.app/</a>',
                    'id'       => 'language_svg',
                    'settings' => array(
                        'theme' => 'dracula',
                    ),
                    'sanitize'   => false,//关闭HTML过滤器
                    'type'     => 'textarea',
                ),
            ),
        ),
    )
));

CSF::createSection(
    $prefix,
    array(
        'parent' => 'feature',
        'title' => '数字&销售',
        'icon' => 'fa fa-fw fa-product-hunt',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'dproduct',
                'type' => 'switcher',
                'label' => '开启后可在新建页面销售数字产品（仿子比购买）',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'title'   => ' ',
                'type'    => "content",
                'content' => '<div style="color:#ff2153;"><i class="fa fa-fw fa-info-circle fa-fw"></i>以下功能，只有授权用户设置才能生效，可配合WML授权系统使用</div>',
            ),
            array(
                'dependency' => array('dproduct', '!=', ''),
                'id' => 'dproduct_user',
                'type' => 'switcher',
                'label' => '开启后会员中心显示数字商品信息',
                'default' => false,
                'title' => '会员中心',
            ),
            array(
                'dependency' => array(
                    array('dproduct', '!=', ''),
                    array('dproduct_user', '!=', ''),
                ),
                'id' => 'dproduct_user_name',
                'type' => 'text',
                'title' => '商品名称',
                'desc' => '',
                'default' => 'WML美化增强',
                'class' => 'mini-input',
            ),
            array(
                'dependency' => array(
                    array('dproduct', '!=', ''),
                    array('dproduct_user', '!=', ''),
                ),
                'id' => 'dproduct_user_info',
                'type' => 'text',
                'title' => '商品说明',
                'desc' => '',
                'default' => '最好的子比美化增强插件',
                'class' => 'mini-input compact',
            ),
            array(
                'dependency' => array(
                    array('dproduct', '!=', ''),
                    array('dproduct_user', '!=', ''),
                ),
                'id' => 'dproduct_user_button',
                'type' => 'text',
                'title' => '按钮名称',
                'desc' => '',
                'default' => '授权管理',
                'class' => 'mini-input compact',
            ),
            array(
                'dependency' => array(
                    array('dproduct', '!=', ''),
                    array('dproduct_user', '!=', ''),
                ),
                'title' => '商品图标',
                'desc' => '请填写LOGO图片地址',
                'id' => 'dproduct_user_logo',
                'preview' => true,
                'library' => 'image',
                'type' => 'upload',
                'default' => 'https://waimao.la/wp-content/uploads/2024/09/f50c73d00f20240920082650.png',
                'class' => 'compact',
            ),
            array(
                'dependency' => array(
                    array('dproduct', '!=', ''),
                    array('dproduct_user', '!=', ''),
                ),
                'id' => 'dproduct_user_sid',
                'type' => 'text',
                'title' => '商品ID',
                'desc' => '输入指定商品ID，指定商品在会员中心显示',
                'default' => '',
                'class' => 'mini-input',
            ),
            array(
                'dependency' => array(
                    array('dproduct', '!=', ''),
                    array('dproduct_user', '!=', ''),
                ),
                'id' => 'dproduct_user_aut',
                'type' => 'switcher',
                'label' => '开启后会员中心会显示授权信息，一般不需要，需要定制',
                'default' => false,
                'title' => '授权信息',
            ),
            array(
                'dependency' => array(
                    array('dproduct', '!=', ''),
                    array('dproduct_user', '!=', ''),
                ),
                'title'                  => '下载按钮',
                'id'                     => 'dproduct_user_down',
                'type'                   => 'group',
                'accordion_title_number' => '1',
                'sanitize'               => false,
                'button_title'           => '添加下载',
                'default'                => array(
                    array(
                        'name' => '极速下载',
                        'info' => '版本：V8.0',
                        'link'     => array(
                            'url'=> 'https://waimao.la/',
                            'text'=> '本地下载',
                            'target'=> '_blank',
                        ),
                    ),
                    array(
                        'name' => '备用下载',
                        'info' => '版本：V8.0',
                        'link'     => array(
                            'url'=> 'https://waimao.la/',
                            'text'=> '本地下载',
                            'target'=> '_blank',
                        ),
                    ),
                ),
                'fields'=> array(
                    array(
                        'title' => '下载名称',
                        'id' => 'name',
                        'desc' => '',
                        'default' => '',
                        'type' => 'text',
                        'class' => 'mini-input',
                    ),
                    array(
                        'title' => '下载说明',
                        'id' => 'info',
                        'desc' => '',
                        'default' => '',
                        'type' => 'text',
                        'class' => 'mini-input',
                    ),
                    array(
                        'id'           => 'link',
                        'type'         => 'link',
                        'title'        => '跳转链接',
                        'default'      => array(),
                        'add_title'    => '添加链接',
                        'edit_title'   => '编辑链接',
                        'remove_title' => '删除链接',
                    ),
                ),
            ),
            array(
                'dependency' => array(
                    array('dproduct', '!=', ''),
                    array('dproduct_user', '!=', ''),
                ),
                'title'      => '使用说明',
                'subtitle'   => ' ',
                'id'         => 'dproduct_user_text',
                'default'    => '<li class="c-yellow-2 mb6">严禁用于任何违法内容，一经发现直接报警<a target="_blank" class="focus-color" href="https://www.zibll.com/forum-post/28835.html">【查看详情】</a></li>
                    <li class="c-yellow-2 mb6">请严格遵守授权规范，违规使用将做封号处理<a target="_blank" class="focus-color" href="https://www.zibll.com/zibll-pay-desc">【查看详情】</a></li>
                    <li class="c-blue mb6">首次使用请查看<a href="https://www.zibll.com/8332.html" target="_blank" class="focus-color">【WordPress搭建教程】</a>、<a href="https://www.zibll.com/46.html" target="_blank" class="focus-color">【主题安装教程及准备】</a></li>
                    <li class="c-blue mb6">更新授权域名后，如需更换网站域名请使用<a href="https://www.zibll.com/19369.html" target="_blank" class="focus-color">【一键换域名插件】</a></li>
                    <li class="c-yellow">更新主题请务必<b class="c-red">清空浏览器缓存</b>、<b class="c-red">刷新CDN缓存</b></li>
                    </div>
                    <div class="mt10 ml10"><a target="_blank" href="https://www.zibll.com/375.html" class="but c-blue mt6 mr10"><i aria-hidden="true" class="fa fa-cloud-upload"></i>更新日志</a>
                    <a target="_blank" class="but c-blue mt6 mr10" href="https://www.zibll.com/forums"><i aria-hidden="true" class="fa fa-grav"></i>社区论坛</a>
                    <a target="_blank" class="but c-blue mt6 mr10" href="https://www.zibll.com/%e4%b8%bb%e9%a2%98%e6%96%87%e6%a1%a3"><i aria-hidden="true" class="fa fa-bookmark"></i>主题文档</a></div>',
                'sanitize'   => false,
                'type'       => 'textarea',
                'class'      => 'compact',
                'attributes' => array(
                    'rows' => 6,
                ),
            ),  
            array(
                'dependency' => array(
                    array('dproduct', '!=', ''),
                    array('dproduct_user', '!=', ''),
                ),
                'title'                  => '客服扫码',
                'id'                     => 'dproduct_user_kf',
                'type'                   => 'group',
                'accordion_title_number' => '1',
                'sanitize'               => false,
                'button_title'           => '添加客服',
                'class'                  => 'compact',
                'default'                => array(
                    array(
                        'name' => '扫码加入用户群',
                        'info' => 'QQ群号870461997',
                        'img'      => 'https://assets.waimao.la/img/qun_qq_zib.jpg',
                        'link'     => array(
                            'url'=> 'https://qm.qq.com/q/bphhwTlXby',
                            'text'=> 'QQ群号870461997',
                            'target'=> '_blank',
                        ),
                    ),
                ),
                'fields'=> array(
                    array(
                        'title' => '扫码名称',
                        'id' => 'name',
                        'desc' => '',
                        'default' => '',
                        'type' => 'text',
                        'class' => 'mini-input',
                    ),
                    array(
                        'title' => '扫码图片',
                        'desc' => '请填写图片地址',
                        'id' => 'img',
                        'preview' => true,
                        'library' => 'image',
                        'type' => 'upload',
                    ),
                    array(
                        'id'           => 'link',
                        'type'         => 'link',
                        'title'        => '跳转链接',
                        'default'      => array(),
                        'add_title'    => '添加链接',
                        'edit_title'   => '编辑链接',
                        'remove_title' => '删除链接',
                    ),
                ),
            ),
            array(
                'dependency' => array('dproduct', '!=', ''),
                'id' => 'dproduct_api',
                'type' => 'switcher',
                'label' => '开启后可针对某个商品在支付成功后做API执行和回调，比如用来发送邮件、授权信息、和其他密钥信息，具体由自己需求而定制。',
                'default' => false,
                'title' => '支付执行',
            ),
            array(
                'dependency' => array(
                    array('dproduct', '!=', ''),
                    array('dproduct_api', '!=', ''),
                ),
                'id' => 'dproduct_api_url',
                'type' => 'text',
                'title' => 'API接口',
                'desc' => '输入API地址，如：http://waimao.la/zibpay-api，对应的文件api/zibpay-api.php，可自由定制',
                'default' => 'http://waimao.la/zibpay-api',
            ),
            array(
                'dependency' => array(
                    array('dproduct', '!=', ''),
                    array('dproduct_api', '!=', ''),
                ),
                'id' => 'dproduct_api_key',
                'type' => 'text',
                'title' => 'KEY验证',
                'desc' => '设置需要验证KEY才能执行，防止不明来源恶意执行，这里更换成自己的',
                'default' => 'f320618d4cd5198f3fc68ea82d17563e',
                'class' => 'compact',
            ),
            array(
                'dependency' => array(
                    array('dproduct', '!=', ''),
                    array('dproduct_api', '!=', ''),
                ),
                'id' => 'dproduct_api_origin',
                'type' => 'switcher',
                'label' => '开启后该API允许跨域发送请求',
                'default' => false,
                'title' => '是否允许跨域',
                'class' => 'compact',
            ),
            array(
                'dependency' => array(
                    array('dproduct', '!=', ''),
                    array('dproduct_api', '!=', ''),
                ),
                'id' => 'dproduct_api_email',
                'type' => 'switcher',
                'label' => '成功购买授权后自动向用户发送邮件通知',
                'default' => false,
                'title' => '发送授权邮件',
                'class' => 'compact',
            ),
            array(
                'dependency' => array(
                    array('dproduct', '!=', ''),
                    array('dproduct_api', '!=', ''),
                ),
                'title'   => 'API接口说明',
                'type'    => "content",
                'content' => '<p>该接口请求采用更为安全的curl方式，需要在PHP安装curl扩展，接收形式为POST数组，如：<font style="color:#fd4c73;"><code>$_POST[\'user_id\']</code></font></p>
                <p>传递参数具体如下：<font style="color:#fd4c73;"><code>array("user_id"=>1,"payment_methodbar"=>"balance","order_num"=>"2411110736334976818","order_price"=>"99.9","ip_address"=>"1.1.1.1","error"=>0,"reload"=>true);</code></font></p>
                <p>user_id：购买者会员ID</p>
                <p>payment_method：支付方式</p>
                <p>post_id：商品id</p>
                <p>order_num：订单号</p>
                <p>order_price：支付金额</p>
                <p>ip_address：IP地址</p>
                <hr><div style="color:#ff2153;"><i class="fa fa-fw fa-info-circle fa-fw"></i>提示：该接口只有支付成功后可触发，需要有一定开发能力，可扩展性强。</div>',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'feature',
        'title' => '卡密&自售',
        'icon' => 'fa fa-fw fa-credit-card-alt',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'card_sales',
                'type' => 'switcher',
                'label' => '卡密自动发放自动售卡功能总开关',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'title'   => ' ',
                'type'    => "content",
                'content' => '<div style="color:#ff2153;"><i class="fa fa-fw fa-info-circle fa-fw"></i>开启后，新建文章时可选择卡密出售选项，同付费阅读一栏。</div>',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'feature',
        'id' => 'watermark',
        'title' => '图片&水印',
        'icon' => 'fa fa-fw fa-file-image-o',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '开启水印功能',
                'id'      => 'imk_onOff',
                'type'    => 'switcher',
                'default' => true,
                'label'   => '实现水印开关，不需要关闭插件即可关闭水印功能',
            ),array(
                'id' => 'imk-type',
                'title' => '水印类型',
                'type' => 'radio',
                'inline'  => true,
                'options' => array(
                    '1' => '文本水印',
                    '2' => '图片水印'
                ),
                'default' => 1
            ),array(
                'id' => 'filtration',
                'type' => 'text',
                'title' => '需要过滤的名称',
                'desc' => '添加图片上传时需要过滤的名称，多个使用英文逗号隔开',
                'default' => 'cover'
            ),array(
                'dependency' => array( 'imk-type', '==', 1 ),
                'id' => 'content',
                'type' => 'text',
                'title' => '文本内容',
                'default' => '外贸啦 - Waimao.La'
            ),array(
                'dependency' => array( 'imk-type', '==', 1 ),
                'id' => 'font',
                'title' => '文本字体',
                'desc' => '字体文件较大，自定义字体请上传到wml-zib-diy/core/watermark/assets/fonts目录',
                'type' => 'select',
                'chosen' => true,
                'options' => 'imk_fonts',
                'default' => 1
            ),array(
                'dependency' => array( 'imk-type', '==', 1 ),
                'id' => 'color',
                'title' => '文本颜色',
                'default'    => '#d8d8d8',
                'type'       => 'color',
            ),array(
                'dependency' => array( 'imk-type', '==', 2 ),
                'id' => 'img_url',
                'title' => '图片地址',
                'desc' => '建议使用logo或者文字图片以及透明背景',
                'default'    => get_imk_img_url('viu-imk.png'),
                'type'       => 'upload',
            ),array(
                'id' => 'qx',
                'title' => '水印倾斜',
                'desc' => '默认为0，负数为左低右高，正数为左高右低',
                'default'    => 0,
                'max'        => 180,
                'min'        => -180,
                'step'       => 5,
                'unit'       => '%',
                'type'       => 'spinner',
            ),array(
                'id' => 'size',
                'title' => '水印大小',
                'default'    => 68,
                'min'        => 1,
                'step'       => 2,
                'unit'       => 'px',
                'type'       => 'spinner',
            ),array(
                'id' => 'opacity',
                'title' => '水印透明度',
                'default'    => 68,
                'max'        => 100,
                'min'        => 0,
                'step'       => 2,
                'unit'       => '%',
                'desc'      => '0-100，越小越透明，建议设置30',
                'type'       => 'spinner',
            ),array(
                'title'   => '开启仅管理员上传添加水印',
                'id'      => 'is_admin',
                'type'    => 'switcher',
                'default' => true,
                'label'   => '开启后，仅管理员登录权限上传添加水印',
            ),array(
                'title'   => '开启仅后台上传添加水印',
                'id'      => 'is_console',
                'type'    => 'switcher',
                'default' => false,
                'label'   => '开启后，仅后台上传添加水印',
            ),array(
                'id' => 'site',
                'title' => '水印位置',
                'type' => 'radio',
                'inline'  => true,
                'desc' => '随机九宫格为每次上传随机水印在九宫格的位置，而不是查看图片时随机',
                'options' => array(
                    '1' => '九宫格',
                    '2' => '随机九宫格',
                    '3' => '铺满'
                ),
                'default' => 1
            ),array(
                'dependency' => array( 'site', '==', 1 ),
                'id' => 'padding',
                'title' => '水印边距',
                'desc' => '水印起始位置距离图片四周边距数值， 建议30',
                'default'    => 30,
                'min'        => 1,
                'step'       => 2,
                'unit'       => 'px',
                'type'       => 'spinner',
            ),array(
                'dependency' => array( 'site', '==', 3 ),
                'id' => 'spacing',
                'title' => '水印间距',
                'desc' => '铺满时水印之间的距离',
                'default'    => 12,
                'min'        => 1,
                'step'       => 2,
                'unit'       => 'px',
                'type'       => 'spinner',
            ),array(
                'dependency' => array( 'site', '==', 3 ),
                'id' => 'row_height',
                'title' => '水印行高',
                'desc' => '铺满时水印上下行的距离',
                'default'    => 10,
                'min'        => 1,
                'step'       => 2,
                'unit'       => 'px',
                'type'       => 'spinner',
            ),array(
                'dependency' => array( 'site', '==', 3 ),
                'id' => 'interleaving',
                'title' => '水印交错',
                'desc' => '铺满时水印上下行的左右交错',
                'default'    => 20,
                'min'        => 1,
                'step'       => 2,
                'unit'       => 'px',
                'type'       => 'spinner',
            ),array(
                'dependency' => array( 'site', '==', 1 ),
                'id' => 'jgg_site',
                'type' => 'image_select',
                'title' => '九宫格位置',
                'before' => '<style>.jgg-site .csf-fieldset .csf--image-group{
                    display: flex;
                    flex-wrap: wrap;
                }
                .jgg-site .csf-fieldset .csf--image-group .csf--image{
                    width: calc(33.33333% - 6px);
                    height: calc(33.33333% - 6px);
                }</style>',
                'default' => '9',
                'options' => array(
                    '1' => get_imk_img_url('jgg-1.jpg'),
                    '2' => get_imk_img_url('jgg-2.jpg'),
                    '3' => get_imk_img_url('jgg-3.jpg'),
                    '4' => get_imk_img_url('jgg-4.jpg'),
                    '5' => get_imk_img_url('jgg-5.jpg'),
                    '6' => get_imk_img_url('jgg-6.jpg'),
                    '7' => get_imk_img_url('jgg-7.jpg'),
                    '8' => get_imk_img_url('jgg-8.jpg'),
                    '9' => get_imk_img_url('jgg-9.jpg'),
                ),
                'class' => 'jgg-site'
            ),array(
                'content' => '<style>.preview_img{width: 75%;}@media (min-width: 768px) { .preview_img{width: 55%}}</style><div><b>水印效果预览：</b>
                <br/>水印配置完成保存后在此预览</div>
                <img class="preview_img" src="'.get_imk_img_url('preview.jpg').'"/>
                <ajaxform class="ajax-form">
                <div class="flex ac hh"><input class="mt6 mr10" type="text" style="max-width:300px;" ajax-name="img_url" value="'.get_imk_img_url('preview.jpg').'" placeholder="请输入图片地址"><a href="javascript:;" class="but jb-yellow ajax-submit mt6"><i class="fa fa-paper-plane-o"></i> 点击预览</a></div>
                <div class="ajax-notice mt10"></div>
                <input type="hidden" ajax-name="action" value="imk_test_send">
                </ajaxform>',
                'style'   => 'warning',
                'type'    => 'submessage',
            ),
        ),
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'feature',
        'title' => '角标&标志',
        'icon' => 'fa fa-fw fa-bullhorn',
        'description' => '',
        'fields' => array(
            array(
                'title' => '仿Mac角标',
                'label' => '启用后，文章列表左上角仿Mac角标美化',
                'id' => 'horn_mac_switch',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'title' => '置顶角标',
                'label' => '启用后，文章列表置顶角标美化（不可与自定义角标混用）',
                'id' => 'horn_zd_switch',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'title' => '标题前缀',
                'label' => '启用后，发布文章时下方可为标题添加美观的自定义前缀',
                'id' => 'horn_qz_switch',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('horn_zd_switch', '!=', ''),
                'title' => '背景颜色',
                'id' => 'horn_zd_ct',
                'default' => '0',
                'inline' => true,
                'class' => 'compact',
                'type' => 'radio',
                'options' => array(
                    '0' => __('【跟随系统】', 'zib_language'),
                    '1' => __('【选择颜色】', 'zib_language'),
                ),
            ),
            array(
                'dependency' => array(
                    array('horn_zd_switch', '!=', ''),
                    array('horn_zd_ct', '==', '1'),
                ),
                'title'      => ' ',
                'subtitle'   => ' ',
                'id'         => "horn_zd_c",
                'class'      => 'compact skin-color',
                'default'    => "b-red",
                'type'       => "palette",
                'options'  => CSF_Module_Wml_Zib::zib_palette(),
            ),
            array(
                'title' => '自定义角标',
                'label' => '启用后，可自定义文章列表角标（不可与置顶角标混用）',
                'id' => 'horn_diy_switch',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('horn_diy_switch', '!=', ''),
                'title' => ' ',
                'id' => 'horn_diy',
                'default' => '1',
                'inline' => true,
                'desc' => '默认全局显示，如果选择指定文章显示，可在文章发布页下方进行编辑',
                'class' => 'compact',
                'type' => 'radio',
                'options' => array(
                    '1' => __('【全局显示】', 'zib_language'),
                    '2' => __('【指定文章】', 'zib_language'),
                ),
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '1'),
                ),
                'title'   => __('左上角标内容'),
                'id'      => 'horn_diy_l_t',
                'type'    => 'text',
                'desc'    => '默认留空，留空则显示文章的更新时间，格式：<font color="red">2025.08.08</font> ',
                'default' => '',
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '1'),
                ),
                'title'   => __('背景颜色'),
                'subtitle'   => ' ',
                'id'         => "horn_diy_l_c",
                'default' => 'b-red',
                'class'   => 'compact skin-color',
                'type'    => "palette",
                'options'  => CSF_Module_Wml_Zib::zib_palette(),
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '1'),
                ),
                'title'   => '启用生效',
                'id'      => 'horn_diy_l_w',
                'type'    => "checkbox",
                'inline'  => true,
                'class'   => 'compact',
                'options' => array(
                    'on'   => ' ',
                ),
                'default'    => array('on'),
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '1'),
                ),
                'title'   => __('右上角标内容'),
                'id'      => 'horn_diy_r_t',
                'type'    => 'text',
                'desc'    => '默认则只有指定最新发布的时间内显示',
                'default' => '精品推荐',
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '1'),
                ),
                'title' => '显示类型',
                'id' => 'horn_diy_r_type',
                'default' => '1',
                'inline' => true,
                'class' => 'compact',
                'type' => 'radio',
                'options' => array(
                    '1' => __('【最新发布】', 'zib_language'),
                    '2' => __('【显示所有】', 'zib_language'),
                ),
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '1'),
                    array('horn_diy_r_type', '==', '1'),
                ),
                'title'       => ' ',
                'subtitle'    => __('发布时间', 'zib_language'),
                'id'          => 'horn_diy_r_time',
                'class'       => 'compact',
                'type'        => 'select',
                'placeholder' => '选择显示的时间',
                'options'     => array(
                    '86400'      => '24小时',
                    '259200'      => '三天内',
                    '604800'     => '一周内',
                    '2592000'     => '一月内',
                ),
                'default'     => '604800',
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '1'),
                ),
                'title'   => __('背景颜色'),
                'subtitle'   => ' ',
                'id'         => "horn_diy_r_c",
                'default' => 'b-blue',
                'class'   => 'compact skin-color',
                'type'    => "palette",
                'options'  => CSF_Module_Wml_Zib::zib_palette(),
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '1'),
                ),
                'title'   => '启用生效',
                'id'      => 'horn_diy_r_w',
                'type'    => "checkbox",
                'inline'  => true,
                'class'   => 'compact',
                'options' => array(
                    'on'   => ' ',
                ),
                'default'    => array('on'),
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '1'),
                ),
                'title'   => __('封面底部内容'),
                'id'      => 'horn_diy_b_t',
                'type'    => 'text',
                'desc'    => '默认留空即可，留空则显示文章的副标题',
                'default' => '',
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '1'),
                ),
                'title'   => __('背景颜色'),
                'subtitle'   => ' ',
                'id'         => "horn_diy_b_c",
                'default' => 'b-blue',
                'class'   => 'compact skin-color',
                'type'    => "palette",
                'options'  => CSF_Module_Wml_Zib::zib_palette(),
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '1'),
                ),
                'title'   => '启用生效',
                'id'      => 'horn_diy_b_w',
                'type'    => "checkbox",
                'inline'  => true,
                'class'   => 'compact',
                'options' => array(
                    'on'   => ' ',
                ),
                'default'    => array('on'),
            ),
            //指定文章预置
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '2'),
                ),
                'title'   => __('文章角标预设'),
                'type'    => 'content',
                'content' => '以下可设置文章角标的默认预设，同时每篇文章或页面均可单独设置',
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '2'),
                ),
                'title'   => __('左上角标内容'),
                'id'      => 'horn_diy_l_t2',
                'type'    => 'text',
                'default' => '原创',
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '2'),
                ),
                'title'   => __('背景颜色'),
                'id'      => 'horn_diy_l_c2',
                'default' => 'b-red',
                'class'   => 'compact skin-color',
                'type'    => "palette",
                'options'  => CSF_Module_Wml_Zib::zib_palette(),
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '2'),
                ),
                'title'   => __('右上角标内容'),
                'id'      => 'horn_diy_r_t2',
                'type'    => 'text',
                'default' => '精品推荐',
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '2'),
                ),
                'title'   => __('背景颜色'),
                'id'      => 'horn_diy_r_c2',
                'class'   => 'compact skin-color',
                'default' => 'b-blue',
                'type'    => "palette",
                'options'  => CSF_Module_Wml_Zib::zib_palette(),
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '2'),
                ),
                'title'   => __('封面底部内容'),
                'id'      => 'horn_diy_b_t2',
                'type'    => 'text',
                'default' => '支持Win、Mac、Ios、Android',
            ),
            array(
                'dependency' => array(
                    array('horn_diy_switch', '!=', ''),
                    array('horn_diy', '==', '2'),
                ),
                'title'   => __('背景颜色'),
                'id'      => 'horn_diy_b_c2',
                'class'   => 'compact skin-color',
                'default' => 'b-blue',
                'type'    => "palette",
                'options'  => CSF_Module_Wml_Zib::zib_palette(),
            ),
            array(
                'title'   => '前端显示方法',
                'type'    => "content",
                'content' => '<p>1、打开子比主题根目录下的文件：<font style="color:#fd4c73;"><code>wp-content/themes/zibll/inc/functions/zib-posts-list.php</code></font></p>
                <p>2、查找：<font style="color:#fd4c73;"><code>置顶</code></font>，约511行</p>
                <p>3、在置顶if闭合下面，也就是第一个 <font style="color:#fd4c73;"><code>$html</code></font> 上面插入以下代码</p>
                <p>4、<code><font style="color:#fd4c73;">$sticky = apply_filters( \'zib_post_img_horn_after\', $post);</font></code></p>
                <hr><div style="color:#ff2153;"><i class="fa fa-fw fa-info-circle fa-fw"></i>提示：如需要关闭自定义角标功能，务必把以上添加的钩子删除。</div>',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'feature',
        'title' => '夸夸&随机',
        'icon' => 'fa fa-sign-language',
        'description' => '',
        'fields' => array(
            array(
                'title' => '评论夸夸',
                'label' => '启用后，评论区可使用一键夸夸代替评论',
                'id' => 'comments_kuakua_is',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'title' => '随机一言',
                'label' => '启用后，评论区可使用随机一言代替评论',
                'id' => 'comments_suiji_is',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'title'   => '夸夸&随机自定义',
                'type'    => "content",
                'content' => '<p>1、打开插件目录下：<font style="color:#fd4c73;"><code>wml-zib-diy/api/yiyan/</code></font>的文件进行修改</p>',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'feature',
        'title' => '邮件&提醒',
        'icon' => 'fa fa-envelope',
        'description' => '',
        'fields' => array(
            array(
                'title' => '文章发布通知用户',
                'label' => '文章发布时通知全站用户',
                'id' => 'post_emal_send',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'title' => '文章更新通知用户',
                'label' => '文章更新通知评论过的用户',
                'id' => 'post_emal_update',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'title' => '用户登陆提醒',
                'label' => '用户登陆网站时发送一封登陆提醒邮件',
                'id' => 'user_profile_update_email',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'title' => '用户资料变更提醒',
                'label' => '用户修改个人资料时发送一封提醒邮件',
                'id' => 'Wml_zib_user_update',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'title' => '推广用户注册提醒',
                'label' => '当有人走邀请码注册时邮件提醒邀请人',
                'id' => 'Wml_zib_user_reg',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'title' => '会员到期通知',
                'label' => '在会员到期前通知用户续费',
                'id' => 'Wml_vip',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('Wml_vip', '!=', ''),
                'id' => 'vip_notification_days',
                'title' => '会员到期提醒',
                'subtitle' => '选择提前多少天发送提醒',
                'desc' => '选择一个或多个天数',
                'type' => 'select',
                'chosen' => true,
                'multiple' => true,
                'default' => array('1', '3', '7'),
                'options' => array(
                    '1' => '1天',
                    '3' => '3天',
                    '5' => '5天',
                    '7' => '7天',
                    '9' => '9天',
                    '15' => '15天',
                ),
            ),
            array(
                'title' => '后台登陆提醒',
                'label' => '防止后台密码被爆破登陆后台篡改信息',
                'id' => 'Wml_admin',
                'default' => false,
                'type' => 'switcher',
            ),
        )
    )
);


CSF::createSection(
    $prefix,
    array(
        'parent' => 'feature',
        'title' => '下载&页面',
        'icon' => 'fa fa-fw fa-download',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'down',
                'type' => 'switcher',
                'title' => '是否启用',
                'label' => '开启后即可使用本功能',
                'default' => false,
            ),
            array(
                'title' => '下载区块样式选择',
                'id' => 'down_layout',
                'default' => "ceo",
                //'type' => "image_select",
                'type' => "select",
                'options' => array(
                    //'ceo' => $img . '/admin/down_layout.png',
                    'ceo' => '默认样式',
                ),
            ),
            array(
                'id' => 'down_img',
                'type' => 'switcher',
                'title' => '左侧轮播图片',
                'label' => '关闭后左侧将不显示轮播图片（开启下载区域美化后有效）',
                'default' => true,
            ),
            array(
                'title' => '模块显示位置',
                'id' => 'pay_box_position',
                'default' => 'head',
                'type' => "radio",
                'desc' => "设置付费区块显示的位置，推荐显示在<code>文章顶部全区块</code>",
                'options' => array(
                    'head' => '文章顶部全宽度',
                    'box_top' => '文章模块上方',
                    'top' => '文章内容顶部',
                    'bottom' => '文章内容底部',
                    'box_bottom' => '文章模块下方',
                ),
            ),
            array(
                'title' => '顶部全宽度附加配置',
                'id' => 'pay_box_container',
                'default' => true,
                'type' => 'switcher',
                'desc' => '顶部全区块跟随页面宽度',
                'dependency' => array(
                    'pay_box_position',
                    '==',
                    'head'
                ),
            ),
        ),
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'feature',
        'title' => '公告&滚动',
        'icon' => 'fa fa-fw fa-bell',
        'description' => '',
        'fields' => array(
            array(
                'title' => '公告模块',
                'label' => '打开公告功能，WP后台左侧菜单栏增加公告模块',
                'id' => 'bulletin_switch',
                'default' => false,
                'type' => 'switcher'
            ),
            array(
                'dependency' => array('bulletin_switch', '!=', ''),
                'id' => 'bulletin_c',
                'title' => '显示内容',
                'type' => 'radio',
                'inline'  => true,
                'options' => array(
                    '1' => '最新公告',
                    '2' => '最新文章'
                ),
                'default' => 1
            ),
            array(
                'dependency' => array('bulletin_switch', '!=', ''),
                'title'   => '显示数量',
                'id'      => 'bulletin_num',
                'type'    => 'text',
                'desc'    => '前端显示的文章数量，默认5条',
                'class' => 'mini-input compact',
                'default' => '5',
            ),
            array(
                'dependency' => array('bulletin_switch', '!=', ''),
                'id' => 'bulletin_type',
                'title' => '显示方法',
                'type' => 'radio',
                'inline'  => true,
                'options' => array(
                    '1' => '小工具组件',
                    '2' => '自定义代码'
                ),
                'default' => 1
            ),
            array(
                'dependency' => array('bulletin_switch', '!=', ''),
                'title'   => '前端显示方法',
                'type'    => "content",
                'content' => '<p>方法一-小工具组件：</p>
                <p>1、在以上开启小工具组件</p>
                <p>2、后台-外观-小工具，在自己想要的位置添加</p>
                <p>建议首页主内容上面添加</p>
                <hr><p>方法二-自定义代码：</p><p>以首页为例：1、打开子比主题根目录下的文件：<font style="color:#fd4c73;"><code>wp-content/themes/zibll/index.php</code></font></p>
                <p>2、查找：<font style="color:#fd4c73;"><code>"main"</code></font></p>
                <p>3、在下面位置插入钩子：<font style="color:#fd4c73;"><code>do_action(\'wp_head_home_wml\');</code></font></p>
                <hr><div style="color:#ff2153;"><i class="fa fa-fw fa-info-circle fa-fw"></i>提示：两种方法只能选择一种。</div>',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'feature',
        'title' => '媒体&回收',
        'icon' => 'fa fa-fw fa-trash',
        'description' => '',
        'fields' => array(
            array(
                'title' => '媒体回收站',
                'label' => '打开回收站后，在删除之前将文件移到回收站',
                'id' => 'trash_switch',
                'default' => false,
                'type' => 'switcher'
            ),
            array(
                'dependency' => array('trash_switch', '!=', ''),
                'title'   => '开启方法',
                'type'    => "content",
                'content' => '<p>要在媒体中启用回收站功能，请添加一行定义<font style="color:#fd4c73;"><code>define( \'MEDIA_TRASH\', \'true\' );</code></font>到主目录<font style="color:#fd4c73;"><code>wp-config.php</code></font>文件中，在“<code><font style="color:#fd4c73;">就这，停止编辑</code></font>”这一行之前。</p>
                <hr>开启定期清理：<font style="color:#fd4c73;"><code>define(\'EMPTY_TRASH_DAYS\', 7);</code></font>其中7天自动清理，请按需开启，默认可在媒体-回收站管理回收的文件。',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'feature',
        'title' => '外链&跳转',
        'icon' => 'fa fa-link',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'link_go',
                'type' => 'switcher',
                'label' => '启用后，可在以下选择外链GO的跳转风格',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('link_go', '!=', ''),
                'title' => ' ',
                'id' => 'link_go_select',
                'default' => '1',
                'inline' => true,
                'type' => 'radio',
                'options' => array(
                    '1' => __('【样式一】', 'zib_language'),
                    '2' => __('【样式二】', 'zib_language'),
                    '3' => __('【样式三】', 'zib_language'),
                    '4' => __('【自定义】', 'zib_language'),
                ),
            ),
            array(
                'dependency' => array(
                    array('link_go', '!=', ''),
                    array('link_go_select', '==', '4'),
                ),
                'title'    => '自定义代码',
                'subtitle' => '直接填写html代码，需要注意代码闭合',
                'id'       => 'link_go_diy',
                'settings' => array(
                    'theme' => 'dracula',
                ),
                'sanitize' => false,
                'type'     => 'code_editor',
            ),
            array(
                'dependency' => array('link_go', '!=', ''),
                'title'   => '替换生效',
                'subtitle' => '先保存设置，再进行替换',
                'type'    => "content",
                'content' => '<ajaxform class="ajax-form" ajax-url="' . admin_url("admin-ajax.php") . '"><div class="ajax-notice"></div>
                <div><a href="javascript:;" data-confirm="点击确认后开始替换文件" class="but jb-yellow ajax-submit"><i class="fa fa-floppy-o"></i> 立即替换</a></div>
                 <input type="hidden" ajax-name="action" value="wml_zib_go"></ajaxform>',
            ),
            array(
                'title'   => '恢复默认',
                'subtitle' => '恢复子比主题默认的风格',
                'type'    => "content",
                'content' => '<ajaxform class="ajax-form" ajax-url="' . admin_url("admin-ajax.php") . '"><div class="ajax-notice"></div>
                <div><a href="javascript:;" data-confirm="点击确认后开始恢复默认" class="but jb-blue ajax-submit"><i class="fa fa-repeat"></i> 立即恢复</a></div>
                 <input type="hidden" ajax-name="action" value="wml_zib_gos"></ajaxform>',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'feature',
        'title' => '维护&暂停',
        'icon' => 'fa fa-fw fa-pause',
        'description' => '',
        'fields' => array(
            array(
                'content' => '
                <div style="color:#ff2153;">维护模式仅用于网站调试阶段使用，开启后只有登陆状态下的管理员账号权限才可以看到网站的正常内容，其他访客将显示维护倒计时。<i class="fa fa-fw fa-info-circle fa-fw"></i>
注意：如果不幸被锁在倒计时界面，只需访问: https://'.$_SERVER['HTTP_HOST'].'/wp-login.php，登录管理员账户即可。</div>',
                'style' => 'warning',
                'type' => 'submessage',
            ),
            array(
                'id'      => 'is_maintenance',
                'type'    => 'switcher',
                'title'   => '开启维护',
                'label'   => '网站正式上线后一定要记得关闭维护模式',
                'default' => false,
            ),
            array(
                'id'      => 'maintenance_logo',
                'type'    => 'upload',
                'title'   => 'LOGO',
                'desc'       => '自行设置',
                'default' => get_stylesheet_directory_uri().'/img/logo.png',
                'dependency' => array('is_maintenance', '==', 'true'),
            ),
            array(
                'id'         => 'maintenance_title',
                'type'       => 'text',
                'title'      => '标题',
                'desc'       => '维护标题',
                'default'    => '网站维护',
                'dependency' => array('is_maintenance', '==', 'true'),
            ),
            array(
                'id'         => 'maintenance_desc',
                'type'       => 'textarea',
                'title'      => '描述内容',
                'desc'       => '可使用html格式',
                'attributes' => array(
                    'style' => 'width: 100%;',
                ),
                'default'    => '<p><br>抱歉，我们的网站正在维护中...<br><span class="dull-text">敬请关注网站开放时间！</span><br></p>',
                'dependency' => array('is_maintenance', '==', 'true'),
            ),
            array(
                'id'         => 'maintenance_time',
                'type'       => 'text',
                'title'      => '开放时间',
                'desc'       => '预计网站开放时间，格式：2025/08/08 01:01',
                'default'    => date('Y/m/d H:i', strtotime('+3 day')),
                'dependency' => array('is_maintenance', '==', 'true'),
            ),
            array(
                'id'         => 'maintenance_redirectUrl',
                'type'       => 'text',
                'title'      => '显示备用站点地址',
                'desc'       => '如果你有站点维护中时存在的其他备用站点，请填写链接地址。如https://waimao.la',
                'default'    => 'https://waimao.la',
                'dependency' => array('is_maintenance', '==', 'true'),
            ),
            array(
                'id'         => 'maintenance_redirectUrlName',
                'type'       => 'text',
                'title'      => '显示备用站点名称',
                'desc'       => '备用站点名称',
                'default'    => '外贸啦',
                'dependency' => array('is_maintenance', '==', 'true'),
            ),
            array(
                'id'         => 'maintenance_copyright',
                'type'       => 'text',
                'title'      => '显示网站版权信息',
                'desc'       => '',
                'default'    => 'Copyright © 2024-2025. WaiMaoLa. All Rights Reserved.',
                'dependency' => array('is_maintenance', '==', 'true'),
            ),
            array(
                'id'         => 'maintenance_beian',
                'type'       => 'text',
                'title'      => '显示网站备案号',
                'desc'       => '填写网站备案号',
                'default'    => '皖ICP备88888888号',
                'dependency' => array('is_maintenance', '==', 'true'),
            ),
        ),
    )
);