<?php
class Wml_PageTemplater
{
  // 此类的实例引用.
  private static $instance;

  // 该插件跟踪的模板数组.
  protected $templates;

  // 返回此类的实例.
  public static function wml_get_instance()
  {
    if (null == self::$instance) {
      self::$instance = new Wml_PageTemplater();
    }
    return self::$instance;
  }

  // 通过设置过滤器和管理功能初始化插件.
  private function __construct()
  {
    $this->templates = array();

    // 向属性元盒添加过滤器，以将模板注入缓存.
    if (version_compare(floatval(get_bloginfo('version')), '4.7', '<')) {
      // 4.6及以下版本
      add_filter(
        'page_attributes_dropdown_pages_args',
        array($this, 'wml_register_project_templates')
      );
    } else {
      // 向wp 4.7及以上版本属性元盒添加过滤器
      add_filter(
        'theme_page_templates',
        array($this, 'wml_add_new_template')
      );
    }

    // 在保存帖子时添加过滤器，将模板注入页面缓存
    add_filter(
      'wp_insert_post_data',
      array($this, 'wml_register_project_templates')
    );

    // 在模板include中添加一个过滤器，以确定页面是否具有分配模板并返回其路径
    add_filter(
      'template_include',
      array($this, 'wml_view_project_template')
    );

    // 根据条件将模板添加到此数组
    if (wml_zib('zanzu-page')) {
      $this->templates['wml-sponsor.php'] = 'WML-站长赞助';
    }
    if (wml_zib('ziyuan-page')) {
      $this->templates['wml-download.php'] = 'WML-资源下载';
    }
    if (wml_zib('vip_info')) {
      $this->templates['wml-vip.php'] = 'WML-VIP说明';
    }
    if (wml_zib('page_tags')) {
      $this->templates['wml-tags.php'] = 'WML-热门标签';
    }
    if (wml_zib('page_shuoshuo')) {
      $this->templates['wml-shuoshuo.php'] = 'WML-说说';
    }
    if (wml_zib('page_weiyu')) {
      $this->templates['wml-weiyu.php'] = 'WML-微语';
    }
    if (wml_zib('page_video')) {
      $this->templates['wml-video.php'] = 'WML-视频解析';
    }
    if (wml_zib('page_map')) {
      $this->templates['wml-map.php'] = 'WML-站点地图';
    }
    if (wml_zib('page_colour')) {
      $this->templates['wml-colour.php'] = 'WML-颜色取色';
    }
    if (wml_zib('page_heiwu')) {
      $this->templates['wml-heiwu.php'] = 'WML-封禁黑屋';
    }
    if (wml_zib('page_qixia')) {
      $this->templates['wml-qixia.php'] = 'WML-旗下站点';
    }
    if (wml_zib('page_links')) {
      $this->templates['wml-links.php'] = 'WML-友链检测';
    }
    if (wml_zib('page_thumbnail')) {
      $this->templates['wml-thumbnail.php'] = 'WML-封面制作';
    }
  }

  // 将我们的模板添加到 v4.7+ 的下拉页面模板中
  public function wml_add_new_template($posts_templates)
  {
    $posts_templates = array_merge($posts_templates, $this->templates);
    return $posts_templates;
  }

  // 将我们的模板添加到页面缓存以欺骗WordPress认为模板文件存在于它实际上不存在的地方
  public function wml_register_project_templates($atts)
  {
    // 创建用于主题缓存的键
    $cache_key = 'page_templates-' . md5(get_theme_root() . '/' . get_stylesheet());

    // 检索缓存列表. 如果不存在或为空，请准备一个数组
    $templates = wp_get_theme()->get_page_templates();
    if (empty($templates)) {
      $templates = array();
    }

    // 新缓存，因此删除旧缓存
    wp_cache_delete($cache_key, 'themes');

    // 现在通过合并我们的模板，将我们的模板添加到模板列表中
    $templates = array_merge($templates, $this->templates);

    // 添加修改后的缓存以允许WordPress将其提取以供登录可用模板
    wp_cache_add($cache_key, $templates, 'themes', 1800);
    return $atts;
  }

  // 检查模板是否已分配给页面
  public function wml_view_project_template($template)
  {
    // 获取全局帖子
    global $post;

    // 如果帖子为空，则返回模板
    if (!$post) {
      return $template;
    }

    // 如果没有定义自定义模板，则返回默认模板
    if (!isset($this->templates[get_post_meta($post->ID, '_wp_page_template', true)])) {
      return $template;
    }

    $file = plugin_dir_path(__FILE__) . get_post_meta($post->ID, '_wp_page_template', true);

    // 为了安全起见，我们先检查文件是否存在
    if (file_exists($file)) {
      return $file;
    } else {
      echo $file;
    }
    // 返回模板
    return $template;
  }
}

// 在插件加载时初始化 Wml_PageTemplater 类的实例
add_action('plugins_loaded', array('Wml_PageTemplater', 'wml_get_instance'));

require_once 'fun.php';//引入模块核心
?>