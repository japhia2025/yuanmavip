<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 16:00:09
 * @FilePath: \wml-zib-diy\core\functions\feature\wml-pages.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-06-27 16:19:08
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */
