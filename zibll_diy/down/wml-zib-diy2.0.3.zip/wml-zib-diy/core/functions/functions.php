<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-20 22:17:22
 $ @ 文件路径: \wml-zib-diy\core\functions\functions.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

// 载入核心文件
$include_once = array(
  "feature/wml-down",
  "feature/wml-message",
  "feature/wml-language",
  "feature/wml-maintenance",
  "feature/wml-horn",
  "feature/wml-bulletin",
  "feature/wml-trash",
  "feature/wml-comments",
  "feature/wml-cardsales",
  "feature/wml-dproduct",
  "feature/wml-crisp",
  "beautify/wml-footer",
  "beautify/wml-all",
  "beautify/wml-index",
  "beautify/wml-bottom",
  "beautify/wml-top",
  "beautify/wml-right",
  "beautify/wml-left",
  "beautify/wml-post",
  "beautify/wml-comments",
  "beautify/wml-mouse",
  "beautify/wml-font",
  "beautify/wml-avatar",
  "beautify/wml-logo",
  "beautify/wml-prompt",
  "beautify/wml-rbutton",
  "seo/wml-crib",
  'seo/wml-psot',
  'seo/wml-limit',
  'seo/wml-slug',
  //'seo/wml-sitemap',
  'diy/wml-diy',
);
foreach ($include_once as $inc) {
  include $inc . '.php';
}
require_once 'page/class.php';//引入页面模块
