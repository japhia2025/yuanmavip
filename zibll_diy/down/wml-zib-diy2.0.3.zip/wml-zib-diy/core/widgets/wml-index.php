<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-21 01:42:45
 $ @ 文件路径: \wml-zib-diy\core\widgets\wml-index.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/
 // 载入小工具文件
$include_once = array(
    'homeph',
    'usergd',
    'wzad',
    'gdad',
    'imgad',
    'textad',
    'adstool',
    'countdown',
    'music',
    'sharedh',
    'newhy',
    'hyxx',
    'hyweather',
    'count',
    'tplm',
    'heiwu',
    'ipqm',
);
foreach ($include_once as $inc) {
    include 'wml-' . $inc . '.php';
}