<?php
$files = glob(IMK_COM_DIR .'assets/img/viu-download*');
        foreach ($files as $file) {
            //@unlink($file);
        }
function imk_enqueue_styles_scripts() {
    // 获取当前页面的hook_suffix
    $current_screen = get_current_screen();
    $hook_suffix = $current_screen->id;
    $min = '.min';
    // 检查当前主题 保留用来兼容所有主题
    $current_theme = wp_get_theme();
    $is_zibll_theme = ($current_theme->name == '子比主题' || $current_theme->parent_theme == '子比主题');
    // 判断是否为插件的设置页面且主题为zibll
    //if ('toplevel_page_'.IMK_OPTS === $hook_suffix) {
        // 加载JS
        //wp_enqueue_script( 'csf-script', IMK_COM_URL . 'assets/js/ajax.js', array('jquery'), '1.0.0', true );//文件丢失
    //}
}
add_action( 'admin_enqueue_scripts', 'imk_enqueue_styles_scripts' );
// 图片路径
function get_imk_img_url($file_name = ''){
	// 拼接目录
	$path = IMK_COM_URL . 'assets/img/';
	if($file_name != '')
	{
		return $path . $file_name;
	}
	return $path;
}
// 字体路径
function get_imk_fonts_dir($file_name = ''){
	// 拼接目录
	$path = IMK_COM_DIR . 'assets/fonts/';
	if($file_name != '')
	{
		return $path . $file_name;
	}
	return $path;
}
// 文本字体
function imk_fonts(){
    return apply_filters('add_imk_fonts','default');
}
function add_imk_fonts_args($default) {
	// 初始化数据
	// 拼接目录
	$path = get_imk_fonts_dir();
	// 获取目录下所有文件
	$files = scandir($path);
	// 遍历文件，查找TTF文件
	    foreach ($files as $file) {
	        if (strpos($file, '.ttf') !== false) {
				$font_name = pathinfo($file, PATHINFO_FILENAME);
				$args[$file] = $file;
				//$args[$file] = iconv('gbk' , 'utf-8' , $file ) ;//中文文件名转换
	        }
	    }
        
    return $args;
}
add_filter('add_imk_fonts', 'add_imk_fonts_args');
function imk_get_img_info($img_url)
{
    $parsedUrl = parse_url($img_url);
    $name = basename($parsedUrl['path']);
    $path = IMK_COM_DIR . 'assets/img/' . $name;
    return array(
        'name' => $name,
        'url' => $img_url,
        'path' => $path
    );
}
function imk_test_sends()
{
    if (empty($_POST['img_url'])) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请输入图片地址')));
        exit();
    }

    // echo json_encode(ZibSMS::send($_POST['phone_number'], '888888'));
	// echo '<img src="'.$_POST['img_url'].'"/>';
	echo (json_encode(array('success' => 1, 'ys' => 'danger', 'msg' => '<img class="preview_img" src="'.$_POST['img_url'].'"/>')));
    exit();
}
add_action('wp_ajax_imk_test_sends', 'imk_test_sends');
// 检测是否包含特定后缀
function imk_check_image_name_for_specific_chars($file_path, $specific_chars) {
    // 检查第二个参数是否为空或只包含空格
    if (empty($specific_chars) || trim($specific_chars) === '') {
        return false; // 如果为空或只包含空格，则返回false
    }

    // 从文件路径中提取文件名
    $filename = basename($file_path);

    // 将传入的特定字符字符串分割成数组
    $chars_array = explode(',', $specific_chars);

    // 遍历每个字符，检查文件名中是否包含
    foreach ($chars_array as $char) {
        $char = trim($char); // 移除空格
        if (!empty($char) && strpos($filename, $char) !== false) {
            return true; // 如果找到，则返回true
        }
    }

    // 如果没有找到任何特定字符，则返回false
    return false;
}

/**
 * 检测PHP扩展是否已经安装
 * @param string $extension 扩展名称
 * @return bool 扩展是否已安装
 */
function isExtensionLoaded($extension) {
    return extension_loaded($extension);
}
/**
 * 生成一个随机字符串
 * @param int $length 字符串长度
 * @return string
 */
function generateRandomString($length = 6) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = 'viu-download-';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

/**
 * 从URL中获取图片的扩展名
 * @param string $url 图片URL
 * @return string
 */
function getExtensionFromUrl($url) {
    $path = parse_url($url, PHP_URL_PATH);
    $parts = explode('.', $path);
    $extension = end($parts);
    $validExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];
    return in_array($extension, $validExtensions) ? '.' . $extension : '';
}

/**
 * 检测图片类型
 * @param string $filePath 图片文件路径
 * @return string
 */
function detectImageType($filePath) {
    if (!isExtensionLoaded('fileinfo')) {
        return 600; // 返回错误码
    } else {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if (!$finfo) {
            return 601; // 返回错误码
        }
    }
    $type = finfo_file($finfo, $filePath);
    finfo_close($finfo);
    $mimeTypes = [
        'image/jpeg' => '.jpg',
        'image/png' => '.png',
        'image/gif' => '.gif',
        'image/bmp' => '.bmp',
        'image/webp' => '.webp',
    ];
    return isset($mimeTypes[$type]) ? $mimeTypes[$type] : '';
}

/**
 * 使用cURL下载远程文件到本地，并确保文件名唯一
 * @param string $url 文件的远程URL
 * @param string $localDir 本地存储目录
 * @return mixed 成功返回文件的本地路径，失败返回错误码
 */
function downloadFileWithCurlUnique($url, $localDir) {
    $extension = getExtensionFromUrl($url);
    if ($extension === '') {
        $tempPath = tempnam(sys_get_temp_dir(), 'tmp');
        if (!downloadFileWithCurl($url, $tempPath)) {
            return 603; // cURL下载失败
        }
        $extension = detectImageType($tempPath);
        if ($extension === '') {
            unlink($tempPath);
            return 602; // 无法确定图片扩展名
        } else if ($extension === 600) {
            return 600;
        } else if ($extension === 601) {
            return 601;
        }
        $newFileName = generateRandomString() . $extension;
        $localPath = $localDir . '/' . $newFileName;
        rename($tempPath, $localPath);
    } else {
        $newFileName = generateRandomString() . $extension;
        $localPath = $localDir . '/' . $newFileName;
        // 检查文件名是否重复
        while (file_exists($localPath)) {
            $newFileName = generateRandomString() . $extension;
            $localPath = $localDir . '/' . $newFileName;
        }
        if (!downloadFileWithCurl($url, $localPath)) {
            return 603; // cURL下载失败
        }
    }

    return array($localPath); // 成功返回本地文件路径
}

/**
 * 使用cURL下载远程文件到本地指定路径
 *
 * @param string $url 文件的远程URL
 * @param string $localPath 本地存储路径
 * @return bool 成功返回true，失败返回false
 */
function downloadFileWithCurl($url, $localPath) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
    curl_setopt($ch, CURLOPT_FAILONERROR, true);
    curl_setopt($ch, CURLOPT_FILE, fopen($localPath, 'w'));
    $result = curl_exec($ch);
    curl_close($ch);
    return $result !== 605;
}
function ensureCorrectEncoding($path) {
    // 确保路径中的中文字符编码正确，仅在 Windows 环境下进行转换
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        // 假设输入路径为 UTF-8 编码，转换为 Windows 默认的 CP1252 编码
        $path = iconv('GBK', 'UTF-8', $path);
    }
    return $path;
}
