<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 16:56:13
 $ @ 最后修改: 2024-11-14 16:04:13
 $ @ 文件路径: \wml-zib-diy\uninstall.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if(!defined('ABSPATH') && !define('WP_UNINSTALL_PLUGIN')){
	exit();
}

//删除配置
delete_option('wml_zib_diy');
delete_option('widget_wml_adstool');
delete_option('widget_wml_countdown');
delete_option('widget_wml_textad');
delete_option('widget_wml_wzad');