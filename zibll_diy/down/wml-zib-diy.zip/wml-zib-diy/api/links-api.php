<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-28 01:27:47
 $ @ 最后修改: 2024-11-14 08:30:35
 $ @ 文件路径: \wml-zib-diy\api\links-api.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

header('Content-Type: application/json; charset=utf-8');
//毕方资源网：www.bfbke.com
// 检查是否传入了 myurl 和 targeturl 参数
if (!isset($_GET['myurl']) || !isset($_GET['targeturl'])) {
    echo json_encode(['code' => 400, 'data' => ['message' => '缺少参数: myurl 或 targeturl']], JSON_UNESCAPED_UNICODE);
    exit;
}

$myurl = $_GET['myurl'];
$targeturl = $_GET['targeturl'];

// 检查参数是否为空
if (empty($myurl) || empty($targeturl)) {
    echo json_encode(['code' => 400, 'data' => ['message' => '参数 myurl 或 targeturl 不能为空']], JSON_UNESCAPED_UNICODE);
    exit;
}

// 模拟友情链接存在的逻辑。你可以根据实际需求替换这个部分。
function check_link($myurl, $targeturl) {
    // 示例逻辑：简单检查目标URL页面内容中是否包含来源URL
    $html = @file_get_contents($targeturl);
    if ($html === FALSE) {
        return false;
    }
    return strpos($html, $myurl) !== false;
}

if (check_link($myurl, $targeturl)) {
    echo json_encode([
        'code' => 200,
        'data' => [
            'message' => '友情链接存在!',
            'myurl' => $myurl,
            'targeturl' => $targeturl,
            'title' => '检测成功'
        ]
    ], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode([
        'code' => 404,
        'data' => [
            'message' => '友情链接不存在!',
            'myurl' => $myurl,
            'targeturl' => $targeturl,
            'title' => '检测失败'
        ]
    ], JSON_UNESCAPED_UNICODE);
}
?>