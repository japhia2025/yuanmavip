/*
 * @Author: Qinver
 * @Url: zibll.com
 * @Date: 2020-11-27 22:18:32
 * @LastEditTime: 2021-12-27 16:25:38
 */
$(window).load(function () {
    function get_zib_api(data, c, _this, type) {
        notyf("正在处理请稍等...", "load", "", "user_ajax"), _tt = _this.html();
        _this.attr('disabled', true).html('<i class="loading em12"></i><span class="ml10">请稍候</span>'),
            c = c || "处理完成";
        // console.log(data);
        $.ajax({
            type: "POST",
            url: _win.ajax_url,
            data: data,
            dataType: "json",
            success: function (n) {
                // console.log(n);
                ys = (n.ys ? n.ys : (n.error ? 'danger' : ""));
                notyf(n.msg || c, ys, '', 'user_ajax');
                _txet_1 = '恭喜您，授权添加成功';
                _txet_2 = '请刷新页面查看详细信息';
                _button = '';

                if (type == 'oldaut') {
                    _txet_1 = '查询到以下信息';
                    _txet_2 = '请确认信息是否匹配，确认无误后请点击下方按钮以导入到您的数据中';
                    _button = '<div class="box-body text-center"><a href="javascript:;" class="but jb-blue radius btn-block padding-lg import-ordery" style="max-width:260px;">确认导入</a></div>';
                    addzibaut = n;
                }
                if (type == 'reload' && !n.msg) {
                    location.reload();
                }

                if (n.authorization_code) {
                    _url = '';
                    for (j = 0, len = n.authorization_url.length; j < len; j++) {
                        _url += '<span class="badg mr6 mb6 c-blue">' + n.authorization_url[j] + '</span>';
                    }
                    _html = '<div class="text-center mt10 mb10 c-red"><i class="fa fa-shield mr10"></i>' + _txet_1 + '</div>\
                <div class="mb10"><div class="author-set-left">授权码</div><div class="author-set-right"><b class="badg mr6 mb6 c-red">' + n.authorization_code + '</b></div></div>\
                <div class="mb10"><div class="author-set-left">授权域名</div><div class="author-set-right">' + _url + '</div></div>\
                <div class="text-center mt10 mb10 muted-2-color">' + _txet_2 + '</div>' + _button;
                    _this.parents('form').html(_html);

                } else {
                    _this.attr('disabled', false).html(_tt).addClass('jb-red');
                }
            }
        });
    }

    $(document).on("click", '.addzibaut', function (e) {
        var _this = $(this);

        var form = _this.parents('form');
        var inputs = form.serializeObject();

        get_zib_api(inputs, '授权成功', _this);

    });
    /**导入老用户授权信息 */
    var addzibaut = {};
    $(document).on("click", '.query-ordery', function (e) {
        var _this = $(this);

        var form = _this.parents('form');
        var inputs = form.serializeObject();

        get_zib_api(inputs, '查询到授权信息', _this, 'oldaut');

    });
    $(document).on("click", '.import-ordery', function (e) {
        var _this = $(this);

        var inputs = addzibaut;
        inputs.action = 'import_autordery';

        get_zib_api(inputs, '导入成功！正在刷新页面', _this, 'reload');
    });

    /**刷新授权信息 */
    $(document).on("click", '.refresh-autordery', function (e) {
        var _this = $(this);

        var form = _this.parents('form');
        var inputs = form.serializeObject();
        inputs.action = 'wml_refresh_autordery';

        get_zib_api(inputs, '信息已更新！正在刷新页面', _this, 'reload');
    });
});