<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 21:41:08
 $ @ 文件路径: \wml-zib-diy\core\functions\beautify\wml-footer.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

//  获取时间设置信息
function get_wml_zib_time()
{
    $wml_footer_time = wml_zib('footers_men', true, 'wml_footers_time');
    $wml_time = strtotime($wml_footer_time);
    $time = ceil((time() - $wml_time) / 86400) - 1;
    return $time;
}
//men底部简约
if (wml_zib('foot_men', false, 'wml_foot'))
{
    function wml_foot() { ?>
        <footer class="footer">
            <?php if (function_exists('dynamic_sidebar')) {
                dynamic_sidebar('all_footer');
            } ?>
            <p class="fcode-links" style="text-align:center;">
                <?php echo wml_zib('foot_men', true, 'foot_html'); ?>
            </p>
            <div style="text-align:center;">
                <?php if (wml_zib('foot_men', true, 'copyright_foot_img_3')) { ?>
                    <div class="item">
                        <a target="_blank" href="<?php echo wml_zib('foot_men', true, 'copyright_foot_url_1,'); ?>" rel="nofollow">
                            <img style="max-width:100%;overflow:hidden;" src="<?php echo wml_zib('foot_men', true, 'copyright_foot_img_3'); ?>" alt="本站受中华人民共和国法律保护"></a>
                    </div>
                <?php } ?>
                <?php echo wml_zib('foot_men', true, 'copyright_foot_html_3'); ?> | <span id=localtime></span>
                <?php if (wml_zib('foot_men', true, 'copyright_foot_time')) { ?>
                    <script type="text/javascript">
                        function showLocale(objD) {
                            var str, colorhead, colorfoot;
                            var yy = objD.getYear();
                            if (yy < 1900) yy = yy + 1900;
                            var MM = objD.getMonth() + 1;
                            if (MM < 10) MM = '0' + MM;
                            var dd = objD.getDate();
                            if (dd < 10) dd = '0' + dd;
                            var hh = objD.getHours();
                            if (hh < 10) hh = '0' + hh;
                            var mm = objD.getMinutes();
                            if (mm < 10) mm = '0' + mm;
                            var ss = objD.getSeconds();
                            if (ss < 10) ss = '0' + ss;
                            var ww = objD.getDay();
                            if (ww == 0) colorhead = "<font color=\"#FF3030\">";
                            if (ww > 0 && ww < 6) colorhead = "<font color=\"#FF3030\">";
                            if (ww == 6) colorhead = "<font color=\"#FF3030\">";
                            if (ww == 0) ww = "星期日";
                            if (ww == 1) ww = "星期一";
                            if (ww == 2) ww = "星期二";
                            if (ww == 3) ww = "星期三";
                            if (ww == 4) ww = "星期四";
                            if (ww == 5) ww = "星期五";
                            if (ww == 6) ww = "星期六";
                            colorfoot = "</font>"
                            str = colorhead + yy + "-" + MM + "-" + dd + "丨" + hh + ":" + mm + ":" + ss + "丨" + ww + colorfoot;
                            return (str);
                        }

                        function tick() {
                            var today;
                            today = new Date();
                            document.getElementById("localtime").innerHTML = showLocale(today);
                            window.setTimeout("tick()", 1000);
                        }
                        tick();
                    </script><?php } ?><br>
                <?php echo wml_zib('foot_men', true, 'copyright_foot_html_4'); ?><?php if (wml_zib('foot_men', true, 'copyright_foot_img_4')) { ?><img src="<?php echo wml_zib('foot_men', true, 'copyright_foot_img_4'); ?>" alt="我们一直用心在做标语"><?php } ?><br>
            <?php if (wml_zib('foot_men', true, 'icp_foot')) { ?>
                <p class="fcode-links" style="text-align:center;">
                    <?php if (wml_zib('foot_men', true, 'wml_icp_foot_img')) { ?><img src="<?php echo wml_zib('foot_men', true, 'wml_icp_foot_img'); ?>" alt="icp备案图标" style="width: 18px;"><?php } ?><a href="https://beian.miit.gov.cn/" style="text-decoration: none;"> <?php echo wml_zib('foot_men', true, 'wml_icp_foot_text'); ?></a>&nbsp;
                <?php } ?>
                <?php if (wml_zib('foot_men', true, 'beian_foot')) { ?>
                    <?php if (wml_zib('foot_men', true, 'wml_beian_foot_img')) { ?><img src="<?php echo wml_zib('foot_men', true, 'wml_beian_foot_img'); ?>" alt="公安备案图标"><?php } ?><a href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=<?php echo wml_zib('foot_men', true, 'wml_beian_foot_text'); ?>" style="text-decoration: none;"> <?php echo wml_zib('foot_men', true, 'wml_beian_foot_text'); ?></a>
                </p>
            <?php } ?>
            </div>
        </footer>
    <?php }
    add_action('wml_footer', 'wml_foot');
}

if (wml_zib('footers_men', false, 'wml_footers'))
{
    function wml_footer() {
        //首先你要有读写文件的权限，首次访问肯不显示，正常情况刷新即可
        $online_log = WML_ZIB_BEAUT_DIR_PATH . "/img/footer/maplers.dat"; //保存人数的文件到根目录,
        $timeout = 30; //30秒内没动作者,认为掉线
        $entries = file($online_log);
        $temp = array();

        for ($i = 0; $i < count($entries); $i++) {
            $entry = explode(",", trim($entries[$i]));
            if (($entry[0] != getenv('REMOTE_ADDR')) && ($entry[1] > time())) {
                array_push($temp, $entry[0] . "," . $entry[1] . "\n"); //取出其他浏览者的信息,并去掉超时者,保存进$temp
            }
        }

        array_push($temp, getenv('REMOTE_ADDR') . "," . (time() + ($timeout)) . "\n"); //更新浏览者的时间
        $maplers = count($temp); //计算在线人数
        $entries = implode("", $temp);
        //写入文件
        $fp = fopen($online_log, "w");
        flock($fp, LOCK_EX); //flock() 不能在NFS以及其他的一些网络文件系统中正常工作
        fputs($fp, $entries);
        flock($fp, LOCK_UN);
        fclose($fp);
    ?>
        <link rel="stylesheet" href="<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/css/footers.css' ?>" type="text/css">
        <?php
        if (wml_zib('footers_men', false, 'wml_footers_tj')) {
        ?>
            <div id="huliku_stat">
                <div class="siteCount">
                    <div class="wrapper">
                        <div class="p-wh">
                            <ul>
                                <li>
                                    <span><?php $count_posts = wp_count_posts();
                                            echo $published_posts = $count_posts->publish; ?></span>
                                    <p>文章数目</p>
                                </li>
                                <li>
                                    <span><?php global $wpdb;
                                            $users = $wpdb->get_var("select count(id) from $wpdb->users");
                                            echo "$users" ?></span>
                                    <p>注册用户</p>
                                </li>
                                <li>
                                    <span><?php echo CSF_Module_Wml_Count::get_posts_count_from_last_168h(); ?></span>
                                    <p>本周发布</p>
                                </li>
                                <li>
                                    <span><?php echo get_wml_zib_time(); ?></span>
                                    <p>稳定运行</p>
                                </li>
                                <li>
                                    <span><?php echo '' . CSF_Module_Wml_Count::all_view() . ''; ?></span>
                                    <p>总访问量</p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        <?php
        }
        ?>
        <div class="wave-box">
            <div class="marquee-box marquee-up" id="marquee-box">
                <div class="marquee">
                    <div class="wave-list-box" id="wave-list-box1">
                        <ul>
                            <li><img height="60" alt="波浪" src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/img/footer/wave_2.png' ?>"></li>
                        </ul>
                    </div>
                    <div class="wave-list-box" id="wave-list-box2">
                        <ul>
                            <li><img height="60" alt="波浪" src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/img/footer/wave_2.png' ?>"></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="marquee-box" id="marquee-box3">
                <div class="marquee">
                    <div class="wave-list-box" id="wave-list-box4">
                        <ul>
                            <li><img height="60" alt="波浪" src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/img/footer/wave_1.png' ?>"></li>
                        </ul>
                    </div>
                    <div class="wave-list-box" id="wave-list-box5">
                        <ul>
                            <li><img height="60" alt="波浪" src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/img/footer/wave_1.png' ?>"></li>
                        </ul>
                    </div>
                </div>
            </div>

        </div>

        <script type="text/javascript" src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/js/script.js' ?>"></script>
        <footer class="footer">
            <?php if (function_exists('dynamic_sidebar')) {
                dynamic_sidebar('all_footer');
            } ?>

            <div id="colophon" class="footer">
                <div id="Onecad_footer_ys2" class="footer-navi">
                    <div id="huliku_title" class="wrapper">
                        <div class="about widget Onecad_fl">
                            <div class="title">
                                <h2><?php echo get_bloginfo('name'); ?></h2>
                            </div>
                            <p><?php echo wml_zib('footers_men', true, 'description'); ?></p>
                            <?php empty($maplers)?$maplers='':$maplers=$maplers;//在线人数临时解决BUG?>
                            <?php printf(' 页面耗时 %.3f 秒 | 数据库查询 %d 次 | 内存 %.2f MB | 在线人数：%d 人', timer_stop(0, 3), get_num_queries(), memory_get_peak_usage() / 1024 / 1024, $maplers); ?>
                        </div>
                        <div class="navis Onecad_fl hide_sm">
                            <?php echo wml_zib('footers_men', true, 'about'); ?>
                            <?php echo wml_zib('footers_men', true, 'function'); ?>
                            <?php echo wml_zib('footers_men', true, 'user'); ?>
                        </div>
                        <div class="ewms widget fr hide_sm">
                            <ul class="clearfix">

                                <li>
                                    <a rel="nofollow" href="<?php echo wml_zib('footers_men', true, 'wml_footers_text1_url'); ?>" target="_blank">
                                        <div>
                                            <div class="Onecad_footer_ico"><i class="thumb " style="background-image:url(<?php echo wml_zib('footers_men', true, 'wml_footers_img1'); ?>)"></i></div>
                                            <h4><?php echo wml_zib('footers_men', true, 'wml_footers_text1'); ?></h4>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a rel="nofollow" href="<?php echo wml_zib('footers_men', true, 'wml_footers_text2_url'); ?>" target="_blank">
                                        <div>
                                            <div class="Onecad_footer_ico"><i class="thumb " style="background-image:url(<?php echo wml_zib('footers_men', true, 'wml_footers_img2'); ?>)"></i></div>
                                            <h4><?php echo wml_zib('footers_men', true, 'wml_footers_text2'); ?></h4>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a rel="nofollow" href="<?php echo wml_zib('footers_men', true, 'wml_footers_text3_url'); ?>" target="_blank">
                                        <div>
                                            <div class="Onecad_footer_ico"><i class="thumb " style="background-image:url(<?php echo wml_zib('footers_men', true, 'wml_footers_img3'); ?>)"></i></div>
                                            <h4><?php echo wml_zib('footers_men', true, 'wml_footers_text3'); ?></h4>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                            <div class="like">
                                <strong><?php $count_posts = wp_count_posts();
                                        echo $published_posts = $count_posts->publish; ?>+</strong>
                                <h3>精品文章等您来关注</h3>
                            </div>
                        </div>
                    </div>


                    <div class="footer-colors"></div>
                    <div class="footer-colors colors-shadow"></div>
                    <div id="huliku_bg_box">
                        <div id="huliku_links">
                            <ul>友情链接：<?php wp_list_bookmarks('title_li=&categorize=0&category=0&before=<span>&after=·</span>&show_images=0&show_description=0&orderby=url'); ?><a href="<?php echo wml_zib('footers_men', true, 'wml_footers_url'); ?>" style="color: #0078ff; float: right;">申请友链</a></ul>
                        </div>
                    </div>
                    <center>
                        <div class="foot-copyright">
                            <div class="wrapper">
                                <p class="foot-copyright-fl fla"><?php echo wml_zib('footers_men', true, 'wml_footers_copyright'); ?></p>
                            </div>
                        </div>
                    </center>
                </div>
            </div>
        </footer>
    <?php }
    add_action('wml_footer', 'wml_footer');
}

if (wml_zib('footer_custom', false, 'custom_footer'))
{
    function wml_custom() { ?>
        <footer class="footer">
            <?php if (function_exists('dynamic_sidebar')) {
                dynamic_sidebar('all_footer');
            } ?>
            <?php echo wml_zib('footer_custom', true, 'foot_custom'); ?>
        <?php } ?>
        </div>
        </footer>
    <?php
    add_action('wml_footer', 'wml_custom');
}
