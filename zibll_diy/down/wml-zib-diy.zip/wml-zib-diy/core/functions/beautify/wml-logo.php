<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 21:40:11
 $ @ 文件路径: \wml-zib-diy\core\functions\beautify\wml-logo.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

// 网站LOGO扫光
if (wml_zib('logoflash', false))
{
    function wml_zib_logoflash() { ?>
        <style>
            .navbar-brand {position: relative;overflow: hidden;margin: 0 0 0 0;}.navbar-brand:before {content: "";position: absolute;left: -665px;top: -460px;width: 200px;height: 15px;background-color: rgba(255, 255, 255, .5);-webkit-transform: rotate(-45deg);-moz-transform: rotate(-45deg);-ms-transform: rotate(-45deg);-o-transform: rotate(-45deg);transform: rotate(-45deg);-webkit-animation: searchLights 6s ease-in 0s infinite;-o-animation: searchLights 6s ease-in 0s infinite;animation: searchLights 6s ease-in 0s infinite;}@-moz-keyframes searchLights {50% {left: -100px;top: 0;}65% {left: 120px;top: 100px;}}@keyframes searchLights {40% {left: -100px;top: 0;}60% {left: 120px;top: 100px;}80% {left: -100px;top: 0;}}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_logoflash');
}

// LOGO色彩渐变
if (wml_zib('logogradient', false))
{
    function wml_zib_logogradient() { ?>
        <style>
            .navbar-logo {animation: hue 4s infinite;}@keyframes hue {from {filter: hue-rotate(0deg);}to {filter: hue-rotate(-360deg);}}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_logogradient');
}

// LOGO反色
if (wml_zib('logo2', false))
{
    function wml_zib_logo2() { ?>
        <style>
            .navbar-logo {filter: invert(1);}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_logo2');
}

// LOGO淡绿色阴影
if (wml_zib('logo3', false))
{
    function wml_zib_logo3() { ?>
        <style>
            .navbar-logo {filter: drop-shadow(0 0 10px dodgerblue);}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_logo3');
}

// LOGO夜间反色
if (wml_zib('logo4', false))
{
    function wml_zib_logo4() { ?>
        <style>
            .dark-theme .navbar-logo {filter: invert(1);}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_logo4');
}
