<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-09 21:49:38
 $ @ 最后修改: 2024-11-14 19:51:18
 $ @ 文件路径: \wml-zib-diy\core\functions\feature\wml-horn-all.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

CSF::createMetabox('Mario', array(
    'title'     => '附加选项',
    'post_type' => array('post', 'plate', 'forum_post'),
    'context'   => 'advanced',
    'data_type' => 'unserialize',
));

CSF::createSection('Mario', array(
    'fields' => array(
        array(
            'title'   => __('开启文章角标'),
            'id'      => 'horn_diy_switch',
            'type'    => 'switcher',
            'label'   => '角标',
            'desc'   => '填哪个显示哪个，内容留空则不显示',
            'default' => false
        ),
        array(
            'dependency' => array('horn_diy_switch', '!=', ''),
            'title'   => __('左上角标内容'),
            'id'      => 'horn_diy_l_t',
            'type'    => 'text',
            'default' => wml_zib('horn_diy_l_t2'),
        ),
        array(
            'dependency' => array('horn_diy_switch', '!=', ''),
            'title'   => __('背景颜色'),
            'id'      => 'horn_diy_l_c',
            'default' => wml_zib('horn_diy_l_c2'),
            'class'   => 'compact skin-color',
            'type'    => "palette",
            'options'  => CSF_Module_Wml_Zib::zib_palette(),
        ),
        array(
            'dependency' => array('horn_diy_switch', '!=', ''),
            'title'   => __('右上角标内容'),
            'id'      => 'horn_diy_r_t',
            'type'    => 'text',
            'default' => wml_zib('horn_diy_r_t2'),
        ),
        array(
            'dependency' => array('horn_diy_switch', '!=', ''),
            'title'   => __('背景颜色'),
            'id'      => 'horn_diy_r_c',
            'class'   => 'compact skin-color',
            'default' => wml_zib('horn_diy_r_c2'),
            'type'    => "palette",
            'options'  => CSF_Module_Wml_Zib::zib_palette(),
        ),
        array(
            'dependency' => array('horn_diy_switch', '!=', ''),
            'title'   => __('封面底部内容'),
            'id'      => 'horn_diy_b_t',
            'type'    => 'text',
            'default' => wml_zib('horn_diy_b_t2'),
        ),
        array(
            'dependency' => array('horn_diy_switch', '!=', ''),
            'title'   => __('背景颜色'),
            'id'      => 'horn_diy_b_c',
            'class'   => 'compact skin-color',
            'default' => wml_zib('horn_diy_b_c2'),
            'type'    => "palette",
            'options'  => CSF_Module_Wml_Zib::zib_palette(),
        ),

    ),
));