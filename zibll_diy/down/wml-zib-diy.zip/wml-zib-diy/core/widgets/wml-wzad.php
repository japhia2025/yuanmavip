<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 18:47:11
 $ @ 文件路径: \wml-zib-diy\core\widgets\wml-wzad.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (wml_zib('wzad_switch', false)) {
    //注册钩子
    add_action('widgets_init', 'register_wzad');
    function register_wzad()
    {
        register_widget('wml_wzad');
    }
    class wml_wzad extends WP_Widget
    {
        public function __construct()
        {
            //定义小工具
            $widget = array(
                'w_id'        => 'wml_wzad',
                'w_name'      => 'WML - 侧边彩色导航',
                'classname'   => '',
                'description' => '网址导航，彩色广告，侧边栏导航',
            );
            parent::__construct($widget['w_id'], $widget['w_name'], $widget);
        }

        public function widget($args, $instance)
        {
            if (!zib_widget_is_show($instance)) {
                return;
            }
            extract($args);
            $list=wml_zib('wzad_links');
            if(!empty($list)){
                $new_button='';$new_button_c='';$i=1;
                foreach($list as $val) {
                    empty($val['name_color'])?$name_color='#ffffff':$name_color=$val['name_color'];//默认名字颜色
                    empty($val['info_color'])?$info_color='#000000':$info_color=$val['info_color'];//默认介绍颜色
                    $i==1?$br='':$br='<br />';
                    $new_button.=$br.'
                    <span class="zhan-widget-link zhan-link-z'.$i.'"> <span class="zhan-widget-link-count">'.$val['info'].'</span> <a href="'.$val['link']['url'].'" target="'.$val['link']['target'].'" title="'.$val['link']['text'].'" rel="noopener"><span class="zhan-widget-link-title">'.$val['name'].'</span> </a></span>';
                    $new_button_c.='.zhan-link-z'.$i.'{border-color:'.$val['link_color']['frame'].';color:'.$info_color.'}.zhan-link-z'.$i.' i{color:#FFF;margin-right:3px}.zhan-link-z'.$i.' .zhan-widget-link-title{background-color:'.$val['link_color']['bg'].';color:'.$name_color.'}';
                    $i++;
                }
            }
            ?>
            
            <div class="zib-widget"><div class="textwidget"><div class="attentionus">
            <?php echo $new_button ?>
            </div></div></div>
            <style type="text/css">
            .zhan-widget-link{
            position:relative;margin-bottom:-10px !important;position:relative;display:block;font-size:13px;background:#fff;color:#525252;line-height:40px;margin-left:-10px;padding:0 14px;border:1px solid #DDD;border-radius:2px;width:100%}
            span.zhan-widget-link.zhan-link-z1 {margin-top: -10px;}
            .zhan-widget-link-count i{margin-right:9px;font-size:17px;vertical-align:middle}
            .zhan-widget-link-title{position:absolute;top:-1px;right:-14px !important;bottom:-1px;width:100px;text-align:center;background:rgba(255,255,255,.08);transition:width .3s;border-radius:0 3px 3px 0}
            .zhan-widget-link:hover .zhan-widget-link-title{width:116px}
            .zhan-widget-link a{position:absolute;top:0;left:0;right:0;bottom:0}
            <?php echo $new_button_c ?>
            </style>
        <?php
        }
    }
}
