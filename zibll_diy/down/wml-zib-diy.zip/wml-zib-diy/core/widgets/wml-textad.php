<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 16:16:52
 $ @ 文件路径: \wml-zib-diy\core\widgets\wml-textad.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (wml_zib('textad_switch', false)) {
    //注册钩子
    add_action('widgets_init', 'register_textad');
    function register_textad()
    {
        register_widget('wml_textad');
    }
    class wml_textad extends WP_Widget
    {
        public function __construct()
        {
            //定义小工具
            $widget = array(
                'w_id'        => 'wml_textad',
                'w_name'      => 'WML - 全屏文字广告列表',
                'classname'   => '',
                'description' => '文字广告，彩色广告，文字栏目广告',
            );
            parent::__construct($widget['w_id'], $widget['w_name'], $widget);
        }

        public function widget($args, $instance)
        {
            if (!zib_widget_is_show($instance)) {
                return;
            }
            extract($args);
            $list=wml_zib('textad_links');
            if(!empty($list)){
                $new_button='<tr>';
                $count=0;//初始化计数器
                foreach($list as $val) {
                    empty($val['color'])?$color='':$color='color:'.$val['color'].';';//广告位颜色
                    if ($count % 5 == 0) {
                        $new_button.='</tr><tr>';//输出换行符
                    }
                    $new_button.='
                    <td style="width:20%;vertical-align:middle;"><a href="'.$val['link']['url'].'" target="'.$val['link']['target'].'" title="'.$val['link']['text'].'" rel="noopener"><span style="font-size:'.$val['size'].'px;'.$color.'">'.$val['name'].'</span></a></td>';
                    $count++; //计数器加1
                }
                if ($count % 5 != 0) {
                    $new_button.='</tr>';
                }//未满5个广告位补上
                $new_button.='</tr>';
            }
            ?>
            <div class="textwidget custom-html-widget"><table style="width:100%;font-weight:700;text-align:center;" cellspacing="0" cellpadding="0" bordercolor="<?php echo wml_zib('textad_bk') ?>" border="1">
            <tbody>
                <?php echo $new_button;?>
              <tr>
                <td colspan="5" style="font-size:15px;" height="28">
                  <p>
                    </p><div id="bdcs"></div><marquee scrollamount="3" behavior="alternate"><?php echo wml_zib('textad_name') ?></marquee>
                </td>
              </tr>
            </tbody>
          </table></div>
        <?php
        }
    }
}
