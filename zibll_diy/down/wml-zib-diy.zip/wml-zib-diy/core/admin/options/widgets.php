<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 16:07:11
 $ @ 最后修改: 2024-11-14 18:21:27
 $ @ 文件路径: \wml-zib-diy\core\admin\options\widgets.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

CSF::createSection(
    $prefix,
    array(
        'id' => 'widgets',
        'title' => '小工具组件',
        'icon' => 'fa fa-fw fa-wrench',
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'widgets',
        'title' => '用户&滚动',
        'icon' => 'fa fa-user-circle',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '演示图',
                'type'    => "content",
                'content' => '<img src="'.$img.'/widgets/test_usergd.jpg">',
            ),
            array(
                'id' => 'usergd_switch',
                'type' => 'switcher',
                'label' => '启用后，可在外观-小工具使用用户欢迎信息',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('usergd_switch', '!=', ''),
                'id' => 'usergd_mobile',
                'type' => 'switcher',
                'label' => '启用后，手机端可显示该滚动条',
                'default' => false,
                'title' => '手机显示',
            ),
            array(
                'dependency' => array(
                    array('usergd_switch', '!=', ''),
                    array('usergd_mobile', '!=', ''),
                ),
                'title' => '显示方式',
                'desc' => '手机端屏幕限制，只能选择以下一种显示',
                'id' => 'usergd_mobile_type',
                'inline' => true,
                'type' => 'radio',
                'options' => array(
                    '1' => __('新人欢迎', 'zib_language'),
                    '2' => __('购买记录', 'zib_language'),
                    '3' => __('最近评论', 'zib_language'),
                ),
                'default' => '1',
                'class'      => 'compact',
            ),
            array(
                'dependency' => array('usergd_switch', '!=', ''),
                'title'   => '显示数量',
                'type'    => "content",
                'content' => '<p>显示新人数量、消费记录、评论记录请转到<font style="color:#fd4c73;"><code>SEO组件-统计</code></font>设置</p>',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'widgets',
        'title' => '欢迎&信息',
        'icon' => 'fa fa-address-card',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '演示图',
                'type'    => "content",
                'content' => '<img src="'.$img.'/widgets/test_hyxx.jpg">',
            ),
            array(
                'id' => 'hyxx_switch',
                'type' => 'switcher',
                'label' => '启用后，可在外观-小工具使用欢迎信息',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('hyxx_switch', '!=', ''),
                'id'      => 'hyxx_color',
                'type'    => 'color',
                'title'   => '背景颜色',
                'default'      => '#ecf2ff',
            ),
            array(
                'dependency' => array('hyxx_switch', '!=', ''),
                'title' => 'API接口',
                'id' => 'hyxx_api',
                'desc' => '腾讯位置API获取：<a target="_blank" href="https://lbs.qq.com/">https://lbs.qq.com/</a>，选择WebServiceAPI',
                'default' => 'OGHBZ-BSUK5-VHKIA-IMK46-N77P5-T4B7B',
                'type' => 'text',
            ),
            array(
                'dependency' => array('hyxx_switch', '!=', ''),
                'title' => '博主坐标',
                'id' => 'hyxx_zb',
                'class'      => 'compact',
                'desc' => '坐标拾取器：<a target="_blank" href="https://lbs.amap.com/tools/picker">https://lbs.amap.com/tools/picker</a>',
                'default' => '110.227896,20.001875',
                'type' => 'text',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'widgets',
        'title' => '音乐&播放',
        'icon' => 'fa fa-music',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '演示图',
                'type'    => "content",
                'content' => '<img src="'.$img.'/widgets/test_music.jpg">',
            ),
            array(
                'title' => '音乐播放器',
                'label' => '启用后，可在网站使用音乐播放器',
                'id' => 'music_switch',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('music_switch', '!=', ''),
                'title' => '显示方式',
                'desc' => '固定模式：需要在外观-小工具摆放想要的位置；吸底模式：显示在所有页面的左下角。',
                'id' => 'music_type',
                'inline' => true,
                'type' => 'radio',
                'options' => array(
                    '1' => __('固定模式', 'zib_language'),
                    '2' => __('吸底模式', 'zib_language'),
                ),
                'default' => '1',
            ),
            array(
                'dependency' => array(
                    array('music_switch', '!=', ''),
                ),
                'title'      => '主题颜色',
                'subtitle'   => ' ',
                'id'         => 'music_theme',
                'class'      => 'compact skin-color',
                'default'    => 'transparent',
                'type'       => 'palette',
                'options'  => CSF_Module_Wml_Zib::zib_palette(array(), array('t','c', 'b')),
            ),
            array(
                'dependency' => array(
                    array('music_switch', '!=', ''),
                ),
                'title'   => '列表折叠',
                'id'      => 'music_folded',
                'inline' => true,
                'type' => 'radio',
                'options' => array(
                    'true' => '列表折叠',
                    'false' => '列表展开',
                ),
                'default' => 'true',
            ),
            array(
                'dependency' => array(
                    array('music_switch', '!=', ''),
                ),
                'title'       => '循环播放',
                'id'          => 'music_loop',
                'inline' => true,
                'class' => 'compact',
                'type' => 'radio',
                'options' => array(
                    'all' => __('列表循环', 'zib_language'),
                    'one' => __('单曲循环', 'zib_language'),
                ),
                'default' => 'all',
            ),
            array(
                'dependency' => array(
                    array('music_switch', '!=', ''),
                ),
                'title'       => '播放方式',
                'id'          => 'music_order',
                'inline' => true,
                'type' => 'radio',
                'class' => 'compact',
                'options' => array(
                    'random' => __('随机播放', 'zib_language'),
                    'list' => __('顺序播放', 'zib_language'),
                ),
                'default' => 'random',
            ),
            array(
                'dependency' => array(
                    array('music_switch', '!=', ''),
                ),
                'title' => '自动播放',
                'label' => '启用后，打开网页即自动播放音频',
                'id' => 'music_autoplay',
                'class' => 'compact',
                'default' => true,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array(
                    array('music_switch', '!=', ''),
                ),
                'title'   => '歌曲单ID',
                'id'      => 'music_id',
                'type'    => 'text',
                'desc'    => '歌单列表ID，ID具体获取方法自行搜索,添加歌曲务必添加非会员可听的音乐。',
                'class' => 'mini-input',
                'default' => '12714133544',
            ),
            array(
                'dependency' => array(
                    array('music_switch', '!=', ''),
                ),
                'title'       => '音乐平台',
                'id'          => 'music_server',
                'inline' => true,
                'type' => 'radio',
                'class' => 'compact',
                'options' => array(
                    'netease' => '网易',
                    'tencent' => 'QQ',
                    'kugou' => '酷狗',
                    'xiami' => '虾米',
                    'baidu' => '百度',
                ),
                'default' => 'tencent',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'widgets',
        'title' => '导航&目录',
        'icon' => 'fa fa-map-signs',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '演示图',
                'type'    => "content",
                'content' => '<img src="'.$img.'/widgets/test_wzad.jpg">',
            ),
            array(
                'id' => 'wzad_switch',
                'type' => 'switcher',
                'label' => '启用后，可在外观-小工具使用网址导航广告',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('wzad_switch', '!=', ''),
                'title'                  => '默认显示',
                'subtitle'               => '选择并排序默认显示的网址',
                'id'                     => 'wzad_links',
                'type'                   => 'group',
                'accordion_title_number' => '1',
                'sanitize'               => false,
                'button_title'           => '添加网址',
                'default'                => array(
                    array(
                        'name'      => '外贸拉',
                        'info'      => '空白资源网',
                        'name_color'      => '#ffffff',
                        'info_color'      => '#000000',
                        'link'           => array(
                            'url'=> 'https://waimao.la/',
                            'text'=> '外贸啦',
                            'target'=> '_blank',
                        ),
                        'link_color'     => array(
                            'frame'=> 'rgba(236,61,81,.39)',
                            'bg'=> '#ec3d51',
                        ),
                    ),
                    array(
                        'name'      => '视频解析',
                        'info'      => '在线视频解析',
                        'name_color'      => '#ffffff',
                        'info_color'      => '#000000',
                        'link'           => array(
                            'url'=> 'https://waimao.la/',
                            'text'=> '外贸啦',
                            'target'=> '_blank',
                        ),
                        'link_color'     => array(
                            'frame'=> 'rgba(18,170,232,.39)',
                            'bg'=> '#12aae8',
                        ),
                    ),
                    array(
                        'name'      => '时光轴啊',
                        'info'      => '时间流逝，记录我的网站',
                        'name_color'      => '#ffffff',
                        'info_color'      => '#000000',
                        'link'           => array(
                            'url'=> 'https://waimao.la/',
                            'text'=> '外贸啦',
                            'target'=> '_blank',
                        ),
                        'link_color'     => array(
                            'frame'=> 'rgba(221,7,208,.39)',
                            'bg'=> '#dd07d0',
                        ),
                    ),
                    array(
                        'name'      => '网站开发',
                        'info'      => 'PHP开发，插件功能开发',
                        'name_color'      => '#ffffff',
                        'info_color'      => '#000000',
                        'link'           => array(
                            'url'=> 'https://waimao.la/',
                            'text'=> '外贸啦',
                            'target'=> '_blank',
                        ),
                        'link_color'     => array(
                            'frame'=> 'rgba(249,82,16,.39)',
                            'bg'=> '#f95210',
                        ),
                    ),
                    array(
                        'name'      => '文档归类',
                        'info'      => '博客文档归类',
                        'name_color'      => '#ffffff',
                        'info_color'      => '#000000',
                        'link'           => array(
                            'url'=> 'https://waimao.la/',
                            'text'=> '外贸啦',
                            'target'=> '_blank',
                        ),
                        'link_color'     => array(
                            'frame'=> 'rgba(25,152,114,.39)',
                            'bg'=> '#199872',
                        ),
                    ),
                ),
                'fields'                 => array(
                    array(
                        'title'   => '链接文字',
                        'id'      => 'name',
                        'type'    => 'text',
                        'default' => '',
                        'desc'    => '右侧背景上的名字',
                        'class' => 'mini-input',
                    ),
                    array(
                        'id'      => 'name_color',
                        'type'    => 'color',
                        'class' => 'compact',
                        'title'   => '文字颜色',
                        'default'      => '#ffffff',
                    ),
                    array(
                        'title'   => '链接简介',
                        'id'      => 'info',
                        'type'    => 'text',
                        'default' => '',
                        'desc'    => '导航网址左侧文字介绍',
                    ),
                    array(
                        'id'      => 'info_color',
                        'type'    => 'color',
                        'class' => 'compact',
                        'title'   => '简介颜色',
                        'default'      => '#000000',
                    ),
                    array(
                        'id'           => 'link',
                        'type'         => 'link',
                        'title'        => '跳转链接',
                        'default'      => array(),
                        'add_title'    => '添加链接',
                        'edit_title'   => '编辑链接',
                        'remove_title' => '删除链接',
                    ),
                    array(
                        'id'      => 'link_color',
                        'type'    => 'color_group',
                        'title'   => '自定义颜色',
                        'desc'    => '自定义颜色请注意日间、夜间模式的适配',
                        'default'      => array('frame' => '#000000','bg' => '#000000'),
                        'options' => array(
                            'frame' => '边框颜色',
                            'bg'    => '背景颜色',
                        ),
                    ),
                ),
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'widgets',
        'title' => '工具&推荐',
        'icon' => 'fa fa-wrench',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '演示图',
                'type'    => "content",
                'content' => '<img src="'.$img.'/widgets/test_adstool.jpg">',
            ),
            array(
                'id' => 'adstool_switch',
                'type' => 'switcher',
                'label' => '启用后，可在外观-小工具使用广告工具',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('adstool_switch', '!=', ''),
                'id'           => 'adstool_link',
                'type'         => 'link',
                'title'        => '跳转链接',
                'default'      => array(),
                'add_title'    => '添加链接',
                'edit_title'   => '编辑链接',
                'remove_title' => '删除链接',
            ),
            array(
                'dependency' => array('adstool_switch', '!=', ''),
                'title' => '大标题',
                'id' => 'adstool_name',
                'desc' => '',
                'default' => '空白的小工具',
                'type' => 'text',
                'class' => 'mini-input',
            ),
            array(
                'dependency' => array('adstool_switch', '!=', ''),
                'title' => '小标题',
                'id' => 'adstool_h4',
                'desc' => '',
                'class' => 'compact',
                'default' => '空白推荐，安全有保障',
                'type' => 'text',
            ),
            array(
                'dependency' => array('adstool_switch', '!=', ''),
                'id'      => 'adstool_btcolor',
                'type'    => 'color',
                'class' => 'compact',
                'title'   => '标题颜色',
                'default'      => '#fff',
            ),
            array(
                'dependency' => array('adstool_switch', '!=', ''),
                'title' => '按钮',
                'id' => 'adstool_h5',
                'desc' => '',
                'default' => '立即进入',
                'type' => 'text',
                'class' => 'mini-input',
            ),
            array(
                'dependency' => array('adstool_switch', '!=', ''),
                'id'      => 'adstool_ancolor',
                'type'    => 'color_group',
                'class'   => 'compact',
                'title'   => '按钮颜色',
                'desc'    => '依次可更改按钮的文字、边框、悬停等颜色',
                'default'      => array('an1' => '#fff','an2' => '#fff','an3' => '#343a3c','an4' => '#fff'),
                'options' => array(
                    'an1' => '文字颜色',
                    'an2' => '背景边框',
                    'an3' => '悬停文字',
                    'an4' => '悬停背景',
                ),
            ),
            array(
                'dependency' => array('adstool_switch', '!=', ''),
                'id'      => 'adstool_bjcolor',
                'type'    => 'color_group',
                'title'   => '背景颜色',
                'desc'    => '两种背景颜色可显示渐变效果',
                'default'      => array('jb1' => '#bbafe7','jb2' => '#5368d9'),
                'options' => array(
                    'jb1' => '渐变1',
                    'jb2' => '渐变2',
                ),
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'widgets',
        'title' => '滚动&广告',
        'icon' => 'fa fa-audio-description',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '演示图',
                'type'    => "content",
                'content' => '<img src="'.$img.'/widgets/test_gdad.jpg">',
            ),
            array(
                'id' => 'gdad_switch',
                'type' => 'switcher',
                'label' => '启用后，可在外观-小工具使用滚动图片广告位',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('gdad_switch', '!=', ''),
                'title'                  => '图片广告位',
                'id'                     => 'gdad_tp',
                'type'                   => 'group',
                'accordion_title_number' => '1',
                'sanitize'               => false,
                'button_title'           => '添加广告位',
                'default'                => array(
                    array(
                        'name' => '外贸啦广告位承接',
                        'img'      => $img.'widgets/gdad.png',
                        'link'     => array(
                            'url'=> 'https://waimao.la/',
                            'text'=> '外贸啦',
                            'target'=> '_blank',
                        ),
                    ),
                ),
                'fields'                 => array(
                    array(
                        'title' => '广告位名称',
                        'id' => 'name',
                        'desc' => '',
                        'default' => '',
                        'type' => 'text',
                        'class' => 'mini-input',
                    ),
                    array(
                        'title' => '广告位图片',
                        'desc' => '请填写图片地址(根据高度)',
                        'id' => 'img',
                        'preview' => true,
                        'library' => 'image',
                        'type' => 'upload',
                    ),
                    array(
                        'id'           => 'link',
                        'type'         => 'link',
                        'title'        => '跳转链接',
                        'default'      => array(),
                        'add_title'    => '添加链接',
                        'edit_title'   => '编辑链接',
                        'remove_title' => '删除链接',
                    ),
                ),
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'widgets',
        'title' => '图文&广告',
        'icon' => 'fa fa-audio-description',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '演示图',
                'type'    => "content",
                'content' => '<img src="'.$img.'/widgets/test_imgad.jpg">',
            ),
            array(
                'id' => 'imgad_switch',
                'type' => 'switcher',
                'label' => '启用后，可在外观-小工具使用图文广告位',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('imgad_switch', '!=', ''),
                'id'           => 'imgad_icon',
                'type'         => 'icon',
                'title'        => '左上图标',
                'button_title' => '选择图标',
                'default'      => 'fa fa-audio-description',
            ),
            array(
                'dependency' => array('imgad_switch', '!=', ''),
                'title' => '广告位名称',
                'id' => 'imgad_name',
                'desc' => '',
                'default' => '首页广告位',
                'type' => 'text',
                'class' => 'mini-input',
            ),
            array(
                'dependency' => array('imgad_switch', '!=', ''),
                'id'           => 'imgad_rz_link',
                'type'         => 'link',
                'title'        => '入驻说明',
                'subtitle'     => '入驻说明跳转链接',
                'default'      => array(),
                'add_title'    => '添加链接',
                'edit_title'   => '编辑链接',
                'remove_title' => '删除链接',
            ),
            array(
                'dependency' => array('imgad_switch', '!=', ''),
                'title'                  => '图片广告位',
                'subtitle'               => '选择并排序默认显示的广告位',
                'id'                     => 'imgad_tp',
                'type'                   => 'group',
                'accordion_title_number' => '1',
                'sanitize'               => false,
                'button_title'           => '添加广告位',
                'default'                => array(
                    array(
                        'img'      => $img.'widgets/imgad_tpad1.webp',
                        'link'     => array(
                            'url'=> 'https://waimao.la/',
                            'text'=> '外贸啦',
                            'target'=> '_blank',
                        ),
                    ),
                    array(
                        'img'      => $img.'widgets/imgad_tpad1.webp',
                        'link'     => array(
                            'url'=> 'https://waimao.la/',
                            'text'=> '外贸啦',
                            'target'=> '_blank',
                        ),
                    ),
                ),
                'fields'                 => array(
                    array(
                        'title' => '广告图片',
                        'desc' => '请填写图片地址(根据高度)',
                        'id' => 'img',
                        'default' => $img . 'widgets/imgad_tpad1.webp',
                        'preview' => true,
                        'library' => 'image',
                        'type' => 'upload',
                    ),
                    array(
                        'id'           => 'link',
                        'type'         => 'link',
                        'title'        => '跳转链接',
                        'default'      => array(),
                        'add_title'    => '添加链接',
                        'edit_title'   => '编辑链接',
                        'remove_title' => '删除链接',
                    ),
                ),
            ),
            array(
                'dependency' => array('imgad_switch', '!=', ''),
                'title'                  => '文字广告位',
                'subtitle'               => '选择并排序默认显示的广告位',
                'id'                     => 'imgad_wz',
                'type'                   => 'group',
                'accordion_title_number' => '1',
                'sanitize'               => false,
                'button_title'           => '添加广告位',
                'default'                => array(
                    array(
                        'name'      => '文字广告位50元/年',
                        'color'      => '#1e73be',
                    ),
                    array(
                        'name'      => '图片广告位100元/年',
                        'color'      => '#8224e3',
                    ),
                    array(
                        'name'      => '图片广告位100元/年',
                        'color'      => '#dd3333',
                    ),
                    array(
                        'name'      => '图片广告位100元/年',
                        'color'      => '#81d742',
                    ),
                    array(
                        'name'      => '图片广告位100元/年',
                        'color'      => '#ff00d2',
                    ),
                    array(
                        'name'      => '图片广告位100元/年',
                        'color'      => '#dd9933',
                    ),
                ),
                'fields'                 => array(
                    array(
                        'title'   => '链接文字',
                        'id'      => 'name',
                        'type'    => 'text',
                        'default' => '',
                        'desc'    => '',
                        'class' => 'mini-input',
                    ),
                    array(
                        'id'      => 'color',
                        'type'    => 'color',
                        'class' => 'compact',
                        'title'   => '文字颜色',
                        'default'      => '',
                    ),
                    array(
                        'id'           => 'link',
                        'type'         => 'link',
                        'title'        => '跳转链接',
                        'default'      => array(),
                        'add_title'    => '添加链接',
                        'edit_title'   => '编辑链接',
                        'remove_title' => '删除链接',
                    ),
                ),
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'widgets',
        'title' => '文字&广告',
        'icon' => 'fa fa-audio-description',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '演示图',
                'type'    => "content",
                'content' => '<img src="'.$img.'/widgets/test_textad.jpg">',
            ),
            array(
                'id' => 'textad_switch',
                'type' => 'switcher',
                'label' => '启用后，可在外观-小工具使用文字广告',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('textad_switch', '!=', ''),
                'id'      => 'textad_bk',
                'type'    => 'color',
                'title'   => '边框颜色',
                'default'  => '#640EF6',
            ),
            array(
                'dependency' => array('textad_switch', '!=', ''),
                'title' => '底部标语',
                'id' => 'textad_name',
                'desc' => '',
                'default' => '温馨提示：请在上面搜索| 查找更多免费资源，如需广告位请联系站长QQ 181682245',
                'type' => 'text',
            ),
            array(
                'dependency' => array('textad_switch', '!=', ''),
                'id'      => 'textad_by',
                'type'    => 'color',
                'title'   => '标语颜色',
                'class' => 'compact',
                'default'  => '#640EF6',
            ),
            array(
                'dependency' => array('textad_switch', '!=', ''),
                'title'                  => '文字广告位',
                'subtitle'               => '选择并排序默认显示的广告位',
                'id'                     => 'textad_links',
                'type'                   => 'group',
                'accordion_title_number' => '1',
                'sanitize'               => false,
                'button_title'           => '添加广告位',
                'fields'                 => array(
                    array(
                        'title'   => '链接文字',
                        'id'      => 'name',
                        'type'    => 'text',
                        'default' => '',
                        'desc'    => '',
                        'class' => 'mini-input',
                    ),
                    array(
                        'id'      => 'color',
                        'type'    => 'color',
                        'class' => 'compact',
                        'title'   => '文字颜色',
                        'default'      => '',
                    ),
                    array(
                        'id'      => 'size',
                        'title'   => '文字大小',
                        'desc'    => '',
                        'default' => 13,
                        'max'     => 30,
                        'min'     => 10,
                        'step'    => 1,
                        'unit'    => 'px',
                        'type'    => 'slider',
                    ),
                    array(
                        'id'           => 'link',
                        'type'         => 'link',
                        'title'        => '跳转链接',
                        'default'      => array(),
                        'add_title'    => '添加链接',
                        'edit_title'   => '编辑链接',
                        'remove_title' => '删除链接',
                    ),
                ),
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'widgets',
        'title' => '分享&导航',
        'icon' => 'fa fa-share-alt',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '演示图',
                'type'    => "content",
                'content' => '<img src="'.$img.'/widgets/test_sharedh.jpg">',
            ),
            array(
                'id' => 'sharedh_switch',
                'type' => 'switcher',
                'label' => '启用后，可在外观-小工具使用分享导航',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('sharedh_switch', '!=', ''),
                'title'                  => '导航一',
                'subtitle'               => '选择并排序默认显示的导航',
                'id'                     => 'sharedh_dh1',
                'type'                   => 'group',
                'accordion_title_number' => '1',
                'sanitize'               => false,
                'button_title'           => '添加导航一',
                'default'                => array(
                    array(
                        'name'      => '外贸拉',
                        'name_color'      => '',
                        'info'      => '数字 移民 海淘 支付 充值 翻墙 互联 破解 VPN 分享 技术 导航',
                        'info_color'      => '',
                        'logo_url'    => $img.'/logo.png',
                        'bg_color'     => 'c-yellow',
                    ),
                ),
                'fields'=> array(
                    array(
                        'title'   => '导航文字',
                        'id'      => 'name',
                        'type'    => 'text',
                        'default' => '',
                        'class' => 'mini-input',
                    ),
                    array(
                        'id'      => 'name_color',
                        'type'    => 'color',
                        'class' => 'compact',
                        'title'   => '文字颜色',
                        'subtitle'   => '默认跟随主题',
                        'default'      => '',
                    ),
                    array(
                        'title'   => '导航简介',
                        'id'      => 'info',
                        'type'    => 'text',
                        'default' => '',
                    ),
                    array(
                        'id'      => 'info_color',
                        'type'    => 'color',
                        'class' => 'compact',
                        'title'   => '简介颜色',
                        'subtitle'   => '默认跟随主题',
                        'default'      => '',
                    ),
                    array(
                        'id' => 'logo_url',
                        'title' => '左侧LOGO',
                        'desc' => '建议尺寸50X50',
                        'default'    => '',
                        'type'       => 'upload',
                    ),
                    array(
                        'title'      => '背景颜色',
                        'subtitle'   => ' ',
                        'id'         => 'bg_color',
                        'class'      => 'compact skin-color',
                        'default'    => 'transparent',
                        'type'       => 'palette',
                        'options'  => CSF_Module_Wml_Zib::zib_palette(),
                    ),
                ),
            ),
            array(
                'dependency' => array('sharedh_switch', '!=', ''),
                'title'                  => '导航二',
                'subtitle'               => '选择并排序默认显示的导航',
                'id'                     => 'sharedh_dh2',
                'type'                   => 'group',
                'accordion_title_number' => '1',
                'sanitize'               => false,
                'button_title'           => '添加导航二',
                'default'                => array(
                    array(
                        'name'      => '美国电话卡',
                        'name_color'      => '',
                        'info'      => '全球通话，$5/月',
                        'info_color'      => '',
                        'bg_color'     => 'c-purple-2',
                        'link'           => array(
                            'url'=> 'https://waimao.la/',
                            'text'=> '外贸啦',
                            'target'=> '_blank',
                        ),
                    ),
                    array(
                        'name'      => '美国电话卡',
                        'name_color'      => '',
                        'info'      => '全球通话，$5/月',
                        'info_color'      => '',
                        'bg_color'     => 'c-red',
                        'link'           => array(
                            'url'=> 'https://waimao.la/',
                            'text'=> '外贸啦',
                            'target'=> '_blank',
                        ),
                    ),
                ),
                'fields'=> array(
                    array(
                        'title'   => '导航文字',
                        'id'      => 'name',
                        'type'    => 'text',
                        'default' => '',
                        'class' => 'mini-input',
                    ),
                    array(
                        'id'      => 'name_color',
                        'type'    => 'color',
                        'class' => 'compact',
                        'title'   => '文字颜色',
                        'subtitle'   => '默认跟随主题',
                        'default'      => '',
                    ),
                    array(
                        'title'   => '导航简介',
                        'id'      => 'info',
                        'type'    => 'text',
                        'default' => '',
                    ),
                    array(
                        'id'      => 'info_color',
                        'type'    => 'color',
                        'class' => 'compact',
                        'title'   => '简介颜色',
                        'subtitle'   => '默认跟随主题',
                        'default'      => '',
                    ),
                    array(
                        'id'           => 'link',
                        'type'         => 'link',
                        'title'        => '跳转链接',
                        'default'      => array(),
                        'add_title'    => '添加链接',
                        'edit_title'   => '编辑链接',
                        'remove_title' => '删除链接',
                    ),
                    array(
                        'title'      => '背景颜色',
                        'subtitle'   => ' ',
                        'id'         => 'bg_color',
                        'class'      => 'compact skin-color',
                        'default'    => 'transparent',
                        'type'       => 'palette',
                        'options'  => CSF_Module_Wml_Zib::zib_palette(),
                    ),
                ),
            ),
            array(
                'dependency' => array('sharedh_switch', '!=', ''),
                'title'                  => '导航三',
                'subtitle'               => '选择并排序默认显示的导航',
                'id'                     => 'sharedh_dh3',
                'type'                   => 'group',
                'accordion_title_number' => '1',
                'sanitize'               => false,
                'button_title'           => '添加导航三',
                'default'                => array(
                    array(
                        'name'      => 'QQ',
                        'name_color'      => '',
                        'info'      => '181682233',
                        'info_color'      => '',
                        'bg_color'     => 'c-green',
                    ),
                    array(
                        'name'      => 'QQ群',
                        'name_color'      => '',
                        'info'      => '123456789',
                        'info_color'      => '',
                        'bg_color'     => 'c-blue',
                    ),
                ),
                'fields'=> array(
                    array(
                        'title'   => '联系方式',
                        'id'      => 'name',
                        'type'    => 'text',
                        'default' => '',
                        'class' => 'mini-input',
                    ),
                    array(
                        'id'      => 'name_color',
                        'type'    => 'color',
                        'class' => 'compact',
                        'title'   => '文字颜色',
                        'subtitle'   => '默认跟随主题',
                        'default'      => '',
                    ),
                    array(
                        'title'   => '联系账号',
                        'id'      => 'info',
                        'type'    => 'text',
                        'default' => '',
                    ),
                    array(
                        'id'      => 'info_color',
                        'type'    => 'color',
                        'class' => 'compact',
                        'title'   => '简介颜色',
                        'subtitle'   => '默认跟随主题',
                        'default'      => '',
                    ),
                    array(
                        'title'      => '背景颜色',
                        'subtitle'   => ' ',
                        'id'         => 'bg_color',
                        'class'      => 'compact skin-color',
                        'default'    => 'transparent',
                        'type'       => 'palette',
                        'options'  => CSF_Module_Wml_Zib::zib_palette(),
                    ),
                ),
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'widgets',
        'title' => '节日&计时',
        'icon' => 'fa fa-tachometer',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '演示图',
                'type'    => "content",
                'content' => '<img src="'.$img.'/widgets/test_countdown.jpg">',
            ),
            array(
                'id' => 'countdown_switch',
                'type' => 'switcher',
                'label' => '启用后，可在外观-小工具使用广告工具',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('countdown_switch', '!=', ''),
                'title' => '春节日期',
                'id' => 'countdown_rq',
                'desc' => '输入春节日期，格式：<font color="#ff0000">2025-01-29</font>',
                'default' => '2025-01-29',
                'type' => 'text',
                'class' => 'mini-input',
            ),
            array(
                'dependency' => array('countdown_switch', '!=', ''),
                'id'      => 'countdown_bj',
                'type'    => 'color',
                'title'   => '进度条颜色',
                'default'      => '#425AEF',
            ),
            array(
                'dependency' => array('countdown_switch', '!=', ''),
                'title'    => ' ',
                'subtitle' => '进度条透明',
                'id'       => 'countdown_tm',
                'default'  => '6d',
                'class'    => 'compact',
                'type'     => 'select',
                'options'  => array(
                    '0d'  => '90',
                    '2d'  => '80',
                    '4d'  => '70',
                    '6d'  => '60',
                    '8d'  => '50',
                    'fd'  => '无',
                ),
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'widgets',
        'title' => '新人&滚动',
        'icon' => 'fa fa-user',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '演示图',
                'type'    => "content",
                'content' => '<img src="'.$img.'/widgets/test_newhy.jpg">',
            ),
            array(
                'id' => 'newhy_switch',
                'type' => 'switcher',
                'label' => '启用后，可在外观-小工具使用广告工具',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('newhy_switch', '!=', ''),
                'title'      => '主题颜色',
                'subtitle'   => ' ',
                'id'         => 'newhy_theme',
                'class'      => 'compact skin-color',
                'default'    => 'transparent',
                'type'       => 'palette',
                'options'  => CSF_Module_Wml_Zib::zib_palette(array(), array('t','c')),
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'widgets',
        'title' => '欢迎&天气',
        'icon' => 'fa fa-sun-o',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '演示图',
                'type'    => "content",
                'content' => '<img src="'.$img.'/widgets/test_hyweather.jpg">',
            ),
            array(
                'id' => 'hyweather_switch',
                'type' => 'switcher',
                'label' => '启用后，可在外观-小工具使用欢迎天气横条',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('hyweather_switch', '!=', ''),
                'id'      => 'hyweather_color',
                'type'    => 'color',
                'title'   => '文字颜色',
                'desc'  => '默认跟随主题颜色',
                'default'      => ' ',
            ),
            array(
                'dependency' => array('hyweather_switch', '!=', ''),
                'title'      => '背景颜色',
                'desc'  => '默认跟随主题颜色',
                'subtitle'   => ' ',
                'id'         => 'hyweather_theme',
                'class'      => 'skin-color',
                'default'    => 'transparent',
                'type'       => 'palette',
                'options'  => CSF_Module_Wml_Zib::zib_palette(),
            ),
            array(
                'dependency' => array('hyweather_switch', '!=', ''),
                'id'      => 'hyweather_size',
                'title'   => '文字大小',
                'desc'    => '',
                'default' => 20,
                'max'     => 30,
                'min'     => 15,
                'step'    => 1,
                'unit'    => 'px',
                'type'    => 'slider',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'widgets',
        'title' => '信息&统计',
        'icon' => 'fa fa-industry',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '演示图',
                'type'    => "content",
                'content' => '<img src="'.$img.'/widgets/test_count.jpg">',
            ),
            array(
                'id' => 'count_switch',
                'type' => 'switcher',
                'label' => '启用后，可在外观-小工具使用信息统计',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('count_switch', '!=', ''),
                'title' => '信息标题',
                'id' => 'count_name',
                'default' => '—— 外贸啦播报 ——',
                'type' => 'text',
            ),
            array(
                'dependency' => array('count_switch', '!=', ''),
                'id' => 'count_type',
                'title' => '星期风格',
                'type' => 'radio',
                'inline'  => true,
                'options' => array(
                    '1' => '风格1',
                    '2' => '风格2'
                ),
                'default' => 1
            ),
            array(
                'dependency' => array('count_switch', '!=', ''),
                'title' => '时间风格',
                'id' => 'count_time',
                'default' => '1',
                'type' => 'image_select',
                'options' => array(
                    '1' => $img . '/widgets/count_t1.jpg',
                    '2' => $img . '/widgets/count_t2.jpg',
                ),
            ),
            array(
                'dependency' => array('count_switch', '!=', ''),
                'title'   => '其他设置',
                'type'    => "content",
                'content' => '<p>可配合<font style="color:#fd4c73;">SEO组件-统计作弊</font>显示相关信息</p>',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'widgets',
        'title' => '图片&栏目',
        'icon' => 'fa fa-picture-o',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '演示图',
                'type'    => "content",
                'content' => '<img src="'.$img.'/widgets/test_tplm.jpg">',
            ),
            array(
                'id' => 'tplm_switch',
                'type' => 'switcher',
                'label' => '启用后，可在外观-小工具使用图片栏目工具',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('tplm_switch', '!=', ''),
                'title'   => '使用说明',
                'type'    => "content",
                'content' => '<p>开启后进入<font style="color:#fd4c73;">外观-小工具</font>添加到想放置的位置，输入<font style="color:#fd4c73;">标题、目录ID</font>。</p>',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'widgets',
        'title' => 'IP&签名档',
        'icon' => 'fa fa-pencil-square',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '演示图',
                'type'    => "content",
                'content' => '<img src="'.$img.'/widgets/test_ipqm.jpg">',
            ),
            array(
                'id' => 'ipqm_switch',
                'type' => 'switcher',
                'label' => '启用后，可在外观-小工具使用IP签名档（推荐侧边栏使用）',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('ipqm_switch', '!=', ''),
                'title' => 'API接口',
                'type' => 'content',
                'content' => '高德地图API获取：<a target="_blank" href="https://api.amap.com/">https://api.amap.com/</a>，添加白名单。<p>打开：<font style="color:#fd4c73;"><code>page/ipqm/ipqm.php</code></font>修改替换头部打开第六行KEY部分</p>',
            ),
            array(
                'dependency' => array('ipqm_switch', '!=', ''),
                'title' => '随机显示',
                'type' => 'image_select',
                'before' => '<style>.ipqm-site .csf-fieldset .csf--image-group{
                    display: flex;
                    flex-wrap: wrap;
                }
                .ipqm-site .csf-fieldset .csf--image-group .csf--image{
                    width: calc(23.33333% - 6px);
                    height: calc(23.33333% - 6px);
                }</style>',
                'options' => array(
                    '1' => WML_ZIB_BEAUT_DIR_URL.'/page/ipqm/img/ipqm_bg1.png',
                    '2' => WML_ZIB_BEAUT_DIR_URL.'/page/ipqm/img/ipqm_bg2.png',
                    '3' => WML_ZIB_BEAUT_DIR_URL.'/page/ipqm/img/ipqm_bg3.png',
                ),
                'class' => 'ipqm-site'
            ),
            array(
                'dependency' => array('ipqm_switch', '!=', ''),
                'title' => ' ',
                'type' => 'content',
                'content' => '如不希望随时显示，可打开：page/ipqm/ipqm.php<font style="color:#fd4c73;"><code>查找rand(1,3)</code></font>更改图片地址',
            ),
        )
    )
);