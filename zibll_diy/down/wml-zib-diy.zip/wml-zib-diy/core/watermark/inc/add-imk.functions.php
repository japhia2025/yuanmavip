<?php
// 检查PHP是否安装了Imagick
if (!extension_loaded('imagick')) {
    function imk_notice_new_install()
    {
        $con = '<div class="notice notice-success is-dismissible">
				<h2 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 感谢您使用外贸啦DIY</h2>
				<p>imagemagick 扩展未安装，水印功能请先安装 imagemagick 扩展。</p>
			</div>';
        echo $con;
    }
    add_action('admin_notices', 'imk_notice_new_install');
}
// 添加钩子处理上传图片
function viu_imk_process_upload($file)
{
    // 检查是否是图片
    if (stripos($file['type'], 'image') === false) { // 判断上传的文件是否是图片
        return $file;
    }
    // 判断是否开启水印
    if (!_imk('imk_onOff', true)) {
        return $file;
    }
    $img_path = $file['file']; // 获取文件路径
    // 判断是否包含特定不需要添加水印的图片
    if (imk_check_image_name_for_specific_chars($img_path, _imk('filtration', ''))) {
        return $file;
    }
    // 检查是否在后台且用户是否为管理员
    $is_admin = is_admin() && current_user_can('manage_options');

    // 检查是否在前台
    $is_console = !$is_admin;
    // 生成随机后缀
    //$random_suffix = generateRandomString();
    //$output_path = dirname($img_path) . '/' . $random_suffix . basename($img_path);

    // 设置水印参数
    $imk_data_args = array(
        'img_path' => $img_path,
        'output_path' => $img_path, // 使用新的输出路径
        'type' => _imk('imk-type', 1),
        'content' => _imk('content', 'viu轻水印'),
        'font' => get_imk_fonts_dir(_imk('font', '微软雅黑.ttf')),
        'color' => _imk('color', '#d8d8d8'),
        'water_url' => _imk('img_url', get_imk_img_url('viu-imk.png')),
        'water_path' => imk_get_img_info(_imk('img_url', get_imk_img_url('viu-imk.png')))['path'],
        'angle' => _imk('qx', 0),
        'size' => _imk('size', 20),
        'opacity' => _imk('opacity', 100),
        'is_admin' => _imk('is_admin', true),
        'is_console' => _imk('is_console', false),
        'site' => _imk('site', 1),
        'padding' => _imk('padding', 30),
        'spacing' => _imk('spacing', 12),
        'row_height' => _imk('row_height', 10),
        'interleaving' => _imk('interleaving', 20),
        'jgg_site' => _imk('jgg_site', 5),
    );
    // 创建 ImageWatermark 实例并处理
        if (class_exists('ImageWatermark')) {
            $imageWatermark = new ImageWatermark($imk_data_args);
            $result = $imageWatermark->process();
            if ($result['code'] == 0) {
                // 更新文件信息
                $file['file'] = $img_path;
                $file['url'] = $img_path; // 如果需要更新URL
            }
        }
    

    return $file;
}

// 注册钩子
add_filter('wp_handle_upload', 'viu_imk_process_upload');
// 函数：生成带有水印的图片预览
function imk_test_send()
{
    // 检查是否提供了图片URL
    if (empty($_POST['img_url'])) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请输入图片地址'));
        exit();
    }
    $img_url = $_POST['img_url'];
    // 待处理图片路径
    $img_path = imk_get_img_info($img_url)['path'];
    if (!file_exists($img_path)) {
        $localPath = downloadFileWithCurlUnique($img_url, IMK_COM_DIR . 'assets/img');
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' =>$localPath[0])['url']);
        exit();
        if (is_array($localPath)) {
            $img_url = imk_get_img_info($localPath[0])['url'];
            // 待处理图片路径
            $img_path = imk_get_img_info($localPath[0])['path'];
        } else {
            switch ($localPath) {
        case 600:
            $msg = "文件信息检测错误：fileinfo 扩展未安装。";
            break;
        case 601:
            $msg = "文件信息检测错误：无法打开 fileinfo 数据库。";
            break;
        case 602:
            $msg = "文件下载错误：无法确定图片扩展名。";
            break;
        case 603:
            $msg = "文件下载错误：cURL 下载失败。";
            break;
        case 604:
            $msg = "文件下载错误：文件名冲突，无法创建唯一文件。";
            break;
        case 605:
            $msg = "文件下载错误：cURL 执行错误。";
            break;
        default:
            $msg = "文件下载失败，未知错误。";
    }
            echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => $msg));
            exit();
        }
    }
    // 待处理图片名
    $filename = imk_get_img_info($img_url)['name'];
    // 生成动态后缀
    $timestamp = time();
    $dynamic_suffix = '_' . $timestamp;
    // 构建新的图片文件名
    $new_img_filename = 'viu-preview-' . $timestamp . '-' . $filename;
    $watermarked_img_path = IMK_COM_DIR . 'assets/img/' . $new_img_filename;
    $watermarked_img_url = IMK_COM_URL . 'assets/img/' . $new_img_filename;
    $imk_data_args = array(
        'img_path' => $img_path,
        'type' => _imk('imk-type', 1),
        'content' => _imk('content', 'viu轻水印'),
        'font' => get_imk_fonts_dir(_imk('font', '微软雅黑.ttf')),
        'color' => _imk('color', '#d8d8d8'),
        'water_url' => _imk('img_url', get_imk_img_url('viu-imk.png')),
        'water_path' => imk_get_img_info(_imk('img_url', get_imk_img_url('viu-imk.png')))['path'],
        'angle' => _imk('qx', 0),
        'size' => _imk('size', 20),
        'opacity' => _imk('opacity', 100),
        'is_admin' => _imk('is_admin', true),
        'is_console' => _imk('is_console', false),
        'site' => _imk('site', 1),
        'padding' => _imk('padding', 30),
        'spacing' => _imk('spacing', 12),
        'row_height' => _imk('row_height', 10),
        'interleaving' => _imk('interleaving', 20),
        'jgg_site' => _imk('jgg_site', 5),
        'output_path' => $watermarked_img_path
    );
    $imageWatermark = new ImageWatermark($imk_data_args);
    $result = $imageWatermark->process();
    if ($result['code'] == 0) {
        // 返回带有水印的图片的HTML标记
        $preview_img = '<img class="preview_img" src="' . $watermarked_img_url . '" alt="Watermarked Image">';
        echo json_encode(array('success' => $result['code'], 'ys' => 'success', 'msg' => $preview_img));
        exit;
    } else {
        echo json_encode(array('error' => $result['code'], 'ys' => 'danger', 'msg' => $result['msg']));
        exit;
    }
}
add_action('wp_ajax_imk_test_send', 'imk_test_send');
add_action('wp_ajax_nopriv_imk_test_send', 'imk_test_send'); // 为了非登录用户也能使用
