<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 18:42:09
 $ @ 文件路径: \wml-zib-diy\core\widgets\wml-countdown.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (wml_zib('countdown_switch', false)) {
    //注册钩子
    add_action('widgets_init', 'register_countdown');
    function register_countdown()
    {
        register_widget('wml_countdown');
    }
    class wml_countdown extends WP_Widget
    {
        public function __construct()
        {
            //定义小工具
            $widget = array(
                'w_id'        => 'wml_countdown',
                'w_name'      => 'WML - 侧边节日倒计时',
                'classname'   => '',
                'description' => '显示距离节日和时间日期的倒计时',
            );
            parent::__construct($widget['w_id'], $widget['w_name'], $widget);
        }

        public function widget($args, $instance)
        {
            echo $args['before_widget'];

            $festival_date = !empty($instance['festival_date']) ? esc_attr($instance['festival_date']) : wml_zib('countdown_rq');

            ?>
            <style type="text/css"> .count-down {display: flex;flex-direction: row;align-items: center;background-color: var(--main-bg-color);border-radius: 10px;}.count-down .count-left {position: relative;display: flex;flex-direction: column;align-items: center;justify-content: space-evenly;margin-right: 0.8rem;}.count-down .count-left .text {font-size: 14px;color: var(--key-color);}.count-down .count-left .name {font-weight: 700;font-size: 18px;margin-top: 2px;}.count-down .count-left .time {font-size: 30px;font-weight: 700;margin: 4px 0;color: var(--main-color);}.count-down .count-left .date {font-size: 12px;opacity: .6;}.count-down .count-left {position: relative;display: flex;flex-direction: column;align-items: center;justify-content: space-evenly;margin-right: 0.8rem;padding: 18px;margin-bottom: 1rem;}.count-down .count-left:after {content: "";position: absolute;right: -0.8rem;width: 2px;height: 60%;background-color: #E3E8F7;}.count-down .count-right .count-item {display: flex;flex-direction: row;align-items: center;height: 24px;margin: 6px 0;}.count-down .count-right .count-item .item-name {font-size: 14px;margin-right: 0.8rem;white-space: nowrap;color: var(--main-color);}.count-down .count-right .count-item .item-progress .percentage.many, .count-down .count-right .count-item .item-progress .remaining.many {color: #fff;}.count-down .count-right .count-item .item-progress .progress-bar {height: 100%;border-radius: 8px;background-color: <?php echo wml_zib('countdown_bj');?>;}.count-down .count-right .count-item {display: flex;flex-direction: row;align-items: center;height: 24px;margin: 6px 0;}.count-down .count-right .count-item .item-progress {position: relative;display: flex;flex-direction: row;align-items: center;justify-content: space-between;height: 100%;width: 100%;border-radius: 8px;background-color: var(--main-color-bg);overflow: hidden;}.count-down .count-right .count-item .item-progress .percentage.many .tip, .count-down .count-right .count-item .item-progress .remaining.many .tip {opacity: .8;}.count-down .count-right .count-item .item-progress {position: relative;display: flex;flex-direction: row;align-items: center;justify-content: space-between;height: 100%;width: 70%;border-radius: 8px;background-color: <?php echo wml_zib('countdown_bj').wml_zib('countdown_tm');?>;overflow: hidden;}.count-down .count-right .count-item .item-progress .percentage, .count-down .count-right .count-item .item-progress .remaining {position: absolute;font-size: 12px;margin: 0 6px;transition: opacity .3s, transform .3s;}.count-down .count-right {flex: 1;width: 100%;margin-left: 0.8rem;}.count-down .count-right .count-item .item-progress .remaining {opacity: 0;transform: translate(10px);}.s-card:hover.hover {border-color: var(--main-color);box-shadow: 0 8px 16px -4px var(--main-color-bg) }.count-down:hover .count-right .remaining {transform: translate(0)!important;opacity: 1!important }.count-down:hover .count-right .percentage {transform: translate(-10px)!important;opacity: 0!important }</style>
            <div class="count-down s-card weidgets">
                <div class="count-left">
                    <span class="text">距离</span>
                    <span class="name">春节</span>
                    <span class="time"></span>
                    <span class="date"></span>
                </div>
                <div class="count-right">
                    <div class="count-item">
                        <div class="item-name">今日</div>
                        <div class="item-progress">
                            <div class="progress-bar" style="width: 0%;"></div>
                            <span class="percentage many">0%</span>
                            <span class="remaining many"></span>
                        </div>
                    </div>
                    <div class="count-item">
                        <div class="item-name">本周</div>
                        <div class="item-progress">
                            <div class="progress-bar" style="width: 0%;"></div>
                            <span class="percentage many">0%</span>
                            <span class="remaining many"></span>
                        </div>
                    </div>
                    <div class="count-item">
                        <div class="item-name">本月</div>
                        <div class="item-progress">
                            <div class="progress-bar" style="width: 0%;"></div>
                            <span class="percentage many">0%</span>
                            <span class="remaining many"></span>
                        </div>
                    </div>
                    <div class="count-item">
                        <div class="item-name">本年</div>
                        <div class="item-progress">
                            <div class="progress-bar" style="width: 0%;"></div>
                            <span class="percentage many">0%</span>
                            <span class="remaining many"></span>
                        </div>
                    </div>
                </div>
            </div>
            <script>
                document.addEventListener("DOMContentLoaded", function() {
                    const festivalDate = new Date("<?php echo $festival_date; ?>");
                    const now = new Date();

                    // 更新左侧春节的倒计时 腾飞博客- - www.tfbkw.com
                    const timeElement = document.querySelector('.count-left .time');
                    const dateElement = document.querySelector('.count-left .date');
                    const countdownTime = Math.ceil((festivalDate - now) / (1000 * 3600 * 24));
                    timeElement.innerText = countdownTime + " 天"; // 添加单位
                    dateElement.innerText = festivalDate.toISOString().split('T')[0];

                    const countItems = document.querySelectorAll('.count-item');

                    function calculateProgress() {
                        const currentTime = new Date();

                        // 今日的开始时间
                        const startOfToday = new Date(currentTime.getFullYear(), currentTime.getMonth(), currentTime.getDate());
                        const totalHoursToday = 24;

                        // 计算已过的小时
                        const hoursPassedToday = (currentTime - startOfToday) / (1000 * 3600);

                        // 更新今日进度
                        const todayPercent = (hoursPassedToday / totalHoursToday) * 100;
                        updateProgress(countItems[0], todayPercent, totalHoursToday - Math.floor(hoursPassedToday), '小时');

                        // 本周进度
                        const startOfWeek = new Date(currentTime);
                        startOfWeek.setDate(currentTime.getDate() - currentTime.getDay());
                        const totalDaysThisWeek = 7;
                        const daysPassedThisWeek = Math.floor((currentTime - startOfWeek) / (1000 * 3600 * 24));

                        // 更新本周进度
                        const weekPercent = (daysPassedThisWeek / totalDaysThisWeek) * 100;
                        updateProgress(countItems[1], weekPercent, totalDaysThisWeek - daysPassedThisWeek, '天');

                        // 本月进度
                        const startOfMonth = new Date(currentTime.getFullYear(), currentTime.getMonth(), 1);
                        const totalDaysThisMonth = new Date(currentTime.getFullYear(), currentTime.getMonth() + 1, 0).getDate();
                        const daysPassedThisMonth = Math.floor((currentTime - startOfMonth) / (1000 * 3600 * 24));

                        // 更新本月进度
                        const monthPercent = (daysPassedThisMonth / totalDaysThisMonth) * 100;
                        updateProgress(countItems[2], monthPercent, totalDaysThisMonth - daysPassedThisMonth, '天');

                        // 本年进度
                        const startOfYear = new Date(currentTime.getFullYear(), 0, 1);
                        const totalDaysThisYear = 365 + (isLeapYear(currentTime.getFullYear()) ? 1 : 0);
                        const daysPassedThisYear = Math.floor((currentTime - startOfYear) / (1000 * 3600 * 24));

                        // 更新本年进度
                        const yearPercent = (daysPassedThisYear / totalDaysThisYear) * 100;
                        updateProgress(countItems[3], yearPercent, totalDaysThisYear - daysPassedThisYear, '天');
                    }

                    function updateProgress(item, percent, remaining, unit) {
                        const progressBar = item.querySelector('.progress-bar');
                        const percentageText = item.querySelector('.percentage');
                        const remainingText = item.querySelector('.remaining');

                        progressBar.style.width = `${percent.toFixed(2)}%`;
                        percentageText.innerText = `${percent.toFixed(2)}%`;
                        remainingText.innerText = `还剩 ${remaining} ${unit}`;
                    }
                    
                    function isLeapYear(year) {
                        return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
                    }

                    calculateProgress();

                    // 鼠标悬停事件
                    document.querySelector('.count-down').addEventListener('mouseenter', calculateProgress);
                });
            </script>
            <?php

            echo $args['after_widget'];
        }

        public function form($instance) {
            $festival_date = !empty($instance['festival_date']) ? esc_attr($instance['festival_date']) : '2025-01-29';
            ?>
            <p>
                <label for="<?php echo $this->get_field_id('festival_date'); ?>">过年日期:</label>
                <input class="widefat" id="<?php echo $this->get_field_id('festival_date'); ?>" name="<?php echo $this->get_field_name('festival_date'); ?>" type="date" value="<?php echo $festival_date; ?>">
            </p>
            <?php
        }

        public function update($new_instance, $old_instance) {
            $instance = array();
            $instance['festival_date'] = (!empty($new_instance['festival_date'])) ? strip_tags($new_instance['festival_date']) : '';
            return $instance;
        }
    }
    // 引入 CSS 样式
    //add_action('wp_enqueue_scripts', function() {
        //wp_enqueue_style('tengfei-data-style', WML_ZIB_BEAUT_DIR_ASSETS . '/css/w_countdown.css', array(), '1.0.0');
    //});
}
