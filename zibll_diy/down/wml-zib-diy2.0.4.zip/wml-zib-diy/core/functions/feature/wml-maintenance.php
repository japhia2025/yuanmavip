<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-06 01:23:30
 $ @ 最后修改: 2024-11-14 19:49:24
 $ @ 文件路径: \wml-zib-diy\core\functions\feature\wml-maintenance.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

//维护开关
if (!is_admin() && wml_zib('is_maintenance', false)) {
	add_action('wp_loaded', function (){
		global $pagenow;

		if (current_user_can('manage_options')  || $pagenow == 'wp-login.php' || $_SERVER['REQUEST_URI'] == "/user-sign?tab=signin&redirect_to") {
		//if (current_user_can('manage_options')) {
			return;
		}
		
		header( $_SERVER["SERVER_PROTOCOL"] . ' 503 Service Temporarily Unavailable', true, 503 );
		header('Content-Type:text/html;charset=utf-8');

		require 'wp-content/plugins/wml-zib-diy/page/maintenance/index.php';

		exit;
	});
}
