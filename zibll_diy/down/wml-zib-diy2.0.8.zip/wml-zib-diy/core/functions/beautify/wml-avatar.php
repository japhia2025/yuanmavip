<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 21:42:30
 $ @ 文件路径: \wml-zib-diy\core\functions\beautify\wml-avatar.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

// 头像美化
if (wml_zib('avatar_mh', false))
{
    function wml_zib_avatar_mh() { ?>
        <style>
            .avatar-img {border-radius: 50%;animation: light 4s ease-in-out infinite;transition: 0.5s;}.avatar-img:hover {transform: scale(1.15) rotate(720deg);}@keyframes light {0% {box-shadow: 0 0 4px #f00;}25% {box-shadow: 0 0 16px #0f0;}50% {box-shadow: 0 0 4px #00f;}75% {box-shadow: 0 0 16px #0f0;}100% {box-shadow: 0 0 4px #f00;}}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_avatar_mh');
}

// 彩色昵称
if (wml_zib('csnc', false))
{
    function wml_zib_csnc() { ?>
        <style>
            .display-name {background-image: -webkit-linear-gradient(90deg, #07c160, #fb6bea 25%, #3aedff 50%, #fb6bea 75%, #28d079);-webkit-text-fill-color: transparent;-webkit-background-clip: text;background-size: 100% 600%;animation: wzw 10s linear infinite;}@keyframes wzw {0% {background-position: 0 0;}100% {background-position: 0 -300%;}}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_csnc');
}

// 用户摇摆
if (wml_zib('avatar_yb', false))
{
    function wml_zib_avatar_yb() { ?>
        <style>
             .user-avatar .avatar-img, .img-ip:hover, .w-a-info img {-webkit-animation: swing 3s .4s ease both;-moz-animation: swing 3s .4s ease both;}@-webkit-keyframes swing {20%, 40%, 60%, 80%, 100% {-webkit-transform-origin: top center }20% {-webkit-transform: rotate(15deg) }40% {-webkit-transform: rotate(-10deg) }60% {-webkit-transform: rotate(5deg) }80% {-webkit-transform: rotate(-5deg) }100% {-webkit-transform: rotate(0deg) }}@-moz-keyframes swing {20%, 40%, 60%, 80%, 100% {-moz-transform-origin: top center }20% {-moz-transform: rotate(15deg) }40% {-moz-transform: rotate(-10deg) }60% {-moz-transform: rotate(5deg) }80% {-moz-transform: rotate(-5deg) }100% {-moz-transform: rotate(0deg) }}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_avatar_yb');
}
