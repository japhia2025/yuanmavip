<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 21:40:28
 $ @ 文件路径: \wml-zib-diy\core\functions\beautify\wml-left.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/


//热榜
function activity_rankings($time_range)
{
    $args = array(
        'posts_per_page' => 10, // 文章数量
        'meta_key' => 'views', // 基于浏览量（需自定义实现）
        'orderby' => 'meta_value_num', // 按数字排序
        'order' => 'DESC', // 降序
    );
    $query = new WP_Query($args);
    if ($query->have_posts()) {
        echo '<div class="rank-box">';
        while ($query->have_posts()) {
            $query->the_post();
            // 链接
            echo '<a class="class-item js-rank" href="' . get_permalink() . '" target="_blank">';
            // 图像
            echo zib_post_thumbnail($img_src, 'class-pic');
            // 文章信息
            echo '<div class="class-info">';
            // 标题
            echo '<div class="name">' . get_the_title() . '</div>';
            // 浏览量（自定义获取方法）
            echo '<span class="badg b-theme badg-sm">' . get_post_view_count('', '热度值') . '</span>';
            echo '</div>';
            echo '</a>';
        }
        echo '</div>';
    } else {
        // 没有找到文章
        echo '<p>没有找到相关文章。</p>';
    }
    wp_reset_postdata(); // 重置文章数据
}
function urlsssss()
{
    $protocol = empty($_SERVER['HTTPS']) ? 'http://' : 'https://';
    $domain = $_SERVER['HTTP_HOST'];
    $url = $protocol . $domain;
    echo $url;
}

//左侧显示文章热榜
if (wml_zib('article_hot_list', false))
{
    function wml_zib_sidebar_ranking() { ?>
        <style>
             .fix-left {position: fixed;top: 150px;left: 10px;z-index: 10;}.fix-item {width: 50px;height: 68px;background-color: #fff;box-shadow: 0 5px 10px 0 rgba(0, 0, 0, .1);margin-bottom: 20px;border-radius: 15px;transition: all .2s;}.item-title {text-align: center;overflow: hidden;cursor: pointer;position: relative;color: #333;}img[data-v-3b17862b] {width: 30px;display: block;margin: 8px auto 0;}span[data-v-3b17862b] {font-size: 12px;}i[data-v-3b17862b] {display: none;position: absolute;width: 30px;height: 30px;line-height: 30px;text-align: center;right: 0;top: 0;color: #fff;}.rank-box[data-v-3b17862b] {display: none;padding: 0 10px;height: 350px;overflow-y: auto;background-color: #fff;box-shadow: 0 5px 10px 0 rgba(0, 0, 0, .1);border-bottom-right-radius: 15px;border-bottom-left-radius: 15px;}ul[data-v-3b17862b] {list-style: none;}li[data-v-3b17862b] {border-bottom: 1px solid #f3e9e961;padding: 8px 0;}.img[data-v-3b17862b] {float: left;width: 100%;height: 100%;overflow: hidden;margin-right: 8px;}.img img[data-v-3b17862b] {width: 100%;height: 100%;}ul li .title[data-v-3b17862b] {overflow: hidden;height: 32px;font-size: 12px;line-height: 16px;color: #333;}.fix-left .fix-item.active[data-v-3b17862b] {width: 280px;}.fix-left .fix-item.active .item-title[data-v-3b17862b] {height: 60px;line-height: 60px;background-color: #333;color: #fff;border-top-left-radius: 15px;border-top-right-radius: 15px;}.fix-left .fix-item.active .item-title img[data-v-3b17862b] {display: inline-block;margin: 0 15px 0 0;}.fix-left .fix-item.active .item-title span[data-v-3b17862b] {font-size: 14px;}.fix-left .fix-item.active .item-title i[data-v-3b17862b], .fix-left .fix-item.active .rank-box[data-v-3b17862b] {display: block }.enlighter-default .enlighter {max-height: 400px;overflow-y: auto !important;}.posts-item .item-heading>a {font-weight: bold;color: unset;}@media (max-width:640px) {.meta-right .meta-view {display: unset !important;}}a.class-item.js-rank {display: block;width: 100%;height: 80px;display: flex;align-items: center;margin-bottom: 20px;}.class-info {width: 190px;font-size: 12px;}.name {line-height: 20px;font-weight: 400;margin-bottom: 2px;text-overflow: ellipsis;display: -webkit-box;-webkit-line-clamp: 2;overflow: hidden;-webkit-box-orient: vertical;font-size: 15px;}img.class-pic {width: 125px;border-radius: 8px;margin-right: 10px;height: 80px;}a.class-item.js-rank {display: block;width: 100%;height: 80px;display: flex;align-items: center;margin-bottom: 20px;}
        </style>
        <div data-v-3b17862b="" class="fix-left">
            <div id="wml_zib_cb_ht" data-v-3b17862b="" class="fix-item">
                <div data-v-3b17862b="" class="item-title">
                    <img data-v-3b17862b="" src="<?php echo wml_zib('article_hot_lists_img'); ?>">
                    <span data-v-3b17862b="">
                        后退
                    </span>
                </div>
            </div>
            <div id="zhiyanx_cb_bd" data-v-3b17862b="" class="fix-item">
                <div data-v-3b17862b="" class="item-title">
                    <img data-v-3b17862b="" src="<?php echo wml_zib('article_hot_list_img'); ?>">
                    <span id="macgf_bd_wz" data-v-3b17862b="">
                        榜单
                    </span>
                </div>
                <div data-v-3b17862b="" class="rank-box">
                    <ul data-v-3b17862b="">
                        <?php activity_rankings('1 month ago');; ?>
                    </ul>
                </div>
            </div>
        </div>
        <script type="text/javascript">
            // 获取元素
            var element = document.getElementById("zhiyanx_cb_bd");

            // 添加点击事件监听器
            element.addEventListener("click", function() {
                // 切换 class
                if (element.classList.contains("active")) {
                    element.classList.remove("active");
                } else {
                    element.classList.add("active");
                }
            });
            document.getElementById("wml_zib_cb_ht").addEventListener("click", function() {
                // 跳转到指定网址
                window.location.href = "<?php echo urlsssss(); ?>";
            });
            document.addEventListener("DOMContentLoaded", function() {
                var divElement = document.getElementById("wml_zib_cb_ht");
                // 获取当前页面的完整URL
                var currentPageUrl = window.location.href;
                // 指定的首页URL
                var homepageUrl = "<?php echo urlsssss(); ?>/";
                // 检查当前页面是否为首页
                if (currentPageUrl !== homepageUrl) {
                    // 如果是首页，则显示 div 元素
                    divElement.style.display = "block";
                } else {
                    // 如果不是首页，则隐藏 div 元素
                    divElement.style.display = "none";
                }
            });
        </script>
    <?php }
    add_action('wp_footer', 'wml_zib_sidebar_ranking');
}

// 左侧显示联系站长按钮
if (wml_zib('qq', false))
{
    function wml_zib_qq() { ?>
        <style>
            .contact-help-qq {position: fixed;z-index: 99999;left: 0;top: calc(30% - 30px);margin-top: -36px;width: 28px;height: 85px;transition: all .3s;font-size: 12px;background: var(--main-bg-color);border-radius: 0 7px 7px 0;padding: 8px 7px;line-height: 14px;}@media screen and (max-width: 768px) {.contact-help-qq {display: none;}}
        </style>
        <script src="<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/js/qq.js' ?>"></script>
        <a href="<?php echo wml_zib('qq_url'); ?>" target="_blank" class="contact-help-qq" style="font-weight:700;"><?php echo wml_zib('qq_text'); ?><svg class="icon" aria-hidden="true">
                <use xlink:href="#icon-QQ"></use>
            </svg></a>
    <?php }
    add_action('wp_head', 'wml_zib_qq');
}