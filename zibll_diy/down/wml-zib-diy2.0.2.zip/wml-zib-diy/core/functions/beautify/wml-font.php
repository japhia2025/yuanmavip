<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 21:41:25
 $ @ 文件路径: \wml-zib-diy\core\functions\beautify\wml-font.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

//字体选择
if (wml_zib('font_switch', false)) {
    function wml_zib_font_switch()
    {
        if(wml_zib('font_select_t')==1){
            $type = wml_zib('font_select'); //样式
            if ($type=='1') {//抖音美好体 ?>
                <style>
                    @font-face {font-family: 'zti';src:url('<?php echo WML_ZIB_BEAUT_DIR_ASSETS . 'font/dymht.woff2' ?>');}
                    body {font-family: 'zti' !important;}
                </style>
            <?php }
            elseif ($type=='2') {//阿里妈妈方圆体 ?>
                <style>
                    @font-face {font-family: 'zti';src:url('<?php echo WML_ZIB_BEAUT_DIR_ASSETS . 'font/AlimamaFangYuanTiVF-Thin.woff2' ?>');}
                    body {font-family: 'zti' !important;}
                </style>
            <?php }
        }else{// 自定义字体 ?>
        <style>
            @font-face {font-family: 'zti';src:url(<?php echo wml_zib('font_select_diy') ?>);}
            body {font-family: 'zti' !important;}
        </style>
        <?php }
    }
    add_action('wp_footer', 'wml_zib_font_switch');
}
