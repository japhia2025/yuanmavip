<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-21 01:42:17
 $ @ 最后修改: 2024-11-21 02:11:49
 $ @ 文件路径: \wml-zib-diy\core\widgets\wml-homeph.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (wml_zib('homeph_switch', false)) {
    //注册钩子
    add_action('widgets_init', 'register_homeph');
    function register_homeph()
    {
        register_widget('wml_homeph');
    }
    class wml_homeph extends WP_Widget
    {
        public function __construct()
        {
            //定义小工具
            $widget = array(
                'w_id'        => 'wml_homeph',
                'w_name'      => 'WML - 首页排行',
                'classname'   => '',
                'description' => '首页排行榜',
            );
            parent::__construct($widget['w_id'], $widget['w_name'], $widget);
        }
        public function widget($args, $instance)
        {
            if (!zib_widget_is_show($instance)) {
                return;
            }
            extract($args);
            ?>
            
        <link rel="stylesheet" href="<?php echo WML_ZIB_BEAUT_DIR_ASSETS;?>css/homeph.css">
            <div id="syphb" class="container list clearfix">
			<div class="ranking-item">
				<a   class="top-icon js-rank-bottom1"><?php echo wml_zib('homeph_a');?></a>
				<div class="class-box">
				      <?php query_posts('cat='.wml_zib('homeph_a_id').'&showposts='.wml_zib('homeph_a_num').'&orderby=views'); ?>
                    <?php while (have_posts()) : the_post(); ?>
				    <a class="class-item js-rank" href="<?php esc_url(the_permalink()); ?>" target="_blank">
					   <div class="num-icon num-icon<?php 	
									 ++$phnum1;
										   echo $phnum1; 
										?>"></div> 
											<span class="syphimg" >  <?php echo zib_post_thumbnail(); ?></span>
					   <div class="class-info">
						<div class="name"><?php the_title(); ?></div>
						<span class="badg b-theme badg-sm"><?php echo get_post_view_count('', ''); ?>热度值</span>
						
					   </div>
					</a>
				<?php endwhile;?> 
					</div>
				<a class="bottom-link js-rank-bottom">
					<span>榜单实时更新</span>
					<i class="imv2-chevrons-right"></i>
				</a>
			</div>
				<div class="ranking-item">
				<a class="top-icon js-rank-bottom2" ><?php echo wml_zib('homeph_b');?></a>
				<div class="class-box">
				      <?php query_posts('cat='.wml_zib('homeph_b_id').'&showposts='.wml_zib('homeph_b_num').'&orderby=views'); ?>
                    <?php while (have_posts()) : the_post(); ?>
				    <a class="class-item js-rank" href="<?php esc_url(the_permalink()); ?>" target="_blank">
					   <div class="num-icon num-icon<?php 	
									 ++$phnum2;
										   echo $phnum2; 
										?>"></div> 
											<span class="syphimg" >  <?php echo zib_post_thumbnail(); ?></span>
					   <div class="class-info">
						<div class="name"><?php the_title(); ?></div>
						<span class="badg b-theme badg-sm"><?php echo get_post_view_count('', ''); ?>热度值</span>
						
					   </div>
					</a>
				<?php endwhile;?> 
					</div>
				<a class="bottom-link js-rank-bottom">
					<span>榜单实时更新</span>
					<i class="imv2-chevrons-right"></i>
				</a>
			</div>
				<div class="ranking-item">
				<a   class="top-icon js-rank-bottom3" ><?php echo wml_zib('homeph_c');?></a>
				<div class="class-box">
				      <?php query_posts('cat='.wml_zib('homeph_c_id').'&showposts='.wml_zib('homeph_c_num').'&orderby=views'); ?>
                    <?php while (have_posts()) : the_post(); ?>
				    <a class="class-item js-rank" href="<?php esc_url(the_permalink()); ?>" target="_blank">
					   <div class="num-icon num-icon<?php 	
									 ++$phnum3;
										   echo $phnum3; 
										?>"></div> 
											<span class="syphimg" >  <?php echo zib_post_thumbnail(); ?></span>
					   <div class="class-info">
						<div class="name"><?php the_title(); ?></div>
						<span class="badg b-theme badg-sm"><?php echo get_post_view_count('', ''); ?>热度值</span>
						
					   </div>
					</a>
				<?php endwhile;?> 
					</div>
				<a class="bottom-link js-rank-bottom">
					<span>榜单实时更新</span>
					<i class="imv2-chevrons-right"></i>
				</a>
			</div>
		</div>
        <?php
        }
    }
}
