<?php
/**
 * 配置文件
 *
 * @package WP_REAL_PERSON_VERIFY
 */

define( 'WTHNBO_VERSION', '1.5' );

define( 'WTHNBO_ROOT_PATH', plugin_dir_path( __FILE__ ) );

define( 'WTHNBO_ROOT_URL', plugin_dir_url( __FILE__ ) );
