<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-09 12:22:22
 $ @ 最后修改: 2024-11-14 19:50:58
 $ @ 文件路径: \wml-zib-diy\core\functions\feature\wml-horn.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

//仿Mac角标美化
if (wml_zib('horn_mac_switch', false)) {
    function wml_zib_horn_mac_switch()
    { ?>
        <style>
            .posts-item {position: relative;}
            .posts-item.card::before {
                content: "";
                display: block;
                background: #fc625d;
                top: 10px;
                left: 15px;
                border-radius: 50%;
                width: 10px;
                height: 10px;
                box-shadow: 16px 0 #fdbc40, 32px 0 #35cd4b;
                position: absolute;
            }
            .posts-item.card {
                padding: 26px 10px 10px 10px;
            }
        </style>
        <?php 
    }
    add_action('wp_head', 'wml_zib_horn_mac_switch');
}

//置顶角标
if (wml_zib('horn_zd_switch', false)) {
    function wml_zib_horn_zd_switch()
    { 
        if(wml_zib('horn_zd_ct')==1){
            $palette=CSF_Module_Wml_Zib::zib_palette();
            $zd_bg=$palette[wml_zib('horn_zd_c')][0];
        }else{
            $zd_bg='var(--theme-color)';
        }
    ?>
        <style>
        .posts-item badge.img-badge.left.jb-red {
            position: absolute;
            top: 10px;
            right: -50px;
            z-index: 1;
            width: 140px;
            height: 20px;
            background: <?php echo $zd_bg;?>;
            color: #fff;
            line-height: 20px;
            transform: rotate(45deg);
            text-align: center;
            font-size: 12px;
            left: auto;
            border-radius: 0 50px 50px 0;
        }
        </style>
        <?php 
    }
    add_action('wp_head', 'wml_zib_horn_zd_switch');
}


//标题前缀
if (wml_zib('horn_qz_switch', false)) {
    CSF::createMetabox('DearLicy_titles', array(
        'title'     => '标题前缀',
        'post_type' => 'post',
        'context'   => 'advanced',
        'data_type' => 'unserialize',
        'priority'  => 'high',
    ));
    
    CSF::createSection( 'DearLicy_titles', array(
        'fields' => array(
            array(
                'id'       => 'titles_moshi',
                'type'     => 'radio',
                'title'    => '模式选择',
                'desc'     => '选择图片或自定义文字',
                'inline'   => true,
                'options'  => array(
                    'img'   => '图片',
                    'text'  => '文字',
                ),
                'default' => 'img',  // 默认选择图片模式
            ),
            array(
                'id'      => 'text',
                'type'    => 'text',
                'title'   => '文字模式',
                'desc'    => '建议两个字',
                'dependency' => array( 'titles_moshi', '==', 'text' ),  // 依赖关系：当模式选择为文字时显示
            ),
            array(
                'id'      => 'text_bg_color',
                'type'    => 'palette',
                'title'   => '背景颜色',
                'desc'    => '部分颜色带有文字颜色，其余默认白色',
                'class'   => 'compact skin-color',
                'default' => "jb-vip2",
                'options' => CSF_Module_Wml_Zib::zib_palette(array(), array('jb')),
                'dependency' => array( 'titles_moshi', '==', 'text' ),  // 依赖关系：当模式选择为文字时显示
            ),
            array(
                'id'      => 'img',
                'type'    => 'palette',
                'title'   => '选择一个图片',
                'desc'    => '固定使用以下几款SVG图标',
                'class'   => 'compact skin-color',
                'default' => "jb-vip2",
                'options' => array(
                    'shice'    => array('url('.WML_ZIB_BEAUT_DIR_ASSETS.'/img/feature/horn-qz1.svg);width: 50px;'),
                    'dujia'    => array('url('.WML_ZIB_BEAUT_DIR_ASSETS.'/img/feature/horn-qz2.svg);width: 50px;'),
                    'shoufa'   => array('url('.WML_ZIB_BEAUT_DIR_ASSETS.'/img/feature/horn-qz3.svg);width: 50px;'),
                ),
                'dependency' => array( 'titles_moshi', '==', 'img' ),  // 依赖关系：当模式选择为图片时显示
            ),
        ),
    ));
    
    function apply_dearlicy_prefixes_to_title($title, $id = null) {
        // 只有在前端，并且非单个页面，才对标题进行更改
        if (!is_admin() && !is_single() && $id) {
            // 先获取meta box中的设置项
            $prefixes_setting = get_post_meta($id, 'titles_moshi', true);
    
            if($prefixes_setting == 'img') {
                $selected_img = get_post_meta($id, 'img', true);
                $img_url ='';
                switch ($selected_img) {
                    case 'shice':
                        $img_url = WML_ZIB_BEAUT_DIR_ASSETS.'/img/feature/horn-qz1.svg';
                        break;
                    case 'shoufa':
                        $img_url = WML_ZIB_BEAUT_DIR_ASSETS.'/img/feature/horn-qz2.svg';
                        break;
                    case 'dujia':
                        $img_url = WML_ZIB_BEAUT_DIR_ASSETS.'/img/feature/horn-qz3.svg';
                        break;
                }
                
                if(!empty($img_url)) {
                    $title = "<img src='$img_url' alt='$img_url' style=' height: 20px; pointer-events: none;margin-right: 3px;'/>" . $title;
                }
            } else {
                // 对保存的文字前缀进行处理
                $prefix_text = get_post_meta($id, 'text', true);
                $prefix_bg_color = get_post_meta($id, 'text_bg_color', true);
                if (!empty($prefix_text)) {
                    $title = "<span class='DearLicy_prefix ". esc_attr($prefix_bg_color) ."'>" . esc_html($prefix_text) . "</span> " . $title;
                }
            }
        }
        return $title;
    }
    add_filter('the_title', 'apply_dearlicy_prefixes_to_title', 10, 2);
    
    function wml_zib_horn_qz_css(){//CSS顶部
        ?>
        <style>
             .DearLicy_prefix{position: relative;overflow: hidden;display: inline-flex;align-items: center;border-radius: 5px;padding: 5px 4px;margin-right: 3px;height: 19px;font-size: 12px;top: -3px;clip-path: polygon(7% 0, 99% 0, 93% 100%, 0 100%);}.DearLicy_prefix:after, .DearLicy_prefix:after {position: absolute;content: " ";display: block;left: -100%;top: -5px;width: 15px;height: 145%;background-image: linear-gradient(90deg, rgba(255, 255, 255, 0), rgba(255, 255, 255, 0.5), rgba(255, 255, 255, 0));animation: sweepTitle 3s ease-in-out infinite;transform: rotate(28deg);}@keyframes sweepTitle {0% {left: -100% }100% {left: 100% }}
        </style>
        <?php
    }
    add_action('wp_head', 'wml_zib_horn_qz_css');
}


//自定义角标
if (wml_zib('horn_diy_switch', false)) {
    if(wml_zib('horn_diy')==2){require_once 'wml-horn-all.php';}//后台文章编辑插入功能栏
    function wml_zib_horn_diy_post($post){
        $type=wml_zib('horn_diy');
        $sticky = '';
        if($type==2){
            if (get_post_meta($post->ID, 'horn_diy_switch', true)){
                $left = get_post_meta($post->ID, 'horn_diy_l_t', true);
                $horn_diy_l_c = get_post_meta($post->ID, 'horn_diy_l_c', true);
                $bottom = get_post_meta($post->ID, 'horn_diy_b_t', true);
                $horn_diy_b_c = get_post_meta($post->ID, 'horn_diy_b_c', true);
                $horn_diy_r_t = get_post_meta($post->ID, 'horn_diy_r_t', true);
                $horn_diy_r_c = get_post_meta($post->ID, 'horn_diy_r_c', true);
                
                $palette=CSF_Module_Wml_Zib::zib_palette();
                if ($horn_diy_r_t) {
                    $sticky .= '<badge class="jiaobiao2" style="background:'.$theme=$palette[$horn_diy_r_c][0].';">'.$horn_diy_r_t.'</badge>';
                }
                if ($left){
                    $sticky .= '<a class="item-category" style="background:'.$theme=$palette[$horn_diy_l_c][0].';"> '.$left.' </a>';
                }
                if ($bottom){
                    $sticky .= '<div class="n-collect-item-bottom" style="background:'.$theme=$palette[$horn_diy_b_c][0].';"><span class="bottom-l">'.$bottom.'</span></div>';
                }
            }
        }elseif($type==1){
            $palette=CSF_Module_Wml_Zib::zib_palette();
            if (wml_zib('horn_diy_l_w', false)) {
                if(empty(wml_zib('horn_diy_l_t'))){
                    $horn_diy_l_t=date("Y.m.d",strtotime($post->post_modified));
                }else $horn_diy_l_t=wml_zib('horn_diy_l_t');
                $sticky .= '<a class="item-category" style="background:'.$theme=$palette[wml_zib('horn_diy_l_c')][0].';"> '.$horn_diy_l_t.' </a>';
            }
            if (wml_zib('horn_diy_r_w', false)) {
                if(wml_zib('horn_diy_r_type')==2){
                    $sticky .= '<badge class="jiaobiao2" style="background:'.$palette[wml_zib('horn_diy_r_c')][0].';">'.wml_zib('horn_diy_r_t').'</badge>';
                }elseif(wml_zib('horn_diy_r_type')==1){
                    $utime=time()-wml_zib('horn_diy_r_time');
                    if($utime<strtotime($post->post_date)){
                        $sticky .= '<badge class="jiaobiao2" style="background:'.$palette[wml_zib('horn_diy_r_c')][0].';">'.wml_zib('horn_diy_r_t').'</badge>';
                    }
                }
            }
            if (wml_zib('horn_diy_b_w', false)) {
                if(empty(wml_zib('horn_diy_b_t'))){
                    if(get_the_subtitle(false)){
                        $sticky .= '<div class="n-collect-item-bottom" style="background:'.$palette[wml_zib('horn_diy_b_c')][0].';"><span class="bottom-l">'.get_the_subtitle(false).'</span></div>';
                    }
                }else{
                    $sticky .= '<div class="n-collect-item-bottom" style="background:'.$palette[wml_zib('horn_diy_b_c')][0].';"><span class="bottom-l">'.wml_zib('horn_diy_b_t').'</span></div>';
                }
            }
        }
        return $sticky;
    }
    add_filter( 'zib_post_img_horn_after', 'wml_zib_horn_diy_post', 10, 2 ); 
    
    function wml_zib_horn_diy_css(){//CSS顶部
        ?>
        <style>
             .posts-item.card .item-thumbnail {background:#c4cffa26;width:100%;padding-bottom:var(--posts-card-scale);}a.item-category {position:absolute;left:10px;top:10px;padding:5px 6px;font-size:1rem;line-height:1;color:#fff;background:var(--theme-color);border-radius:6px;}a.item-category-app {position:absolute;height:24px;line-height:24px;width:100%;text-align:center;bottom:0;left:0;background:radial-gradient(circle,#3783ff,#3783ffbf);color:#fff;font-size:12px;border-radius:0 0 10px 10px;}a.item-category-app-b {position:absolute;height:24px;line-height:24px;width:100%;text-align:center;bottom:0;left:0;background:radial-gradient(circle,#ff5631,#ff5631ba);color:#fff;font-size:12px;border-radius:0 0 10px 10px;}a.item-category-app-c {position:absolute;height:24px;line-height:24px;width:100%;text-align:center;bottom:0;left:0;background:radial-gradient(circle,#464242,#464242ad);color:#fff;font-size:12px;border-radius:0 0 10px 10px;}span.bottom-l {overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}.n-collect-item-bottom {position:absolute;bottom:0;left:0;width:100%;height:25px;background:var(--theme-color);border-radius:0 0 var(--main-radius);font-size:13px;color:#fff;text-shadow:0 2px 2px rgba(0,0,0,.16);display:flex;-webkit-box-align:center;align-items:center;-webkit-box-pack:justify;justify-content:space-between;padding:0 18px;z-index:5;justify-content:center;}.jiaobiao2 {position:absolute;top:10px;right:-50px;z-index:1;width:140px;height:20px;background:var(--theme-color);color:#fff;line-height:20px;transform:rotate(45deg);text-align:center;font-size:12px;left:auto;border-radius:0 50px 50px 0;}
        </style>
        <?php
    }
    add_action('wp_head', 'wml_zib_horn_diy_css');
}