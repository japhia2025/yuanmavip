<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 22:09:51
 $ @ 文件路径: \wml-zib-diy\core\functions\feature\wml-comments.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

// 夸夸/随机一言开启
if (wml_zib('comments_kuakua_is', false)||wml_zib('comments_suiji_is', false))
{
    //夸夸/随机一言替换评论模板
    add_filter( 'comments_template', 'wml_comments_template' );
    function wml_comments_template( $comment_template ) {
        return WML_ZIB_BEAUT_DIR_PATH.'/templates/wml-comments.php';
    }

    //显示按钮内容
    function wml_zibll_comments_display($re = ''){
        if(wml_zib('comments_kuakua_is', false)){
            $url = WML_ZIB_BEAUT_DIR_URL."/api/yiyan/yiyan.php?code=kuakua";
            $html = '<link rel="stylesheet" type="text/css" href="'.WML_ZIB_BEAUT_DIR_ASSETS.'/css/kuakua.css">
            <script src="https://at.alicdn.com/t/font_2827587_zt5tfqudn5.js"></script>
            <a class="but btn-input-expand input-image" id="kuakua" href="javascript:;">
                <svg class="icon" aria-hidden="true"><use xlink:href="#icon-kuakua"></use></svg><span class="hide-sm">夸夸</span>
            </a>
            <div class="kuakua-div" style="width: 9999px;height: 99999px;background: #000;z-index: 1031;position: fixed;top: 0;left: 0;opacity: .6;display:none"></div>
            <div class="kuakua-first-box">
                    <div class="kuakua-ei">
                <span class="kuakua-close" title="关闭">
                        <div>
                            <svg fill-rule="evenodd" clip-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="1.414" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" id="close" class="sc-eCImPb iRFNEp"><g fill="none" fill-rule="evenodd" stroke="currentColor"><path d="M7.99 7.99L1 1l6.99 6.99L1 14.98l6.99-6.99zm0 0L15 15 7.99 7.99 14.98 1 7.99 7.99z" stroke="currentColor"></path></g></svg>
                        </div>
                    </span>
                <div>
                    <div class="kuakua-column">
                    <section class="kuakua-headerIcon"><svg class="icon kuakua-icon" aria-hidden="true">
                        <use xlink:href="#icon-kuakua"></use></svg>
                    </section>
                    <span size="16" color="black4" class="kuakua-headerTitle">夸夸</span>
                    </div>
                </div>
                <div  style="position: relative;display: block;">
                    <div>
                    <section class="kuakua-modal-body">
                        <section class="kuakua-contentBox">
                            <span size="18" color="black4" class="kuakua-comment">还有吗！没看够！</span>
                        <button type="button" class="kuakua-cancelBtn">换一换</button>
                        </section>
                        <button type="button" class="kuakua-confirmBtn">夸夸TA</button>
                    </section>
                    </div>
                </div>
                </div>
            </div>
            <script>
                $(function(){
                $(".kuakua-cancelBtn").click(function() {
                    $.getJSON("' . $url . '",function(data){
                    $(".kuakua-comment").html(data.text);
                    $("#comment").text(data.text);
                    });
                });
                });
                $(".kuakua-confirmBtn").click(function() {
                $("#submit").trigger("click");
                $(".kuakua-first-box").hide(150);//隐藏速度
                $(".kuakua-div").hide(150);//隐藏速度
                });
                $("#kuakua").click(function (e) {//
                    /*阻止冒泡事件*/
                    $(".kuakua-first-box").show(150);//显示速度
                $(".kuakua-div").show(150);//显示速度
                $.getJSON("' . $url . '",function(data){
                    $(".kuakua-comment").html(data.text);
                    $("#comment").text(data.text);
                });
                e = window.event || e;
                if (e.stopPropagation) {
                    e.stopPropagation();
                } else {
                    e.cancelBubble = true;
                }
                });
                $(".kuakua-close").click(function () {
                $(".kuakua-first-box").hide(150);//隐藏速度
                $(".kuakua-div").hide(150);//隐藏速度
                $("#comment").text("");
                });
            </script>';
            if($re && $re == 'return'){
                return $html;
            }elseif($re && $re == 'echo'){
                    echo $html;
            }
        }
        if(wml_zib('comments_suiji_is', false)){
            $html = '<!--随机评论-->
            <a class="but" onclick="insertComment(); return false;" title="自动输入随机评论"><i class="fa fa-commenting-o"></i><span class="hide-sm">随机</span></a><script>
            // 向评论框输入内容
            function insertComment() {
                // 获取文本框中的原有评论内容
                var originalComment = document.getElementsByName("comment")[0];

                // 检测是否有输入
                if (originalComment.value.trim() !== "") {
                    originalComment.value = "";
                }

                // 从文本文件中获取随机一行文字
                fetch("'.WML_ZIB_BEAUT_DIR_URL.'/api/yiyan/yiyan.php?code=suiji")
                    .then(response => response.text())
                    .then(data => {
                        // 按行拆分文本内容
                        var lines = data.split("\n");

                        // 随机生成一行序号
                        var randomLineIndex = Math.floor(Math.random() * lines.length);

                        // 获取随机一行文字，并去除首尾空白字符
                        var randomLine = lines[randomLineIndex].trim();

                        // 拼接新的评论内容，并换行
                        var newComment = originalComment.value + randomLine + "\n";

                        // 将新的评论内容更新到文本框中
                        originalComment.value = newComment;
                })
                .catch(error => console.error(error));
            }
            </script>';
            if($re && $re == 'return'){
                return $html;
            }elseif($re && $re == 'echo'){
                    echo $html;
            }
        }
    }
}