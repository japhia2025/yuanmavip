<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-14 00:28:32
 $ @ 最后修改: 2024-11-14 16:18:00
 $ @ 文件路径: \wml-zib-diy\core\widgets\wml-newhy.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (wml_zib('newhy_switch', false)) {
    //注册钩子
    add_action('widgets_init', 'register_newhy');
    function register_newhy()
    {
        register_widget('wml_newhy');
    }
    class wml_newhy extends WP_Widget
    {
        public function __construct()
        {
            //定义小工具
            $widget = array(
                'w_id'        => 'wml_newhy',
                'w_name'      => 'WML - 新入会员滚动',
                'classname'   => '',
                'description' => '全宽新注册会员滚动提示条',
            );
            parent::__construct($widget['w_id'], $widget['w_name'], $widget);
        }

        public function widget($args, $instance)
        {
            if (!zib_widget_is_show($instance)) {
                return;
            }
            extract($args);
            
            function DearLicy_notice() 
            {    
                // 执行查询    
                $users = CSF_Module_Wml_Count::new_user();    
                
                $slides = ''; // 初始化$slides变量，用于存储每个用户的HTML代码片段    
                
                // 遍历结果集并生成HTML代码    
                if ($users) {    
                    foreach ($users as $user) {    
                        $user_name = $user->user_login;    
                        $avatar     = zib_get_avatar_box($user->ID, 'avatar-img avatar-mini mr6', false, true);
                        $link     = zib_get_user_home_url($user->ID);
                        $registration_date = date('Y-m-d H:i:s', strtotime($user->user_registered));  
              
                        // 为每个用户生成一个swiper-slide  
                        $slide = '<div class="swiper-slide notice-slide">';  
                        $slide .= '<a class="text-ellipsis" href="'.$link.'">' . $avatar . $user_name . ' 在 ' . $registration_date . ' 加入了本站</a>';  
                        $slide .= '</div>';  
              
                        // 拼接每个用户的HTML代码片段  
                        $slides .= $slide;  
                    }    
                } 
              
                // 构建完整的HTML结构  
                $html = '<div class="theme-box">';  
                $html .= '<div class="swiper-bulletin '.wml_zib('newhy_theme').' radius8">';  
                $html .= '<div class="new-swiper" data-interval="5000" data-direction="vertical" data-loop="true" data-autoplay="1">';  
                $html .= '<div class="swiper-wrapper">';  
                $html .= $slides; // 插入所有用户的HTML代码片段  
                $html .= '</div>';  
                $html .= '<span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>';  
                $html .= '</div>';  
                $html .= '</div>';
                $html .= '</div>';
              
                return $html; // 返回生成的HTML代码    
            }
            echo DearLicy_notice();
        }
    }
}
