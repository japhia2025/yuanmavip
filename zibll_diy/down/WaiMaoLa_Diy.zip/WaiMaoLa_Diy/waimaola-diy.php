<?php
/*
Plugin Name: 外贸啦DIY（子比）
Plugin URI: https://waimao.la
Description: 由Japhia开发的子比主题增强插件，为子比主题提供更多的扩展功能。最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682233
Author: 外贸啦-WaiMaoLa
Version: 1.3
Author URI: https://waimao.la
*/

if (!defined('ABSPATH')) {
    die('-1');
}

// 检查插件文件夹名/PHP版本/Swoole Compiler扩展/Source Guardian Compiler扩展
if(!function_exists('sg_load')){
    wp_die('本插件依赖Source Guardian Compiler扩展，请根据教程安装 <a target="_blank" href="/wp-content/plugins/WaiMaoLa_Diy/help/source-guardian-loader-helper.php">查看教程</a>');
}elseif (extension_loaded('swoole_loader')) {
    wp_die('本插件不与Swoole Compiler扩展兼容，请先完成扩展卸载');
} 

// 注册激活钩子
register_activation_hook(__FILE__, 'wml_zib_check_theme_before_activation');

if (!file_exists(get_theme_file_path('/inc/codestar-framework/codestar-framework.php'))) {
    return;
}else{
    // 定义插件常量
    define('WML_ZIB_BEAUT_DIR_PATH', plugin_dir_path(__FILE__));//插件绝对目录
    define('WML_ZIB_BEAUT_DIR_URL', plugin_dir_url(__FILE__));//插件网址目录
    define("WML_ZIB_DIY_INDEX","WaiMaoLa_Diy/waimaola-diy.php");//插件主文件
    define("WML_VERSION","1.3");//本地版本号
    include_once(plugin_dir_path(__FILE__) ."/core/core.php");//核心文件version
}

//插件插件设置链接
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links)
{
  $url = array('settings' => '<a style="color: green;" href="/wp-admin/admin.php?page=wml_zib_diy">配置插件</a>');
  $links = array_merge($url, $links);
  
  return $links;
});