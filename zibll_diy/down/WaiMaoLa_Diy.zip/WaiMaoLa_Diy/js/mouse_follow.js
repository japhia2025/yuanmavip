/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\js\shubiao.js
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-06-27 21:20:16
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

jQuery(document).ready(function($) {
    var myCursor = jQuery('.mouse-cursor');
    if (myCursor.length) {
        if ($('body')) {
            const e = document.querySelector('.cursor-inner'),
                t = document.querySelector('.cursor-outer');
            let n, i = 0,
                o = !1;
            window.onmousemove = function(s) {
                o || (t.style.transform = "translate(" + s.clientX + "px, " + s.clientY + "px)"), e.style.transform = "translate(" + s.clientX + "px, " + s.clientY + "px)", n = s.clientY, i = s.clientX
            }, $('body').on("mouseenter", "a, .cursor-pointer", function() {
                e.classList.add('cursor-hover'), t.classList.add('cursor-hover')
            }), $('body').on("mouseleave", "a, .cursor-pointer", function() {
                $(this).is("a") && $(this).closest(".cursor-pointer").length || (e.classList.remove('cursor-hover'), t.classList.remove('cursor-hover'))
            }), e.style.visibility = "visible", t.style.visibility = "visible"
        }
    }
})