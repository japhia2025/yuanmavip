<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-28 01:27:47
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-28 01:27:57
 * @FilePath: \WaiMaoLa_Diy\api\links-api.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682233
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */
header('Content-Type: application/json; charset=utf-8');
//毕方资源网：www.bfbke.com
// 检查是否传入了 myurl 和 targeturl 参数
if (!isset($_GET['myurl']) || !isset($_GET['targeturl'])) {
    echo json_encode(['code' => 400, 'data' => ['message' => '缺少参数: myurl 或 targeturl']], JSON_UNESCAPED_UNICODE);
    exit;
}

$myurl = $_GET['myurl'];
$targeturl = $_GET['targeturl'];

// 检查参数是否为空
if (empty($myurl) || empty($targeturl)) {
    echo json_encode(['code' => 400, 'data' => ['message' => '参数 myurl 或 targeturl 不能为空']], JSON_UNESCAPED_UNICODE);
    exit;
}

// 模拟友情链接存在的逻辑。你可以根据实际需求替换这个部分。
function check_link($myurl, $targeturl) {
    // 示例逻辑：简单检查目标URL页面内容中是否包含来源URL
    $html = @file_get_contents($targeturl);
    if ($html === FALSE) {
        return false;
    }
    return strpos($html, $myurl) !== false;
}

if (check_link($myurl, $targeturl)) {
    echo json_encode([
        'code' => 200,
        'data' => [
            'message' => '友情链接存在!',
            'myurl' => $myurl,
            'targeturl' => $targeturl,
            'title' => '检测成功'
        ]
    ], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode([
        'code' => 404,
        'data' => [
            'message' => '友情链接不存在!',
            'myurl' => $myurl,
            'targeturl' => $targeturl,
            'title' => '检测失败'
        ]
    ], JSON_UNESCAPED_UNICODE);
}
?>