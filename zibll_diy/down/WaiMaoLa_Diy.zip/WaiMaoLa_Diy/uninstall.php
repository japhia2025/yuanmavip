<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-05 16:56:13
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-06 22:23:08
 * @FilePath: \WaiMaoLa_Diy\uninstall.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682245
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */
if(!defined('ABSPATH') && !define('WP_UNINSTALL_PLUGIN')){
	exit();
}

//删除配置
delete_option('wml_zib_diy');
delete_option('widget_wml_adstool');
delete_option('widget_wml_countdown');
delete_option('widget_wml_textad');
delete_option('widget_wml_wzad');