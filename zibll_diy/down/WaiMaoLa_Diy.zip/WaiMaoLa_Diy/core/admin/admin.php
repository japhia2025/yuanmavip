<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-05 13:44:10
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-11-08 17:10:22
 * @FilePath: \WaiMaoLa_Diy\core\admin\admin.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682245
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

if (! defined('ABSPATH')) {
	die;
}
if (class_exists('CSF')) {
    $prefix = 'wml_zib_diy';
    $img = '/wp-content/plugins/WaiMaoLa_Diy/img/';
    // 开始构建主菜单
    CSF::createOptions($prefix,array(
            'menu_title' => '子比DIY',
            'framework_title' => '子比DIY',
            'menu_slug' => $prefix,
            'theme' => 'light',
            'show_in_customizer' => true,
            'footer_text' => '<i class="fa fa-fw fa-heart-o" aria-hidden="true"></i>更好的WordPress网站美化方案-外贸啦DIY(子比) V '.WML_VERSION.'',
            'footer_text'        => "由<span style='color:#ff2153;display: inline-block;padding: .35em .65em;font-size: .75em;font-weight: 700;line-height: 1;color: #fff;text-align: center;white-space: nowrap;vertical-align: baseline;border-radius: .25rem;background-color: #dc3545!important;'>Japhia</span>开发并免费共享，最强最全最完美的子比增强插件！ <a href='https://waimao.la/'>WaiMao.La</a>",
            'footer_credit' => '<i class="fa fa-fw fa-heart-o" aria-hidden="true"></i> ',
            'menu_icon' =>'dashicons-analytics',
        )
    );
    // 载入核心文件
    $include_once = array(
        'module',//数据文件
        'options/welcome',//欢迎
        'options/seo',//seo组件
        'options/beautify',//美化组件
        'options/feature',//功能组件
        'options/page',//页面组件
        'options/admins',//后台组件
        'options/widgets',//小工具组件
        'options/diy',//diy代码组件
        'options/about',//关于我们
    );
    foreach ($include_once as $inc) {
        include_once $inc . '.php';
    }
}
require 'updatechecker.php';//检查更新

