<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-05 16:13:05
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-05 16:15:30
 * @FilePath: \WaiMaoLa_Diy\core\admin\options\about.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682245
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */
/*
$jiange = time() - filectime(zibll_Add_ons_dir."/tmp/about.txt");
if($jiange > 86400){
    $filegetopts = array(
        'ssl' => array(
            'verify_peer' => false,
            'verify_peername' => false
        ),
        'https' => array(
            'method' => 'GET',
            'timeout' => 5,
        )
      );
    $about = @file_get_contents("https://www.dift.cn/custom/zibll_Add_ons/gonggao/about.php",false, stream_context_create($filegetopts));
    if($about){
		file_put_contents(zibll_Add_ons_dir."/tmp/about.txt",$about);
	}else{
	    touch(zibll_Add_ons_dir."/tmp/about.txt", time());
	}
}
$about = file_get_contents(zibll_Add_ons_dir."/tmp/about.txt");
    CSF::createSection($prefix, array(
        'id'    => 'About',
        'title' => '关于我们',
        'icon'  => 'fa fa-fw fa-user-circle',
        'fields'      => array(
            array(
                'content' => $about,
                'type'    => 'content',
            ),
    
      )
    ));*/