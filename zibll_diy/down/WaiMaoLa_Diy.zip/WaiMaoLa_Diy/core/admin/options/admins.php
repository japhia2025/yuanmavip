<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-05 16:08:45
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-28 18:02:26
 * @FilePath: \WaiMaoLa_Diy\core\admin\options\admins.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682245
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */
 
 CSF::createSection(
    $prefix,
    array(
        'id' => 'admins',
        'title' => '系统组件',
        'icon' => 'fa fa-wordpress',
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'admins',
        'title' => '前端&优化',
        'icon' => 'fa fa-scissors',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'remove_version',
                'type' => 'switcher',
                'label' => '开启以后网页不再显示WordPress版本号标识符，以免遭受版本号攻击',
                'default' => false,
                'title' => '移除版本号',
            ),
            array(
                'id' => 'remove_file_version',
                'type' => 'switcher',
                'label' => 'WordPress加载JS和CSS文件的时候，会默认添加版本号，如果不想让别人看到版本号，可以移除',
                'default' => false,
                'title' => '移除加载文件版本号',
            ),
            array(
                'id' => 'remove_dns_prefetch',
                'type' => 'switcher',
                'label' => '开启后不显示dns-prefetch预加载链接',
                'default' => false,
                'title' => '移除dns-prefetch',
            ),
            array(
                'id' => 'remove_json_url',
                'type' => 'switcher',
                'label' => '开启以后网页不再显示json链接地址',
                'default' => false,
                'title' => '移除头部json链接',
            ),
            array(
                'id' => 'remove_post_meta',
                'type' => 'switcher',
                'label' => '头部有前后文章链接，没什么用',
                'default' => false,
                'title' => '移除文章页面前后页meta',
            ),
            array(
                'id' => 'remove_post_feed',
                'type' => 'switcher',
                'label' => 'RSS订阅，容易被采集，可以关闭',
                'default' => false,
                'title' => '移除文章头部feed',
            ),
            array(
                'id' => 'remove_dashicons',
                'type' => 'switcher',
                'label' => '移除前台加载的 Dashicons 资源，第三方主题基本用不上',
                'default' => false,
                'title' => '移除Dashicons',
            ),
            array(
                'id' => 'remove_rsd',
                'type' => 'switcher',
                'label' => '移除输出的rsd链接，不用XML-RPC接口可以关闭输出。彻底关闭XML-RPC请在功能开关里面设置。',
                'default' => false,
                'title' => '移除RSD',
            ),
            array(
                'id' => 'remove_wlwmanifest',
                'type' => 'switcher',
                'label' => 'wlwmanifest链接是一个过时的工具了，用于直接发布到wordpress，可以直接移除。',
                'default' => false,
                'title' => '移除wlwmanifest',
            ),
            array(
                'id' => 'remove_shortlink',
                'type' => 'switcher',
                'label' => '短链接标记也是存在每个页面上。包含有指向pageID文章的链接，你要使用的自定义URL这个就可以移除了。',
                'default' => false,
                'title' => '移除短链接',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'admins',
        'title' => '系统&加速',
        'icon' => 'fa fa-scissors',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'ban_translations_api',
                'type' => 'switcher',
                'label' => '进入设置后，会访问WordPress.org查询翻译，非常慢，建议禁用',
                'default' => false,
                'title' => '禁用translations_api',
            ),
            array(
                'id' => 'ban_current_screen',
                'type' => 'switcher',
                'label' => '用于获取当前屏幕的信息',
                'default' => false,
                'title' => '禁用current_screen',
            ),
            array(
                'id' => 'ban_wp_check_php_version',
                'type' => 'switcher',
                'label' => '进入设置后，检查用户当前PHP是否支持，非常慢，建议禁用',
                'default' => false,
                'title' => '禁用wp_check_php_version',
            ),
            array(
                'id' => 'ban_wp_check_browser_version',
                'type' => 'switcher',
                'label' => '进入设置后，检查用户浏览器是否和WordPress兼容，很慢，建议禁用',
                'default' => false,
                'title' => '禁用wp_check_browser_version',
            ),
            array(
                'title'   => '提示：',
                'type'    => "content",
                'content' => '<p>本插件无法完全禁止，wp_check_php_version和wp_check_browser_version，这是导致后台慢的根本原因。</p><p>请手动修改WordPress文件
                方法请看：<font style="color:#fd4c73;"><code><a target="_blank" href="https://www.yuanmavip.com/wordpress-admin-solve.html">点击跳转</a></code></font></p>',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'admins',
        'title' => '功能&禁用',
        'icon' => 'fa fa-scissors',
        'description' => '',
        'fields' => array(
            array(
                'title'   => '接口相关',
                'type'    => "content",
                'content' => '<p>禁用无用的功能，可提升速度</p>',
            ),
            array(
                'id' => 'close_rest_api',
                'type' => 'switcher',
                'label' => '没有小程序等APP功能的，可以关闭',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '屏蔽 REST API',
                'class'   => 'compact',
            ),
            array(
                'id' => 'close_pingback',
                'type' => 'switcher',
                'label' => '别人复制了你的网站内容，对方也是WordPress的话，你会收到一条系统留言',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '屏蔽 Trackbacks/Pingback',
                'class'   => 'compact',
            ),
            array(
                'id' => 'close_xml_rpc',
                'type' => 'switcher',
                'label' => 'WordPress对接第三方应用接口，没有可以关闭',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '关闭XML-RPC接口',
                'class'   => 'compact',
            ),
            array(
                'id' => 'close_emoji',
                'type' => 'switcher',
                'label' => 'Emoji表情为WordPress默认表情功能，会在前台页面加载静态资源"',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '禁用Emoji表情',
                'class'   => 'compact',
            ),
            array(
                'title'   => '文章与编辑',
                'type'    => "content",
                'content' => ' ',
            ),
            array(
                'id' => 'close_revision',
                'type' => 'switcher',
                'label' => '修订版本占用数据库，打乱文章ID，可以关闭"',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '关闭保存修订版本',
                'class'   => 'compact',
            ),
            array(
                'id' => 'close_auto_save_post',
                'type' => 'switcher',
                'label' => '自动保存占用数据库，打乱文章ID，可以关闭',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '关闭文章自动保存',
                'class'   => 'compact',
            ),
            array(
                'id' => 'close_image_height_limit',
                'type' => 'switcher',
                'label' => '超过WordPress规定高度的图片，会被WordPress压缩，建议关闭',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '关闭图像高度限制',
                'class'   => 'compact',
            ),
            array(
                'id' => 'close_image_creat_size',
                'type' => 'switcher',
                'label' => '上传图片后，WordPress会生成多种图片尺寸大小，建议禁止',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '禁止生成多种图像尺寸',
                'class'   => 'compact',
            ),
            array(
                'id' => 'close_image_srcset',
                'type' => 'switcher',
                'label' => '关闭生成多种尺寸后，建议关闭',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '禁止图片设置多种尺寸',
                'class'   => 'compact',
            ),
            array(
                'id' => 'close_image_attributes',
                'type' => 'switcher',
                'label' => '插入图片的时候会添加 width、height、class属性，会导致图片宽高被定死，建议禁止',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '禁止插入图片添加属性',
                'class'   => 'compact',
            ),
            array(
                'id' => 'close_transcoding',
                'type' => 'switcher',
                'label' => 'WordPress会转义内容，英文符号转中文符号。还拖慢速度，建议关闭',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '关闭字符转码',
                'class'   => 'compact',
            ),
            array(
                'id' => 'close_auto_embeds',
                'type' => 'switcher',
                'label' => '插入url会被自动转换成卡片，一键嵌入内容',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '禁止Auto Embeds',
                'class'   => 'compact',
            ),
            array(
                'id' => 'close_post_embeds',
                'type' => 'switcher',
                'label' => '插入url会自动转换成文章卡片',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '禁止文章Embeds',
                'class'   => 'compact',
            ),
            array(
                'id' => 'restore_gutenberg',
                'type' => 'switcher',
                'label' => '还原经典编辑器',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '禁止新版古藤堡编辑器',
                'class'   => 'compact',
            ),
            array(
                'id' => 'restore_widget_gutenberg',
                'type' => 'switcher',
                'label' => 'WordPress 5.8 及之后版本小工具模块换变成了区块编辑器管理，建议禁止',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '禁止小工具区块编辑器',
                'class'   => 'compact',
            ),
            array(
                'title'   => '升级和更新',
                'type'    => "content",
                'content' => ' ',
            ),
            array(
                'id' => 'close_core_update',
                'type' => 'switcher',
                'label' => '禁止WordPress自身检查更新，加快运行速度',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '关闭WordPress核心更新',
                'class'   => 'compact',
            ),
            array(
                'id' => 'close_theme_update',
                'type' => 'switcher',
                'label' => '彻底关闭主题后端自动更新检查',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '关闭主题自动更新',
                'class'   => 'compact',
            ),
            array(
                'id' => 'close_plugin_update',
                'type' => 'switcher',
                'label' => '彻底关闭插件后端自动更新检查',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '关闭插件自动更新',
                'class'   => 'compact',
            ),
            array(
                'title'   => '邮件相关',
                'type'    => "content",
                'content' => ' ',
            ),
            array(
                'id' => 'close_mail_update_user_info_note',
                'type' => 'switcher',
                'label' => '如果邮件服务器可用，用户修改密码或者邮箱等信息后，会发邮件通知你',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '关闭用户信息邮件通知',
                'class'   => 'compact',
            ),
            array(
                'id' => 'close_mail_register_note',
                'type' => 'switcher',
                'label' => '如果邮件服务器可用，用户注册就会发邮件通知你',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '关闭注册邮件通知',
                'class'   => 'compact',
            ),
            array(
                'id' => 'close_email_check',
                'type' => 'switcher',
                'label' => '如果邮件服务器可用，过一段时间就会要求你验证邮箱',
                'default' => false,
                'title' => ' ',
                'subtitle'=> '屏蔽定期邮箱验证',
                'class'   => 'compact',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'admins',
        'title' => '外观&移除',
        'icon' => 'fa fa-scissors',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'remove_login_logo',
                'type' => 'switcher',
                'label' => '开启后，将关闭WordPress默认登录页面的logo',
                'default' => false,
                'title' => '移除后台登录页面logo',
            ),
            array(
                'id' => 'close_admin_bar',
                'type' => 'switcher',
                'label' => '开启后将关闭前台顶部工具条，有的主题可能原本就不显示',
                'default' => false,
                'title' => '移除前台顶部管理工具条',
            ),
            array(
                'id' => 'close_login_translate',
                'type' => 'switcher',
                'label' => 'WordPress 6.0以上版本自带登录页面会显示语言切换',
                'default' => false,
                'title' => '移除登录页面语言选择',
            ),
            array(
                'id' => 'remove_dashboard_icon',
                'type' => 'switcher',
                'label' => '开启后将关闭后台顶部左边的WordPress的logo',
                'default' => false,
                'title' => '移除左上角WordPress的icon',
            ),
            array(
                'id' => 'remove_dashboard_content',
                'type' => 'switcher',
                'label' => '开启后将清空仪表盘默认的内容模块，官方版本通知和其他插件生成的除外',
                'default' => false,
                'title' => '移除仪表盘模块',
            ),
            array(
                'id' => 'remove_houtai_xuanxiang',
                'type' => 'switcher',
                'label' => '开启后仪表盘的右上角选项按钮即可被隐藏',
                'default' => false,
                'title' => '移除后台选项按钮',
            ),
            array(
                'id' => 'remove_houtai_bangzhu',
                'type' => 'switcher',
                'label' => '开启后仪表盘的右上角帮助按钮即可被隐藏',
                'default' => false,
                'title' => '移除后台帮助按钮',
            ),
            array(
                'id' => 'remove_houtai_banbenhao',
                'type' => 'switcher',
                'label' => '开启后后台右下角版本号即可被隐藏',
                'default' => false,
                'title' => '移除后台右下角版本号',
            ),
            array(
                'id' => 'remove_houtai_ganxiesy',
                'type' => 'switcher',
                'label' => '开启内容区块左下角感谢您使用wordpress创作可被隐藏',
                'default' => false,
                'title' => '移除感谢您使用wordpress创作',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'admins',
        'title' => '菜单&隐藏',
        'icon' => 'fa fa-scissors',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'hide_menu_dashboard',
                'type' => 'switcher',
                'label' => '开启后仪表盘菜单将被隐藏，不会在后台显示。',
                'default' => false,
                'title' => '隐藏仪表盘菜单',
            ),
            array(
                'id' => 'hide_menu_upload',
                'type' => 'switcher',
                'label' => '开启后多媒体菜单将被隐藏，不会在后台显示。',
                'default' => false,
                'title' => '隐藏多媒体菜单',
            ),
            array(
                'id' => 'hide_menu_page',
                'type' => 'switcher',
                'label' => '开启后页面菜单将被隐藏，不会在后台显示。',
                'default' => false,
                'title' => '隐藏页面菜单',
            ),
            array(
                'id' => 'hide_menu_comments',
                'type' => 'switcher',
                'label' => '开启后评论菜单将被隐藏，不会在后台显示。',
                'default' => false,
                'title' => '隐藏评论菜单',
            ),
            array(
                'id' => 'hide_menu_links',
                'type' => 'switcher',
                'label' => '开启后链接菜单将被隐藏，不会在后台显示。',
                'default' => false,
                'title' => '隐藏链接菜单',
            ),
            array(
                'id' => 'hide_menu_plugins',
                'type' => 'switcher',
                'label' => '开启后插件菜单将被隐藏，不会在后台显示。',
                'default' => false,
                'title' => '隐藏插件菜单',
            ),
            array(
                'id' => 'hide_menu_themes',
                'type' => 'switcher',
                'label' => '开启后外观菜单将被隐藏，不会在后台显示。',
                'default' => false,
                'title' => '隐藏外观菜单',
            ),
            array(
                'id' => 'hide_menu_users',
                'type' => 'switcher',
                'label' => '开启后用户菜单将被隐藏，不会在后台显示。',
                'default' => false,
                'title' => '隐藏用户菜单',
            ),
            array(
                'id' => 'hide_menu_tools',
                'type' => 'switcher',
                'label' => '开启后工具菜单将被隐藏，不会在后台显示。',
                'default' => false,
                'title' => '隐藏工具菜单',
            ),
            array(
                'id' => 'hide_menu_general',
                'type' => 'switcher',
                'label' => '开启后设置菜单将被隐藏，不会在后台显示。',
                'default' => false,
                'title' => '隐藏设置菜单',
            ),
            array(
                'id' => 'hide_menu_edit',
                'type' => 'switcher',
                'label' => '开启后主题插件安装编辑将被隐藏，不会在后台显示。',
                'default' => false,
                'title' => '隐藏主题插件安装编辑',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'admins',
        'title' => '后台&美化',
        'icon' => 'fa fa-pie-chart',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'admins_switch',
                'type' => 'switcher',
                'label' => '启用后，可改变后台默认的风格',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'title' => ' ',
                'id' => 'admins_select',
                'dependency' => array('admins_switch', '!=', ''),
                'default' => '1',
                'inline' => true,
                'type' => 'image_select',
                'options' => array(
                    '1' => $img . '/admin/admins_zib.jpg',
                    '2' => $img . '/admin/admins_lv.jpg',
                    '3' => $img . '/admin/admins_kuhei.jpg',
                    '4' => $img . '/admin/admins_hong.jpg',
                ),
            ),
        )
    )
);