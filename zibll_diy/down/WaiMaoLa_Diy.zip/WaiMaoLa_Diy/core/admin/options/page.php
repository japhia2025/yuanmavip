<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-05 16:05:48
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-11-02 00:30:29
 * @FilePath: \WaiMaoLa_Diy\core\admin\options\page.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682233
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

CSF::createSection(
    $prefix,
    array(
        'id' => 'page',
        'title' => '页面组件',
        'icon' => 'fa fa-internet-explorer',
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'page',
        'title' => '视频&解析',
        'icon' => 'fa fa-video-camera',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'page_video',
                'type' => 'switcher',
                'label' => '启用后，可在创建页面时使用 外贸啦DIY-视频解析 模板',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('page_video', '!=', ''), 
                'title' => '项目名称',
                'id' => 'page_video_name',
                'desc' => '',
                'default' => '外贸啦 - 全网短视频/图集无水印在线解析',
                'type' => 'text',
            ),
            array(
                'dependency' => array('page_video', '!=', ''),
                'title'      => '视频支持',
                'desc'       => '请用半角逗号,分割',
                'id'         => 'page_video_v',
                'default'    => '皮皮虾,抖音,微视,快手,6间房,哔哩哔哩,微博,绿洲,度小视,开眼,陌陌,皮皮搞笑,全民k歌,逗拍,虎牙,新片场,哔哩哔哩,Acfun,美拍,西瓜视频,火山小视频',
                'sanitize'   => false,
                'type'       => 'textarea',
                'attributes' => array(
                    'rows' => 2,
                ),
            ),
            array(
                'dependency' => array('page_video', '!=', ''),
                'title'      => '图集支持',
                'desc'       => '请用半角逗号,分割',
                'id'         => 'page_video_p',
                'default'    => '抖音,快手,微博,皮皮虾,最右,皮皮搞笑',
                'sanitize'   => false,
                'type'       => 'textarea',
                'attributes' => array(
                    'rows' => 2,
                ),
            ),
            array(
                'dependency' => array('page_video', '!=', ''), 
                'title' => '视频API接口',
                'id' => 'page_video_vapi',
                'desc' => '',
                'default' => 'https://tenapi.cn/v2/video?url=',
                'desc' => '格式：<font style="color:#fd4c73;"><code>https://tenapi.cn/v2/video?url=</code></font>，也可以使用非第三方的自制接口。',
                'type' => 'text',
            ),
            array(
                'dependency' => array('page_video', '!=', ''), 
                'title' => '图集API接口',
                'id' => 'page_video_papi',
                'desc' => '',
                'default' => 'https://tenapi.cn/v2/images?url=',
                'desc' => '格式：<font style="color:#fd4c73;"><code>https://tenapi.cn/v2/images?url=</code></font>，也可以使用非第三方的自制接口。',
                'type' => 'text',
            ),
            array(
                'dependency' => array('page_video', '!=', ''),
                'title'   => '使用权限设置',
                'type'    => "content",
                'content' => '<p>以下为视频解析权限设置',
            ),
            array(
                'dependency' => array('page_video', '!=', ''),
                'id' => 'page_video_login',
                'type' => 'switcher',
                'label' => '启用后，游客无法使用',
                'default' => false,
                'title' => '登录使用',
            ),
            array(
                'dependency' => array('page_video', '!=', ''),
                'id' => 'page_video_cs',
                'type' => 'switcher',
                'label' => '启用后，可设定自定义解析次数',
                'default' => false,
                'title' => '次数限制',
            ),
            array(
                'dependency' => array(
                    array('page_video', '!=', ''),
                    array('page_video_cs', '!=', ''),
                ),
                'title'   => ' ',
                'subtitle'   => '游客',
                'id'      => 'page_video_cs0',
                'class'       => 'compact',
                'default' => '1',
                'type'    => 'number',
                'unit'    => '次/天',
            ),
            array(
                'dependency' => array(
                    array('page_video', '!=', ''),
                    array('page_video_cs', '!=', ''),
                ),
                'title'   => ' ',
                'subtitle'   => '普通会员',
                'id'      => 'page_video_cs9',
                'class'       => 'compact',
                'default' => '3',
                'type'    => 'number',
                'unit'    => '次/天',
            ),
            array(
                'dependency' => array(
                    array('page_video', '!=', ''),
                    array('page_video_cs', '!=', ''),
                ),
                'title'   => ' ',
                'subtitle'   => '一级会员',
                'id'      => 'page_video_cs1',
                'class'       => 'compact',
                'default' => '8',
                'type'    => 'number',
                'unit'    => '次/天',
            ),
            array(
                'dependency' => array(
                    array('page_video', '!=', ''),
                    array('page_video_cs', '!=', ''),
                ),
                'title'   => ' ',
                'subtitle'   => '二级会员',
                'id'      => 'page_video_cs2',
                'class'       => 'compact',
                'default' => '88',
                'type'    => 'number',
                'unit'    => '次/天',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'page',
        'title' => '封面&制作',
        'icon' => 'fa fa-fw fa-picture-o',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'page_thumbnail',
                'type' => 'switcher',
                'label' => '启用后，可在创建页面时使用 外贸啦DIY-封面制作 模板',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('page_thumbnail', '!=', ''),
                'id' => 'page_thumbnail_dl',
                'type' => 'switcher',
                'label' => '启用后，游客不可用，需登录',
                'default' => false,
                'title' => '登录可用',
            ),
            array(
                'dependency' => array('page_thumbnail', '!=', ''),
                'id' => 'page_thumbnail_rz',
                'type' => 'switcher',
                'label' => '启用后，只有认证用户才可以使用',
                'default' => false,
                'title' => '认证可用',
            ),
            array(
                'dependency' => array('page_thumbnail', '!=', ''),
                'title'   => '图库API',
                'type'    => "content",
                'content' => '<p>需要到<font style="color:#fd4c73;"><code>https://unsplash.com/</code></font>申请API接口，</p>
                <p>打开<font style="color:#fd4c73;"><code>page/thumbnail/static/js/main.1b350163.js</code></font>搜索<font style="color:#fd4c73;"><code>unsplash-api接口</code></font>替换即可</p>',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'page',
        'title' => '封禁&黑屋',
        'icon' => 'fa fa-fw fa-user-times',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'page_heiwu',
                'type' => 'switcher',
                'label' => '启用后，可在创建页面时使用 外贸啦DIY-封禁黑屋 模板',
                'default' => false,
                'title' => '页面模板',
            ),
            array(
                'id' => 'page_heiwu_gj',
                'type' => 'switcher',
                'label' => '启用后，可在外观-小工具使用封禁黑屋',
                'default' => false,
                'title' => '侧边工具',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'page',
        'title' => '友链&检测',
        'icon' => 'fa fa-fw fa-chain-broken',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'page_links',
                'type' => 'switcher',
                'label' => '启用后，可在创建页面时使用 外贸啦DIY-友链检测 模板',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('page_links', '!=', ''), 
                'title' => '顶部背景',
                'desc' => '请填写/上传图片地址',
                'id' => 'links_bj',
                'preview' => true,
                'library' => 'image',
                'type' => 'upload',
                'default' => $img.'page/video_background.jpg',
            ),
            array(
                'dependency' => array('page_links', '!=', ''), 
                'title' => '链接介绍',
                'id' => 'links_js',
                'desc' => '',
                'default' => '专注优质网络资源分享的技术博客',
                'type' => 'text',
            ),
            array(
                'dependency' => array('page_links', '!=', ''), 
                'title' => '链接LOGO',
                'id' => 'links_logo',
                'desc' => '',
                'default' => get_bloginfo('url').'/logo.png',
                'type' => 'text',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'page',
        'title' => '旗下&站点',
        'icon' => 'fa fa-fw fa-bars',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'page_qixia',
                'type' => 'switcher',
                'label' => '启用后，可在创建页面时使用 外贸啦DIY-旗下站点 模板',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('page_qixia', '!=', ''), 
                'title' => '导航名称',
                'id' => 'qixia_name',
                'desc' => '',
                'default' => '我的旗下站点',
                'type' => 'text',
                'class' => 'mini-input',
            ),
            array(
                'dependency' => array('page_qixia', '!=', ''), 
                'title' => '顶部背景',
                'desc' => '请填写/上传图片地址',
                'id' => 'qixia_bj',
                'preview' => true,
                'library' => 'image',
                'type' => 'upload',
                'default' => $img.'page/video_background.jpg',
            ),
            array(
                'dependency' => array('page_qixia', '!=', ''),
                'title'                  => '站点列表',
                'id'                     => 'qixia_zd',
                'type'                   => 'group',
                'accordion_title_number' => '1',
                'sanitize'               => false,
                'button_title'           => '添加站点',
                'default'                => array(
                    array(
                        'name' => '外贸子站',
                        'info' => '数字移民，外贸工具',
                        'icon'      => 'fa fa-flag',
                        'color' => '#A845F7',
                        'link'     => array(
                            'url'=> 'https://waimao.la/',
                            'text'=> '外贸啦',
                            'target'=> '_blank',
                        ),
                    ),
                ),
                'fields'                 => array(
                    array(
                        'title' => '站点名称',
                        'id' => 'name',
                        'desc' => '',
                        'default' => '',
                        'type' => 'text',
                        'class' => 'mini-input',
                    ),
                    array(
                        'title' => '简短介绍',
                        'id' => 'info',
                        'desc' => '',
                        'default' => '',
                        'type' => 'text',
                        'class' => 'mini-input',
                    ),
                    array(
                        'id'           => 'icon',
                        'type'         => 'icon',
                        'desc'         => '按钮默认显示的图标，这里可以选择内置图标',
                        'title'        => '按钮默认图标',
                        'button_title' => '选择预置图标',
                        'default'      => 'fa fa-flag',
                    ),
                    array(
                        'id'      => 'color',
                        'type'    => 'color',
                        'class' => 'compact',
                        'title'   => '图标颜色',
                        'default' => '#A845F7',
                    ),
                    array(
                        'id'           => 'link',
                        'type'         => 'link',
                        'title'        => '跳转链接',
                        'default'      => array(),
                        'add_title'    => '添加链接',
                        'edit_title'   => '编辑链接',
                        'remove_title' => '删除链接',
                    ),
                ),
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'page',
        'title' => '会员&说明',
        'icon' => 'fa fa-diamond',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'vip_info',
                'type' => 'switcher',
                'label' => '启用后，可在创建页面时使用 外贸啦DIY-会员说明 模板',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('vip_info', '!=', ''), 
                'title' => 'VIP名称1',
                'id' => 'vip_name1',
                'desc' => '',
                'default' => '黄钻会员',
                'type' => 'text',
                'class' => 'mini-input',
            ),
            array(
                'dependency' => array('vip_info', '!=', ''), 
                'title' => '支付价格',
                'id' => 'vip_rmb1',
                'default' => '9.9',
                'type' => 'text',
                'class' => 'mini-input compact',
            ),
            array(
                'dependency' => array('vip_info', '!=', ''), 
                'title' => '有效时间',
                'id' => 'vip_time1',
                'default' => '月',
                'type' => 'text',
                'class' => 'mini-input compact',
            ),
            array(
                'dependency' => array('vip_info', '!=', ''), 
                'title' => '加入人数',
                'id' => 'vip_rs1',
                'desc' => '已加入该VIP会员的人数',
                'default' => '43',
                'type' => 'text',
                'class' => 'mini-input compact',
            ),
            array(
                'dependency' => array('vip_info', '!=', ''), 
                'title' => 'VIP名称2',
                'id' => 'vip_name2',
                'desc' => '',
                'default' => '黑钻会员',
                'type' => 'text',
                'class' => 'mini-input',
            ),
            array(
                'dependency' => array('vip_info', '!=', ''), 
                'title' => '支付价格',
                'id' => 'vip_rmb2',
                'default' => '19.9',
                'type' => 'text',
                'class' => 'mini-input compact',
            ),
            array(
                'dependency' => array('vip_info', '!=', ''), 
                'title' => '有效时间',
                'id' => 'vip_time2',
                'default' => '月',
                'type' => 'text',
                'class' => 'mini-input compact',
            ),
            array(
                'dependency' => array('vip_info', '!=', ''), 
                'title' => '加入人数',
                'id' => 'vip_rs2',
                'desc' => '已加入该VIP会员的人数',
                'default' => '89',
                'type' => 'text',
                'class' => 'mini-input compact',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'page',
        'title' => '标签&热门',
        'icon' => 'fa fa-fw fa-tasks',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'page_tags',
                'type' => 'switcher',
                'label' => '启用后，可在创建页面时使用 外贸啦DIY-热门标签 模板',
                'default' => false,
                'title' => '是否启用',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'page',
        'title' => '站点&地图',
        'icon' => 'fa fa-fw fa-map-marker',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'page_map',
                'type' => 'switcher',
                'label' => '启用后，可在创建页面时使用 外贸啦DIY-站点地图 模板',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('page_map', '!=', ''),
                'title' => '显示数量',
                'desc' => '留空则显示所有',
                'id' => 'page_map_num',
                'default' => '',
                'type' => 'text',
                'class' => 'mini-input',
            ),
            array(
                'dependency' => array('page_map', '!=', ''),
                'id'          => 'page_map_cats',
                'title'       => '排除分类',
                'default'     => '',
                'options'     => 'categories',
                'placeholder' => '输入关键词以搜索分类',
                'chosen'      => true,
                'ajax'        => true,
                'multiple'    => true,
                'settings'    => array(
                    'min_length' => 2,
                ),
                'type'        => 'select',
            ),
            array(
                'dependency' => array('page_map', '!=', ''),
                'id'          => 'page_map_posts',
                'title'       => '排除文章',
                'default'     => '',
                'options'     => 'posts',
                'placeholder' => '输入文章标题关键词以搜索文章',
                'chosen'      => true,
                'ajax'        => true,
                'multiple'    => true,
                'settings'    => array(
                    'min_length' => 2,
                ),
                'type'        => 'select',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'page',
        'title' => '说说&微语',
        'icon' => 'fa fa-heart',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'page_shuoshuo',
                'type' => 'switcher',
                'label' => '启用后，可在创建页面时使用 外贸啦DIY-说说 模板',
                'default' => false,
                'title' => '说说',
            ),
            array(
                'dependency' => array('page_shuoshuo', '!=', ''),
                'title' => ' ',
                'id' => 'page_shuoshuo_t',
                'default' => '1',
                'inline' => true,
                'type' => 'radio',
                'options' => array(
                    '1' => __('【样式一】', 'zib_language'),
                    '2' => __('【样式二】', 'zib_language'),
                ),
                'class' => 'compact',
            ),
            array(
                'id' => 'page_weiyu',
                'type' => 'switcher',
                'label' => '启用后，可在创建页面时使用 外贸啦DIY-微语 模板',
                'default' => false,
                'title' => '微语',
            ),
            array(
                'dependency' => array('page_weiyu', '!=', ''), 
                'title' => 'QQ号',
                'id' => 'page_weiyu_qq',
                'default' => '181682233',
                'type' => 'text',
                'class' => 'mini-input compact',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'page',
        'title' => '赞助&打赏',
        'icon' => 'fa fa-paypal',
        'description' => '',
        'fields' => array(
            array(
                'content' => '
                <div style="color:#ff2153;"><i class="fa fa-fw fa-info-circle fa-fw"></i>特别提醒：请将付款码自己生成对应金额重命名后上传至/wp-content/plugins/WaiMaoLa_Diy/img/pay/</div>',
                'style' => 'warning',
                'type' => 'submessage',
            ),
            array(
                'id' => 'zanzu-page',
                'type' => 'switcher',
                'label' => '启用后，可在创建页面时使用 外贸啦DIY-站长赞助 模板',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('zanzu-page', '!=', ''), 
                'title' => '站点名称',
                'id' => 'zanzu-page-name',
                'desc' => '',
                'default' => '外贸啦',
                'type' => 'text',
            ),
            array(
                'dependency' => array('zanzu-page', '!=', ''), 
                'title' => '站点网址',
                'id' => 'zanzu-page-url',
                'desc' => '',
                'default' => 'waimao.la',
                'type' => 'text',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'page',
        'title' => '颜色&取色',
        'icon' => 'fa fa-adjust',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'page_colour',
                'type' => 'switcher',
                'label' => '启用后，可在创建页面时使用 外贸啦DIY-颜色取色 模板',
                'default' => false,
                'title' => '是否启用',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'page',
        'title' => '资源&下载',
        'icon' => 'fa fa-folder-open',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'ziyuan-page',
                'type' => 'switcher',
                'label' => '启用后，可在创建页面时使用 外贸啦DIY-资源下载 模板',
                'default' => false,
                'title' => '是否启用',
            ),
            array(
                'dependency' => array('ziyuan-page', '!=', ''), 
                'title' => '下载介绍',
                'id' => 'ziyuan-jiesao',
                'default' => '<div style="padding:0 15px 15px 15px">
        <div class="popTipBox">
          下载的资源使用前请仔细核对文字内容,如资源中包含国旗、国徽、党徽、天安门等图片,请在《中华人民共和国国旗法》、《中华人民共和国国徽法》等相关法律法规规定范围内使用,请保证国旗、国徽、天安门等图案的完整性,如因违规使用造成的一切经济损失及法律责任,将由您自行承担。
        </div>
      </div>
      <dl class="download-notice clearfix zib-widget">
        <dt class="fl download-notice-title"><span
            class="inline-block vertical-middle mr5 mb5 download-notice-ico ico"></span>注意事项</dt>
        <dd class="download-notice-detail">
          <p><b class="red1">本站大部分下载资源收集于网络，只做学习和交流使用，版权归原作者所有。</b></p>
          <p>若为付费资源，请在下载后24小时之内自觉删除，若作商业用途，请到原网站购买，由于未及时购买和付费发生的侵权行为，与本站无关。</p>
          <p>本站发布的内容若侵犯到您的权益，请联外贸啦删除，我们将及时处理！</p>
          <p><b>如下载有问题请重新下载，文件自下载之日起，可免费重复下载。若文件有问题，请及时联系夕阳处理。</b></p>
        </dd>
      </dl>',
                'type' => 'textarea',
                'attributes' => array(
                    'rows' => 5,
                ),
            ),
        )
    )
);