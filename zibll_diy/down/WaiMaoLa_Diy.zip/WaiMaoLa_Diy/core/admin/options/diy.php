<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-05 16:10:03
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-16 01:03:03
 * @FilePath: \WaiMaoLa_Diy\core\admin\options\diy.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682245
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

CSF::createSection(
    $prefix,
    array(
        'id' => 'diy',
        'title' => '自定义代码',
        'icon' => 'fa fa-fw fa-code',
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'diy',
        'title' => 'CSS代码',
        'icon' => 'fa fa-fw fa-code',
        'description' => '',
        'fields' => array(
    array(
        'type' => 'submessage',
        'style' => 'warning',
        'content' => '<h3 style="color:#fd4c73;">自定义CSS代码，将会输出在网站顶部</h3>
        <p>仅需填写CSS代码以及该样式名称即可</p>',
    ),
    array(
        'title'   => '',
        'label'   => '',
        'id'      => 'css_group',
        'type'          => 'group',
        'button_title'  => '添加样式',
        'fields' => array(
                array(
                    'title'   => '名称',
                    'id'      => 'css_title' ,
                    'default' => '',
                    'type'    => 'text',
                ),
                array(
                    'title'   => '是否启用？',
                    'id'      => 'css_switcher' ,
                    'default' => true,
                    'type'    => 'switcher',
                ),
                array(
                    'title'    => '代码',
                    'subtitle' => '直接写样式代码，不用添加&lt;style&gt;标签',
                    'id'       => 'css_code',
                    'settings' => array(
                        'mode'  => 'css',
                        'theme' => 'dracula',
                    ),
                    'sanitize' => false,
                    'type'     => 'code_editor',
                ),
            ),
        ),
    )
));

CSF::createSection(
    $prefix,
    array(
        'parent' => 'diy',
        'title' => 'JS代码',
        'icon' => 'fa fa-fw fa-code',
        'description' => '',
        'fields' => array(
    array(
        'type' => 'submessage',
        'style' => 'warning',
        'content' => '<h3 style="color:#fd4c73;">自定义JavaScript代码，将会输出在网站底部</h3>
        <p>仅需填写JavaScript代码以及该样式名称即可</p>',
    ),
    array(
        'title'   => '',
        'label'   => '',
        'id'      => 'javascript_group',
        'type'          => 'group',
        'button_title'  => '添加样式',
        'fields' => array(
                array(
                    'title'   => '名称',
                    'id'      => 'javascript_title' ,
                    'default' => '',
                    'type'    => 'text',
                ),
                array(
                    'title'   => '是否启用？',
                    'id'      => 'javascript_switcher' ,
                    'default' => true,
                    'type'    => 'switcher',
                ),
                array(
                    'title'    => '代码',
                    'subtitle' => '直接填写JS代码，不需要添加&lt;script&gt;标签',
                    'id'       => 'javascript_code',
                    'settings' => array(
                        'mode'  => 'javascript',
                        'theme' => 'dracula',
                    ),
                    'sanitize' => false,
                    'type'     => 'code_editor',
                ),
            ),
        ),
    )
));

CSF::createSection(
    $prefix,
    array(
        'parent' => 'diy',
        'title' => 'HTML代码',
        'icon' => 'fa fa-fw fa-code',
        'description' => '',
        'fields' => array(
    array(
        'type' => 'submessage',
        'style' => 'warning',
        'content' => '<h3 style="color:#fd4c73;">自定义HTML代码，将会输出在网站头部或底部</h3>',
    ),
    array(
        'title'   => '',
        'label'   => '',
        'id'      => 'html_group',
        'type'          => 'group',
        'sanitize' => false,
        'button_title'  => '添加样式',
        'fields' => array(
                array(
                    'title'   => '名称',
                    'id'      => 'html_title' ,
                    'default' => '',
                    'type'    => 'text',
                ),
                array(
                    'title'   => '是否启用？',
                    'id'      => 'html_switcher' ,
                    'default' => true,
                    'type'    => 'switcher',
                ),
                array(
                    'title'   => '模块显示位置',
                    'id'      => 'html_locate',
                    'default' => 'head',
                    'type'    => "radio",
                    'options' => array(
                        'head'       => '顶部优先加载',
                        'footer'    => '底部延迟加载',
                    ),
                ),
                array(
                    'title'    => '代码',
                    'subtitle' => '直接填写html代码，需要注意代码闭合',
                    'id'       => 'html_code',
                    'settings' => array(
                        'theme' => 'dracula',
                    ),
                    'sanitize' => false,
                    'type'     => 'code_editor',
                ),
            ),
        ),
    )
));