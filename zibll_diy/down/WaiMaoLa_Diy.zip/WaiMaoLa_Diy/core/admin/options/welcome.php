<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-05 14:28:26
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-11-08 10:56:07
 * @FilePath: \WaiMaoLa_Diy\core\admin\options\welcome.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682245
 */

 CSF::createSection(
    $prefix,
    array(
        'id' => 'welcome',
        'title' => '欢迎使用',
        'icon' => 'fa fa-star',
    )
);
 CSF::createSection($prefix,array(
        'parent' => 'welcome',
        'title' => '公告&说明',
        'icon' => 'fa fa-fw fa-bell',
        'fields' => CSF_Module_Wml_Zib_admin::thank(),
    )
);
CSF::createSection($prefix, array(
    'parent' => 'welcome',
    'title'       => '系统&环境',
    'icon'        => 'fa fa-fw fa-windows',
    'fields' => array(
        array(
            'type' => 'content',
            'content' => CSF_Module_Wml_Zib_admin::system(),
        ),
    )
));


CSF::createSection($prefix, array(
        'parent' => 'welcome',
        'title'  => '备份&恢复',
        'icon'   => 'fa fa-fw fa-clipboard',
        'fields' => CSF_Module_Wml_Zib_admin::backup(),
    )
);


?>