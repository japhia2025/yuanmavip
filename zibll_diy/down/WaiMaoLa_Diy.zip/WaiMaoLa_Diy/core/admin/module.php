<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-05 13:44:10
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-11-08 09:38:35
 * @FilePath: \WaiMaoLa_Diy\core\admin\module.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682245
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */
class CSF_Module_Wml_Zib_admin
{
    public static function thank()
    {
        $thank = array();
        $thank[] = array(
            'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 感谢您的使用，自己动手丰衣足食。</h3>
                    <p>基于子比主题的一个全集合DIY美化插件，大多来源网络。做了大量的优化和改进。无授权，无后门，无任何后台API接口，使用过程无任何其他因素影响。由于同类插件各种鱼龙混杂，倒买倒卖非常多。偷盗他人劳动成果，源码加密摇身一变就拿来收费，我很鄙视这种人。本人向来是支持正版原创的，因此也踩了几次坑，也花了几次小钱购买各种授权，但使用过程都非常失望。要么某个部位不是自己想要的效果，要么加密源码中安插各种AIP接口和后门，一旦对象服务器出现问题或者或者停止维护了，自个的网站也会受影响甚至瘫痪，体验感极差。因此，本人铁了心整理开发出一套最为全面最全的增强插件，拿来自用并分享出来，希望能帮助到大家，同时也希望大家多多支持原创，拒绝盗版倒卖插后门的可耻行为。</p>
                    <div style="margin:10px 14px;"><ul>
                    <li>如有任何疑问和合作意向可以联系QQ：<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=181682233&amp;site=qq&amp;menu=yes">181682233</a></li>
                    <li>如果该插件为您增添了价值，并且你希望支持这个项目，你可以通过 <a target="_blank" href="https://waimao.la/wp-wml/img/wechatpay.jpg">微信</a> 赞助我。</li>
                    <hr><div style="color:#ff2153;"><i class="fa fa-fw fa-info-circle fa-fw"></i>提示：打开过多的美化功能会影响网站速度，请按需开启。部分JS、CSS为公共CDN资源，如失效或加载慢请联系我。</div>
                    </ul></div>',
                    'style' => 'warning',
            'type' => 'submessage',
        );
        return $thank;
    }
    public static function system()
    {
        global $wpdb;

        // 获取Nginx版本
        $nginx = str_replace('nginx/', '', $_SERVER['SERVER_SOFTWARE']);
        // 获取PHP版本
        $php   = PHP_VERSION . (version_compare(PHP_VERSION, '7.2') >= 0 ? '<badge class="jb-green ml6">已是推荐版本</badge>' : '<badge class="jb-red ml6">建议升级到 PHP 7.2或更高版本</badge>');
        // 获取PHP最大上传限制
        $php_upload = ini_get('upload_max_filesize') . (intval(ini_get('upload_max_filesize')) < 256 ? '<badge class="jb-red ml6">建议将上传限制调整为256M</badge>' : ' <badge class="jb-green ml6">已是推荐配置</badge>');
        // 获取MySQL版本
        $mysql = $wpdb->db_version() . (version_compare($wpdb->db_version(), '8.0') < 0 ? ' <badge class="jb-red ml6">4H4G以上服务器建议使用 MySQL 8.0或更高版本</badge>' : ' <badge class="jb-green ml6">4H4G以下服务器建议使用 MySQL 5.7</badge>');
        // 获取Redis安装状态
        $redis = (extension_loaded('redis') ? '<badge class="jb-green ml6">已安装</badge>' : '<badge class="jb-red ml6">未安装，建议安装</badge>');
        // 获取Opchace安装状态
        $opchace = (extension_loaded('Zend OPcache') ? '<badge class="jb-green ml6">已安装</badge>' : '<badge class="jb-red ml6">未安装，建议安装</badge>');
        // 获取Wordpress版本
        $wordpress_version = get_bloginfo('version');
        // 获取服务器时间
        $time = current_time('mysql');

        $html = '<div style="margin-left:14px;">';
        $html .= '<li><strong>IP地址</strong>： ' . GetHostByName($_SERVER['SERVER_NAME']) . ' </li>';
        $html .= '<li><strong>域名</strong>： ' . home_url() . ' </li>';
        $html .= '<li><strong>服务器</strong>： ' . $nginx . ' </li>';
        $html .= '<li><strong>PHP版本</strong>： ' . $php .' </li>';
        $html .= '<li><strong>PHP上传限制</strong>： ' . $php_upload . ' </li>';
        $html .= '<li><strong>MySQL版本</strong>： ' . $mysql . ' </li>';
        $html .= '<li><strong>Redis扩展</strong>： ' . $redis . ' </li>';
        $html .= '<li><strong>Opcache扩展</strong>： ' . $opchace . ' </li>';
        $html .= '<li><strong>WordPress版本</strong>： ' . $wordpress_version . '</li>';
        $html .= '<li><strong>服务器时间</strong>： ' . $time . '</li>';
        $html .= '</div>';
        $html .= '<a class="but c-yellow" href="' . admin_url('site-health.php?tab=debug') . '">查看更多系统信息</a>';

        return $html;
    }
    public static function backup()
    {
        $csf            = array();
        $prefix         = 'wml_zib_diy';
        $options        = get_option($prefix . '_backup');
        $lists          = '暂无备份数据！';
        $admin_ajax_url = admin_url('admin-ajax.php', 'relative');
        $delete_but     = '';
        if ($options) {
            $lists   = '';
            $options = array_reverse($options);
            $count   = 0;
            foreach ($options as $key => $val) {
                $ajax_url = add_query_arg('key', $key, $admin_ajax_url);
                $del      = '<a href="javascript:;" ajax-url="' . add_query_arg('action', 'wml_options_backup_delete', $ajax_url) . '" data-confirm="确认要删除此备份[' . $key . ']？删除后不可恢复！" class="but c-yellow ajax-get ml10">删除</a>';
                $restore  = '<a href="javascript:;" ajax-url="' . add_query_arg('action', 'wml_options_backup_restore', $ajax_url) . '" data-confirm="确认将主题设置恢复到此备份吗？[' . $key . ']？" class="but c-blue ajax-get ml10">恢复</a>';
                $lists .= '<div class="backup-item flex ac jsb">';
                $lists .= '<div class="item-left"><div>' . $val['time'] . '</div><div> [' . $val['type'] . ']</div></div>';
                $lists .= '<span class="shrink-0">' . $restore . $del . '</span>';
                $lists .= '</div>';
                $count++;
            }
            if ($count > 3) {
                $delete_but = '<a href="javascript:;" ajax-url="' . add_query_arg(array('action' => 'wml_options_backup_delete_surplus', 'key' => 'all'), $admin_ajax_url) . '" data-confirm="确认要删除多余的备份数据吗？删除后不可恢复！" class="but jb-red ajax-get">删除备份 保留最新三份</a>';
            }
        }
        $csf[] = array(
            'type'    => 'submessage',
            'style'   => 'warning',
            'content' => '<h3 style="color:#fd4c73;"><i class="csf-tab-icon fa fa-fw fa-copy"></i> 备份&恢复</h3>
            <ajaxform class="ajax-form">
            <div style="margin:10px 0">
            <p>系统会在重置、更新等重要操作时自动备份插件设置，您可以此进行恢复备份或手动备份</p>
            <p>恢复备份后，请先保存一次插件设置，然后刷新后再做其它操作！</p>
            <p class="c-yellow">系统最多只能保存20次备份，如需长期保存，请手动下载后存留</p>
            <p class="c-yellow">该备份的数据为本插件数据，与子比插件数据互不影响</p>
            <p class="c-yellow">请注意：恢复非当前网站或非当前插件版本的备份数据，可能会出现异常</p>
            <p><b>备份列表：</b></p>
            <div class="card-box backup-box">
            ' . $lists . '
            </div>
            </div>
            <a href="javascript:;" ajax-url="' . add_query_arg('action', 'wml_options_backup', $admin_ajax_url) . '" class="but jb-blue ajax-get">备份当前配置</a>
            ' . $delete_but . '
            <div class="ajax-notice" style="margin-top: 10px;"></div>
            </ajaxform>',
        );

        require_once( ABSPATH . 'wp-includes/pluggable.php' );//调用wp_create_nonce函数，否则出错
        $csf[] = array(
            'type'    => 'submessage',
            'style'   => 'warning',
            'content' => '<h3 style="color:#fd4c73;"><i class="csf-tab-icon fa fa-fw fa-copy"></i> 导入&导出</h3>
            <ajaxform class="ajax-form">
            <div style="margin:10px 0">
            <p>您可以在此处将插件配置导出为json文件，同时也可以使用json格式的配置内容进行配置导入，导入时请确保json格式正确</p>
            <textarea ajax-name="import_data" style="width: 100%;min-height: 200px;" placeholder="粘贴导出的json数据以进行导入"></textarea>
            </div>
            <input type="hidden" ajax-name="action" value="wml_options_import">
            <a href="javascript:;" class="but jb-yellow ajax-submit"><i class="fa fa-paper-plane-o"></i> 导入配置</a>
            <a href="' . add_query_arg(array('action' => 'csf-export', 'unique' => $prefix, 'nonce' => wp_create_nonce('csf_backup_nonce')), $admin_ajax_url) . '" class="but jb-green" target="_blank">导出当前配置</a>
            <div class="ajax-notice" style="margin-top: 10px;"></div>
            </ajaxform>',
        );

        return $csf;
    }
    //在线更新
    public static function update($is_update_data = 'null')
    {
        $csf           = array();
        //$data          = $is_update_data !== 'null' ? $is_update_data : ZibAut::is_update();
        $data          = $is_update_data;
        $theme_data    = wp_get_theme();
        $theme_version = $theme_data['Version'];

        if ($data) {
            $notice = '<div class="ajax-form">
                        <p style="color:#ff2f86"><i class="csf-tab-icon fa fa-cloud-upload fa-2x"></i></p>
                        <p><b>当前主题版本：V' . $theme_version . '，可更新到最新版本：<code style="color:#ff1919;background: #fbeeee; font-size: 16px; ">V' . $data['version'] . '</code></b></p>'
                . ($data['update_description'] ? '<p>' . $data['update_description'] . '</p>' : '') . '
                        <div>
                            <input type="hidden" ajax-name="action" value="admin_skip_update">
                            <div class="progress"><div class="progress-bar"></div></div>
                            <p class="ajax-notice"></p>
                            <a href="javascript:;" class="but jb-blue mr10 online-update"><i class="fa fa-cloud-download fa-fw"></i> 在线更新</a><a href="javascript:;" class="but c-yellow ajax-submit"><i class="fa fa-ban fa-fw"></i> 忽略此次更新</a>
                        </div>
                        <div style="text-align: right;font-size: 12px;opacity: .5;"><a style="color: inherit;" target="_blank" href="https://www.zibll.com/1411.html">遇到问题？点此查看官网教程</a></div>
                    </div>';

            $log = '<div class="box-theme">';
            $log .= $data['update_content'];
            $log .= '</div><div><a class="but c-blue" target="_blank" href="https://www.zibll.com/375.html">查看更多更新日志</a></div>';
            $csf[] = array(
                'type'    => 'notice',
                'style'   => 'info',
                'content' => $notice,
            );
            $csf[] = array(
                'title'   => '更新日志',
                'type'    => 'content',
                'content' => $log,
            );
        } else {
            $notice = '<div class="ajax-form">
            <h3 class="c-red"><i class="fa fa-thumbs-o-up fa-fw" aria-hidden="true"></i> 当前主题已经是最新版啦</h3>
            <p><b>当前主题版本：V' . wp_get_theme()['Version'] . ' </b></p>
            <p class="ajax-notice"></p>
            <p><a href="javascript:;" class="but jb-blue ajax-submit">检测更新</a></p>
            <input type="hidden" ajax-name="action" value="admin_detect_update">
            </div>';

            $docs = '<div style="margin-left:14px;">';
            $docs .= '<li><a target="_blank" href="https://www.zibll.com/375.html">Zibll子比主题历史更新日志</a></li>';
            $docs .= '</div>';
            $csf[] = array(
                'type'    => 'notice',
                'style'   => 'info',
                'content' => $notice,
            );

            $db_update = get_option('zibll_new_version'); //不能使用zib_get_option
            if (!empty($db_update['update_content'])) {
                $csf[] = array(
                    'type' => 'tabbed',
                    'id'   => 'theme_text',
                    'tabs' => array(
                        array(
                            'title'  => '主题文档',
                            'icon'   => 'fa fa-file-text-o fa-fw',
                            'fields' => array(
                                array(
                                    'title'   => '主题文档',
                                    'type'    => 'content',
                                    'style'   => 'success',
                                    'content' => $docs,
                                ),
                            ),
                        ),
                        array(
                            'title'  => '更新日志',
                            'icon'   => 'fa fa-cloud-upload fa-fw',
                            'fields' => array(
                                array(
                                    'title'   => '更新日志',
                                    'type'    => 'content',
                                    'style'   => 'success',
                                    'content' => ($db_update['update_description'] ? '<p>' . $db_update['update_description'] . '</p>' : '') . $db_update['update_content'] . '<p><a class="but c-blue" target="_blank" href="https://www.zibll.com/375.html">查看更多更新日志</a></p>',
                                ),
                            ),
                        ),
                    ),
                );
            } else {
                $csf[] = array(
                    'title'   => '主题文档',
                    'type'    => 'content',
                    'style'   => 'success',
                    'content' => $docs,
                );
            }
        }

        $csf[] = array(
            'title'   => '系统环境',
            'type'    => 'content',
            'content' => '<div style="margin-left:14px;"><li><strong>操作系统</strong>： ' . PHP_OS . ' </li>
            <li><strong>运行环境</strong>： ' . $_SERVER["SERVER_SOFTWARE"] . ' </li>
            <li><strong>PHP版本</strong>： ' . PHP_VERSION . ' </li>
            <li><strong>PHP上传限制</strong>： ' . ini_get('upload_max_filesize') . ' </li>
            <li><strong>WordPress版本</strong>： ' . get_bloginfo('version') . '</li>
            <li><strong>系统信息</strong>： ' . php_uname() . ' </li>
            <li><strong>服务器时间</strong>： ' . current_time('mysql') . '</li></div>
            <a class="but c-yellow" href="' . admin_url('site-health.php?tab=debug') . '">查看更多系统信息</a>',
        );
        $csf[] = array(
            'title'   => '推荐环境',
            'type'    => 'content',
            'content' => '<div style="margin-left:14px;"><li><strong>WordPress</strong>：5.0+，推荐使用最新版</li>
            <li><strong>PHP</strong>：PHP7.0及以上，推荐使用7.2</li>
            <li><strong>服务器配置</strong>：无要求，最低配都行</li>
            <li><strong>操作系统</strong>：无要求，不推荐使用Windows系统</li></div>',
        );
        return $csf;
    }

}

//备份插件设置
function wml_ajax_options_backup()
{
    $type   = !empty($_REQUEST['type']) ? $_REQUEST['type'] : '手动备份';
    $backup = wml_options_backup($type);
    echo (json_encode(array('error' => 0, 'reload' => 1, 'msg' => '当前配置已经备份')));
    exit();
}
add_action('wp_ajax_wml_options_backup', 'wml_ajax_options_backup');
//删除备份设置
function wml_ajax_options_backup_delete()
{

    if (!is_super_admin()) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足')));
        exit();
    }
    if (empty($_REQUEST['key'])) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '参数传入错误')));
        exit();
    }

    $prefix = 'wml_zib_diy';
    if ('wml_options_backup_delete_all' == $_REQUEST['action']) {
        update_option($prefix . '_backup', false);
        echo (json_encode(array('error' => 0, 'reload' => 1, 'msg' => '已删除全部备份数据')));
        exit();
    }

    $options_backup = get_option($prefix . '_backup');

    if ('wml_options_backup_delete_surplus' == $_REQUEST['action']) {
        if ($options_backup) {
            $options_backup = array_reverse($options_backup);
            update_option($prefix . '_backup', array_reverse(array_slice($options_backup, 0, 3)));
            echo (json_encode(array('error' => 0, 'reload' => 1, 'msg' => '已删除多余备份数据，仅保留最新3份')));
            exit();
        }
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '暂无可删除的数据')));
    }

    if (isset($options_backup[$_REQUEST['key']])) {
        unset($options_backup[$_REQUEST['key']]);

        update_option($prefix . '_backup', $options_backup);
        echo (json_encode(array('error' => 0, 'reload' => 1, 'msg' => '所选备份已删除')));
    } else {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '此备份已删除')));
    }
    exit();
}
add_action('wp_ajax_wml_options_backup_delete', 'wml_ajax_options_backup_delete');
add_action('wp_ajax_wml_options_backup_delete_all', 'wml_ajax_options_backup_delete');
add_action('wp_ajax_wml_options_backup_delete_surplus', 'wml_ajax_options_backup_delete');

//恢复备份设置
function wml_ajax_options_backup_restore()
{
    if (!is_super_admin()) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足')));
        exit();
    }
    if (empty($_REQUEST['key'])) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '参数传入错误')));
        exit();
    }

    $prefix         = 'wml_zib_diy';
    $options_backup = get_option($prefix . '_backup');
    if (isset($options_backup[$_REQUEST['key']]['data'])) {
        update_option($prefix, $options_backup[$_REQUEST['key']]['data']);
        echo (json_encode(array('error' => 0, 'reload' => 1, 'msg' => '主题设置已恢复到所选备份[' . $_REQUEST['key'] . ']')));
    } else {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '备份恢复失败，未找到对应数据')));
    }
    exit();
}
add_action('wp_ajax_wml_options_backup_restore', 'wml_ajax_options_backup_restore');

//导入插件设置
function wml_ajax_options_import()
{
    if (!is_super_admin()) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足')));
        exit();
    }

    $data = !empty($_REQUEST['import_data']) ? $_REQUEST['import_data'] : '';

    if (!$data) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请粘贴需导入配置的json代码')));
        exit();
    }

    $import_data = json_decode(wp_unslash(trim($data)), true);

    if (empty($import_data) || !is_array($import_data)) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => 'json代码格式错误，无法导入')));
        exit();
    }

    wml_options_backup('导入配置 自动备份');

    $prefix = 'wml_zib_diy';
    update_option($prefix, $import_data);
    echo (json_encode(array('error' => 0, 'reload' => 1, 'msg' => '插件设置已导入，请刷新页面')));
    exit();
}
add_action('wp_ajax_wml_options_import', 'wml_ajax_options_import');

//备份插件数据
function wml_options_backup($type = '自动备份')
{
    $prefix  = 'wml_zib_diy';
    $options = get_option($prefix);

    $options_backup = get_option($prefix . '_backup');
    if (!$options_backup) {
        $options_backup = array();
    }

    $time                  = current_time('Y-m-d H:i:s');
    $options_backup[$time] = array(
        'time' => $time,
        'type' => $type,
        'data' => $options,
    );

    //保留20次数据，删除多余的
    if (count($options_backup) > 20) {
        $options_backup = array_slice($options_backup, -20);
    }
    return update_option($prefix . '_backup', $options_backup);
}
function wml_csf_reset_to_backup()
{
    wml_options_backup('重置全部 自动备份');
}
add_action('csf_wml_zib_diy_reset_before', 'wml_csf_reset_to_backup');

function wml_csf_reset_section_to_backup()
{
    wml_options_backup('重置选区 自动备份');
}
add_action('csf_wml_zib_diy_reset_section_before', 'wml_csf_reset_section_to_backup');
//定期自动备份
function wml_csf_save_section_to_backup()
{
    $prefix         = 'wml_zib_diy';
    $options_backup = get_option($prefix . '_backup');
    $time           = false;

    if ($options_backup) {
        $options_backup = array_reverse($options_backup);
        foreach ($options_backup as $key => $val) {
            if ('定期自动备份' == $val['type']) {
                $time = $key;
                break;
            }
        }
    }
    if (!$time || (floor((strtotime(current_time("Y-m-d H:i:s")) - strtotime($time)) / 3600) > 600)) {
        wml_options_backup('定期自动备份');
    }
}
add_action('csf_wml_zib_diy_saved', 'wml_csf_save_section_to_backup');

//插件更新自动备份
function wml_new_to_backup()
{
    $prefix         = 'wml_zib_diy';
    $options_backup = get_option($prefix . '_backup');
    $time           = false;

    if ($options_backup) {
        $options_backup = array_reverse($options_backup);
        foreach ($options_backup as $key => $val) {
            if ('更新插件 自动备份' == $val['type']) {
                $time = $key;
                break;
            }
        }
    }
    if (!$time || (floor((strtotime(current_time("Y-m-d H:i:s")) - strtotime($time)) / 3600) > 240)) {
        wml_options_backup('更新插件 自动备份');
        //更新插件刷新所有缓存
        wp_cache_flush();
    }
}
add_action('wml_update_notices', 'wml_new_to_backup');

function wml_update_cache_flush()
{
    //在线更新插件前，先刷新全部缓存
    wp_cache_flush();
}
add_action('wp_ajax_wml_update_file', 'wml_update_cache_flush', 5);


//  短信部分代码替换
function wml_zib_sms_plugin()
{
    // 检查当前用户是否为超级管理员
    if (!current_user_can('manage_options')) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足'));
        wp_die(); // 结束执行
    }

    // 定义原始文件路径和目标文件路径
    $original_file_path = WML_ZIB_BEAUT_DIR_PATH  . '/core/coppy/sms-class.php';
    $target_file_path = get_template_directory() . '/inc/class/sms-class.php';

    // 尝试替换文件
    if (file_exists($original_file_path) && copy($original_file_path, $target_file_path)) {
        // 刷新所有缓存
        wp_cache_flush();
        echo json_encode(array('error' => 0, 'msg' => '已替换 sms-class.php 验证码功能可用'));
    } else {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '无法替换，存在异常'));
    }

    wp_die(); // 结束执行
}
add_action('wp_ajax_wml_zib_sms', 'wml_zib_sms_plugin');

//  底部页脚功能文件替换
function wml_zib_footer_plugin()
{
    // 检查当前用户是否为超级管理员
    if (!current_user_can('manage_options')) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足'));
        wp_die(); // 结束执行
    }

    //备份原文件
    $bakpath = get_template_directory().'/footer_bak.php';
    if (!file_exists($bakpath)) {
        rename(get_template_directory().'/footer.php',get_template_directory().'/footer_bak.php');
    }

    // 定义原始文件路径和目标文件路径
    $original_file_path = WML_ZIB_BEAUT_DIR_PATH  . '/core/coppy/footer.php';
    $target_file_path = get_template_directory() . '/footer.php';

    // 尝试替换文件
    if (file_exists($original_file_path) && copy($original_file_path, $target_file_path)) {
        // 刷新所有缓存
        wp_cache_flush();
        echo json_encode(array('error' => 0, 'msg' => '已替换 footer.php 页角功能可用'));
    } else {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '无法替换，存在异常'));
    }

    wp_die(); // 结束执行
}
add_action('wp_ajax_wml_zib_footer', 'wml_zib_footer_plugin');

//  底部页脚功能恢复默认
function wml_zib_footers_plugin()
{
    // 检查当前用户是否为超级管理员
    if (!current_user_can('manage_options')) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足'));
        wp_die(); // 结束执行
    }

    //备份原文件
    $bakpath = get_template_directory().'/footer_bak.php';
    if (!file_exists($bakpath)) {
       echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '未作任何改变'));
       wp_die(); // 结束执行
    }

    // 定义原始文件路径和目标文件路径
    $original_file_path = get_template_directory().'/footer_bak.php';
    $target_file_path = get_template_directory() . '/footer.php';

    // 尝试替换文件
    if (file_exists($original_file_path) && copy($original_file_path, $target_file_path)) {
        // 刷新所有缓存
        wp_cache_flush();
        echo json_encode(array('error' => 0, 'msg' => '恢复生效，已使用默认页脚'));
    } else {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '无法恢复，存在异常'));
    }

    wp_die(); // 结束执行
}
add_action('wp_ajax_wml_zib_footers', 'wml_zib_footers_plugin');

//  GO文件替换
function wml_zib_go_plugin()
{
    // 检查当前用户是否为超级管理员
    if (!current_user_can('manage_options')) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足'));
        wp_die(); // 结束执行
    }
    // 检查是否开启
    if (!wml_zib('link_go')) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '功能未开启，请先保存设置再执行此操作'));
        wp_die(); // 结束执行
    }

    $gol=wml_zib('link_go_select');
    if($gol==4){
        $myfile = fopen(WML_ZIB_BEAUT_DIR_PATH.'/core/coppy/go4.php', "w") or die("无法打开文件!");
        $txt = wml_zib('link_go_diy');
        fwrite($myfile, $txt);
        fclose($myfile);
    }

    //备份原文件
    $bakpath = get_template_directory().'/go_bak.php';
    if (!file_exists($bakpath)) {
        rename(get_template_directory().'/go.php',get_template_directory().'/go_bak.php');
    }
    // 定义原始文件路径和目标文件路径
    $original_file_path = WML_ZIB_BEAUT_DIR_PATH . '/core/coppy/go'.$gol.'.php';
    $target_file_path = get_template_directory() . '/go.php';

    // 尝试替换文件
    if (file_exists($original_file_path) && copy($original_file_path, $target_file_path)) {
        // 刷新所有缓存
        wp_cache_flush();
        echo json_encode(array('error' => 0, 'msg' => '已替换成功并生效'));
    } else {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '无法替换，存在异常'));
    }

    wp_die(); // 结束执行
}
add_action('wp_ajax_wml_zib_go', 'wml_zib_go_plugin');

//  GO恢复默认文件
function wml_zib_gos_plugin()
{
    // 检查当前用户是否为超级管理员
    if (!current_user_can('manage_options')) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足'));
        wp_die(); // 结束执行
    }

    //检查原文件是否存在，不存在则无操作
    $bakpath = get_template_directory().'/go_bak.php';
    if (!file_exists($bakpath)) {
       echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '已是系统默认，无需恢复'));
       wp_die(); // 结束执行
    }

    // 定义原始文件路径和目标文件路径
    $original_file_path = get_template_directory().'/go_bak.php';
    $target_file_path = get_template_directory() . '/go.php';

    // 尝试替换文件
    if (file_exists($original_file_path) && copy($original_file_path, $target_file_path)) {
        // 刷新所有缓存
        wp_cache_flush();
        echo json_encode(array('error' => 0, 'msg' => '恢复成功，已使用默认页脚'));
    } else {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '无法恢复，存在异常'));
    }

    wp_die(); // 结束执行
}
add_action('wp_ajax_wml_zib_gos', 'wml_zib_gos_plugin');