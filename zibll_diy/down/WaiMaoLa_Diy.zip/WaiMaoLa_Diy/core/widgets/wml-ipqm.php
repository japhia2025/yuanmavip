<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\widgets\wml-ipqm.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-07 00:43:11
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */
if (wml_zib('ipqm_switch', false)) {
    //注册钩子
    add_action('widgets_init', 'register_ipqm');
    function register_ipqm()
    {
        register_widget('wml_ipqm');
    }
    class wml_ipqm extends WP_Widget
    {
        public function __construct()
        {
            //定义小工具
            $widget = array(
                'w_id'        => 'wml_ipqm',
                'w_name'      => '外贸啦 - IP签名档',
                'classname'   => '',
                'description' => '天气预报，侧边IP签名档',
            );
            parent::__construct($widget['w_id'], $widget['w_name'], $widget);
        }

        public function widget($args, $instance)
        {
            if (!zib_widget_is_show($instance)) {
                return;
            }
            extract($args);
            
            ?>
            <div class="zib-widget"><img class="fit-cover ls-is-cached lazyloaded lazyloadafter" data-src="<?php echo WML_ZIB_BEAUT_DIR_URL;?>/page/ipqm/ipqm.php" src="<?php echo WML_ZIB_BEAUT_DIR_URL;?>/page/ipqm/ipqm.php" alt="图片-外贸啦"></div>
        <?php
        }
    }
}
