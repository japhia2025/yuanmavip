<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\widgets\wml-count.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-21 03:46:07
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */
if (wml_zib('count_switch', false)) {
    //注册钩子
    add_action('widgets_init', 'register_count');
    function register_count()
    {
        register_widget('wml_count');
    }
    class wml_count extends WP_Widget
    {
        public function __construct()
        {
            //定义小工具
            $widget = array(
                'w_id'        => 'wml_count',
                'w_name'      => '外贸啦 - 信息统计',
                'classname'   => '',
                'description' => '底部横向，网站信息统计',
            );
            parent::__construct($widget['w_id'], $widget['w_name'], $widget);
        }

        public function widget($args, $instance)
        {
            if (!zib_widget_is_show($instance)) {
                return;
            }
            extract($args);
            
            ?>
            <script type="text/javascript" >
            //文章总数↓
            <?php $count_posts = wp_count_posts(); $published_posts =$count_posts->publish;echo "var stat_wzzs="."'$published_posts'";?>
            //本周发布↓
            <?php $post_wpdb = CSF_Module_Wml_Count::get_posts_count_from_last_168h($post_type ='post');echo "var stat_bzfb="."'$post_wpdb'";?>
            //运行时间↓
            <?php $wdyx_time = floor((time()-strtotime(wml_zib('cheat_yx')))/86400);echo "var stat_yxsj="."'$wdyx_time'";?>
            //用户总数↓
            <?php global $wpdb;$users = wml_zib('cheat_hy')+$wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->users");echo "var stat_zcyh="."'$users'";?>
            //总访问量↓
            <?php $post_view = wml_zib('cheat_ll')+CSF_Module_Wml_Count::all_view();echo "var stat_zfwl="."'$post_view'";?>
            </script>
            
             <div class="textwidget custom-html-widget"><div id="mizhi-info-wg-mian">
            <div class="mizhi-info-item">
            
            <div class="mizhi-wz-item">
            <div class="mizhi-wz-sty mizhi-wzzs-item">
            <svg class="icon fa-2x" aria-hidden="true">
            <use xlink:href="#icon-wenzhang" rel="external nofollow" ></use>
            </svg>
            <span class="mizhi-i-num"><script type="text/javascript">
            document.write(stat_wzzs);
            </script>篇</span>
            <span class="frame-bg" title="文章数目">文章数目</span>
            </div>
            
            <div class="mizhi-wz-sty mizhi-jrfb-item">
            <svg class="icon fa-2x" aria-hidden="true">
            <use xlink:href="#icon-benzhoudianjihou-copy" rel="external nofollow" ></use>
            </svg>
            <span class="mizhi-i-num"><script type="text/javascript">
            document.write(stat_bzfb);
            </script>篇</span>
            <span class="frame-bg" title="本周发布">本周发布</span>
            </div>
            </div>
            
            <div class="mizhi-yhzs-item">
            <svg class="icon fa-2x" aria-hidden="true">
            <use xlink:href="#icon-yonghu" rel="external nofollow" ></use>
            </svg>
            <span class="mizhi-i-num"><script type="text/javascript">
            document.write(stat_zcyh);
            </script>位</span>
            <span class="frame-bg" title="注册用户">注册用户</span>
            </div>
            
            <div class="mizhi-yxsj-item">
            <svg class="icon fa-2x" aria-hidden="true">
            <use xlink:href="#icon-daojishi" rel="external nofollow" ></use>
            </svg>
            <span class="mizhi-i-num"><script type="text/javascript">
            document.write(stat_yxsj);
            </script>天</span>
            <span class="frame-bg" title="运行时间">运行时间</span>
            </div>
            
            <div class="mizhi-llzs-item">
            <svg class="icon fa-2x" aria-hidden="true">
            <use xlink:href="#icon-yanjing-" rel="external nofollow" ></use>
            </svg>
            <span class="mizhi-i-num "><script type="text/javascript">
            document.write(stat_zfwl);
            </script>次</span>
            <span class="frame-bg" title="浏览次数">浏览次数</span>
            </div>
            
            <div class="mizhi-sjcs-item">
            <div class="mizhi-sjcj-m">
            <span class="mizhi-i-num"><?php echo wml_zib('count_name');?></span>
            <div id="mizhi-date-text"></div>
            <div id="mizhi-week-text"></div>
            <div class="mizhi-meo-item">
            <img id="mizhi-meos" src="<?php echo WML_ZIB_BEAUT_DIR_URL;?>/img/widgets/week<?php echo wml_zib('count_type');?>/week-1.webp" alt="emo">
            </div>
            <div class="mizhi-sjcj-content">
            <span id="mizhi-fatalism"></span>
            </div>
            </div>
            </div>    
            <div class="mizhi-sjcs-item2"><iframe src="<?php echo WML_ZIB_BEAUT_DIR_URL;?>/page/tkr<?php echo wml_zib('count_time');?>/" width="290" height="290" frameborder="no"></iframe></div> 
            </div>
            </div>
            <script>
            $(function () {
                var myDate = new Date();
                var year = myDate.getFullYear(); //获取当前年
                var mon = myDate.getMonth() + 1; //获取当前月
                var date = myDate.getDate(); //获取当前日
                var week = myDate.getDay();
                var weeks = [
                "星期日",
                "星期一",
                "星期二",
                "星期三",
                "星期四",
                "星期五",
                "星期六"
                ];
                $("#mizhi-date-text").html(year + "年" + mon + "月" + date + "日"+ weeks[week]);
            
                if (week > 0 && week < 5) {
                $("#mizhi-fatalism").html("再坚持一下还有" + (5 - week) + "天就到周末啦！");
                } else if (week === 5) {
                $("#mizhi-fatalism").html("啊啊啊，明天就是周末啦！");
                } else {
                $("#mizhi-fatalism").html("今天是周末，好好放肆玩一下吧！");
                }
                $("#mizhi-meos").attr(
                "src","<?php echo WML_ZIB_BEAUT_DIR_URL;?>/img/widgets/week<?php echo wml_zib('count_type');?>/week-" + week + ".webp"
                );
            });
            $("#mizhi-info-wg-mian").parents(".zib-widget").css({
                padding: "0",
                background: "none"
            });
            
            </script></div>
                <link rel="stylesheet" type="text/css" href="<?php echo WML_ZIB_BEAUT_DIR_URL;?>/css/widgets_count.css">
                <script src="<?php echo WML_ZIB_BEAUT_DIR_URL;?>/js/widgets_count.js"></script>
        <?php
        }
    }
}
