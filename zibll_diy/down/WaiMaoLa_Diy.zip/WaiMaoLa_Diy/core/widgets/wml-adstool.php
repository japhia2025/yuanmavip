<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\functions\widgets\wml-adstool.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-06-27 15:57:44
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */
if (wml_zib('adstool_switch', false)) {
    //注册钩子
    add_action('widgets_init', 'register_adstool');
    function register_adstool()
    {
        register_widget('wml_adstool');
    }
    class wml_adstool extends WP_Widget
    {
        public function __construct()
        {
            //定义小工具
            $widget = array(
                'w_id'        => 'wml_adstool',
                'w_name'      => '外贸啦 - 侧边工具广告',
                'classname'   => '',
                'description' => '广告工具图，侧边栏广告工具',
            );
            parent::__construct($widget['w_id'], $widget['w_name'], $widget);
        }

        public function widget($args, $instance)
        {
            if (!zib_widget_is_show($instance)) {
                return;
            }
            extract($args);
            $bjcolor=wml_zib('adstool_bjcolor');
            $ancolor=wml_zib('adstool_ancolor');
            $link=wml_zib('adstool_link');
            ?>
            <style>
            .ads{display:block; padding:40px 15px; text-align:center; color:<?php echo wml_zib('adstool_btcolor');?>!important; background:#ff5719; background-image:-webkit-linear-gradient(135deg,<?php echo $bjcolor['jb1'];?>,<?php echo $bjcolor['jb2'];?>); background-image:linear-gradient(135deg,<?php echo $bjcolor['jb1'];?>,<?php echo $bjcolor['jb2'];?>)}
            .ads h4{margin:0; font-size:22px; font-weight:bold}
            .ads h5{margin:10px 0 0; font-size:14px; font-weight:bold}.ads.ads-btn{margin-top:20px; font-weight:bold}
            .ads.ads-btn:hover{color:#ff5719}
            .ads-btn{display:inline-block; font-weight:normal; margin-top:10px; color:#666; text-align:center; vertical-align:top; user-select:none; border:none; padding:0 36px; line-height:38px; font-size:14px; border-radius:10px; outline:0; -webkit-transition:all 0.3s ease-in-out; -moz-transition:all 0.3s ease-in-out; transition:all 0.3s ease-in-out}
            .ads-btn:hover,.btn:focus,.btn.focus{outline:0; text-decoration:none}
            .ads-btn:active,.btn.active{outline:0; box-shadow:inset 0 3px 5px rgba(0,0,0,0.125)}
            .ads-btn-outline{line-height:36px; color:<?php echo $ancolor['an1'];?>; background-color:transparent; border:1px solid<?php echo $ancolor['an2'];?>}
            .ads-btn-outline:hover,.btn-outline:focus,.btn-outline.focus{color:<?php echo $ancolor['an3'];?>; background-color:<?php echo $ancolor['an4'];?>}
            </style>
            <div class="zib-widget">
            <a class="ads" href="<?php echo $link['url'];?>" rel="external nofollow"  title="<?php echo $link['text'];?>" target="<?php echo $link['target'];?>" style="border-radius:5px;">
              <h4>空白的小工具</h4>
              <h5>空白推荐，安全有保障</h5>
              <span class="ads-btn ads-btn-outline">立即进入</span></a>
            </div>
        <?php
        }
    }
}
