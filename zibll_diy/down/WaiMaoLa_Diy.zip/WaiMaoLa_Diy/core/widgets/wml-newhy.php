<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\widgets\wml-newhy.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-21 03:59:31
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */
if (wml_zib('newhy_switch', false)) {
    //注册钩子
    add_action('widgets_init', 'register_newhy');
    function register_newhy()
    {
        register_widget('wml_newhy');
    }
    class wml_newhy extends WP_Widget
    {
        public function __construct()
        {
            //定义小工具
            $widget = array(
                'w_id'        => 'wml_newhy',
                'w_name'      => '外贸啦 - 新入会员滚动',
                'classname'   => '',
                'description' => '全宽新注册会员滚动提示条',
            );
            parent::__construct($widget['w_id'], $widget['w_name'], $widget);
        }

        public function widget($args, $instance)
        {
            if (!zib_widget_is_show($instance)) {
                return;
            }
            extract($args);
            
            function DearLicy_notice() 
            {    
                // 执行查询    
                $users = CSF_Module_Wml_Count::new_user();    
                
                $slides = ''; // 初始化$slides变量，用于存储每个用户的HTML代码片段    
                
                // 遍历结果集并生成HTML代码    
                if ($users) {    
                    foreach ($users as $user) {    
                        $user_name = $user->user_login;    
                        $avatar     = zib_get_avatar_box($user->ID, 'avatar-img avatar-mini mr6', false, true);
                        $link     = zib_get_user_home_url($user->ID);
                        $registration_date = date('Y-m-d H:i:s', strtotime($user->user_registered));  
              
                        // 为每个用户生成一个swiper-slide  
                        $slide = '<div class="swiper-slide notice-slide">';  
                        $slide .= '<a class="text-ellipsis" href="'.$link.'">' . $avatar . $user_name . ' 在 ' . $registration_date . ' 加入了本站</a>';  
                        $slide .= '</div>';  
              
                        // 拼接每个用户的HTML代码片段  
                        $slides .= $slide;  
                    }    
                } 
              
                // 构建完整的HTML结构  
                $html = '<div class="theme-box">';  
                $html .= '<div class="swiper-bulletin '.wml_zib('newhy_theme').' radius8">';  
                $html .= '<div class="new-swiper" data-interval="5000" data-direction="vertical" data-loop="true" data-autoplay="1">';  
                $html .= '<div class="swiper-wrapper">';  
                $html .= $slides; // 插入所有用户的HTML代码片段  
                $html .= '</div>';  
                $html .= '<span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>';  
                $html .= '</div>';  
                $html .= '</div>';
                $html .= '</div>';
              
                return $html; // 返回生成的HTML代码    
            }
            echo DearLicy_notice();
        }
    }
}
