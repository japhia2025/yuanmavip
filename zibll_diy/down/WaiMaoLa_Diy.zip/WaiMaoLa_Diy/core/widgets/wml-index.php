<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-29 12:10:52
 * @FilePath: \WaiMaoLa_Diy\core\widgets\wml-index.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-12 19:52:15
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

 // 载入核心文件
$include_once = array(
    'usergd',
    'wzad',
    'gdad',
    'imgad',
    'textad',
    'adstool',
    'countdown',
    'music',
    'sharedh',
    'newhy',
    'hyxx',
    'hyweather',
    'count',
    'tplm',
    'heiwu',
    'ipqm',
);
foreach ($include_once as $inc) {
    include 'wml-' . $inc . '.php';
}