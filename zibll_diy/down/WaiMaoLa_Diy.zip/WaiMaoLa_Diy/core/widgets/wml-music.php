<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\widgets\wml-music.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-11 13:37:38
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

//音乐播放器
if (wml_zib('music_switch', false)) {
    //加载CSS+JS
    add_action('wp_enqueue_scripts', 'music_css_js');
    function music_css_js() {
        ?>
        <!-- require APlayer -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/aplayer/dist/APlayer.min.css">
        <script src="https://cdn.jsdelivr.net/npm/aplayer/dist/APlayer.min.js"></script>
        <!-- require MetingJS -->
        <script src="https://cdn.jsdelivr.net/npm/meting@2.0.1/dist/Meting.min.js"></script>
        <?php
    }
    if(wml_zib('music_type')==2){
        function wml_zib_music_switch()
        {
            $palette=CSF_Module_Wml_Zib::zib_palette(array(), array('t','c', 'b'));
            $theme=$palette[wml_zib('music_theme')][0];
            wml_zib('music_autoplay', false)?$autoplay='ture':$autoplay='false';
            echo '
            <meting-js type="playlist" volume="1" preload="auto" lrctype="0" list-max-height="300px" server="'.wml_zib('music_server').'" id="'.wml_zib('music_id').'" autoplay="'.$autoplay.'" loop="'.wml_zib('music_loop').'" order="'.wml_zib('music_order').'" list-folded="'.wml_zib('music_folded').'" theme="'.$theme.'" mutex="ture" fixed="ture"></meting-js>';
        }
        add_action('wp_footer', 'wml_zib_music_switch');
    }else{
        //注册钩子
        add_action('widgets_init', 'register_music');
        function register_music()
        {
            register_widget('wml_music');
        }
        class wml_music extends WP_Widget
        {
            public function __construct()
            {
                //定义小工具
                $widget = array(
                    'w_id'        => 'wml_music',
                    'w_name'      => '外贸啦 - 音乐播放器',
                    'classname'   => '',
                    'description' => '侧边音乐播放器',
                );
                parent::__construct($widget['w_id'], $widget['w_name'], $widget);
            }

            public function widget($args, $instance)
            {
                if (!zib_widget_is_show($instance)) {
                    return;
                }
                extract($args);
                
                $palette=CSF_Module_Wml_Zib::zib_palette(array(), array('t','c', 'b'));
                $theme=$palette[wml_zib('music_theme')][0];
                wml_zib('music_autoplay', false)?$autoplay='ture':$autoplay='false';
                echo '
                <div class="zib-widget"><meting-js type="playlist" volume="1" preload="auto" lrctype="0" list-max-height="300px" server="'.wml_zib('music_server').'" id="'.wml_zib('music_id').'" autoplay="'.$autoplay.'" loop="'.wml_zib('music_loop').'" order="'.wml_zib('music_order').'" list-folded="'.wml_zib('music_folded').'" theme="'.$theme.'" mutex="ture"></meting-js></div>';
            }
        }
    }
}