<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\widgets\wml-gdad.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-27 21:20:25
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */
if (wml_zib('gdad_switch', false)) {
    //注册钩子
    add_action('widgets_init', 'register_gdad');
    function register_gdad()
    {
        register_widget('wml_gdad');
    }
    class wml_gdad extends WP_Widget
    {
        public function __construct()
        {
            //定义小工具
            $widget = array(
                'w_id'        => 'wml_gdad',
                'w_name'      => '外贸啦 - 图片滚动广告',
                'classname'   => '',
                'description' => '首页图文广告，横屏滚动广告',
            );
            parent::__construct($widget['w_id'], $widget['w_name'], $widget);
        }

        public function widget($args, $instance)
        {
            if (!zib_widget_is_show($instance)) {
                return;
            }
            extract($args);
            
            ?>
            <style> .gdad_one {margin: auto;height: 160px;overflow: hidden;position: relative;width: 100%;}.gdad_one ul {height: 160px;width: 100000px;position: absolute;left: 0;}.gdad_one ul li {display: block;float: left;margin: 5px;height: 150px;border-radius: 20px;position: relative;}.gdad_one ul li a {display: inline-block;height: 150px;}.gdad_one ul li img {border-radius: 20px;display: block;}.gdad_one ul li a span {height: 0;display: block;background: #f9f9f9cc;position: absolute;bottom: 0;color: #ff4f4f;font-size: 0px;}.gdad_one ul li a:hover span {height: 150px;line-height: 150px;font-size: 20px;text-align: center;transition: all 0.7s;border-radius: 20px ;}.gdad_two {margin: 50px auto;height: 90px;overflow: hidden;position: relative;}.gdad_two ul {height: 90px;width: 100000px;position: absolute;left: 0;}.gdad_two ul li {display: block;float: left;margin: 5px;height: 80px;border-radius: 20px;position: relative;}.gdad_two ul li a {display: inline-block;height: 80px;}.gdad_two ul li img {display: block;border-radius: 20px;height: 80px;}.gdad_two ul li a span {height: 0;display: block;background: #f9f9f9cc;position: absolute;bottom: 0;color: #ff4f4f;font-size: 0px;}.gdad_two ul li a:hover span {height: 80px;line-height: 80px;font-size: 20px;text-align: center;transition: all 0.7s;border-radius: 20px ;}</style>
            <div class="zib-widget">
            <div class="gdad_one">
            <ul style="left: -788pxpx;">
            <?php 
                if(wml_zib('gdad_tp')){
                    foreach(wml_zib('gdad_tp') as $val) {
                        echo '<li><a href="'.$val['link']['url'].'" target="'.$val['link']['target'].'"><img src="'.$val['img'].'" >
                        <span style="width: 0px;">'.$val['name'].'</span></a>
                        </li>';
                    }
                }
            ?>
            </ul>
        </div>
        </div>
            <script>
            /* 有的浏览器第一次加载不会动画  刷新当前页面一次 可以不加的*/
            //function reurl(){ 
                //url = location.href;var times = url.split("?"); 
                //if(times[1] != 1){url += "?1"; self.location.replace(url);} 
            //}
            //onload=reurl ;
            /* 有的浏览器第一次加载不会动画  刷新当前页面一次 */
            $(document).ready(function () {
            var box0 = $(".gdad_one"),v0 = 0.5; 
            var box1 = $(".gdad_two"),v1 = 1;
            Rin(box0,v0);
            Rin(box1,v1); 

                function Rin($Box,v){//$Box移动的对象，v对象移动的速率
                    var $Box_ul = $Box.find("ul"),
                        $Box_li = $Box_ul.find("li"),
                        $Box_li_span = $Box_li.find("span"),
                        left = 0,
                        s=0,
                        timer;//定时器

                        $Box_li.each(function(index){
                            $($Box_li_span[index]).width($(this).width());//hover
                            s += $(this).outerWidth(true); //即要滚动的长度
                        })
                window.requestAnimationFrame = window.requestAnimationFrame||function(Tmove){return setTimeout(Tmove,1000/60)};
                window.cancelAnimationFrame = window.cancelAnimationFrame||clearTimeout;
                        if( s>=$Box.width()){//如果滚动长度超出Box长度即开始滚动，没有的话就不执行滚动
                                    $Box_li.clone(true).appendTo($Box_ul);                       
                                    Tmove();
                                    function Tmove(){
                                            //运动是移动left  从0到-s;（个人习惯往左滚）
                                            left -= v;
                                            if(left <= -s){left = 0;$Box_ul.css("left",left)}else{ $Box_ul.css("left",left) }
                                                timer = requestAnimationFrame(Tmove);   
                                    }
                                $Box_ul.hover(function(){cancelAnimationFrame(timer)},function(){Tmove()})    
                        }  
                }      
            })   
            </script>
        <?php
        }
    }
}
