<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\coppy\footer.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-06-27 15:56:08
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */
?>
<?php if (wml_zib('footer', false)) {
	do_action('wml_footer');
} else { ?>
	<footer class="footer">
		<?php if (function_exists('dynamic_sidebar')) {
			dynamic_sidebar('all_footer');
		} ?>
		<div class="container-fluid container-footer">
			<?php do_action('zib_footer_conter'); ?>
		</div>
	</footer>
<?php }
wp_footer();
?>

</body>

</html>