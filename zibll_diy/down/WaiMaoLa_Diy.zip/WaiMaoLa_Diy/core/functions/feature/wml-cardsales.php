<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-05 13:44:10
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-11-05 05:07:52
 * @FilePath: \WaiMaoLa_Diy\core\functions\feature\wml-cardsales.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682233
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

if (wml_zib('card_sales', false)) {

    function zib_cp_admin_scripts()
    {
        wp_enqueue_style('zib_cp_main',WML_ZIB_BEAUT_DIR_URL.'/css/card_sales.css');
        wp_enqueue_script('zib_cp_main',WML_ZIB_BEAUT_DIR_URL.'/js/card_sales.js', array('jquery'), '', true);
        wp_localize_script('zib_cp_main', 'wp_ajax_url', admin_url("admin-ajax.php"));
    }
    add_action('admin_enqueue_scripts', 'zib_cp_admin_scripts');
    //后台收费选项修改
    function wml_zib_card_sales_admin($fields){
        foreach ($fields as &$v) {
            if(isset($v['id'])&&$v['id']=='pay_type'){
                $v['options']=array(
                    'no' => __('关闭', 'zib_language'),
                    '1'  => __('付费阅读', 'zib_language'),
                    '2'  => __('付费下载', 'zib_language'),
                    '5'  => __('付费图片', 'zib_language'),
                    '6'  => __('付费视频', 'zib_language'),
                    '7'  => __('卡密发放', 'zib_language'),
                );
            }
        }

        $post_id = !empty($_GET['post']) ? $_GET['post'] : '';//获取文章ID
        if (!$post_id) {
            $kami[] = array(
                'dependency' => array('pay_type', '==', '7'),
                'type'       => 'accordion',
                'id'       => 'accordion',
                'accordions' => array(
                    array(
                        'title'  => '<font style="color:#fd4c73;"><i class="fa fa-credit-card-alt" aria-hidden="true"></i> 卡密管理</font>',
                        //'icon'   => 'fa fa-fw fa-credit-card-alt',
                        'fields' => array(
                            array(
                                'type'    => 'content',
                                'content' => '<div style="color:#fb2121;text-align: center;padding: 10px;">请保存文章并刷新页面，再在此管理卡密信息</div>'
                            )
                        )
                    )
                )
            );
        } else {
            $kami[] = array(
                'dependency' => array('pay_type', '==', '7'),
                'type'       => 'accordion',
                'id'       => 'accordion',
                'accordions' => array(
                    array(
                        'title'  => '<font style="color:#fd4c73;"><i class="fa fa-credit-card-alt" aria-hidden="true"></i> 卡密管理</font>',
                        //'icon'   => 'fa fa-fw fa-credit-card-alt',
                        'fields' => array(
                            array(
                                'type'          => 'tabbed',
                                'id'            => 'theme_text',
                                'tabs'          => array(
                                    array(
                                        'title'     => '卡密列表',
                                        'icon'      => 'fa fa-file-text-o fa-fw',
                                        'fields'    => array(
                                            array(
                                                'type'    => 'content',
                                                'content' => zib_cp_post_key_list($post_id)
                                            )
                                        ),
                                    ),
                                    array(
                                        'title'     => '添加卡密',
                                        'icon'      => 'fa fa-cloud-upload fa-fw',
                                        'fields'    => array(
                                            array(
                                                'type'    => 'content',
                                                'content' => zib_cp_post_add_key($post_id)
                                            )
                                        ),
                                    ),
                                )
                            )
                        )
                    ),
                )
            );
        }
        //array_splice($fields,1,0,$kami);//第一个后插入
        array_splice($fields,-5,0,$kami);//倒数第五插入
        return $fields;
    }
    add_filter( 'zib_add_pay_meta_box_args', 'wml_zib_card_sales_admin', 10, 2 );

    //相关函数
    //后台文章编辑卡密列表
    function zib_cp_post_key_list($post_id)
    {
        $date = zib_cp::get($post_id);
        $all_count = '<span style="padding: 1px 10px;min-width: auto;" class="but b-yellow">全部 ' . zib_cp::count($post_id, 'all') . '</span>';
        $pay_count = '<span style="padding: 1px 10px;min-width: auto;" class="but b-red">已售 ' . zib_cp::count($post_id, 'invalid') . '</span>';
        $valid_count = '<span style="padding: 1px 10px;min-width: auto;" class="but b-blue">库存 ' . zib_cp::count($post_id, 'valid') . '</span>';
    
        if (!$date) {
            return '<div style="color:#fb2121;text-align: center;padding: 10px;">暂无卡密信息，请添加！</div>';
        }
    
        $html = '';
        $html .= '<p>';
        $html .= $all_count . $valid_count . $pay_count;
        $html .= '</p>';
    
    
        $table = zib_cp_post_key_table($post_id);
        $html .= '<div style="overflow-y: auto;width: 100%;">';
        $html .= '<table class="widefat fixed striped posts table table-bordered" style="min-width:600px;">';
        $html .= $table;
        $html .= '</table>';
        $html .= '</div>';
        //   $html .= json_encode($date);
    
        return $html;
    }
    function zib_cp_post_key_table($post_id, $show_check = false)
    {
        $date = zib_cp::get($post_id);

        $table = '';
        if ($date) {
            $theads[] = array('width' => '25%', 'orderby' => '', 'name' => '卡号');
            $theads[] = array('width' => '25%', 'orderby' => '', 'name' => '密码');
            $theads[] = array('width' => '15%', 'orderby' => '', 'name' => '状态');
            $theads[] = array('width' => '15%', 'orderby' => '', 'name' => '创建时间');
            $theads[] = array('width' => '15%', 'orderby' => '', 'name' => '售出时间');

            $thead_th = '';
            $thead_th .=  $show_check ? '<th class="check-column"><input type="checkbox" class="check-all"></th>' : '';

            foreach ($theads as $thead) {
                $orderby = '';
                if ($thead['orderby']) {
                    $orderby_url = add_query_arg('orderby', $thead['orderby']);
                    $orderby .= '<a title="降序" href="' . add_query_arg('desc', 'ASC', $orderby_url) . '"><span class="dashicons dashicons-arrow-up"></span></a>';
                    $orderby .= '<a title="升序" href="' . add_query_arg('desc', 'DESC', $orderby_url) . '"><span class="dashicons dashicons-arrow-down"></span></a>';
                    $orderby = '<span class="orderby-but">' . $orderby . '</span>';
                }
                $thead_th .= '<th class="" width="' . $thead['width'] . '">' . $thead['name'] . $orderby . '</th>';
            }
            $table .= '<thead><tr>' . $thead_th . '</tr></thead>';

            $tbody = '';
            foreach ($date as $key => $value) {
                $tbody .= '<tr data-key="' . $key . '" >';
                $value = zib_cp::map($value);

                $status =  zib_cp::status_name($value['status']);
                if (!empty($value['order'])) {
                    $url = admin_url('admin.php?page=zibpay_order_page&s=' . $value['order']);
                    $status .= '<a style="padding: 1px 10px;min-width: auto;" class="but c-red" href="' . $url . '">查看订单</a>';
                }

                $del_link = '<a class="del_cardcode" delete-key="' . $key . '" post-id="' . $post_id . '" form-action="del_cardcode" href="">删除</a>';
                $del = '<div class="row-actions">' . $del_link . '</div>';
                $tbody .= $show_check ?  '<th scope="row" class="check-column"><input class="check-delete check-all-item" type="checkbox" name="delete[]" value="' . $key . '"></th>' : '';

                $tbody .= '<td>' . $value['code'] . $del . '</td>';
                $tbody .= '<td>' . $value['key'] . '</td>';
                $tbody .= '<td>' . $status . '</td>';
                $tbody .= '<td>' . $value['create_time'] . '</td>';
                $tbody .= '<td>' . $value['modified_time'] . '</td>';

                $tbody .= '</tr>';
            }
            $table .= '<tbody>' . $tbody . '</tbody>';
        }

        return $table;
    }
    function zib_cp_post_add_key($post_id = '')
    {
        $html = '<div>';
        $html .= '<p><b>请复制您的卡密数据</b></p>';
        $html .= '<p>一行一个卡密，卡号和密码用英文逗号或者空格或----分割</p>';
        $html .= '<ajaxform class="ajax-form" ajax-url="' . admin_url("admin-ajax.php") . '">';
        $html .= '<textarea ajax-name="cardcode" style="width:100%;" rows="6"></textarea>';
        $html .= '';
        $html .= '<div class="ajax-notice"></div>';
        $html .= '<p><a href="javascript:;" class="but jb-yellow ajax-submit"><i class="fa fa-paper-plane-o"></i>确认提交</a></p>';
        $html .= '<input type="hidden" ajax-name="action" value="add_cardcode">';
        $html .= '<input type="hidden" ajax-name="post_id" id="post_id" value="' . $post_id . '">';
        $html .= '</ajaxform>';
        $html .= '</div>';
        //$html .= '<script type=\'text/javascript\'>const searchParams = new URLSearchParams(window.location.search);document.getElementById(\'post_id\').value = searchParams.get(\'post\');</script>';
        return $html;
    }

    /**挂钩到用户中心 */
    add_action('author_info_tab', 'zib_cp_user_info_tab_cardcode', 11);
    add_action('author_info_tab_con', 'zib_cp_user_info_tab_cardcode_con', 11);
    function zib_cp_user_info_tab_cardcode($user_id)
    {
        echo '<li class=""><a class="muted-2-color but hollow" data-toggle="tab" data-ajax="" href="#author-tab-cardcode"><i class="fa fa-credit-card-alt hide-sm fa-fw" aria-hidden="true"></i>我的卡密</a></li>';
    }
    function zib_cp_user_info_tab_cardcode_con($user_id)
    {
        $id = 'author-tab-cardcode';
        $detail_ajax_href = esc_url(add_query_arg('action', 'author_tab_cardcode', admin_url('admin-ajax.php')));

        $count = zib_cp::user_count($user_id);
        $statistical = '';
        $statistical .= '<div class="row">';
        $statistical .= '<div class="col-sm-6"><div class="zib-widget jb-blue relative-h">';
        $statistical .= '<div class="absolute jb-blue radius" style=" height: 150%; left: 50%; opacity: 0.5; top: 50%; width: 60%; "></div><div class="absolute jb-blue radius" style=" height: 145%; left: -22%; opacity: .8; width: 89%; "></div>';

        $statistical .= '<div class="relative">';
        $statistical .= '<p class="opacity8"><i class="fa fa-credit-card-alt mr6" aria-hidden="true"></i>我的卡密</p>';

        $statistical .= '<div class="text-center"><span class="opacity8">共计</span><span style="font-size: 4em;">' . $count . '</span></div>';
        $statistical .= '</div>';

        $statistical .= '</div></div>';

        $statistical .= '</div>';

        $list = '';
        $list .= '<div class="title-h-left mb10"><b>卡密列表</b></div>';
        $list .= '<div class="ajaxpager">';
        $list .= '<span class="post_ajax_trigger"><a ajax-href="' . $detail_ajax_href . '" class="ajax_load ajax-next ajax-open"></a></span>';
        $placeholder = '<div class="padding-h10"><p class="placeholder t1"></p><h4 class="item-excerpt placeholder k1"></h4><p class="placeholder k2"></p><i class="placeholder s1"></i><i class="placeholder s1 ml10"></i></div>';
        $list .= '<div class="post_ajax_loader">' . $placeholder . $placeholder . $placeholder . '</div>';
        $list .= '</div>';

        $con = '<div class="tab-pane fade" id="' . $id . '">' . $statistical . $list . '</div>';
        echo $con;
    }

    function zib_cp_user_cardcode_lists($user_id = '', $paged = 1, $ice_perpage = 10)
    {
        if (!$user_id) $user_id = get_current_user_id();
        if (!$user_id) return;

        //准备查询参数
        $paged = !empty($_REQUEST['paged']) ? $_REQUEST['paged'] : $paged;
        $ice_perpage = !empty($_REQUEST['ice_perpage']) ? $_REQUEST['ice_perpage'] : $ice_perpage;
        $offset = $ice_perpage * ($paged - 1);
        $post_id = !empty($_REQUEST['post_id']) ? (int)$_REQUEST['post_id'] : 0;

        global $wpdb;
        $WHERE = "WHERE `status` = 1 and `order_type` = 7 and `user_id` = $user_id and `cardcode` is not null";
        if ($post_id) {
            $WHERE .= " and `post_id` = $post_id";
        }
        $db_order = $wpdb->get_results("SELECT * FROM $wpdb->zibpay_order $WHERE order by pay_time DESC limit $offset,$ice_perpage");

        $lists = '';
        if ($db_order) {
            $mark = _pz('pay_mark', '￥');
            $count_all =  $wpdb->get_var("SELECT COUNT(user_id) FROM $wpdb->zibpay_order $WHERE");;
            $ajax_url = esc_url(add_query_arg('action', 'author_tab_cardcode', admin_url('admin-ajax.php')));

            foreach ($db_order as $order) {
                $cp_data = maybe_unserialize($order->cardcode);
                if (!empty($cp_data['code'])) {
                    $cp_data = zib_cp::map($cp_data);
                    $cp_code = '<b data-clipboard-text="' . $cp_data['code'] . '" class="but c-blue clip-aut mr10 mb6">卡号：' . $cp_data['code'] . '</b>';
                    $cp_key = $cp_data['key'] ? '<b data-clipboard-text="' . $cp_data['key'] . '" class="but c-red clip-aut mb6">卡密：' . $cp_data['key'] . '</b>' : '';
                    var_dump($order);
                    $order_num = $order->order_num;
                    $order_price = $order->order_price;
                    $pay_price = $order->pay_price;
                    $pay_time = $order->pay_time;
                    $post_id = $order->post_id;
                    $pay_mate = get_post_meta($post_id, 'posts_zibpay', true);
                    $order_price = !empty($pay_mate['pay_original_price']) ? $pay_mate['pay_original_price'] : $order_price;

                    $posts_title = get_the_title($post_id);
                    $pay_title = !empty($pay_mate['pay_title']) ? $pay_mate['pay_title'] : $posts_title;
                    $pay_title = '<a class="but mr6 mb6" target="_blank" href="' . get_permalink($post_id) . '">' . $pay_title . '</a>';
                    $pay_title .= '<a class="ajax-next ajax-open but mb6" ajax-replace="true" href="' . add_query_arg('post_id', $post_id, $ajax_url) . '">仅查看此商品<i class="fa fa-angle-right ml6"></i></a>';

                    $pay_doc = '<span class="pull-right"><span class="pay-mark">价格：' . $mark . '</span>' . $order_price . '<span class="pay-mark ml10">实付金额：' . $mark . '</span>' . $pay_price . '</span>';
                    $pay_doc .= '订单时间：' . $pay_time;
                    $pay_num = '订单号：' . $order_num;

                    $lists .= '<div class="ajax-item border-bottom padding-h10">';
                    $lists .= '<div class="em09">' . $pay_title . '</div>';
                    $lists .=  $cp_code . $cp_key;
                    $lists .= '<div class="meta-time em09 muted-2-color">' . $pay_num . '</div>';
                    $lists .= '<dd class="meta-time em09 muted-2-color">' . $pay_doc . '</dd>';
                    $lists .= '</div>';
                }
            }

            // 显示下一页按钮
            if ($post_id) {
                $ajax_url = add_query_arg('post_id', $post_id, $ajax_url);
            }
            $lists .= zibpay_get_ajax_next_paging($count_all, $paged, $ice_perpage, $ajax_url);
        } else {
            $lists .= zib_get_ajax_null('暂无卡密订单', 40, 'null-order.svg');
        }

        $html = $lists;
        return $html;
    }

    //ajax导入
    function zib_cp_ajax_add_cardcode()
    {

        if (empty($_POST['post_id'])) {
            echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '文章参数为空，请先保存文章并刷新页面')));
            exit();
        }
        if (empty($_POST['cardcode'])) {
            echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请输入卡密内容')));
            exit();
        }

        $add = zib_cp::add($_POST['post_id'], $_POST['cardcode']);
        if (!empty($add['cardcode'])) {
            echo (json_encode(array('error' => 0, 'ys' => 'danger', 'cardcode' => $add['cardcode'], 'msg' => '成功添加' . $add['add_count'] . '个卡密')));
        } else {
            echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '数据添加失败！')));
        }

        exit();
    }
    add_action('wp_ajax_add_cardcode', 'zib_cp_ajax_add_cardcode');


    //ajax删除
    function zib_cp_ajax_del_cardcode()
    {

        if (empty($_POST['post_id'])) {
            echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '文章参数为空')));
            exit();
        }
        if (empty($_POST['delete'])) {
            echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '未选择删除内容')));
            exit();
        }

        $delete = zib_cp::delete($_POST['post_id'], $_POST['delete']);
        if (!empty($delete['delete'])) {
            echo (json_encode(array('error' => 0, 'ys' => 'danger', 'delete' => $delete['delete'], 'msg' => '成功删除' . $delete['count'] . '个数据')));
        } else {
            echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '内容删除失败')));
        }

        exit();
    }
    add_action('wp_ajax_del_cardcode', 'zib_cp_ajax_del_cardcode');


    //购买成功之后为用户下发卡密
    add_action('payment_order_success', 'zib_cp_add_user_cardcode');
    function zib_cp_add_user_cardcode($values)
    {
        $pay_order = (array) $values;
        $post_id = $pay_order['post_id'];
        $order_type = $pay_order['order_type'];
        //判断订单类型
        if ($order_type != 7) return;
        $order_num = $pay_order['order_num'];
        if (!isset($pay_order['cardcode'])) {
            global $wpdb;
            // 判断数据库推荐返利功能字段，无则添加
            if (!$wpdb->get_row("SELECT column_name FROM information_schema.columns WHERE table_name='$wpdb->zibpay_order' and column_name ='cardcode'")) {
                @$wpdb->query("ALTER TABLE $wpdb->zibpay_order ADD cardcode longtext DEFAULT null COMMENT '卡密'");
            }
        }

        //避免重复
        if (!empty($pay_order['cardcode'])) return;

        //执行下发卡密
        zib_cp::user_add($post_id, $order_num);
    }

    //用户中心AJAX获取卡密信息
    function zib_cp_ajax_show_author_tab_cardcode()
    {
        $con = '';
        $con .=  zib_cp_user_cardcode_lists();
        $con .= '<div class="ajax-pag hide"><div class="next-page ajax-next"><a href="#"></a></div></div>';
        echo '<body><main><div class="ajaxpager">' . $con . '</div></main></body>';
        exit;
    }
    add_action('wp_ajax_author_tab_cardcode', 'zib_cp_ajax_show_author_tab_cardcode');

    //文章内AJAX获取用户卡密信息
    function zib_cp_ajax_show_post_user_cardcode()
    {
        $con = '';
        $con .= zib_cp_post_user_cardcode_lists();
        $con .= '<div class="ajax-pag hide"><div class="next-page ajax-next"><a href="#"></a></div></div>';
        echo '<body><main><div class="ajaxpager">' . $con . '</div></main></body>';
        exit;
    }
    add_action('wp_ajax_post_user_cardcode', 'zib_cp_ajax_show_post_user_cardcode');


    //卡密发放成功为用户推送消息及邮件
    add_action('add_cardcode_success', 'zib_cp_add_cardcode_msg');
    function zib_cp_add_cardcode_msg($values)
    {
        /**根据订单号查询订单 */
        $order = (array) $values;

        $cp_data = maybe_unserialize($order['cardcode']);

        //没有卡密则退出
        if (empty($cp_data['code'])) return;

        ///标题
        $blog_name = get_bloginfo('name');
        $m_title = '卡密购买成功！请查收您的卡密信息';
        $title = '[' . $blog_name . '] ' . $m_title;

        //用户id
        $user_id = $order['user_id'];

        //用户邮箱
        $udata = get_userdata($user_id);
        $user_name = !empty($udata->display_name) ? $udata->display_name : '';
        /**获取用户邮箱 */
        $user_email = !empty($udata->user_email) ? $udata->user_email : '';

        //文章ID
        $post_id = $order['post_id'];
        //时间
        $pay_time = '购买时间：' . $order['pay_time'];

        $cp_code = '<b data-clipboard-text="' . $cp_data['code'] . '" style="color: #2997f7;background: rgba(41, 151, 247, 0.11);padding: 8px 15px;border-radius: 4px;margin-right: 10px;">卡号：' . $cp_data['code'] . '</b>';
        $cp_key = $cp_data['key'] ? '<b data-clipboard-text="' . $cp_data['key'] . '" style="color: #f75929;background: rgba(247, 128, 41, 0.1);padding: 8px 15px;border-radius: 4px;margin-right: 10px;">卡密：' . $cp_data['key'] . '</b>' : '';

        $posts_title = get_the_title($post_id);
        $pay_title = '<a style="color: #f73d2a;" target="_blank" href="' . get_permalink($post_id) . '">' . $posts_title . '</a>';

        $message = '您好！ ' . $user_name . "<br />";
        $message .= '您的卡密购买成功！请查收您的卡密信息，如遗失卡密信息，您还可进入本站用户中心查看！' . "<br />";
        $message .= $cp_code . $cp_key . "<br /><br />";

        $message .= '您可以点击下方链接查看商品详情！' . "<br />";
        $message .= $pay_title . "<br />";
        $message .= $pay_time;

        $msg_arge = array(
            'send_user' => 'admin',
            'receive_user' => $user_id,
            'type' => 'pay',
            'title' => $m_title,
            'content' => $message,
            'meta' => '',
            'other' => '',
        );
        //创建新消息
        if (_pz('message_s', true)) {
            ZibMsg::add($msg_arge);
        }

        /**发送邮件 */
        @wp_mail($user_email, $title, $message);
    }


    //缺少库存时候为管理员发送邮件
    add_action('add_cardcode_success', 'zib_cp_lack_cardcode_email_admin');
    function zib_cp_lack_cardcode_email_admin($values)
    {
        $pay_order = (array) $values;
        $post_id = $pay_order['post_id'];
        $cp_count = zib_cp::count($post_id, 'valid');

        if ($cp_count > 5) return;

        $posts_title = get_the_title($post_id);
        $title = '卡密库存不足，仅剩' . $cp_count . '个！请及时补充：商品[' . zib_str_cut($posts_title, 0, 15) . ']';

        $edit_url = add_query_arg(array('post' => $post_id, 'action' => 'edit'), admin_url('post.php'));
        $message = '您的卡密商品[' . $posts_title . ']<br />库存已经不足，请您及时补充或做其它处理！ ' . "<br /><br />";

        $message .= '卡密商品：<a target="_blank" href="' . get_permalink($post_id) . '">' . $posts_title . '</a>' . "<br /><br />";
        $message .= '当前库存：<b style="color:#ff4d6f;font-size: 30px;">' . $cp_count . '</b>' . "<br /><br />";
        $message .= '您可以点击下方链接以添加库存或者管理此商品' . "<br />";
        $message .= '<a target="_blank" href="' . esc_url($edit_url) . '"></a>' . $edit_url . "<br />";

        $blog_name = get_bloginfo('name');
        $title = '[' . $blog_name . '] ' . $title;

        /**发送邮件 */
        @wp_mail(get_option('admin_email'), $title, $message);
    }

    /**文章已经付费盒子 */
    add_filter('zibpay_posts_paid_box', 'zib_cp_posts_paid_box', 10, 4);
    function zib_cp_posts_paid_box($box, $pay_mate, $paid, $post_id = '')
    {
        $post_id = $post_id ? $post_id : get_the_ID();
        return zib_cp_posts_pay_box($box, $pay_mate, $post_id, $paid);
    }
    //文章支付盒子
    add_filter('zibpay_posts_pay_box', 'zib_cp_posts_pay_box', 10, 3);
    function zib_cp_posts_pay_box($box, $pay_mate, $post_id, $paid = 0)
    {
        // $pay = array(
        //     'order_num' => '0125122644234986754',
        //     'pay_type' => 'alipay',
        //     'pay_price' => 66.6,
        //     'pay_num' =>  '000000111111',
        //     'other' => '',
        // );
        // 更新订单状态
        //$order = ZibPay::payment_order($pay);
        $pay_mate = $pay_mate ? $pay_mate : get_post_meta($post_id, 'posts_zibpay', true);
        if (empty($pay_mate['pay_type']) || $pay_mate['pay_type'] != '7') return;

        $_thumb = zib_post_thumbnail('', 'fit-cover radius8');

        $order_type_name = zibpay_get_pay_type_name($pay_mate['pay_type']);
        $order_type_class = 'order-type-' . $pay_mate['pay_type'];

        $cuont = '';
        if (_pz('pay_show_paycount', true)) {
            global $wpdb;
            $cuont = $wpdb->get_var("SELECT COUNT(id) FROM $wpdb->zibpay_order where post_id=$post_id and status=1");
            $cuont = !empty($pay_mate['pay_cuont']) ? round($pay_mate['pay_cuont'], 0) + $cuont : $cuont;
            $cuont = $cuont > 0 ? $cuont : 0;
            $cuont = '<span class="pay-cuont badg c-green hollow" style="vertical-align: middle;">已售 ' . $cuont . '</span>';
        }

        $cp_count = zib_cp::count($post_id, 'valid');
        $cuont .= '<span class="pay-cuont badg c-red hollow" style="vertical-align: middle;">库存 ' . $cp_count . '</span>';

        $mark = _pz('pay_mark', '￥');
        $mark = '<span class="pay-mark">' . $mark . '</span>';
        $price = round($pay_mate['pay_price'], 2);
        $price_con = $mark . $price;
        //会员价格
        $vip_price = zibpay_get_posts_vip_price($pay_mate);
        $vip_price = $vip_price ? '<dd class="pay-box-price">' . $vip_price . '</dd>' : '';

        $order_name = get_bloginfo('name') . '-虚拟商品';
    
        // 推荐返佣、让利功能
        if (_pz('pay_rebate_s')) {
            $referrer_id = zibpay_get_referrer_id();
            if ($referrer_id) {
                //查询到推荐人
                //返利规则
                $rebate_ratio = zibpay_get_user_rebate_rule($referrer_id);
                if (
                    !empty($pay_mate['pay_rebate_discount'])
                    && $rebate_ratio['type']
                    && is_array($rebate_ratio['type'])
                    && (in_array('all', $rebate_ratio['type']) || in_array($pay_mate['pay_type'], $rebate_ratio['type']))
                ) {
                    // 设置标签文案
                    $referrer_data = get_userdata($referrer_id);
                    $discount_tag = _pz('pay_rebate_text_discount');
                    $discount_tag =  str_replace('%discount%', $pay_mate['pay_rebate_discount'], $discount_tag);
                    $discount_tag =  str_replace('%referrer_name%', $referrer_data->display_name, $discount_tag);
                    $vip_price .= '<dt class="pay-box-price"><span class="badg jb-red px12">' . $discount_tag . '</span></dt>';
                };
            }
        }

        $original_price = empty($pay_mate['pay_original_price']) ? '' : $pay_mate['pay_original_price'];
        if ($original_price) {
            $original_price = '<span class="original-price mr10">' . $mark . $original_price . '</span>';
        }

        $pay_wechat_sdk = _pz('pay_wechat_sdk_options');
        $pay_alipay_sdk = _pz('pay_alipay_sdk_options');

        $posts_title = get_the_title() . get_the_subtitle(false);
        $pay_title = !empty($pay_mate['pay_title']) ? $pay_mate['pay_title'] : $posts_title;

        $pay_doc = !empty($pay_mate['pay_doc']) ? $pay_mate['pay_doc'] : '此内容为' . $order_type_name . '，请付费后获取卡密信息';

        $pay_details = !empty($pay_mate['pay_details']) ? '<div class="pay-details">' . $pay_mate['pay_details'] . '</div>' : '';

        $pay_button = zibpay_get_pay_form_but();

        //变化：必须登录
        $user_id = get_current_user_id();
        if (!$user_id) {
            if (zib_is_close_sign()) {
                $pay_button = '<span class="badg px12 c-yellow-2">登录功能已关闭，暂时无法购买，请与站长联系</span>';
            } else {
                $pay_button = '<a href="javascript:;" class="but jb-blue signin-loader ml10 mr6"><i class="fa fa-angle-right mr6" aria-hidden="true"></i>登录购买</a>';
            }
        }

        if ((!$pay_wechat_sdk || $pay_wechat_sdk == 'null') && (!$pay_alipay_sdk || $pay_alipay_sdk == 'null')) {
            $pay_button = '<span class="badg px12 c-yellow-2">暂时无法购买，请与站长联系</span>';
            if (is_super_admin()) {
                $pay_button = '<a href="' . zib_get_admin_csf_url('商城付费') . '" class="but c-red mr6">请先配置收款方式！</a>';
            }
        }

        if ($cp_count < 1) {
            //如果库存为0,则停止购买
            $pay_button = '<span class="badg em09 mr6 c-red">商品已售罄</span>';
            if (is_super_admin()) {
                $pay_button = '<a href="' . get_edit_post_link($post_id) . '" class="but em09 c-red mr6">商品已售罄，请添加卡密库存</a>';
            }
        }

        $user_cp = '';
        $pay_extra_hide = '';
        if ($user_id && $paid) {
            $user_cp =  zib_cp_post_cp_tab($user_id, $post_id);

            $user_cp = $user_cp ? $user_cp : '';
            $pay_extra_hide = !empty($pay_mate['pay_extra_hide']) ? '<div class="pay-extra-hide pay-details">' . $pay_mate['pay_extra_hide'] . '</div>' : '';
        }


        $con = '<div class="zib-widget pay-box ' . $order_type_class . '" id="posts-pay">
            <div class="pay-tag abs-center">
            <i class="fa fa-book mr3"></i>' . $order_type_name . '
            </div>
            <form class="pay-form flex pay-flexbox">
                            <div class="list-inline flex0 relative mr20 hide-sm pay-thumb">
                            
                                    <div class="graphic">
                                        ' . $_thumb . '
                                    </div>
                            </div>
                            <div class="flex1 flex xx jsb">
                                
                                    <dt class="text-ellipsis pay-title">' . $pay_title . '</dt>
                                    <div class="mt10">' . $pay_doc . '</div>
                                    <div class="price-box c-red"> 
                                    <b class="em3x">'
                                    . $original_price . $price_con . $cuont . 
                                    '</b>
                                    </div>
                                    ' . $vip_price . '
                                    
                                <div class="pay-button text-right mt10">
                                    ' . $pay_button . '
                                    </div>
                            
                                
                            </div>
                                
                <input type="hidden" name="post_id" value="' . $post_id . '">
                <input type="hidden" name="order_name" value="' . $order_name . '">
                <input type="hidden" name="order_type" value="' . $pay_mate['pay_type'] . '">
                <input type="hidden" name="action" value="initiate_pay">
            </form>
            '. $pay_details .  $pay_extra_hide . $user_cp.'
        </div>';
        return $con;
    }


    function zib_cp_post_cp_tab($user_id, $post_id = 0)
    {

        $ajax_arg = array(
            'action' => 'post_user_cardcode',
            'post_id' => $post_id,
        );
        $ajax_url = esc_url(add_query_arg($ajax_arg, admin_url('admin-ajax.php')));

        $ajax_loader = '<div class="mt10"> <i class="placeholder s1" style="width: 40%;height: 30px;"></i><i class="placeholder s1 ml10" style="width: 50%;height: 30px;"></i></div>';
        $ajax_loader = '<span class="post_ajax_loader" style="display: none;">' . $ajax_loader . $ajax_loader . $ajax_loader . '</span>';

        $count =  zib_cp::user_count($user_id, $post_id);
        $but = '';
        if ($count > 1) {
            $but = '<div class="muted-2-color">已购买<b class="badg badg-sm c-red">' . $count . '</b>个卡密<a style="font-size: 12px;padding: 0 10px;" class="ajax-next ajax-open but ml10" ajax-replace="true" href="' . $ajax_url . '"><i class="fa fa-angle-right mr3"></i> 加载全部</a></div>';
        }

        $new_cp = zib_cp_post_user_cardcode_lists($user_id, $post_id, 1, 1, false);
        $html = '';
        $html .= '<div class="padding-10 mt10" style="border: 1px dashed #008cff;">';
        $html .= '<div class="title-h-left">已购卡密</div>';
        $html .= '<div class="ajaxpager">';
        $html .= '<div class="ajax-pag">' . $but . '</div>';

        $html .= $new_cp;
        $html .= $ajax_loader;
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }


    function zib_cp_post_user_cardcode_lists($user_id = '', $post_id = 0, $paged = 1, $ice_perpage = 5, $show_next = true)
    {
        if (!$user_id) $user_id = get_current_user_id();
        if (!$user_id) return;

        //准备查询参数
        $paged = !empty($_REQUEST['paged']) ? $_REQUEST['paged'] : $paged;
        $ice_perpage = !empty($_REQUEST['ice_perpage']) ? $_REQUEST['ice_perpage'] : $ice_perpage;
        $offset = $ice_perpage * ($paged - 1);
        $post_id = !empty($_REQUEST['post_id']) ? (int)$_REQUEST['post_id'] : $post_id;

        global $wpdb;
        $WHERE = "WHERE `status` = 1 and `order_type` = 7 and `user_id` = $user_id and `cardcode` is not null";
        if ($post_id) {
            $WHERE .= " and `post_id` = $post_id";
        }
        $db_order = $wpdb->get_results("SELECT * FROM $wpdb->zibpay_order $WHERE order by pay_time DESC limit $offset,$ice_perpage");

        $lists = '';
        if ($db_order) {
            $mark = _pz('pay_mark', '￥');
            $count_all =  $wpdb->get_var("SELECT COUNT(user_id) FROM $wpdb->zibpay_order $WHERE");;

            foreach ($db_order as $order) {
                $cp_data = maybe_unserialize($order->cardcode);
                if (!empty($cp_data['code'])) {
                    $cp_data = zib_cp::map($cp_data);
                    $cp_code = '<b data-clipboard-text="' . $cp_data['code'] . '" class="but c-blue clip-aut mr10 mb6">卡号：' . $cp_data['code'] . '</b>';
                    $cp_key = $cp_data['key'] ? '<b data-clipboard-text="' . $cp_data['key'] . '" class="but c-red clip-aut mb6">卡密：' . $cp_data['key'] . '</b>' : '';

                    $order_num = $order->order_num;
                    $order_price = $order->order_price;
                    $pay_price = $order->order_price;
                    $pay_time = $order->pay_time;

                    $pay_doc = '<span class="pull-right em12">' . $mark . $pay_price . '</span>';
                    $pay_doc .= '订单时间：' . $pay_time;
                    $pay_num = '订单号：' . $order_num;

                    $lists .= '<div class="ajax-item border-bottom padding-h10">';
                    $lists .=  $cp_code . $cp_key;
                    $lists .= '<div class="meta-time em09 muted-2-color">' . $pay_num . '</div>';
                    $lists .= '<dd class="meta-time em09 muted-2-color">' . $pay_doc . '</dd>';
                    $lists .= '</div>';
                }
            }

            // 显示下一页按钮
            $ajax_arg = array(
                'action' => 'post_user_cardcode',
                'post_id' => $post_id,
            );

            $ajax_url = esc_url(add_query_arg($ajax_arg, admin_url('admin-ajax.php')));

            $lists .= $show_next ? zib_get_ajax_next_paginate($count_all, $paged, $ice_perpage, $ajax_url) : '';
        } else {
            $lists .= zib_get_ajax_null('暂无卡密订单', 40, 'null-order.svg');
        }

        $html = $lists;
        return $html;
    }


    //定义全局变量
    global $wpdb;
    $wpdb->zib_cardcode  = $wpdb->prefix . 'zib_cardcode';
    class zib_cp
    {
        //获取用户卡密数据
        public static function user_get($user_id, $post_id = 0)
        {
            global $wpdb;
            $prepare = array();
            $WHERE = 'WHERE `cardcode` is not null AND order_type = %s AND status= %s AND user_id = %d';
            $prepare[] = 7;
            $prepare[] = 1;
            $prepare[] = $user_id;

            if ($post_id) {
                $WHERE .= ' AND post_id = %d';
                $prepare[] = $post_id;
            }

            $pay_order = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->zibpay_order} $WHERE", $prepare));

            return $pay_order ? (array)$pay_order : false;
        }

        //为用户增加卡密数据
        public static function user_add($post_id, $order_num)
        {
            global $wpdb;
            $cp_data = self::pay($post_id, $order_num);
            if (!$cp_data) return false;

            //准备参数
            $order_data = array(
                'cardcode' => maybe_serialize($cp_data),
            );

            //准备查询参数
            $where = array('order_num' => $order_num);

            if (false !== $wpdb->update($wpdb->zibpay_order, $order_data, $where)) {
                $order = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->zibpay_order} WHERE order_num = %s AND status = %d", $order_num, 1));
                if ($order) {
                    do_action('add_cardcode_success', $order);
                    return $order;
                }
            }
        }

        //获取文章一个未售的卡密数据
        public static function pay($post_id, $order_num)
        {
            $cp_data = self::get($post_id);
            if (!$cp_data) return false;
            $pay_data = array();
            foreach ($cp_data as $key => $cp) {
                if (!empty($cp['code']) && empty($cp['status'])) {
                    $cp['order'] = $order_num;
                    $cp['modified_time'] = current_time('mysql');
                    $cp['status'] = 1;
                    $pay_data = $cp;
                    $cp_data[$key] = $cp;
                    break;
                }
            }

            if (!$pay_data) return false;
            //更新数据
            if (update_post_meta($post_id, 'cardcode', $cp_data)) {
                return $pay_data;
            }
            return false;
        }

        //用户数据格式化
        public static function user_map($data)
        {
            $defaults = array(
                'code' => '',
                'key' => '',
                'posts_id' => '',
                'pay_time' => '',
                'order' => '',
            );
            $val = wp_parse_args((array) $data, $defaults);
            if (!$val['code']) {
                return;
            }
            return $val;
        }

        //获取文章卡密数据
        public static function get($post_id)
        {
            $cp = get_post_meta($post_id, 'cardcode', true);
            return $cp ? (array)$cp : false;
        }

        //删除文章的卡密数据
        public static function delete($post_id, $key)
        {

            $data = self::get($post_id);
            $delete = array();
            if (is_array($key)) {
                //如果传入数组,则循环删除
                foreach ($key as $key_v) {
                    if (!empty($data[$key_v])) {
                        $delete[$key_v] = $data[$key_v];
                        unset($data[$key_v]);
                    }
                }
            } else {
                if (!empty($data[$key])) {
                    $delete[$key] = $data[$key];
                    unset($data[$key]);
                }
            }

            if (update_post_meta($post_id, 'cardcode', $data)) {
                return array('delete' => $delete, 'count' => count($delete));
            } else {
                return false;
            }
        }

        //更新文章卡密数据
        public static function update($post_id, $val = array())
        {
            $old = self::get($post_id);
            if (is_array($old)) {
                $old_count = count($old);
                $new = array_merge($old, $val);
            } else {
                $old_count = 0;
                $new = $val;
            }
            $new = self::array_unset_tt($new, 'code');
            $new_count = count($new);
            if (update_post_meta($post_id, 'cardcode', $new)) {
                return array('cardcode' => $new, 'add_count' => ($new_count - $old_count));
            } else {
                return false;
            }
        }

        //导入文章卡密数据
        public static function import($post_id, $val)
        {
            //分割每一行
            $row_array = preg_split("/\r|\n/", $val);

            //每一行分割为数组
            $val_array = array();
            foreach ($row_array as $row_s) {
                //如果没有卡号则跳出
                $row = preg_split("/,|，|----|\s/", $row_s);
                if (empty($row[0])) {
                    continue;
                }
                $val_array[] = array(
                    'code' => !empty($row[0]) ? trim($row[0]) : '',
                    'key' => !empty($row[1]) ? trim($row[1]) : '',
                    'status' => 0,
                    'create_time' => current_time('mysql'),
                    'modified_time' => '',
                    'order' => '',
                );
            }
            return self::update($post_id, $val_array);
        }

        //添加文章卡密数据
        public static function add($post_id, $val)
        {
            if (is_array($val)) {
                $val = array_map(array('zib_cp', "map"), $val);
                return self::update($post_id, $val);
            } else {
                return self::import($post_id, $val);
            }
        }

        /**
         * @description:
         * @param {*} $post_id
         * @param {*} $status 全部：all|未售有效：valid|已售无效：invalid
         * @return {*}
         */
        public static function count($post_id, $status = 'all')
        {
            $data = self::get($post_id);

            if (!$data) return 0;

            if ($status == 'all') {
                $count = count($data);
            } else {
                $status_1 = array_keys(array_column($data, 'status'), 1);
                $status_1_count = $status_1 ? count($status_1) : 0;
                if ($status == 1 || $status == 'invalid') {
                    $count = $status_1_count;
                } else {
                    $count = count($data) - $status_1_count;
                }
            }
            return $count;
        }

        //获取用户购买的卡密数量
        public static function user_count($user_id, $post_id = 0)
        {
            global $wpdb;
            $WHERE = "WHERE `status` = 1 and `order_type` = 7 and `user_id` = $user_id and `cardcode` is not null";
            if ($post_id) {
                $WHERE .= " and `post_id` = $post_id";
            }

            $count =  $wpdb->get_var("SELECT COUNT(user_id) FROM $wpdb->zibpay_order $WHERE");
            return $count;
        }

        //数组去重
        public static function array_unset_tt($arr, $key)
        {
            //建立一个目标数组
            $res = array();
            foreach ($arr as $value) {
                //查看有没有重复项
                if (isset($res[$value[$key]])) {
                    //有：销毁
                    unset($value[$key]);
                } else {
                    $res[$value[$key]] = $value;
                }
            }
            return $res;
        }

        //
        public static function status_name($status, $html = true)
        {
            $status = (int)$status;
            $status_array = array(
                0 => array(
                    'name' => '未售',
                    'class' => 'b-blue',
                ),
                1 => array(
                    'name' => '已售',
                    'class' => 'b-red',
                ),
            );
            $name = $status_array[$status]['name'];
            $name = $html ? '<span style="padding: 1px 10px;min-width: auto;" class="but ' . $status_array[$status]['class'] . '">' . $name . '</span>' : $name;
            return $name;
        }
        public static function map($val)
        {
            $defaults = array(
                'code' => '',
                'key' => '',
                'status' => 0,
                'create_time' => '',
                'modified_time' => '',
                'order' => '',
            );
            $val = wp_parse_args((array) $val, $defaults);
            if (!$val['code']) {
                return;
            }
            return $val;
        }

        //over
    }

}
?>