<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\functions\feature\wml-bulletin.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-21 03:42:29
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

if (wml_zib('bulletin_switch', false)) {
    //注册公告模块
    function post_type_bulletin() {
        register_post_type(
            'bulletin', 
            array( 'public' => true,
            'publicly_queryable' => true,
            'hierarchical' => false,
            'labels'=>array(
                'name' => _x('公告', 'post type general name'),
                'singular_name' => _x('公告', 'post type singular name'),
                'add_new' => _x('添加新公告', '公告'),
                'add_new_item' => __('添加新公告'),
                'edit_item' => __('编辑公告'),
                'new_item' => __('新的公告'),
                'view_item' => __('预览公告'),
                'search_items' => __('搜索公告'),
                'not_found' =>  __('您还没有发布公告'),
                'not_found_in_trash' => __('回收站中没有公告'), 
                'parent_item_colon' => ''
                ),
             'show_ui' => true,
             'menu_icon' => 'dashicons-megaphone',
             'menu_position'=>5,
                'supports' => array(
                'title',
                'author', 
                'excerpt',
                'thumbnail',
                'trackbacks',
                'editor', 
                'comments',
                'custom-fields',
                'revisions' ) ,
            'show_in_nav_menus' => true ,
            'taxonomies' => array(
                'menutype',
                'post_tag')
                ) 
        ); 
    } 
    add_action('init', 'post_type_bulletin');
     
    function create_genre_taxonomy() {
      $labels = array(
             'name' => _x( '公告分类', 'taxonomy general name' ),
             'singular_name' => _x( 'genre', 'taxonomy singular name' ),
             'search_items' =>  __( '搜索分类' ),
             'all_items' => __( '全部分类' ),
             'parent_item' => __( '父级分类目录' ),
             'parent_item_colon' => __( '父级分类目录:' ),
             'edit_item' => __( '编辑公告分类' ), 
             'update_item' => __( '更新' ),
             'add_new_item' => __( '添加新公告分类' ),
             'new_item_name' => __( 'New Genre Name' ),
      ); 
      register_taxonomy('genre',array('bulletin'), array(
             'hierarchical' => true,
             'labels' => $labels,
             'show_ui' => true,
             'query_var' => true,
             'rewrite' => array( 'slug' => 'genre' ),
      ));
    }
    add_action( 'init', 'create_genre_taxonomy', 0 );
    //注册公告模块结束

    //前端显示
    // 注册头部CSS
    add_action('wp_head', 'bulletin_head');
    function bulletin_head(){?>
        <link rel="stylesheet" href="<?php echo WML_ZIB_BEAUT_DIR_URL . '/css/bulletin.css' ?>" />
    <?php }

    // 注册底部JS
    add_action('wp_footer', 'bulletin_footer');
    function bulletin_footer(){?>
        <script>
        (function($) {
            $.fn.FontScroll = function(options) {
                var d = { time: 3000, s: 'fontColor', num: 1 }
                var o = $.extend(d, options);
                this.children('ul').addClass('line');
                var _con = $('.line').eq(0);
                var _conH = _con.height(); 
                var _conChildH = _con.children().eq(0).height(); 
                var _temp = _conChildH; 
                var _time = d.time; 
                var _s = d.s; 
                _con.clone().insertAfter(_con); 
                var num = d.num;
                var _p = this.find('li');
                var allNum = _p.length;
                _p.eq(num).addClass(_s);
                var timeID = setInterval(Up, _time);
                this.hover(function() { clearInterval(timeID) }, function() { timeID = setInterval(Up, _time); });
                function Up() {
                    _con.animate({ marginTop: '-' + _conChildH });
                    _p.removeClass(_s);
                    num += 1;
                    _p.eq(num).addClass(_s);

                    if (_conH == _conChildH) {
                        _con.animate({ marginTop: '-' + _conChildH }, "normal", over);
                    } else {
                        _conChildH += _temp;
                    }
                }
                function over() {
                    _con.attr("style", 'margin-top:0');
                    _conChildH = _temp;
                    num = 1;
                    _p.removeClass(_s);
                    _p.eq(num).addClass(_s);
                }
            }
        })(jQuery);
        $(function() {
            $('.marquee_box').FontScroll({ time: 5000, num: 1 });
        });
        </script>
    <?php }
    if(wml_zib('bulletin_type')==1){
        //注册钩子
        add_action('widgets_init', 'register_bulletin');
        function register_bulletin()
        {
            register_widget('wml_bulletin');
        }
        class wml_bulletin extends WP_Widget
        {
            public function __construct()
            {
                //定义小工具
                $widget = array(
                    'w_id'        => 'wml_bulletin',
                    'w_name'      => '外贸啦 - 公告滚动条',
                    'classname'   => '',
                    'description' => '公告滚动条，文章、会员统计',
                );
                parent::__construct($widget['w_id'], $widget['w_name'], $widget);
            }

            public function widget($args, $instance)
            {
                if (!zib_widget_is_show($instance)) {
                    return;
                }
                extract($args);
                if (!wp_is_mobile()){//手机端不显示
                    echo wml_zib_bulletin_html();//前端显示
                }
            }
        }
    }else{
        if (!wp_is_mobile()){//手机端不显示
            add_action('wp_head_home_wml', 'wml_zib_bulletin_html');//注册钩子
        }
    }
    function wml_zib_bulletin_html(){
        
        $count_posts = wp_count_posts(); 
        //会员总数
        global $wpdb;
        $users = wml_zib('cheat_hy')+$wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->users");
        ob_start();//打开输出控制缓冲
        if(wml_zib('bulletin_c')==1){
            $tname='最新公告';
            $tsql='bulletin';
        }else{
            $tname='最新发布';
            $tsql='post';
        }
        ?>
        <div class="theme-box">
        <div class="deanggwrap">
        <div class="deangg comfff wow fadeInUp">
        <div class="deanggspan"><i class="fa fa-volume-up"></i><span><?php echo $tname; ?></span></div>
        <b></b>
        <div class="deanggc"><!--[diy=deanggc]-->
        <div class="announce-wrap">
        <ul class="announce-list line" style="margin-top: 0px;">
        <?php
            $post_num = wml_zib('bulletin_num'); // 显示文章的数量.
            $args=array(
            'post_type' => $tsql,//文章类型
            'post_status' => 'publish',//已发布
            'caller_get_posts' => 1,//ID为1的作者
            'posts_per_page' => $post_num
            );
            query_posts($args);
            // 主循环
            if ( have_posts() ) : while ( have_posts() ) : the_post();
        ?>
        <li><a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a><span><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo the_time('Y-m-d')?> <i style="padding-left:10px;" class="fa fa-eye" aria-hidden="true"></i> <?php echo get_post_view_count('', '', ''); ?></li>
        <?php endwhile; else: endif; wp_reset_query();?>
        </ul>
        </div>
        <!--[/diy]--></div>
        <div class="clear"></div>
        </div>
        <div class="deanchart">
        <ul>
        <!--[diy=deanchart]-->
        <div id="portal_block_396_content" class="dxb_bc">
        <li class="deanchart5"><i></i>
        <div class="deanchartdiv"><span>会员总数</span>
        <div class="clear"></div>
        <em id="num4"><?php echo $users;?></em></div>
        <div class="clear"></div>
        </li>
        <li class="deanchart3"><i></i>
        <div class="deanchartdiv"><span>今日发布</span>
        <div class="clear"></div>
        <em id="num4"><?php echo CSF_Module_Wml_Count::WeeklyUpdate();?></em></div>
        <div class="clear"></div>
        </li>
        <li class="deanchart2"><i></i>
        <div class="deanchartdiv"><span>本周发布</span>
        <div class="clear"></div>
        <em id="num6"><?php echo CSF_Module_Wml_Count::get_posts_count_from_last_168h(); ?></em></div>
        <div class="clear"></div>
        </li>
        <li class="deanchart4"><i></i>
        <div class="deanchartdiv"><span>文章总数</span>
        <div class="clear"></div>
        <em id="num3"><?php echo $published_posts = $count_posts->publish;?></em></div>
        <div class="clear"></div>
        </li>
        </div>
        <!--[/diy]-->
        <div class="clear"></div>
        </ul>
        </div>
        <div class="clear"></div>
        </div>
        </div>
    <?php
    }
}
