<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\functions\feature\wml-trash.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-16 02:06:19
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

//开启回收站
if (wml_zib('trash_switch', false)) {
    //判断是否开启回收站定义
    function enable_media_notices() {
        $is_defined = defined( 'MEDIA_TRASH' );
        if ( !($is_defined && MEDIA_TRASH )) {
            ?>
             <div class="notice notice-error is-dismissible">
             <p>提示：要在媒体中启用回收站功能，请添加一行定义<code>define( 'MEDIA_TRASH', 'true' );</code>到主目录<code>wp-config.php</code>文件中，在“<code>就这，停止编辑</code>”这一行之前。</p>
            </div>
            <?php
        }
    }
    add_action('admin_notices','enable_media_notices');

    //后台添加回收站按钮
    add_action('admin_footer', 'wml_admin_footer');
    function wml_admin_footer()
    { ?>
        <script>
                (function($) {
                    "use strict";
                    $(document).ready(function(){
                        $("#menu-media ul").append("<li class='media-trash-menu'><a class='media-trash' href='upload.php?mode=list&attachment-filter=trash&media_folder'>回收站</a></li>");
                        <?php if(isset($_REQUEST['attachment-filter']) && $_REQUEST['attachment-filter']=="trash") { ?>
                            $("#menu-media .current").removeClass("current");
                            $("#menu-media .media-trash-menu").addClass("current");
                            $(".wp-filter .view-switch a").remove();
                            $(".wp-filter .view-switch").css("height","28px").css("margin", "0");
                        <?php } ?>
                    });
                })(jQuery);
            </script>
    <?php }
}
