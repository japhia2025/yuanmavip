<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-09 21:49:38
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-11 15:37:54
 * @FilePath: \WaiMaoLa_Diy\core\functions\feature\wml-horn-all.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682233
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */
CSF::createMetabox('Mario', array(
    'title'     => '附加选项',
    'post_type' => array('post', 'plate', 'forum_post'),
    'context'   => 'advanced',
    'data_type' => 'unserialize',
));

CSF::createSection('Mario', array(
    'fields' => array(
        array(
            'title'   => __('开启文章角标'),
            'id'      => 'horn_diy_switch',
            'type'    => 'switcher',
            'label'   => '角标',
            'desc'   => '填哪个显示哪个，内容留空则不显示',
            'default' => false
        ),
        array(
            'dependency' => array('horn_diy_switch', '!=', ''),
            'title'   => __('左上角标内容'),
            'id'      => 'horn_diy_l_t',
            'type'    => 'text',
            'default' => wml_zib('horn_diy_l_t2'),
        ),
        array(
            'dependency' => array('horn_diy_switch', '!=', ''),
            'title'   => __('背景颜色'),
            'id'      => 'horn_diy_l_c',
            'default' => wml_zib('horn_diy_l_c2'),
            'class'   => 'compact skin-color',
            'type'    => "palette",
            'options'  => CSF_Module_Wml_Zib::zib_palette(),
        ),
        array(
            'dependency' => array('horn_diy_switch', '!=', ''),
            'title'   => __('右上角标内容'),
            'id'      => 'horn_diy_r_t',
            'type'    => 'text',
            'default' => wml_zib('horn_diy_r_t2'),
        ),
        array(
            'dependency' => array('horn_diy_switch', '!=', ''),
            'title'   => __('背景颜色'),
            'id'      => 'horn_diy_r_c',
            'class'   => 'compact skin-color',
            'default' => wml_zib('horn_diy_r_c2'),
            'type'    => "palette",
            'options'  => CSF_Module_Wml_Zib::zib_palette(),
        ),
        array(
            'dependency' => array('horn_diy_switch', '!=', ''),
            'title'   => __('封面底部内容'),
            'id'      => 'horn_diy_b_t',
            'type'    => 'text',
            'default' => wml_zib('horn_diy_b_t2'),
        ),
        array(
            'dependency' => array('horn_diy_switch', '!=', ''),
            'title'   => __('背景颜色'),
            'id'      => 'horn_diy_b_c',
            'class'   => 'compact skin-color',
            'default' => wml_zib('horn_diy_b_c2'),
            'type'    => "palette",
            'options'  => CSF_Module_Wml_Zib::zib_palette(),
        ),

    ),
));