<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\functions\feature\wml-maintenance.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-18 02:38:09
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

//维护开关
if (!is_admin() && wml_zib('is_maintenance', false)) {
	add_action('wp_loaded', function (){
		global $pagenow;

		if (current_user_can('manage_options')  || $pagenow == 'wp-login.php' || $_SERVER['REQUEST_URI'] == "/user-sign?tab=signin&redirect_to") {
		//if (current_user_can('manage_options')) {
			return;
		}
		
		header( $_SERVER["SERVER_PROTOCOL"] . ' 503 Service Temporarily Unavailable', true, 503 );
		header('Content-Type:text/html;charset=utf-8');

		require 'wp-content/plugins/WaiMaoLa_Diy/page/maintenance/index.php';

		exit;
	});
}
