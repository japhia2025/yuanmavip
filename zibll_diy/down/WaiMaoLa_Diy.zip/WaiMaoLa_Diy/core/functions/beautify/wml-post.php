<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\functions\beautify\wml-post.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-30 10:20:21
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

// 文章外部标签随机彩色
if (wml_zib('tag_w_color', false))
{
    function wml_zib_tag_w_color() { ?>
        <script>
            /*文章外部标签随机彩色*/
            var links = document.querySelectorAll('.item-tags a');
            for (var i = 0; i < links.length; i++) {
              var randomColor = '#' + Math.floor(Math.random()*16777215).toString(16);
              links[i].style.backgroundColor = randomColor;
            }
        </script>
        <style>
             .item-tags a {padding: 5px 10px;border-radius: 5px;margin-right: 5px;}.item-tags a.meta-pay {background-color: #FFD700;color: black;}.item-tags a.c-blue {background-color: #1E90FF;color: white;}.item-tags a[href*="tag/"] {background-color: #FF69B4;color: white;}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_tag_w_color');
}

// 文章内部底下标签彩色
if (wml_zib('tag_n_color', false))
{
    function wml_zib_tag_n_color() { ?>
        <style>
            /*文章底部随机彩色标签*/
            .article-tags{margin-bottom: 10px}.article-tags a{padding: 4px 10px;background-color: #19B5FE;color: white;font-size: 12px;line-height: 16px;font-weight: 400;margin: 0 5px 5px 0;border-radius: 2px;display: inline-block}.article-tags a:nth-child(5n){background-color: #4A4A4A;color: #FFF}.article-tags a:nth-child(5n+1){background-color: #ff5e5c;color: #FFF}.article-tags a:nth-child(5n+2){background-color: #ffbb50;color: #FFF}.article-tags a:nth-child(5n+3){background-color: #1ac756;color: #FFF}.article-tags a:nth-child(5n+4){background-color: #19B5FE;color: #FFF}.article-tags a:hover{background-color: #1B1B1B;color: #FFF}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_tag_n_color');
}

// 文章底部添加转载声明
if (wml_zib('posts_zhuanzai', false))
{
    function wml_zib_posts_zhuanzai() {
        echo '
        <div class="em09 muted-3-color"><div><span>©</span> 转载声明</div><div class="posts-copyright"><p>本文链接：<a href="'.get_permalink().'" title="'.get_the_title().'" target="_blank">'.get_permalink().'</a></br>文章版权归作者所有，转载务必注明来源。</p></div></div>';
    }
    add_action('zib_posts_content_after', 'wml_zib_posts_zhuanzai');
}

// 文章底部添加过期提示
if (wml_zib('posts_gqts', false))
{
    function wml_zib_posts_gqts() {
        //$date = get_the_modified_time('Y-m-d');
        $date = get_the_modified_time('Y-m-d H:i:s' );
        $content = '
        <div class="article-timeout">
            <strong>
                <i class="fa fa-exclamation-triangle" aria-hidden="true" style="color: red;"></i> 温馨提示：
            </strong>本文最后更新于<code>' . $date . '</code>，' . wml_zib('posts_gqts_text') . '
        </div>
        <style>
            .article-timeout{position:relative; border-radius: 8px; position: relative; margin-bottom: 25px; padding: 10px; background-color: var(--body-bg-color);}
        </style>';
        echo $content;
    }
    add_action('zib_posts_content_after', 'wml_zib_posts_gqts');
}

// 文章内页提示条
if (wml_zib('post_tooltip', false)) {
    function wml_zib_post_tooltip(){?>
        <style>
        .pt-sys-item {background-image: url(<?php echo WML_ZIB_BEAUT_DIR_URL . 'img/post/tooltip_bj'.wml_zib('post_tooltip_r').'.png';?>);margin-top: 10px;margin-bottom: 10px;height: 40px;line-height: 40px;font-size: 14px;color: #fff;text-align: center;border-radius: 6px;font-weight: 500;}
        </style>
        <div class="pt-sys-item"><?php echo wml_zib('post_tooltip_text'); ?></div>
<?php }
    wml_zib('post_tooltip_t')==1?$add_a='zib_posts_content_before':$add_a='zib_posts_content_after';
    add_action($add_a, 'wml_zib_post_tooltip');
}

// 文章标题鼠标悬停划线
if (wml_zib('xthx', false))
{
    function wml_zib_xthx() { ?>
        <style>
            .posts-item .item-heading>a {background: linear-gradient(to right, #ec695c, #61c454) no-repeat right bottom;background-size: 0 2px;transition: background-size 1300ms }.posts-item .item-heading>a:hover {background-position-x: left;background-size: 100% 5px }.article-title>a {background: linear-gradient(to right, #ec695c, #61c454) no-repeat right bottom;background-size: 0 2px;transition: background-size 1300ms }.article-title>a:hover {background-position-x: left;background-size: 100% 5px }.zib-widget .text-ellipsis>a {background: linear-gradient(to right, #ec695c, #61c454) no-repeat right bottom;background-size: 0 2px;transition: background-size 1300ms }.zib-widget .text-ellipsis>a:hover {background-position-x: left;background-size: 100% 5px }.zib-widget .text-ellipsis-2>a {background: linear-gradient(to right, #ec695c, #61c454) no-repeat right bottom;background-size: 0 2px;transition: background-size 1300ms }.zib-widget .text-ellipsis-2>a:hover {background-position-x: left;background-size: 100% 5px }
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_xthx');
}

// 文章内页小标题美化（图标）
if (wml_zib('subtitle', false))
{
    function wml_zib_subtitle() {
    ?>
        <style>
.wp-posts-content>h1.wp-block-zibllblock-biaoti,
.wp-posts-content>h2.wp-block-zibllblock-biaoti,
.wp-posts-content>h3.wp-block-zibllblock-biaoti,
.wp-posts-content>h4.wp-block-zibllblock-biaoti{
	background: initial;
	/* background-color: rgba(114, 114, 114, 0.1); */
}
.wp-posts-content>h1.wp-block-heading,
.wp-posts-content h1{
    line-height: 32px;
    padding: 0px 20px 0px 32px;
	border-bottom: 4px solid rgba(114, 114, 114, 0.1);
	background: url(<?php echo wml_zib('subtitle_h1', false);?>) 0px center no-repeat;
}
.wp-posts-content>h2.wp-block-heading,
.wp-posts-content h2{
	line-height: 33px;
    padding: 0px 20px 0px 28px;
	border-bottom: 4px solid rgba(114, 114, 114, 0.1);
	background: url(<?php echo wml_zib('subtitle_h2', false);?>) 0px center no-repeat;
	background-size: 25px 25px;
}
.wp-posts-content>h3.wp-block-heading,
.wp-posts-content h3{
	padding: 0px 0px 0px 30px !important;
	background: url(<?php echo wml_zib('subtitle_h3', false);?>) 0px center no-repeat;
	background-size: 25px 25px;
}
.wp-posts-content>h4.wp-block-heading,
.wp-posts-content h4{
	padding: 0px 0px 0px 25px !important;
	background: url(<?php echo wml_zib('subtitle_h4', false);?>) 0px center no-repeat;
	background-size: 20px 20px;
}
/* 清除下划线 */
/* .title-theme:before {display: none;} */
.wp-posts-content>h1.wp-block-heading:before{display:none;}
.wp-posts-content>h2.wp-block-heading:before{display:none;}
.wp-posts-content>h3.wp-block-heading:before{display:none;}
.wp-posts-content>h4.wp-block-heading:before{display:none;}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_subtitle');
}


//文章内页小标题美化（颜色）
if (wml_zib('subtitle_color', false)) {
    function wml_zib_subtitle_color()
    {
        $type = wml_zib('subtitle_color_r'); //样式
        if ($type=='1') {//纯色风格 ?>
            <style>
                .wp-posts-content h1, .wp-posts-content h2, .wp-posts-content h3, .wp-posts-content h4, .wp-posts-content h5 {font-weight: bold;background-color: #f6f6f6;margin: 20px 0;border-bottom: 0px solid red;padding: 5px 12px;border-left: 5px solid red;margin: 12px 0px;border-radius: 0rem;}.wp-posts-content h2 {font-weight: bold;background-color: #f6f6f6;margin: 20px 0;border-bottom: 0px solid #FF1493;padding: 5px 12px;border-left: 5px solid #FF1493;border-radius: 0rem;margin: 12px 0px;}.wp-posts-content h3 {font-weight: bold;background-color: #f6f6f6;margin: 20px 0;border-bottom: 0px solid #4169E1;padding: 5px 12px;border-left: 5px solid #4169E1;margin: 12px 0px;border-radius: 0rem;}.wp-posts-content h4 {font-weight: bold;background-color: #f6f6f6;margin: 20px 0;border-bottom: 0px solid #3CB371;padding: 5px 12px;border-left: 5px solid #3CB371;margin: 12px 0px;border-radius: 0rem;}.wp-posts-content h5 {font-weight: bold;background-color: #f6f6f6;margin: 20px 0;border-bottom: 0px solid #FFC0CB;padding: 5px 12px;border-left: 5px solid #FFC0CB;margin: 12px 0px;border-radius: 0rem;}
            </style>
        <?php }
        elseif ($type=='2') {//彩色风格 ?>
            <style>
                .wp-posts-content h1{font-size:25px;font-weight:bold;color: #e50d4c;background-color: #fccad3;border-bottom: 1px solid;padding: 5px 15px;border-left: 5px solid;margin:18px 0px 18px 0px;overflow: hidden;}.wp-posts-content h2{font-size:21px;font-weight:bold;color: #850de8;background-color: #eeeafe;border-bottom: 1px solid;padding: 5px 15px;border-left: 5px solid;margin:18px 0px 18px 0px;overflow: hidden;}.wp-posts-content h3{font-size:17px;font-weight:bold;color: #41b0f4;background-color: #ddf0fe;border-bottom: 1px solid;padding: 5px 15px;border-left: 5px solid;margin:18px 0px 18px 0px;overflow: hidden;}.wp-posts-content h4{font-size:13px;font-weight:bold;color: #20b60b;background-color: #ebfde5;border-bottom: 1px solid;padding: 5px 15px;border-left: 5px solid;margin:18px 0px 18px 5px;overflow: hidden;}.wp-posts-content h5{font-size:10px;font-weight:bold;color: #f1e40f;background-color: #fefeea;border-bottom: 1px solid;padding: 5px 15px;border-left: 5px solid;margin:18px 0px 18px 10px;overflow: hidden;}
            </style>
        <?php }
        elseif ($type=='3') {//灰色阴影 ?>
            <style>
                .wp-posts-content h1,
                .wp-posts-content h2,
                .wp-posts-content h3,
                .wp-posts-content h4,
                .wp-posts-content h5 {
                    font-size:24px;/*字体大小*/
                    font-weight:bold;/*设置文本粗细*/
                    background-color: #ffffff;/*背景颜色*/
                    border-bottom: 1px solid;/*边框宽度 *颜色定义*/
                    padding: 5px 15px;/*宽高*/
                    border-left: 8px solid;/*定位*/
                    margin:18px 0px 18px -20px;/*定位*/
                    overflow: hidden;/*溢出修剪*/
                    box-shadow:2px 6px 10px #5F9EA0;/*设置块阴影  水平位移   垂直位移    模糊半径 */
                }
            </style>
        <?php }
            //去除下划线开始
            ?>
            <style>
                .wp-posts-content>h1.wp-block-heading:before{display:none;}
                .wp-posts-content>h2.wp-block-heading:before{display:none;}
                .wp-posts-content>h3.wp-block-heading:before{display:none;}
                .wp-posts-content>h4.wp-block-heading:before{display:none;}
                .wp-posts-content>h5.wp-block-heading:before{display:none;}
            </style>
            <?php
            //去除下划线结束
    }
    add_action('wp_footer', 'wml_zib_subtitle_color');
}

// 文章绿色阴影边缘
if (wml_zib('post_box_shadow'))
{
    function wml_zib_post_box_shadow() { ?>
        <style>.article{border-radius:var(--main-radius);box-shadow: 1px 1px 3px 3px rgba(53, 231, 8, 0.35);-moz-box-shadow: 1px 1px 3px 3px rgba(53, 231, 8, 0.35);}.article:hover{box-shadow: 1px 1px 5px 5px rgba(53, 231, 8, 0.35); -moz-box-shadow: 1px 1px 5px 5px rgba(53, 231, 8, 0.35);}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_post_box_shadow');
}

// 文章内图片边框光效
if (wml_zib('post_page_img_shadow'))
{
    function wml_zib_post_page_img_shadow() { ?>
        <style>
            .wp-posts-content img:hover {box-shadow: 0px 0px 8px #63B8FF;}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_post_page_img_shadow');
}

//文章内代码高亮美化
if (wml_zib('bianjiqi', false))
{
    function wml_zib_bianjiqi() { ?>
        <style>
            .enlighter::before {content: "";display: block;background: #fc625d;top: 9px;left: 15px;border-radius: 50%;width: 15px;height: 15px;box-shadow: 20px 0 #fdbc40, 40px 0 #35cd4b;margin: 0px 2px -7px;z-index: 1;position: absolute;}.enlighter-overflow-scroll.enlighter-v-standard .enlighter {padding: 35px 0 12px 0;}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_bianjiqi');
}

//文章页版权声明
if (wml_zib('posts_bq'))
{
    function wml_zib_pro_banquan() {
        $posts_bq_sm = wml_zib('posts_bq_sm'); ?>
        <?php if ($posts_bq_sm['yangshi'] == '1') { ?>
            <div>
                <fieldset style=" border: 1.5px dashed #008cff; padding: 10px; border-radius: 5px; line-height: 2em;font-weight: 700;color: var(--key-color);background-color: var(--body-bg-color);">
                    <legend align="center" style=" margin-bottom: -2px;width: 30%;text-align: center; background-color: #008cff; border-radius: 999px; background-image: linear-gradient(to right, #FFCC99, #FF99CC);border: 1.5px dashed #008cff;">
                        <?php echo $posts_bq_sm['title']; ?>
                    </legend>
                    <span class="btn-info btn-xs">1</span> 本网站名称：<span style="color: #3333ff">
                        <span style="color: #09ace2; font-size: 18px">
                            <strong><?php echo get_bloginfo('name'); ?></strong>
                        </span>
                    </span>
                    <br />
                    <span class="btn-info btn-xs">2</span> 本站永久网址：<font color="#09ace2"><?php echo get_bloginfo('url'); ?></font>
                    <br />
                    <?php
                    @$sm = $posts_bq_sm['sm'];
                    if ($sm) {
                        foreach ($sm as $key => $value) {
                    ?>
                        <span class="btn-info btn-xs"><?php echo $value['id']; ?></span> <?php echo $value['text']; ?>
                        <br />
                    <?php }
                    } ?>
                </fieldset>
            </div><br>
        <?php } ?>
        <?php if ($posts_bq_sm['yangshi'] == '2') { ?>
            <div>
                <fieldset style="
                    border: 1px dashed #008cff;
                    padding: 10px;
                    border-radius: 5px;
                    line-height: 2em;
                    color: #6d6d6d;
                    ">
                    <legend align="center" style="
                        width: 30%;
                        text-align: center;
                        background-color: #008cff;
                        border-radius: 5px;
                    background-image: linear-gradient(to right, #0066FF, #FF99CC); text-align:center;">
                        <?php echo $posts_bq_sm['title']; ?>
                    </legend>
                    <span class="btn-info btn-xs">1</span> 本网站名称：<span style="color: #3333ff">
                        <span style="color: #09ace2; font-size: 18px">
                            <strong><?php echo get_bloginfo('name'); ?></strong>
                        </span>
                    </span>
                    <br />
                    <span class="btn-info btn-xs">2</span> 本站永久网址：<font color="#09ace2"><?php echo get_bloginfo('url'); ?></font>
                    <br />
                    <?php
                    @$sm = $posts_bq_sm['sm'];
                    if ($sm) {
                        foreach ($sm as $key => $value) {
                    ?>
                            <span class="btn-info btn-xs"><?php echo $value['id']; ?></span> <?php echo $value['text']; ?>
                            <br />
                    <?php }
                    } ?>
                </fieldset>
            </div><br>
        <?php } ?>
        <?php if ($posts_bq_sm['yangshi'] == '3') { ?>
            <div>
                <fieldset style="
                    border: 1px dashed #008cff;
                    padding: 10px;
                    border-radius: 5px;
                    line-height: 2em;
                    color: #6d6d6d;
                ">
                    <legend align="center" style="
                    width: 30%;
                    text-align: center;
                    background-color: #008cff;
                    border-radius: 5px;
                    background-image: linear-gradient(to right, #FFCC99, #FF99CC); text-align:center;">
                        <?php echo $posts_bq_sm['title']; ?>
                    </legend>
                    <span class=" btn-info btn-xs">1</span> 本网站名称：<span style="color: #3333ff">
                        <span style="color: #09ace2; font-size: 18px">
                            <strong><?php echo get_bloginfo('name'); ?></strong>
                        </span>
                    </span>
                    <br />
                    <span class="btn-info btn-xs">2</span> 本站永久网址：<font color="#09ace2"><?php echo get_bloginfo('url'); ?></font>
                    <br />
                    <?php
                    @$sm = $posts_bq_sm['sm'];
                    if ($sm) {
                        foreach ($sm as $key => $value) {
                    ?>
                            <span class="btn-info btn-xs"><?php echo $value['id']; ?></span> <?php echo $value['text']; ?>
                            <br />
                    <?php }
                    } ?>
                </fieldset>
            </div><br>
        <?php } ?>
    <?php }
    add_action('zib_posts_content_after', 'wml_zib_pro_banquan');
}

// 文章商用声明
if (wml_zib('sy_copyright', false))
{
    function wml_zib_copyright() { ?>
        <link rel="stylesheet" id="diy-css" href="<?php echo WML_ZIB_BEAUT_DIR_URL . '/css/shangye.css' ?>" type="text/css" media="all" data-filtered="filtered">
        <style>
            .shangye {
                color: #fff;
                background: #5282f7 url(<?php echo WML_ZIB_BEAUT_DIR_URL . '/img/post/shangye.png' ?>) 3px 3px no-repeat;
                border: 1px solid #5282f7;
                overflow: hidden;
                margin: 10px 0;
                padding: 15px 15px 15px 50px;
                border-radius: 4px;
            }
        </style>
        <div class="shangye"><?php echo wml_zib('sy_copyright_text'); ?></div>
    <?php }
    add_action('zib_posts_content_after', 'wml_zib_copyright');
}

//元旦灯笼
if (wml_zib('chunjie', false))
{
    function zib_wml_chunjie() { ?>
        <link rel="stylesheet" href="<?php echo WML_ZIB_BEAUT_DIR_URL . '/css/yuandan.css' ?>">
        <script src="<?php echo WML_ZIB_BEAUT_DIR_URL . '/js/yuandan.js' ?>"></script>
    <?php }
    add_action('wp_footer', 'zib_wml_chunjie');
}
