<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\functions\beautify\wml-rbutton.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-15 18:51:32
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

// 右键菜单
if (wml_zib('rbutton_is', false)) {
    function wml_zib_rbutton()
    {
        $palette=CSF_Module_Wml_Zib::zib_palette();//颜色表
        ?>
        <style type="text/css">
            a {text-decoration: none;}div.usercm {background-repeat: no-repeat;background-position: center center;background-size: cover;background-color: #fff;font-size: 13px!important;width: 130px;-moz-box-shadow: 1px 1px 3px rgba (0,0,0,.3);box-shadow: 0px 0px 15px <?php echo $palette[wml_zib('rbutton_yy_c')][0];?>;position: absolute;display: none;z-index: 10000;opacity: 0.9;border-radius: 8px;}div.usercm ul {list-style-type: none;list-style-position: outside;margin: 0px;padding: 0px;display: block }div.usercm ul li {margin: 0px;padding: 0px;line-height: 35px;}div.usercm ul li a {color: <?php echo wml_zib('rbutton_zt_c');?>;padding: 0 15px;display: block }div.usercm ul li a:hover {color: #fff;background: <?php echo $palette[wml_zib('rbutton_xt_c')][0];?> }div.usercm ul li a i {margin-right: 10px }a.disabled {color: #c8c8c8!important;cursor: not-allowed }a.disabled:hover {background-color: rgba(255,11,11,0)!important }div.usercm {background: #fff !important;}
        </style>
        <div class="usercm" style="left: 199px; top: 5px; display: none;">
            <ul>
            <?php $type = wml_zib('rbutton_gn'); //功能
            if (in_array("copy", $type)) { ?>
                <li>
                    <a href="javascript:void(0);" rel="external nofollow" rel="external nofollow" onclick="getSelect();">
                        <i class="fa fa-file fa-fw"></i>
                        <span>复制</span>
                    </a>
                </li>
                <?php }
                if (in_array("refresh", $type)) { ?>
                <li>
                    <a href="javascript:window.location.reload();" rel="external nofollow">
                        <i class="fa fa-refresh fa-fw"></i>
                        <span>刷新</span>
                    </a>
                </li>
                <?php }
                if (in_array("index", $type)) { ?>
                <li>
                    <a href="/" rel="external nofollow">
                        <i class="fa fa-home fa-fw"></i>
                        <span>首页</span>
                    </a>
                </li>
                <?php }
                if (in_array("forward", $type)) { ?>
                <li>
                    <a href="javascript:history.go(1);" rel="external nofollow">
                        <i class="fa fa-arrow-right fa-fw"></i>
                        <span>前进</span>
                    </a>
                </li>
                <?php }
                if (in_array("retreat", $type)) { ?>
                <li>
                    <a href="javascript:history.go(-1);" rel="external nofollow">
                        <i class="fa fa-arrow-left fa-fw"></i>
                        <span>后退</span>
                    </a>
                </li>
                <?php }
                if (in_array("search", $type)) { ?>
                <li>
                    <a href="javascript:void(0);" onclick="baiduSearch();">
                        <i class="fa fa-search fa-fw"></i>
                        <span>搜索</span>
                    </a>
                </li>
                <?php }?>
                <li style="border-bottom:1px solid gray"></li>
                <?php 
                $list=wml_zib('rbutton_an');
                if(!empty($list)){
                    foreach($list as $val) {
                        echo '<li><a target="'.$val['link']['target'].'" href="'.$val['link']['url'].'"><i class="'.$val['icon'].'"></i><span>'.$val['name'].'</span></a></li>';
                    }
                }
                ?>
            </ul>
        </div>
        <script type="text/javascript">
            (function(a) {
                a.extend({
                    mouseMoveShow: function(b) {
                        var d = 0
                          , c = 0
                          , h = 0
                          , k = 0
                          , e = 0
                          , f = 0;
                        a(window).mousemove(function(g) {
                            d = a(window).width();
                            c = a(window).height();
                            h = g.clientX;
                            k = g.clientY;
                            e = g.pageX;
                            f = g.pageY;
                            h + a(b).width() >= d && (e = e - a(b).width() - 5);
                            k + a(b).height() >= c && (f = f - a(b).height() - 5);
                            a("html").on({
                                contextmenu: function(c) {
                                    3 == c.which && a(b).css({
                                        left: e,
                                        top: f
                                    }).show()
                                },
                                click: function() {
                                    a(b).hide()
                                }
                            })
                        })
                    },
                    disabledContextMenu: function() {
                        window.oncontextmenu = function() {
                            return !1
                        }
                    }
                })
            }
            )(jQuery);
            function getSelect() {
                "" == (window.getSelection ? window.getSelection() : document.selection.createRange().text) ? layer.msg("请选择需要搜索的内容！") : document.execCommand("Copy")
            }
            function baiduSearch() {
                var a = window.getSelection ? window.getSelection() : document.selection.createRange().text;
                "" == a ? layer.msg("请选择需要搜索的内容！") : window.open("<?php echo site_url();?>/?s=" + a)
            }

            $(function() {
                for (var a = navigator.userAgent, b = "Android;iPhone;SymbianOS;Windows Phone;iPad;iPod".split(";"), d = !0, c = 0; c < b.length; c++)
                    if (0 < a.indexOf(b[c])) {
                        d = !1;
                        break
                    }
                d && ($.mouseMoveShow(".usercm"),
                $.disabledContextMenu())
            });
        </script>
    <?php }
    add_action('wp_footer', 'wml_zib_rbutton');
}
