<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\functions\beautify\wml-font.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-20 04:03:47
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

//字体选择
if (wml_zib('font_switch', false)) {
    function wml_zib_font_switch()
    {
        if(wml_zib('font_select_t')==1){
            $type = wml_zib('font_select'); //样式
            if ($type=='1') {//抖音美好体 ?>
                <style>
                    @font-face {font-family: 'zti';src:url('<?php echo WML_ZIB_BEAUT_DIR_URL . 'font/dymht.woff2' ?>');}
                    body {font-family: 'zti' !important;}
                </style>
            <?php }
            elseif ($type=='2') {//阿里妈妈方圆体 ?>
                <style>
                    @font-face {font-family: 'zti';src:url('<?php echo WML_ZIB_BEAUT_DIR_URL . 'font/AlimamaFangYuanTiVF-Thin.woff2' ?>');}
                    body {font-family: 'zti' !important;}
                </style>
            <?php }
        }else{// 自定义字体 ?>
        <style>
            @font-face {font-family: 'zti';src:url(<?php echo wml_zib('font_select_diy') ?>);}
            body {font-family: 'zti' !important;}
        </style>
        <?php }
    }
    add_action('wp_footer', 'wml_zib_font_switch');
}
