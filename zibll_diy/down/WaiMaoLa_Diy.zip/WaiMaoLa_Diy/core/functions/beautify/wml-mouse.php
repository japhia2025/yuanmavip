<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\functions\beautify\wml-mouse.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-15 18:20:24
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

if (wml_zib('mouse_click', false)) {
    function wml_zib_mouse_click()
    {
        $type = wml_zib('mouse_click'); //样式
         if (in_array("mouse_click_explosion", $type)) {//点击五彩斑斓爆炸特效 ?>
            <canvas class="mouse_click_explosion" style="position:fixed;left:0;top:0;z-index:99999999;pointer-events:none;"></canvas>
            <script src="<?php echo WML_ZIB_BEAUT_DIR_URL . '/js/mouse_click_explosion.js' ?>"></script>
        <?php }
         if (in_array("mouse_click_funny", $type)) {//点击搞笑文字特效特效 ?>
            <script src="<?php echo WML_ZIB_BEAUT_DIR_URL . '/js/mouse_click_funny.js' ?>"></script>
        <?php }
         if (in_array("mouse_click_socialism", $type)) {//点击社会主义核心价值观 ?>
            <script>
                var a_idx = 0;
                jQuery(document).ready(function($) {
                    $("body").click(function(e) {
                        var a = new Array("🍉富强🍉", "🎉虎虎生威🎉", "🍉民主🍉", "🍉文明🍉", "🧧恭喜发财🧧", "🎉金虎送福🎉", "🍉和谐🍉", "🍉自由🍉", "🍉平等🍉", "🎉龙腾虎跃🎉", "关注关注🙈", "🍉公正🍉", "🍉法治🍉", "🍉欢迎光临🍉", "🍉爱国🍉", "🍉诚信🍉", "🍉友善🍉");
                        var b = new Array("red", "blue", "yellow", "green", "pink", "blue", "orange");
                        var $i = $("<span/>").text(a[a_idx]);
                        a_idx = (a_idx + 1) % a.length;
                        b_idx = (a_idx + 1) % 7;
                        var x = e.pageX,
                            y = e.pageY;
                        $i.css({
                            "z-index": 9999,
                            "top": y - 20,
                            "left": x,
                            "position": "absolute",
                            "font-weight": "bold",
                            "color": b[b_idx]
                        });
                        $("body").append($i);
                        $i.animate({
                            "top": y - 180,
                            "opacity": 0
                        }, 1500, function() {
                            $i.remove();
                        });
                    });
                });
            </script>
        <?php }
         if (in_array("mouse_click_particle", $type)) {//点击彩色粒子特效 ?>
            <script>
                "use strict";$(function(){function t(t,i){if(!(t instanceof i))throw new TypeError("Cannot call a class as a function")}var i=Object.assign||function(t){for(var i=1;i<arguments.length;i++){var n=arguments[i];for(var e in n)Object.prototype.hasOwnProperty.call(n,e)&&(t[e]=n[e])}return t},n=function(){function t(t,i){for(var n=0;n<i.length;n++){var e=i[n];e.enumerable=e.enumerable||!1,e.configurable=!0,"value"in e&&(e.writable=!0),Object.defineProperty(t,e.key,e)}}return function(i,n,e){return n&&t(i.prototype,n),e&&t(i,e),i}}(),e=function(){function e(n){var o=n.origin,r=n.speed,s=n.color,a=n.angle,h=n.context;t(this,e),this.origin=o,this.position=i({},this.origin),this.color=s,this.speed=r,this.angle=a,this.context=h,this.renderCount=0}return n(e,[{key:"draw",value:function(){this.context.fillStyle=this.color,this.context.beginPath(),this.context.arc(this.position.x,this.position.y,2,0,2*Math.PI),this.context.fill()}},{key:"move",value:function(){this.position.x=Math.sin(this.angle)*this.speed+this.position.x,this.position.y=Math.cos(this.angle)*this.speed+this.position.y+.3*this.renderCount,this.renderCount++}}]),e}(),o=function(){function i(n){var e=n.origin,o=n.context,r=n.circleCount,s=void 0===r?10:r,a=n.area;t(this,i),this.origin=e,this.context=o,this.circleCount=s,this.area=a,this.stop=!1,this.circles=[]}return n(i,[{key:"randomArray",value:function(t){var i=t.length;return t[Math.floor(i*Math.random())]}},{key:"randomColor",value:function(){var t=["8","9","A","B","C","D","E","F"];return"#"+this.randomArray(t)+this.randomArray(t)+this.randomArray(t)+this.randomArray(t)+this.randomArray(t)+this.randomArray(t)}},{key:"randomRange",value:function(t,i){return(i-t)*Math.random()+t}},{key:"init",value:function(){for(var t=0;t<this.circleCount;t++){var i=new e({context:this.context,origin:this.origin,color:this.randomColor(),angle:this.randomRange(Math.PI-1,Math.PI+1),speed:this.randomRange(1,6)});this.circles.push(i)}}},{key:"move",value:function(){var t=this;this.circles.forEach(function(i,n){if(i.position.x>t.area.width||i.position.y>t.area.height)return t.circles.splice(n,1);i.move()}),0==this.circles.length&&(this.stop=!0)}},{key:"draw",value:function(){this.circles.forEach(function(t){return t.draw()})}}]),i}();(new(function(){function i(){t(this,i),this.computerCanvas=document.createElement("canvas"),this.renderCanvas=document.createElement("canvas"),this.computerContext=this.computerCanvas.getContext("2d"),this.renderContext=this.renderCanvas.getContext("2d"),this.globalWidth=window.innerWidth,this.globalHeight=window.innerHeight,this.booms=[],this.running=!1}return n(i,[{key:"handleMouseDown",value:function(t){var i=new o({origin:{x:t.clientX,y:t.clientY},context:this.computerContext,area:{width:this.globalWidth,height:this.globalHeight}});i.init(),this.booms.push(i),this.running||this.run()}},{key:"handlePageHide",value:function(){this.booms=[],this.running=!1}},{key:"init",value:function(){var t=this.renderCanvas.style;t.position="fixed",t.top=t.left=0,t.zIndex="999999999999999999999999999999999999999999",t.pointerEvents="none",t.width=this.renderCanvas.width=this.computerCanvas.width=this.globalWidth,t.height=this.renderCanvas.height=this.computerCanvas.height=this.globalHeight,document.body.append(this.renderCanvas),window.addEventListener("mousedown",this.handleMouseDown.bind(this)),window.addEventListener("pagehide",this.handlePageHide.bind(this))}},{key:"run",value:function(){var t=this;if(this.running=!0,0==this.booms.length)return this.running=!1;requestAnimationFrame(this.run.bind(this)),this.computerContext.clearRect(0,0,this.globalWidth,this.globalHeight),this.renderContext.clearRect(0,0,this.globalWidth,this.globalHeight),this.booms.forEach(function(i,n){if(i.stop)return t.booms.splice(n,1);i.move(),i.draw()}),this.renderContext.drawImage(this.computerCanvas,0,0,this.globalWidth,this.globalHeight)}}]),i}())).init()});
            </script>
        <?php }
    }
    add_action('wp_footer', 'wml_zib_mouse_click');
}


//字体选择
if (wml_zib('mouse_follow', false)) {
    function wml_zib_mouse_follow()
    {
        $type = wml_zib('mouse_follow_select'); //样式
        if ($type=='1') {//蓝色 ?>
            <div class="mouse-cursor cursor-outer"></div>
            <div class="mouse-cursor cursor-inner"></div>
            <script src="<?php echo WML_ZIB_BEAUT_DIR_URL . '/js/mouse_follow.js' ?>"></script>
            <style>
                .mouse-cursor {position: fixed;left: 0;top: 0;pointer-events: none;border-radius: 50%;-webkit-transform: translateZ(0);transform: translateZ(0);visibility: hidden;}.cursor-inner {margin-left: -3px;margin-top: -3px;width: 6px;height: 6px;z-index: 10000001;background: #123eed;-webkit-transition: width .3s ease-in-out, height .3s ease-in-out, margin .3s ease-in-out, opacity .3s ease-in-out;transition: width .3s ease-in-out, height .3s ease-in-out, margin .3s ease-in-out, opacity .3s ease-in-out;}.cursor-inner.cursor-hover {margin-left: -18px;margin-top: -18px;width: 36px;height: 36px;background: #123eed !important;opacity: .3;}.cursor-outer {margin-left: -15px;margin-top: -15px;width: 30px;height: 30px;border: 2px solid #123eed !important;-webkit-box-sizing: border-box;box-sizing: border-box;z-index: 10000000;opacity: .5;-webkit-transition: all .08s ease-out;transition: all .08s ease-out;}.cursor-outer.cursor-hover {opacity: 0;}.main-wrapper[data-magic-cursor=hide] .mouse-cursor {display: none;opacity: 0;visibility: hidden;position: absolute;z-index: -1111;}
            </style>
        <?php }
        elseif ($type=='2') {//绿色 ?>
            <div class="mouse-cursor cursor-outer"></div>
            <div class="mouse-cursor cursor-inner"></div>
            <script src="<?php echo WML_ZIB_BEAUT_DIR_URL . '/js/mouse_follow.js' ?>"></script>
            <style>
                .mouse-cursor {position: fixed;left: 0;top: 0;pointer-events: none;border-radius: 50%;-webkit-transform: translateZ(0);transform: translateZ(0);visibility: hidden }.cursor-inner {margin-left: -3px;margin-top: -3px;width: 6px;height: 6px;z-index: 10000001;background: green;-webkit-transition: width.3s ease-in-out, height.3s ease-in-out, margin.3s ease-in-out, opacity.3s ease-in-out;transition: width.3s ease-in-out, height.3s ease-in-out, margin.3s ease-in-out, opacity.3s ease-in-out }.cursor-inner.cursor-hover {margin-left: -18px;margin-top: -18px;width: 36px;height: 36px;background: green !important;opacity: .3 }.cursor-outer {margin-left: -15px;margin-top: -15px;width: 30px;height: 30px;border: 2px solid green !important;-webkit-box-sizing: border-box;box-sizing: border-box;z-index: 10000000;opacity: .5;-webkit-transition: all.08s ease-out;transition: all.08s ease-out }.cursor-outer.cursor-hover {opacity: 0 }.main-wrapper[data-magic-cursor=hide].mouse-cursor {display: none;opacity: 0;visibility: hidden;position: absolute;z-index: -1111 }
            </style>
        <?php }
        elseif ($type=='3') {//粉色 ?>
            <div class="mouse-cursor cursor-outer"></div>
            <div class="mouse-cursor cursor-inner"></div>
            <script src="<?php echo WML_ZIB_BEAUT_DIR_URL . '/js/mouse_follow.js' ?>"></script>
            <style>
                .mouse-cursor {position: fixed;left: 0;top: 0;pointer-events: none;border-radius: 50%;-webkit-transform: translateZ(0);transform: translateZ(0);visibility: hidden }.cursor-inner {margin-left: -3px;margin-top: -3px;width: 6px;height: 6px;z-index: 10000001;background: hotpink;-webkit-transition: width.3s ease-in-out, height.3s ease-in-out, margin.3s ease-in-out, opacity.3s ease-in-out;transition: width.3s ease-in-out, height.3s ease-in-out, margin.3s ease-in-out, opacity.3s ease-in-out }.cursor-inner.cursor-hover {margin-left: -18px;margin-top: -18px;width: 36px;height: 36px;background: hotpink !important;opacity: .3 }.cursor-outer {margin-left: -15px;margin-top: -15px;width: 30px;height: 30px;border: 2px solid hotpink !important;-webkit-box-sizing: border-box;box-sizing: border-box;z-index: 10000000;opacity: .5;-webkit-transition: all.08s ease-out;transition: all.08s ease-out }.cursor-outer.cursor-hover {opacity: 0 }.main-wrapper[data-magic-cursor=hide].mouse-cursor {display: none;opacity: 0;visibility: hidden;position: absolute;z-index: -1111 }
            </style>
        <?php }
    }
    add_action('wp_footer', 'wml_zib_mouse_follow');
}


//鼠标选择
if (wml_zib('mouse', false)) {
    // 【蓝色精灵】
    function wml_zib_mouse_select()
    {
        $type = wml_zib('mouse_select'); //样式
        if ($type==1) {//鼠标1 ?>
            <style>
                body {cursor: url(<?php echo WML_ZIB_BEAUT_DIR_URL . '/img/mouse/mouse1_1.png' ?>), default;}
                a:hover {cursor: url(<?php echo WML_ZIB_BEAUT_DIR_URL . '/img/mouse/mouse1_2.png' ?>), pointer;}
            </style>
        <?php }
        elseif ($type=='2') {//鼠标2 ?>
            <style>
                body {cursor: url(<?php echo WML_ZIB_BEAUT_DIR_URL . '/img/mouse/mouse2_1.png' ?>), default;}
                a:hover {cursor: url(<?php echo WML_ZIB_BEAUT_DIR_URL . '/img/mouse/mouse2_2.png' ?>), pointer;}
            </style>
        <?php }
        elseif ($type=='3') {//鼠标3 ?>
            <style>
                body {cursor: url(<?php echo WML_ZIB_BEAUT_DIR_URL . '/img/mouse/mouse3_1.png' ?>), default;}
                a:hover {cursor: url(<?php echo WML_ZIB_BEAUT_DIR_URL . '/img/mouse/mouse3_2.png' ?>), pointer;}
            </style>
        <?php }
        elseif ($type=='4') {//鼠标4 ?>
            <style>
                body {cursor: url(<?php echo WML_ZIB_BEAUT_DIR_URL . '/img/mouse/mouse4_1.png' ?>), default;}
                a:hover {cursor: url(<?php echo WML_ZIB_BEAUT_DIR_URL . '/img/mouse/mouse4_2.png' ?>), pointer;}
            </style>
        <?php }
        elseif ($type=='5') {//鼠标5 ?>
            <style>
                body {cursor: url(<?php echo WML_ZIB_BEAUT_DIR_URL . '/img/mouse/mouse5_1.png' ?>), default;}
                a:hover {cursor: url(<?php echo WML_ZIB_BEAUT_DIR_URL . '/img/mouse/mouse5_2.png' ?>), pointer;}
            </style>
        <?php }
        elseif ($type=='6') {//鼠标6 ?>
            <style>
                body {cursor: url(<?php echo WML_ZIB_BEAUT_DIR_URL . '/img/mouse/mouse6_1.png' ?>), default;}
                a:hover {cursor: url(<?php echo WML_ZIB_BEAUT_DIR_URL . '/img/mouse/mouse6_2.png' ?>), pointer;}
            </style>
        <?php }
        elseif ($type=='7') {//鼠标7 ?>
            <style>
                body {cursor: url(<?php echo WML_ZIB_BEAUT_DIR_URL . '/img/mouse/mouse7_1.png' ?>), default;}
                a:hover {cursor: url(<?php echo WML_ZIB_BEAUT_DIR_URL . '/img/mouse/mouse7_2.png' ?>), pointer;}
            </style>
        <?php }
    }
    add_action('wp_footer', 'wml_zib_mouse_select');
}