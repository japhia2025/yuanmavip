<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\functions\beautify\wml-index.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-15 16:30:35
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */


//首页灰色主题
if (wml_zib('grey_page', false))
{
    function wml_zib_grey_page() { ?>
        <style>
            html body.home {
                -webkit-filter: grayscale(100%);
                filter: grayscale(100%);
            }
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_grey_page');
}

// 隐藏首页文章发布时间
if (wml_zib('zibll_post_public_date', false))
{
    function wml_zib_post_public_date() { ?>
        <style>
            span.icon-circle {
                display: none;
            }
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_post_public_date');
}

// 首页文章列表悬停上浮
if (wml_zib('posts_item', false))
{
    function wml_zib_posts_item() { ?>
        <style>
            .tab-content .posts-item:not(article) {
                transition: all 0.3s;
            }
            .tab-content .posts-item:not(article):hover {
                transform: translateY(-10px);
                box-shadow: 0 8px 10px #FFD1D8;
            }
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_posts_item');
}

// 首页文章列表悬停上浮2
if (wml_zib('posts_item2', false))
{
    function wml_zib_posts_item2() { ?>
        <style>
            .tab-content .posts-item:not(article):hover {opacity: 1;z-index: 99;border-radius: 20px;transform: translateY(-5px);box-shadow: 0 3px 20px rgba(0, 0, 0, .25);animation: index-link-active 1s cubic-bezier(0.315, 0.605, 0.375, 0.925) forwards;}@keyframes index-link-active {0% {transform: perspective(2000px) rotateX(0) rotateY(0) translateZ(0);}16% {transform: perspective(2000px) rotateX(10deg) rotateY(5deg) translateZ(32px);}100% {transform: perspective(2000px) rotateX(0) rotateY(0) translateZ(65px);}}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_posts_item2');
}

// 首页文章点击更多美化
if (wml_zib('dianjigengduo', false))
{
    function wml_zib_dianjigengduo() { ?>
        <style>
            .theme-pagination .ajax-next a, .theme-pagination .order-ajax-next a {border-radius: 30px;padding: 15px 0;color: var(--muted-color);background-color: var(--main-bg-color);color: #FF0033;display: block;opacity: 1;font-weight: bold;}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_dianjigengduo');
}

// 首页搜索框边缘透明
if (wml_zib('search_form', false))
{
    function wml_zib_search_form() { ?>
        <style>
        .search-form {
            border: 5px solid rgb(255 255 255 / 30%);
            border-radius: 45px;
            padding: 0;
            font-size: 15px;
        }
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_search_form');
}

//文章图片聚焦
if (wml_zib('st', false))
{
    function wml_zib_st() { ?>
        <style>
            .item-thumbnail:before {content: '';position: absolute;top: 0;left: 0;right: 0;bottom: 0;background: rgba(0, 0, 0, 0);transition: background .35s;border-radius: 8px;z-index: 2;max-width: 765px;margin: 0 auto;pointer-events: none;}.item-thumbnail:after {content: '';position: absolute;top: 50%;left: 50%;width: 50px;height: 50px;margin: -25px 0 0 -25px;background: url(<?php echo wml_zib('st_img');?>);background-repeat: no-repeat;background-size: 100% 100%;z-index: 3;-webkit-transform: scale(2);transform: scale(2);transition: opacity .35s, -webkit-transform .35s;transition: transform .35s, opacity .35s;transition: transform .35s, opacity .35s, -webkit-transform .35s;opacity: 0;pointer-events: none;}.item-thumbnail:hover:before {background: rgba(0, 0, 0, .5) }.item-thumbnail:hover:after {-webkit-transform: scale(1);transform: scale(1);opacity: 1 }
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_st');
}
