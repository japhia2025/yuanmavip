<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\functions\beautify\wml-top.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-27 05:55:52
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

// 导航栏字体加粗
if (wml_zib('navbarb'))
{
    function wml_zib_navbarb() { ?>
        <style>
            ul.nav {font-weight: 650;}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_navbarb');
}

// 导航栏标题
if (wml_zib('navbiaoti'))
{
    function zib_wml_navbiaoti() { ?>
        <style>
            .navbar-nav>li:first-child:before {width: 30px;}.navbar-nav>li:before {width: 60px;top: 23px;background: rgba(0, 0, 0, 0);height: 4px;left: 10px;border-radius: unset;}.navbar-top li.current-menu-item>a, .navbar-top li:hover>a {color: var(--focus-color);}
        </style>
    <?php }
    add_action('wp_footer', 'zib_wml_navbiaoti');
}

// 禁用搜索功能
if (wml_zib('nosearch'))
{
    function wml_zib_nosearch() { ?>
        <script>$(document).ready(function(){$("li.relative").css("display","none")})</script>
    <?php }
    add_action('wp_footer', 'wml_zib_nosearch');
}

// FPS帧率显示
if (wml_zib('show_fps', false))
{
    function menzib_zib_fps() { 
        if(wml_zib('show_fps_t')==1){
        ?>
        <script>
            $('body').before('<div id="fps" style="z-index:10000;position:fixed;top:4px;left:10px;font-weight:bold;background-image:linear-gradient(-90deg, rgb(135, 57, 244),rgb(85, 97, 236), rgb(91, 126, 241));-webkit-background-clip: text;color: transparent;"></div>');var showFPS=(function(){var requestAnimationFrame=window.requestAnimationFrame||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame||window.oRequestAnimationFrame||window.msRequestAnimationFrame||function(callback){window.setTimeout(callback,1000/60)};var e,pe,pid,fps,last,offset,step,appendFps;fps=0;last=Date.now();step=function(){offset=Date.now()-last;fps+=1;if(offset>=1000){last+=offset;appendFps(fps);fps=0}requestAnimationFrame(step)};appendFps=function(fps){console.log(fps+'FPS');$('#fps').html(fps+'&nbsp;FPS')};step()})();
        </script>
        <?php 
        }else{
        ?>
        <script>
            $('body').before('<div id="fps" style="font-size:<?php echo wml_zib('show_fps_dx', false); ?>px !important;z-index:10000;position:fixed;margin-top:<?php echo wml_zib('show_fps_wz', false); ?>px;left:3;font-weight:bold;-webkit-background-clip: text;color: <?php echo wml_zib('show_fps_color', false); ?>;"></div>');
            var showFPS = (function() {
                var requestAnimationFrame = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame || function(callback) {
                    window.setTimeout(callback, 1000 / 60);
                };
                var e, pe, pid, fps, last, offset, step, appendFps;
                fps = 0;
                last = Date.now();
                step = function() {
                    offset = Date.now() - last;
                    fps += 1;
                    if (offset >= 1000) {
                        last += offset;
                        appendFps(fps);
                        fps = 0;
                    }
                    requestAnimationFrame(step);
                };
                appendFps = function(fps) {
                    $('#fps').html(fps + 'FPS');
                };
                step();
            })();
        </script>
    <?php }}
    add_action('wp_footer', 'menzib_zib_fps');
}

//新年网站对联
if (wml_zib('duilian', false))
{
    function wml_zib_duilian() { ?>
        <SCRIPT language="JavaScript">
            lastScrollY = 0;
            function heartBeat() {
                var diffY;
                if (document.documentElement && document.documentElement.scrollTop) diffY = document.documentElement.scrollTop;
                else if (document.body) diffY = document.body.scrollTopelsepercent = .1 * (diffY - lastScrollY);
                if (percent > 0) percent = Math.ceil(percent);
                else percent = Math.floor(percent);
                document.getElementById("leftDiv").style.top = parseInt(document.getElementById("leftDiv").style.top) + percent + "px";
                document.getElementById("rightDiv").style.top = parseInt(document.getElementById("rightDiv").style.top) + percent + "px";
                lastScrollY = lastScrollY + percent;
            }
            function close_left2() {
                left2.style.visibility = 'hidden';
            }
            function close_right2() {
                right2.style.visibility = 'hidden';
            }
            document.writeln("<style type=\"text\/css\">");
            document.writeln("#leftDiv,#rightDiv{position:absolute;}");
            document.writeln(".itemFloat{width:100px;height:auto;line-height:5px}");
            document.writeln("<\/style>");
            document.writeln("<div id=\"leftDiv\" style=\"top:112px;left:50px\">");
            document.writeln("<div id=\"left2\" class=\"itemFloat\">");
            document.writeln("<img border=0 src=<?php echo wml_zib('duilian_img_1', false); ?>>");
            document.writeln("<br><a href=\"javascript:close_left2();\" title=\"关闭上面的对联\">×<\/a>");
            document.writeln("<\/div>");
            document.writeln("<\/div>");
            document.writeln("<div id=\"rightDiv\" style=\"top:112px;right:50px\">");
            document.writeln("<div id=\"right2\" class=\"itemFloat\">");
            document.writeln("<img border=0 src=<?php echo wml_zib('duilian_img_2', false); ?>>");
            document.writeln("<br><a href=\"javascript:close_right2();\" title=\"关闭上面的对联\">×<\/a>");
            document.writeln("<\/div>");
            document.writeln("<\/div>");
        </SCRIPT>
    <?php }
    add_action('wp_footer', 'wml_zib_duilian');
}

//导航栏皮肤
if (wml_zib('navbg', false))
{
    function wml_zib_navbg()
    {
        $type = wml_zib('navbg_radio'); //样式
        if ($type=='1') {//导航栏皮肤1 ?>
            <style>@media screen and (min-width: 1000px){.header-layout-1{position:relative;background-image:url("/wp-content/plugins/WaiMaoLa_Diy/img/navbg/navbg1.gif");background-position:center right;background-size:100% 100%;}}</style>
        <?php }
        elseif ($type=='2') {//导航栏皮肤2 ?>
            <style>@media screen and (min-width: 1000px){.header-layout-1{position:relative;background-image:url("/wp-content/plugins/WaiMaoLa_Diy/img/navbg/navbg2.png");background-position:center right;background-size:100% 100%;}}</style>
        <?php }
        elseif ($type=='3') {//导航栏皮肤3 ?>
            <style>@media screen and (min-width: 1000px){.header-layout-1{position:relative;background-image:url("/wp-content/plugins/WaiMaoLa_Diy/img/navbg/navbg3.png");background-position:center right;background-size:100% 100%;}}</style>
        <?php }
        elseif ($type=='4') {//导航栏皮肤4 ?>
            <style>@media screen and (min-width: 1000px){.header-layout-1{position:relative;background-image:url("/wp-content/plugins/WaiMaoLa_Diy/img/navbg/navbg4.png");background-position:center right;background-size:100% 100%;}}</style>
        <?php }
        elseif ($type=='5') {//导航栏皮肤5 ?>
            <style>@media screen and (min-width: 1000px){.header-layout-1{position:relative;background-image:url("/wp-content/plugins/WaiMaoLa_Diy/img/navbg/navbg5.gif");background-position:center right;background-size:100% 100%;}}</style>
        <?php }
        elseif ($type=='6') {//导航栏皮肤6 ?>
            <style>@media screen and (min-width: 1000px){.header-layout-1{position:relative;background-image:url("/wp-content/plugins/WaiMaoLa_Diy/img/navbg/navbg6.gif");background-position:center right;background-size:100% 100%;}}</style>
        <?php }
        elseif ($type=='7') {//导航栏皮肤7 ?>
            <style>@media screen and (min-width: 1000px){.header-layout-1{position:relative;background-image:url("/wp-content/plugins/WaiMaoLa_Diy/img/navbg/navbg7.gif");background-position:center right;background-size:100% 100%;}}</style>
        <?php }
    }
    add_action('wp_footer', 'wml_zib_navbg');
}

// 导航栏皮肤自定义
if (wml_zib('nosearch'))
{
    function wml_zib_navbg_diy() { ?>
        <style>@media screen and (min-width: 1000px){.header-layout-1{position:relative;background-image:url("<?php echo wml_zib('usernavbg88');?>");background-position:center right;background-size:100% 100%;}}</style>
    <?php }
    add_action('wp_footer', 'wml_zib_navbg_diy');
}
