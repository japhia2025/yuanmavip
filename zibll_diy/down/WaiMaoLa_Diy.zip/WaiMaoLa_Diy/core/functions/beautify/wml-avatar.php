<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\functions\beautify\wml-avatar.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-06-27 15:56:44
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

// 头像美化
if (wml_zib('avatar_mh', false))
{
    function wml_zib_avatar_mh() { ?>
        <style>
            .avatar-img {border-radius: 50%;animation: light 4s ease-in-out infinite;transition: 0.5s;}.avatar-img:hover {transform: scale(1.15) rotate(720deg);}@keyframes light {0% {box-shadow: 0 0 4px #f00;}25% {box-shadow: 0 0 16px #0f0;}50% {box-shadow: 0 0 4px #00f;}75% {box-shadow: 0 0 16px #0f0;}100% {box-shadow: 0 0 4px #f00;}}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_avatar_mh');
}

// 彩色昵称
if (wml_zib('csnc', false))
{
    function wml_zib_csnc() { ?>
        <style>
            .display-name {background-image: -webkit-linear-gradient(90deg, #07c160, #fb6bea 25%, #3aedff 50%, #fb6bea 75%, #28d079);-webkit-text-fill-color: transparent;-webkit-background-clip: text;background-size: 100% 600%;animation: wzw 10s linear infinite;}@keyframes wzw {0% {background-position: 0 0;}100% {background-position: 0 -300%;}}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_csnc');
}

// 用户摇摆
if (wml_zib('avatar_yb', false))
{
    function wml_zib_avatar_yb() { ?>
        <style>
             .user-avatar .avatar-img, .img-ip:hover, .w-a-info img {-webkit-animation: swing 3s .4s ease both;-moz-animation: swing 3s .4s ease both;}@-webkit-keyframes swing {20%, 40%, 60%, 80%, 100% {-webkit-transform-origin: top center }20% {-webkit-transform: rotate(15deg) }40% {-webkit-transform: rotate(-10deg) }60% {-webkit-transform: rotate(5deg) }80% {-webkit-transform: rotate(-5deg) }100% {-webkit-transform: rotate(0deg) }}@-moz-keyframes swing {20%, 40%, 60%, 80%, 100% {-moz-transform-origin: top center }20% {-moz-transform: rotate(15deg) }40% {-moz-transform: rotate(-10deg) }60% {-moz-transform: rotate(5deg) }80% {-moz-transform: rotate(-5deg) }100% {-moz-transform: rotate(0deg) }}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_avatar_yb');
}
