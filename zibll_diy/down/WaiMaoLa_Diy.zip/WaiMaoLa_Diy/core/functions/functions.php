<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-05 13:44:10
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-11-03 00:26:56
 * @FilePath: \WaiMaoLa_Diy\core\functions\functions.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682233
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

// 载入核心文件
$include_once = array(
  "feature/wml-down",
  "feature/wml-pages",
  "feature/wml-message",
  "feature/wml-language",
  "feature/wml-maintenance",
  "feature/wml-horn",
  "feature/wml-bulletin",
  "feature/wml-trash",
  "feature/wml-comments",
  "feature/wml-cardsales",
  "beautify/wml-footer",
  "beautify/wml-all",
  "beautify/wml-index",
  "beautify/wml-bottom",
  "beautify/wml-top",
  "beautify/wml-right",
  "beautify/wml-left",
  "beautify/wml-post",
  "beautify/wml-comments",
  "beautify/wml-mouse",
  "beautify/wml-font",
  "beautify/wml-avatar",
  "beautify/wml-logo",
  "beautify/wml-prompt",
  "beautify/wml-rbutton",
  "seo/wml-crib",
  'seo/wml-psot',
  'seo/wml-limit',
  'diy/wml-diy',
);
foreach ($include_once as $inc) {
  include $inc . '.php';
}

require_once 'page/class.php';//引入页面模块
