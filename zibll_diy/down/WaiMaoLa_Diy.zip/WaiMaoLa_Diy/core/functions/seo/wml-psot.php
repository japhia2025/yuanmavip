<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\functions\seo\wml-psot.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-23 03:47:43
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

//  自动文章添加标签
function wp_aatags_html2text($ep)
{
    if (wml_zib('psot_lable')) {
        $search = array("'<script[^>]*?>.*?</script>'si", "'<[\/\!]*?[^<>]*?>'si", "'([\r\n])[\s]+'", "'&(quot|#34|#034|#x22);'i", "'&(amp|#38|#038|#x26);'i", "'&(lt|#60|#060|#x3c);'i", "'&(gt|#62|#062|#x3e);'i", "'&(nbsp|#160|#xa0);'i", "'&(iexcl|#161);'i", "'&(cent|#162);'i", "'&(pound|#163);'i", "'&(copy|#169);'i", "'&(reg|#174);'i", "'&(deg|#176);'i", "'&(#39|#039|#x27);'", "'&(euro|#8364);'i", "'&a(uml|UML);'", "'&o(uml|UML);'", "'&u(uml|UML);'", "'&A(uml|UML);'", "'&O(uml|UML);'", "'&U(uml|UML);'", "'&szlig;'i");
        $replace = array("", "", "\\1", "\"", "&", "<", ">", " ", chr(161), chr(162), chr(163), chr(169), chr(174), chr(176), chr(39), chr(128), "ä", "ö", "ü", "Ä", "Ö", "Ü", "ß");
        return preg_replace($search, $replace, $ep);
    }
}
function wp_aatags_sanitize($taglist)
{
    if (wml_zib('psot_lable')) {
        $special_chars = array('?', '、', '。', '“', '”', '《', '》', '！', '，', '：', '？', '.', '[', ']', '/', '\\', '\=', '<', '>', ':', ';', '\'', '"', '&', '$', '#', '*', '(', ')', '|', '~', '`', '!', '{', '}', '%', '+', chr(0));
        $taglist = preg_replace("#\x{00a0}#siu", ' ', $taglist);
        $taglist = str_replace($special_chars, '', $taglist);
        $taglist = str_replace(array('%20', '+'), '-', $taglist);
        $taglist = preg_replace('/[\d]+/', '', $taglist);
        $taglist = preg_replace('/[\r\n     -]+/', '-', $taglist);
        $taglist = trim($taglist, ',-_');
        return $taglist;
    }
}
function wp_aatags_keycontents($keys, $num)
{
    if (wml_zib('psot_lable')) {
        $request = wp_remote_request('https://cws.9sep.org/extract/json', array('method' => 'POST', 'timeout' => 9, 'body' => array('text' => $keys, 'topk' => $num)));
        if (wp_remote_retrieve_response_code($request) != 200) {
            return 'rEr';
        } else {
            return wp_remote_retrieve_body($request);
        }
    }
}
function wp_aatags_kwsiconv($kws)
{
    if (wml_zib('psot_lable')) {
        return wp_aatags_sanitize(@json_decode($kws, true)['kws']);
    }
}
function wp_aatags_alts($post_ID, $post_title, $post_content)
{
    if (wml_zib('psot_lable')) {
        $tags = get_tags(array('hide_empty' => false));
        $tagx = wml_zib('zyx_post_tag'); // 标签处理范围
        $number = wml_zib('zyx_post_gs'); // 自动标签数量
        echo $tagx;
        switch ($tagx) {
            case 3:
                $d = strtolower($post_title);
                break;
            case 2:
                $d = strtolower(wp_trim_words($post_content, 999, '') . ' ' . $post_title);
                break;
            default:
                $d = strtolower(wp_trim_words($post_content, 333, '') . ' ' . $post_title);
                break;
        }
        if ($tags) {
            $i = 0;
            foreach ($tags as $tag) {
                if (strpos($d, strtolower($tag->name)) !== false) {
                    wp_set_post_tags($post_ID, $tag->name, true);
                    $i++;
                }

                if ($i == $number) {
                    break;
                }
            }
        }
    }
}
function wp_aatags_run($post_ID)
{
    if (wml_zib('psot_lable')) {
        $tags = wml_zib('post_tag'); // 标签处理范围
        $number = wml_zib('post_gs'); // 自动标签数量
        global $wpdb;
        if (get_post($post_ID)->post_type == 'post' && !wp_is_post_revision($post_ID) && !get_the_tags($post_ID)) {
            $post_title = get_post($post_ID)->post_title;
            $post_content = get_post($post_ID)->post_content;
            switch ($tags) {
                case 3:
                    $requix = strtolower($post_title . ' ' . wp_trim_words($post_content, 333, ''));
                    break;
                case 2:
                    $requix = strtolower($post_title . ' ' . wp_trim_words($post_content, 999, ''));
                    break;
                default:
                    $requix = strtolower($post_title);
                    break;
            }
            $body = wp_aatags_keycontents(wp_aatags_html2text($requix), $number);
            if ($body != 'rEr') {
                $keywords = wp_aatags_kwsiconv($body);
                wp_add_post_tags($post_ID, $keywords);
            } else {
                wp_aatags_alts($post_ID, $post_title, $post_content);
            }
        }
    }
    add_action('publish_post', 'wp_aatags_run');
    add_action('edit_post', 'wp_aatags_run');
}

// 标签链接格式更改
function wml_zib_custom_page_rules()
{
    if (wml_zib('tag_id')) {
        global $wp_rewrite;
        //修改tag的固定链接结构
        $wp_rewrite->extra_permastructs['post_tag']['with_front'] = '';
        $wp_rewrite->extra_permastructs['post_tag']['struct'] = 'tag/%post_tag%';
    }
}

// 自动为文章标签加TAG标签链接
if (wml_zib('tag_link')) {
    function wml_zib_tag_sort($a, $b){
        if ( $a->name == $b->name ) return 0;
        return ( strlen($a->name) > strlen($b->name) ) ? -1 : 1;
    }

    function wml_zib_tag_link($content){
        $posttags = get_the_tags();
        $match_num_from = wml_zib('tag_link_num_from');  // 一个标签在文章中出现少于多少次不添加链接
        $match_num_to = wml_zib('tag_link_num_to'); // 一篇文章中同一个标签添加几次链接

        if ($posttags) {
            usort($posttags, "wml_zib_tag_sort");
            foreach($posttags as $tag) {
                $link = get_tag_link($tag->term_id);
                $keyword = $tag->name;
                $cleankeyword = stripslashes($keyword);
                $url = "<a href=\"$link\" title=\"".str_replace('%s',addcslashes($cleankeyword, '$'),__('【查看更多关于 #%s 的文章】'))."\" target=\"_blank\">".addcslashes($cleankeyword, '$')."</a>";
                $limit = rand($match_num_from,$match_num_to);
                $pattern = "/<code.*?>(.*?)<\/code>/is";
                $content = preg_replace_callback(
                    $pattern, 
                    static function($matches) use ($cleankeyword) {
                        return str_replace($cleankeyword, '%&&&&&%', $matches[0]);
                    }, 
                    $content
                );
                $title_pattern = "/<(h[1-6]).*?>(.*?)<\/\\1>/is";
                $content = preg_replace_callback(
                    $title_pattern, 
                    static function($matches) use ($cleankeyword) {
                        return str_replace($cleankeyword, '%&&&&&%', $matches[0]);
                    }, 
                    $content
                );
                $cleankeyword = preg_quote($cleankeyword,'\'');
                $regEx = '\'(?!((<.*?)|(<a.*?)))('. $cleankeyword . ')(?!(([^<>]*?)>)|([^>]*?</a>))\'s';
                $content = preg_replace($regEx,$url,$content,$limit);
                $content = str_replace( '%&&&&&%', stripslashes($cleankeyword), $content);
            }
        }
        return $content;
    }
    add_filter('the_content','wml_zib_tag_link',1);
}

if (wml_zib('is_mate_tag', false)){
    function wml_zib_tag_pay_mate_th($pay_mate,$paid){
        if (empty($pay_mate)) {
            return;
        }
        //自动给#开头链接,格式：$pay_doc = '欢迎大家光临 #欢迎 #光临';
        $type = wml_zib('mate_tag_c'); //选择功能
        if($type){
            $pattern = '/(#\S+)/';// 正则表达式匹配以 # 开头，后面跟随非空格字符，也就是遇到空格或者换行匹配停止
            if (in_array("jj", $type)) {//商品简介
                // 替换回调函数
                $pay_mate['pay_doc'] = preg_replace_callback($pattern, function($matches) {
                    $match = $matches[0]; // 获取匹配到的文本
                    // substr意思是去掉'#' 字符
                    return '<a href="/tag/'.substr($match,1).'" title="【查看更多关于 '.$match.' 的文章】" target="_blank"><font color="'.wml_zib('mate_tag_color').'">'.$match.'</font></a>'; //构造替换后的字符串
                }, $pay_mate['pay_doc']);
            }
            if (in_array("gd", $type)) {//更多详情
                $pay_mate['pay_details'] = preg_replace_callback($pattern, function($matches) {
                    $match = $matches[0]; 
                    return '<a href="/tag/'.substr($match,1).'" title="【查看更多关于 '.$match.' 的文章】" target="_blank"><font color="'.wml_zib('mate_tag_color').'">'.$match.'</font></a>'; 
                }, $pay_mate['pay_details']);
            }
            if (in_array("gd", $type)) {//隐藏内容
                $pay_mate['pay_extra_hide'] = preg_replace_callback($pattern, function($matches) {
                    $match = $matches[0]; 
                    return '<a href="/tag/'.substr($match,1).'" title="【查看更多关于 '.$match.' 的文章】" target="_blank"><font color="'.wml_zib('mate_tag_color').'">'.$match.'</font></a>'; 
                }, $pay_mate['pay_extra_hide']);
            }
            if(wml_zib('mate_tag_m', false)){
                if ($paid&&is_user_logged_in()) {//已购买已登录才显示
                    $pay_mate['pay_doc']='<span class="an_1 but hollow '.wml_zib('mate_tag_m_y').'" style="text-align: left;">'.$pay_mate['pay_doc'].'</span>';
                }
            }
        }
        return $pay_mate;
    }
    add_filter('wml_zib_tag_pay_mate','wml_zib_tag_pay_mate_th', 10, 2);
}