<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: WaiMao.La
 * @Author URI: https://waimao.la/
 * @Date: 2024-06-27 15:38:58
 * @FilePath: \WaiMaoLa_Diy\core\functions\seo\wml-crib.php
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-16 04:21:03
 * @Description: 感谢您使用外贸啦DIY(子比)，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

//  禁用复制
if (wml_zib('disablecopy', false))
{
    function wml_zib_disablecopy() { ?>
        <script>
            //禁用复制
            document.oncopy = function() {
                return false;
            }
        </script>
    <?php }
    add_action('wp_footer', 'wml_zib_disablecopy');
}

// 禁用鼠标选中
if (wml_zib('dismouse', false))
{
    function wml_zib_dismouse() { ?>
        <script>
            document.onselectstart = function() {
                return false;
            }
        </script>
    <?php }
    add_action('wp_footer', 'wml_zib_dismouse');
}

// 禁用F12、禁用Ctrl+S、禁用Ctrl+U、禁用Ctrl+Shift+I等提醒
if (wml_zib('disable', false))
{
    function wml_zib_disable() { ?>
    <!-- 引入VUE -->
    <script src="https://unpkg.com/vue@2.6.14/dist/vue.min.js"></script>
    <!-- 引入样式 -->
    <script src="https://unpkg.com/element-ui@2.15.6/lib/index.js"></script>
    <!-- 引入组件库 -->
    <link rel="stylesheet" href="https://unpkg.com/element-ui@2.15.6/packages/theme-chalk/lib/index.css">
    <script>
    <?php
    $type = wml_zib('disable_click'); //类型
    if (in_array("disable_r", $type)) {//右键 ?>
        /*Right click prohibited*/
        document.oncontextmenu = function () {
        new Vue({
            data:function(){
                this.$notify({
                    title:"<?php echo wml_zib('disable_r_t');?>",
                    message:"<?php echo wml_zib('disable_r_c');?>",
                    position: 'bottom-right',
                    offset: 50,
                    showClose: false,
                    type:"warning"
                });
                return{visible:false}
            }
        })
        return false;
        }
    <?php }?>
        /*Prohibit F12 Ctrl+U Ctrl+S Ctrl+Shift+I*/
        document.onkeydown = function () {
        /*Prohibit F12*/
    <?php if (in_array("disable_f", $type)) {//F12 ?>
        if (window.event && window.event.keyCode == 123) {
        event.keyCode = 0;
        event.returnValue = false;
            new Vue({
                    data:function(){
                        this.$notify({
                            title:"<?php echo wml_zib('disable_f_t');?>",
                            message:"<?php echo wml_zib('disable_f_c');?>",
                            position: 'bottom-right',
                            offset: 50,
                            showClose: false,
                            type:"error"
                        });
                        return{visible:false}
                    }
                })
        return false;
        }
    <?php }if (in_array("disable_u", $type)) {//Ctrl+U?>
        /*Prohibit Ctrl+U*/
        if (event.ctrlKey && window.event.keyCode == 85) {
            new Vue({
                data: function() {
                    this.$notify({
                        title: "嘿！Brother",
                        message: "老弟，源码得换方式获取哦~",
                        position: 'bottom-right',
                        offset: 50,
                        showClose: true,
                        type: "error"
                    });
                    return {
                        visible: false
                    }
                }
            })
            return false;
        }
    <?php }if (in_array("disable_s", $type)) {//Ctrl+S?>
        /*Prohibit Ctrl+S*/
        if (event.ctrlKey && window.event.keyCode == 83) {
            new Vue({
                data: function() {
                    this.$notify({
                        title: "<?php echo wml_zib('disable_s_t');?>",
                        message: "<?php echo wml_zib('disable_s_c');?>",
                        position: 'bottom-right',
                        offset: 50,
                        showClose: true,
                        type: "error"
                    });
                    return {
                        visible: false
                    }
                }
            })
            return false;
        }
    <?php }if (in_array("disable_i", $type)) {//Ctrl+Shift+I?>
    /*Prohibit Ctrl+Shift+I*/
    if ((event.ctrlKey) && (event.shiftKey) && (event.keyCode == 73)) {
    event.keyCode = 0;
      event.returnValue = false;
        new Vue({
                data:function(){
                    this.$notify({
                        title:"<?php echo wml_zib('disable_i_t');?>",
                        message:"<?php echo wml_zib('disable_i_c');?>",
                        position: 'bottom-right',
                        offset: 50,
                        showClose: false,
                        type:"error"
                    });
                    return{visible:false}
                }
            })
                   return false;
    }
    <?php }?>
    };
    /*Copy Remind*/
    /*document.addEventListener("copy", function(e) {
        new Vue({
            data: function() {
                if((window.getSelection ? window.getSelection() : document.selection.createRange().text) != ''){
                    this.$notify({
                        title: "叮！复制成功",
                        message: "若要转载请务必保留原文链接！谢谢~",
                        position: 'bottom-right',
                        offset: 50,
                        showClose: true,
                        type: "success"
                    });
                }else{
                    this.$notify({
                        title: "咦？复制失败",
                        message: "啊噢...你没还没选择内容呢！",
                        position: 'bottom-right',
                        offset: 50,
                        showClose: true,
                        type: "error"
                    });
                }
                return {
                    visible: false
                }
            }
        })
    })*/
    </script>
    <?php }
    add_action('wp_footer', 'wml_zib_disable');
}

// 禁止图片拖放
if (wml_zib('notuofang', false))
{
    function wml_zib_notuofang() { ?>
        <script>
            document.ondragstart = function() {
                return false
            };
        </script>
    <?php }
    add_action('wp_footer', 'wml_zib_notuofang');
}

//禁止打开控制台
if (wml_zib('nodebugger', false))
{
    function wml_zib_nodebugger() { ?>
        <script>
            setInterval(function() {
                check()
            }, 4000);
            var check = function() {
                function doCheck(a) {
                    if (("" + a / a)["length"] !== 1 || a % 20 === 0) {
                        (function() {} ["constructor"]("debugger")())
                    } else {
                        (function() {} ["constructor"]("debugger")())
                    }
                    doCheck(++a)
                }
                try {
                    doCheck(0)
                } catch (err) {}
            };
            check();
        </script>
    <?php }
    add_action('wp_footer', 'wml_zib_nodebugger');
}
