<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-18 21:27:06
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-11-02 20:20:08
 * @FilePath: \WaiMaoLa_Diy\core\functions\page\wml-thumbnail.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682233
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

// 获取链接列表
get_header();
$header_style = zib_get_page_header_style();
?>
<main class="container">
    <div class="content-wrap">
        <div class="content-layout">
            <?php while (have_posts()) : the_post(); ?>
                <?php if ($header_style != 1) {
                    echo zib_get_page_header();
                } ?>
                <?php endwhile;  ?>
                <div class="box-body theme-box radius8 main-bg main-shadow">
                    <?php if ($header_style == 1) {
                        echo zib_get_page_header();
                    } ?>
                <!--主体开始-->
                <?php if(wml_zib('page_thumbnail_dl')&&!is_user_logged_in()){ ?>
                        <div class="comment-signarea text-center box-body radius8">
                        <h3 class="text-muted em12 theme-box muted-3-color">请登录后使用</h3>
                        <p>
                            <a href="javascript:;" class="signin-loader but c-blue padding-lg"><i class="fa fa-fw fa-sign-in mr10" aria-hidden="true"></i>登录</a>
                            <?php echo !is_user_logged_in() ? '<a href="javascript:;" class="signup-loader ml10 but c-yellow padding-lg">' . zib_get_svg('signup',null,'icon mr10') . '注册</a>' : ''; ?>
                        </p>
                        <?php zib_social_login(); ?>
                        </div>
                <?php }elseif(wml_zib('page_thumbnail_rz')&&!zib_is_user_auth()){
                        echo '<div class="mb20 wp-posts-content"><div class="hide-post mt6"><div class=""><i class="fa fa-unlock-alt mr6"></i>该功能仅对内部特定认证人员开放</div><div class="text-center em09 mt20"><p class="separator muted-3-color mb20">以下用户组可查看</p><p><a class="but mm3" href="/user/auth"><svg class="mr6 em12" aria-hidden="true"><use xlink:href="#icon-user-auth"></use></svg>认证用户</a></p></div></div></div>';
                        echo '</div>';
                    }else{ ?>
                        <div class="wp-block-zibllblock-iframe wp-block-embed is-type-video mb20"><div class="" style="padding-bottom:56%"><iframe class="" data-aspect="56%" framespacing="0" border="0" width="100%" frameborder="no" src="<?php echo WML_ZIB_BEAUT_DIR_URL;?>/page/thumbnail"></iframe></div></div>
                <?php }?>
                <!--主体结束-->
                </div>
                <?php comments_template('/template/comments.php', true); ?>
        </div>
    </div>
    <?php get_sidebar(); ?>
</main>
<?php
get_footer();