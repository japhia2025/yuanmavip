<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-24 07:36:49
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-28 02:55:49
 * @FilePath: \WaiMaoLa_Diy\core\functions\page\fun.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682233
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */
//自定义创建PHP
function wml_loadCustomTemplate($template) {
    global $wp_query;
    if(!file_exists($template))return;
    $wp_query->is_page = true;
    $wp_query->is_single = false;
    $wp_query->is_home = false;
    $wp_query->comments = false;
    // if we have a 404 status
    if ($wp_query->is_404) {
    // set status of 404 to false
        unset($wp_query->query["error"]);
        $wp_query->query_vars["error"]="";
        $wp_query->is_404=false;
    }
    // change the header to 200 OK
    header("HTTP/1.1 200 OK");
    //load our template
    include($template);
    exit;
}
function wml_templateRedirect() {
    $basename = basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']);
    wml_loadCustomTemplate(WML_ZIB_BEAUT_DIR_PATH.'/api/'."/$basename.php");//自动检测API目录下文件
}
add_action('template_redirect', 'wml_templateRedirect');


if (wml_zib('page_shuoshuo', false)) {
    //说说
    add_action('init', 'post_type_shuoshuo'); 
    function post_type_shuoshuo() { $labels = array( 'name' => '说说', 'singular_name' => 'singularname', 'add_new' => '发表说说', 'add_new_item' => '发表说说', 'edit_item' => '编辑说说', 'new_item' => '新说说', 'view_item' => '查看说说', 'search_items' => '搜索说说', 'not_found' => '暂无说说', 'not_found_in_trash' => '没有已遗弃的说说', 'parent_item_colon' => '', 'menu_name' => '说说' ); $args = array( 'labels' => $labels, 'public' => true, 'publicly_queryable' => true, 'show_ui' => true, 'show_in_menu' => true, 'query_var' => true, 'rewrite' => true, 'capability_type' => 'post', 'has_archive' => true, 'hierarchical' => false, 'menu_position' => null, 'supports' => array('title','editor','author','custom-fields','comments') ); register_post_type('shuoshuo',$args); }
    //指定说说文章模板
    add_filter( 'template_include', 'include_template_function', 1 );
    function include_template_function( $template_path ) {
        if ( get_post_type() == 'shuoshuo' ) {
            if ( is_single() ) {
                if ( $theme_file = locate_template( array ( 'shuoshuo.php' ) ) ) {
                    $template_path = $theme_file;
                } else {
                    $template_path = plugin_dir_path( __FILE__ ) . '/pages/shuoshuo.php';//自己修改文件路径
                }
            }
        }
        return $template_path;
    }
    /*说说点赞功能*/
    add_action('wp_ajax_nopriv_bigfa_like', 'bigfa_like');
    add_action('wp_ajax_bigfa_like', 'bigfa_like');
    function bigfa_like(){
        global $wpdb,$post;
        $id = $_POST["um_id"];
        $action = $_POST["um_action"];
        if ( $action == 'ding'){
        $bigfa_raters = get_post_meta($id,'bigfa_ding',true);
        $expire = time() + 99999999;
        $domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false; // make cookies work with localhost
        setcookie('bigfa_ding_'.$id,$id,$expire,'/',$domain,false);
        if (!$bigfa_raters || !is_numeric($bigfa_raters)) {
            update_post_meta($id, 'bigfa_ding', 1);
        } 
        else {
                update_post_meta($id, 'bigfa_ding', ($bigfa_raters + 1));
            }
        echo get_post_meta($id,'bigfa_ding',true);
        } 
        die;
    }
}

if (wml_zib('page_weiyu', false)) {
   //微语
    add_action('init', 'post_type_weiyu'); 
    function post_type_weiyu() 
    { 
        $labels = array( 
            'name' => '微语', 
            'singular_name' => 'singularname', 
            'add_new' => '发表微语', 
            'add_new_item' => '发表微语', 
            'edit_item' => '编辑微语', 
            'new_item' => '新微语', 
            'view_item' => '查看微语', 
            'search_items' => '搜索微语', 
            'not_found' => '暂无微语', 
            'not_found_in_trash' => '没有已遗弃的微语', 
            'parent_item_colon' => '', 
            'menu_name' => '微语' ); 
            $args = array( 
                'labels' => $labels, 
                'public' => true, 
                'publicly_queryable' => true, 
                'show_ui' => true, 
                'show_in_menu' => true, 
                'query_var' => true, 
                'rewrite' => true, 
                'capability_type' => 'post',
                'has_archive' => true, 
                'hierarchical' => false, 
                'menu_position' => null, 
                'supports' => array('title','editor','author') );
            register_post_type('weiyu',$args); 
    }
}

//友情链接检测
function xy_link(){
    global $wpdb;
    $links = $wpdb->prefix . 'links';
    $user_url = !empty($_REQUEST['user_url']) ? $_REQUEST['user_url'] : '';
    $xypro_url = esc_url(home_url());
    $url = get_site_url().'/links-api?myurl=' . urlencode($xypro_url) . '&targeturl=' . urlencode($user_url);
    //初始化
      $response = wp_remote_get($url, array(
        'timeout' => 20,
        'sslverify' => false,
    ));
     if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        error_log("HTTP request error: " . $error_message);
        zib_send_json_error(array('code' => -1, 'msg' => '请求数据错误: ' . $error_message));
        return;
    }
     $http_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    
    $deta = date("Y-m-d H:i:s", time()+8*60*60);
    
    
     if ($body) {
        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log("JSON decode error: " . json_last_error_msg());
            zib_send_json_error(array('code' => -1, 'msg' => 'JSON解析错误: ' . json_last_error_msg()));
            return;
        }
        if ($data['code'] == 200 && isset($data['data']['message']) && $data['data']['message'] == '友情链接存在!') {
            $link_visible = 'Y';
            $msg = '检测友情链接正常！';
        } else {
            $link_visible = 'N';
            $msg = isset($data['data']['message']) ? $data['data']['message'] : '未获得URL相关数据，请重试！';
        }
    } else {
        $link_visible = 'N';
        $msg = '请求数据错误';
    }
    $link_con = array(
        'link_visible' => $link_visible,
        'link_updated' => $deta,
        'link_notes'   => $msg,
    );
    $wpdb->update($links,$link_con,array('link_url'=> $user_url));
    zib_send_json_success(array('code' => 0, 'msg' => $msg));
}
add_action('wp_ajax_xy_link', 'xy_link');

function xy_link_jc(){
    global $wpdb;
    $links = $wpdb->prefix . 'links';
    $deta = date("Y-m-d H:i:s", time()+8*60*60);
    $link_YN = !empty($_REQUEST['link_id']) ? $_REQUEST['link_id'] : '';
    $link_yn = mb_substr($link_YN, 0, 1, 'utf-8');
    $link_id = substr_replace($link_YN,"",0,1);
    
    if($link_yn == 'N'){
        $link_con = array(
            'link_visible' => 'N',
            'link_updated' => $deta,
            'link_notes'   => '请确认您已经添加本站的链接',
        );
        $wpdb->update($links,$link_con,array('link_id'=> $link_id));
        zib_send_json_success(array('code' => -1, 'msg' => '已将链接隐藏'));
    }elseif($link_yn == 'Y'){
        $link_con = array(
            'link_visible' => 'Y',
            'link_updated' => $deta,
            'link_notes'   => '检测友情链接正常！',
        );
        $wpdb->update($links,$link_con,array('link_id'=> $link_id));
        zib_send_json_success(array('code' => 0, 'msg' => '已将链接显示'));
    }elseif($link_yn == 'D'){
        $del = $wpdb->delete( $links, array( 'link_id' => $link_id ) );
        if($del){
            zib_send_json_success(array('code' => 0, 'msg' => '删除成功'));
        }
    }
}
add_action('wp_ajax_xy_link_jc', 'xy_link_jc');

/*友情链接检测*/
?>