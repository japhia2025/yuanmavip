<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-18 15:36:04
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-27 23:48:47
 * @FilePath: \WaiMaoLa_Diy\core\functions\page\wml-qixia.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682233
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

// 获取链接列表
get_header();
$header_style = zib_get_page_header_style();
?>

<main class="container">
<div class="content-wrap">
<div class="content-layout">


<div class="page-cover theme-box radius8 main-shadow">
<img class="fit-cover no-scale lazyload" src="<?php echo wml_zib('qixia_bj');?>" data-src="<?php echo wml_zib('qixia_bj');?>">
<div class="absolute page-mask"></div>
<div class="list-inline box-body abs-center text-center">
<div class="title-h-center">
<h3><?php echo wml_zib('qixia_name');?></h3>
         </div>
     </div>
</div>      


<article class="article page-article main-bg theme-box box-body radius8 main-shadow">
<div class="wp-posts-content">

<?php
if(wml_zib('qixia_zd')){
    foreach(wml_zib('qixia_zd') as $val) {
        echo '<div class="wp-block-zibllblock-feature feature feature-default" data-icon="'.$val['icon'].'" data-color="'.$val['color'].'"><div class="feature-icon"><i style="color:'.$val['color'].'" class="'.$val['icon'].'"></i></div><div class="feature-title"><a href="'.$val['link']['url'].'" target="'.$val['link']['target'].'" rel="noreferrer noopener">'.$val['name'].'</a></div><div class="feature-note">'.$val['info'].'</div></div>';
    }
}
?>
</div>
</article>
     </div>
</div>
    </main>
    
<?php
get_footer();