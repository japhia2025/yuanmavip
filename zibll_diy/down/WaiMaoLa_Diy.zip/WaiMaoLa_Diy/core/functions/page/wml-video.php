<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-18 17:40:38
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-27 10:21:57
 * @FilePath: \WaiMaoLa_Diy\core\functions\page\wml-video.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682233
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

//setcookie赋值必须在echo输出前
if (wml_zib('page_video_cs', false)) {
	$stime=strtotime('23:59:59')-time();//当天剩余时间
	if (!isset($_COOKIE['wml_video_down'])) {//获取创建下载次数
		setcookie('wml_video_down', 1, time()+$stime, COOKIEPATH, COOKIE_DOMAIN, false);
		//setcookie('wml_video_down', 1, time()+$stime, '/', '', false);
	}
}

// 获取链接列表
get_header();
$header_style = zib_get_page_header_style();
?>
<main class="container">
    <div class="content-wrap">
        <div class="content-layout">
            <?php while (have_posts()) : the_post(); ?>
                <?php if ($header_style != 1) {
                    echo zib_get_page_header();
                } ?>
                <?php endwhile;  ?>
                <div class="box-body theme-box radius8 main-bg main-shadow">
                    <?php if ($header_style == 1) {
                        echo zib_get_page_header();
                    } ?>
                <!--主体开始-->
<link href="<?php echo WML_ZIB_BEAUT_DIR_URL;?>/css/video_style.css" rel="stylesheet">
	<div class="vheader">
		<div class="vtitle"><?php echo wml_zib('page_video_name');?></div>
	</div>
<div class="home_container">
<div class="vwrap">
<div class="vwrap_background"></div>
<div class="vwrap_search">
<select class="selectType" id="mySelect">
<option value="1">视频</option>
<option value="2">图集</option>
</select>
<input type="text" id="url" placeholder="请将APP里复制的视频链接粘贴到这里" autocomplete="off">
<button type="submit" id="button">解析</button>
</div>
</div>
<!-- 内容 -->
<div class="home_page">
	<div class="page_list">
		<div class="list_box">
			<div class="list_ico">
				<i class="fa fa-paw"></i>
			</div>
			<div class="list_title">一键解析</div>
		</div>
		<div class="list_box">
			<div class="list_ico">
				<i class="fa fa-safari"></i>
			</div>
			<div class="list_title">方便快捷</div>
		</div>
		<div class="list_box">
			<div class="list_ico">
				<i class="fa fa-gift"></i>
			</div>
			<div class="list_title">永久免费</div>
		</div>
		<div class="list_box">
			<div class="list_ico">
			<i class="fa fa-cloud-download"></i>
			</div>
			<div class="list_title">无限下载</div>
		</div>
	</div>

<div class="vwatermark">
<div class="mark_title"><span>温馨提示：</span>粘贴视频地址时无需删除文案 但如果视频链接正确但解析失败请删掉文案后重试....</div>
</div>

</div>
</div>
<div id="load"></div>

                <!--主体结束-->
                </div>

<div class="box-body theme-box radius8 main-bg main-shadow">
<div class="vdesc">
	<div class="mark_title">使用说明</div>
	<div class="mark_content">
        <?php 
        if (wml_zib('page_video_v')){
            $vv='';
            $video_v = wml_zib('page_video_v');
            $video_v = preg_split("/,|，|\s|\n/", $video_v);
            foreach ($video_v as $vol) {
                $vv.='<span class="video-badge-rim">'.$vol.'</span>';
            }
        }
        if (wml_zib('page_video_p')){
            $vp='';
            $video_p = wml_zib('page_video_p');
            $video_p = preg_split("/,|，|\s|\n/", $video_p);
            foreach ($video_p as $vol) {
                $vp.='<span class="video-badge-rim">'.$vol.'</span>';
            }
        }
        ?>
		<p><em></em>视频支持:<?php echo $vv;?></p>
		<p><em></em>图集支持:<?php echo $vp;?></p>
		<p><em></em>打开视频APP，点开某个视频，点击分享按钮，在分享弹框中点击复制链接或通过分享到微信QQ等获取分享链接</p>
		<p><em></em>将复制的分享链接粘贴到输入框进行解析</p>
		<p><em></em>本站可以解析99%以上的视频。但如果视频作者上传的视频本身就有水印，这种水印暂时无法去除。请查看该视频在相应的APP里播放时是否有水印。</p>
		<p><em></em>视频被删除、被设置成私密、或在审核中都有可能导致解析失败。</p>
	</div>
</div>
</div>

                <?php comments_template('/template/comments.php', true); ?>
        </div>
    </div>
    <?php get_sidebar(); ?>
</main>
<link rel="stylesheet" type="text/css" href="<?php echo WML_ZIB_BEAUT_DIR_URL;?>/css/video-analysis.css">
<script type="text/javascript" src="<?php echo WML_ZIB_BEAUT_DIR_URL;?>/js/video-analysis.js"></script>
<script>
//协议判断 勿删
var meta = '<meta content="width=device-width,maximum-scale=1.0,minimum-scale=1.0,initial-scale=1.0,user-scalable=no" name="viewport">';
var meta = '<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests" />';
var meta = '<meta name="referrer" content="same-origin">';//<!--跨域协议-->

$(document).ready(function () {
$('#button').click(function () {
// 获取select元素
var selectElement = document.getElementById('mySelect');
// 获取选中项的值
var selectedValue = selectElement.value;
// 打印选中项的值
console.log(selectedValue);
//var text = $('#url').val();
var data = document.getElementById("url").value;
let regex = /http[s]?:\/\/[\w.]+[\w\/]*[\w.]*\??[\w=&:\-\+\%]*[/]*/;
if (data == '') {
	swal('链接不能为空');
return false;
}
if (data.toString().indexOf('https') === -1) {
	swal('请输入正确的链接');
return false;
}
var text = data.match(regex)[0];
var url = "/video-api";
$.ajax({
url,
type: 'get',
dataType: 'json',
data: { url: text,type: selectedValue },
beforeSend: function () {
$("#load").html('<div class="preloader"><div class="loader"></div></div>');
$("head").prepend(meta);
},
success: function (data) {
if (data.code == 200&&data.data!=null) {
//添加成功提示
swal(data.msg);
$("#load").empty();
if (selectedValue == "1") {
var mkhtml = '<div class="mark_title">解析结果</div><div class="water_content"><p>' + data.data.title + '</p><div class="video"><video width="100%" height="100%" controls><source src="'+data.data.url+'" type="video/mp4"></video></div><div class="download"><a href="' + data.data.cover + '" target="_blank" rel="nofollow">封面图片</a><a href="' + data.data.url + '" target="_blank" rel="nofollow" referrerpolicy="no-referrer">下载视频</a></div></div>';//<a href="' + data.data.music.avatar + '" target="_blank" rel="nofollow" referrerpolicy="no-referrer">下载音乐</a>
$(".vwatermark").html(mkhtml);
//$("#load").empty();
}

if (selectedValue == "2") {
var htmlContent = '<div class="theme-box wp-posts-content"><figure class="wp-block-gallery has-nested-images columns-default is-cropped wp-block-gallery-1 is-layout-flex">';
var imgList = data.data.images;
for (var i = 0; i < imgList.length; i++) {
htmlContent += '<figure class="wp-block-image size-large"><img decoding="async" src="' + imgList[i] + '" data-src="' + imgList[i] + '" class="wp-image-1342 ls-is-cached lazyloaded lazyloadafter" imgbox-index="5"/></figure>';
}
htmlContent += '</figure></div>';
$(".vwatermark").html(htmlContent);
$("#load").empty();
}
} else {
swal(data.msg);
$("#load").empty();
}
}
});
});
});
</script>

<?php
get_footer();



