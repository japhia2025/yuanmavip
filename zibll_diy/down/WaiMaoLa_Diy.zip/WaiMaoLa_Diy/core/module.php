<?php
/*
 * @Project Name: 外贸啦DIY(子比)
 * @Project URI: https://waimao.la/
 * @Author: Japhia
 * @version: 外贸啦Diy 1.0
 * @Date: 2024-10-05 13:44:10
 * @Email: Japhia@mail.com
 * @LastEditors: WaiMao.La
 * @LastEditTime: 2024-10-28 04:52:12
 * @FilePath: \WaiMaoLa_Diy\core\module.php
 * @Description: 感谢您使用外贸啦DIY,最全最强最完美的子比插件,不改动主题和内核,有问题联系QQ:181682245
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

class CSF_Module_Wml_Zib
{
    //翻译语言读取
    public static function language()
    {
        //读取语言JSON文件和数据
        /*if(is_admin()){
            $json_file = WML_ZIB_BEAUT_DIR_PATH . '/json/languages.json';
        }else{
            $json_file = 'wp-content/plugins/WaiMaoLa_Diy/json/languages.json';
        }
        error_log('正在尝试从'.$json_file.'加载语言:');//尝试加载语言文件
        if (!file_exists($json_file)) {
            error_log('找不到languages.json文件');
            return;
        }
        $json_content = file_get_contents($json_file);//读取josn文件的数据
        */
        $data = json_decode(language_json(), true);//解析数据
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('解析languages.json失败' . json_last_error_msg());
            return;
        }
        if (!isset($data['list']) || !is_array($data['list'])) {
            error_log('languages.json中的结构无效：找不到“list”键或不是数组');
            return;
        }
        //遍历数组
        $list=$data['list'];
        return $list;
    }
    //翻译语言选择
    public static function language_select()
    {
        $list=self::language();//读取语言数组文件
        //遍历数组
        //$language['select_language']='请选择语言';
        foreach($list as $key => $value) {
            $language[$value['id']]=$value['name'].'('.$value['value'].')';//创建新数组
        }
        return $language;
    }
    //颜色选择
    public static function zib_palette($palette = array(), $show = array('t','c', 'b', 'jb'))
    {
        if (in_array('t', $show)) {
            $palette = array_merge($palette, array(
                'transparent' => array('rgba(114, 114, 114, 0.1)'),//透明色
            ));
        }
        if (in_array('c', $show)) {
            $palette = array_merge($palette, array(
                'c-red'      => array('rgba(255, 84, 115, .4)'),
                'c-red-2'    => array('rgba(194, 41, 46, 0.4)'),
                'c-yellow'   => array('rgba(255, 111, 6, 0.4)'),
                'c-yellow-2' => array('rgba(179, 103, 8, 0.4)'),
                'c-cyan'     => array('rgba(8, 196, 193, 1)'),
                'c-blue'     => array('rgba(41, 151, 247, .4)'),
                'c-blue-2'   => array('rgba(77, 130, 249, .4)'),
                'c-green'    => array('rgba(18, 185, 40, .4)'),
                'c-green-2'  => array('rgba(72, 135, 24, .4)'),
                'c-purple'   => array('rgba(213, 72, 245, 0.4)'),
                'c-purple-2' => array('rgba(154, 72, 245, 0.4)'),
            ));
        }
        if (in_array('b', $show)) {
            $palette = array_merge($palette, array(
                'b-red'    => array('#f74b3d'),
                'b-yellow' => array('#f3920a'),
                'b-cyan'   => array('#08c4c1'),
                'b-blue'   => array('#0a8cf3'),
                'b-green'  => array('#1fd05a'),
                'b-purple' => array('#c133f5'),
            ));
        }
        if (in_array('jb', $show)) {
            $palette = array_merge($palette, array(
                'jb-red'    => array('linear-gradient(135deg, #ffbeb4 10%, #f61a1a 100%)'),
                'jb-pink'   => array('linear-gradient(135deg, #ff5e7f 30%, #ff967e 100%)'),
                'jb-yellow' => array('linear-gradient(135deg, #ffd6b2 10%, #ff651c 100%)'),
                'jb-cyan'   => array('linear-gradient(140deg, #039ab3 10%, #58dbcf 90%)'),
                'jb-blue'   => array('linear-gradient(135deg, #b6e6ff 10%, #198aff 100%)'),
                'jb-green'  => array('linear-gradient(135deg, #ccffcd 10%, #52bb51 100%)'),
                'jb-purple' => array('linear-gradient(135deg, #fec2ff 10%, #d000de 100%)'),
                'jb-vip1'   => array('linear-gradient(25deg, #eab869 10%, #fbecd4 60%, #ffe0ae 100%)'),
                'jb-vip2'   => array('linear-gradient(317deg, #4d4c4c 30%, #878787 70%, #5f5c5c 100%)'),
            ));
        }
        return $palette;
    }


}

// 翻译国家列表
function language_json() {
    $json='{ "result": 1, "info": "成功", "list": [ { "id": "corsican", "name": "Corsu", "serviceId": "co", "value": "科西嘉语" }, { "id": "guarani", "name": "guarani", "serviceId": "gn", "value": "瓜拉尼语" }, { "id": "kinyarwanda", "name": "Kinyarwanda", "serviceId": "rw", "value": "卢旺达语" }, { "id": "hausa", "name": "Hausa", "serviceId": "ha", "value": "豪萨语" }, { "id": "norwegian", "name": "Norge", "serviceId": "no", "value": "挪威语" }, { "id": "dutch", "name": "Nederlands", "serviceId": "nl", "value": "荷兰语" }, { "id": "yoruba", "name": "Yoruba", "serviceId": "yo", "value": "约鲁巴语" }, { "id": "english", "name": "English", "serviceId": "en", "value": "英语" }, { "id": "gongen", "name": "गोंगेन हें नांव", "serviceId": "gg", "value": "贡根语" }, { "id": "latin", "name": "Latina", "serviceId": "la", "value": "拉丁语" }, { "id": "nepali", "name": "नेपाली", "serviceId": "ne", "value": "尼泊尔语" }, { "id": "french", "name": "Français", "serviceId": "fr", "value": "法语" }, { "id": "czech", "name": "čeština", "serviceId": "cs", "value": "捷克语" }, { "id": "hawaiian", "name": "ʻŌlelo Hawaiʻi", "serviceId": "haw", "value": "夏威夷语" }, { "id": "georgian", "name": "ჯორჯიანი", "serviceId": "ka", "value": "格鲁吉亚语" }, { "id": "russian", "name": "Русский язык", "serviceId": "ru", "value": "俄语" }, { "id": "chinese_simplified", "name": "简体中文", "serviceId": "zh-CN", "value": "中文（简体）" }, { "id": "persian", "name": "فارسی", "serviceId": "fa", "value": "波斯语" }, { "id": "bhojpuri", "name": "भोजपुरी", "serviceId": "bho", "value": "博杰普尔语" }, { "id": "hindi", "name": "हिंदी", "serviceId": "hi", "value": "印地语" }, { "id": "belarusian", "name": "беларускі", "serviceId": "be", "value": "白俄罗斯语" }, { "id": "swahili", "name": "Kiswahili", "serviceId": "sw", "value": "斯瓦希里语" }, { "id": "icelandic", "name": "ÍslandName", "serviceId": "is", "value": "冰岛语" }, { "id": "yiddish", "name": "ייַדיש", "serviceId": "yi", "value": "意第绪语" }, { "id": "twi", "name": "tur", "serviceId": "ak", "value": "契维语" }, { "id": "irish", "name": "Gaeilge", "serviceId": "ga", "value": "爱尔兰语" }, { "id": "gujarati", "name": "ગુજરાતી", "serviceId": "gu", "value": "古吉拉特语" }, { "id": "khmer", "name": "កម្ពុជា", "serviceId": "km", "value": "柬埔寨语" }, { "id": "slovak", "name": "Slovenská", "serviceId": "sk", "value": "斯洛伐克语" }, { "id": "hebrew", "name": "היברית", "serviceId": "iw", "value": "希伯来语" }, { "id": "kannada", "name": "ಕನ್ನಡ್", "serviceId": "kn", "value": "卡纳达语" }, { "id": "hungarian", "name": "Magyar", "serviceId": "hu", "value": "匈牙利语" }, { "id": "tamil", "name": "தாமில்", "serviceId": "ta", "value": "泰米尔语" }, { "id": "arabic", "name": "بالعربية", "serviceId": "ar", "value": "阿拉伯语" }, { "id": "bengali", "name": "বাংলা", "serviceId": "bn", "value": "孟加拉语" }, { "id": "azerbaijani", "name": "Azərbaycan", "serviceId": "az", "value": "阿塞拜疆语" }, { "id": "samoan", "name": "lifiava", "serviceId": "sm", "value": "萨摩亚语" }, { "id": "afrikaans", "name": "Suid-Afrikaanse", "serviceId": "af", "value": "布尔语(南非荷兰语)" }, { "id": "danish", "name": "dansk", "serviceId": "da", "value": "丹麦语" }, { "id": "shona", "name": "Shona", "serviceId": "sn", "value": "修纳语" }, { "id": "bambara", "name": "Bamanankan", "serviceId": "bm", "value": "班巴拉语" }, { "id": "lithuanian", "name": "Lietuva", "serviceId": "lt", "value": "立陶宛语" }, { "id": "vietnamese", "name": "Tiếng Việt", "serviceId": "vi", "value": "越南语" }, { "id": "maltese", "name": "Malti", "serviceId": "mt", "value": "马耳他语" }, { "id": "turkmen", "name": "Türkmençe", "serviceId": "tk", "value": "土库曼语" }, { "id": "assamese", "name": "অসমীয়া", "serviceId": "as", "value": "阿萨姆语" }, { "id": "catalan", "name": "català", "serviceId": "ca", "value": "加泰罗尼亚语" }, { "id": "singapore", "name": "සිංගාපුර්", "serviceId": "si", "value": "僧伽罗语" }, { "id": "cebuano", "name": "Cebuano", "serviceId": "ceb", "value": "宿务语" }, { "id": "scottish-gaelic", "name": "Gàidhlig na h-Alba", "serviceId": "gd", "value": "苏格兰盖尔语" }, { "id": "sanskrit", "name": "Sanskrit", "serviceId": "sa", "value": "梵语" }, { "id": "polish", "name": "Polski", "serviceId": "pl", "value": "波兰语" }, { "id": "galician", "name": "galego", "serviceId": "gl", "value": "加利西亚语" }, { "id": "latvian", "name": "latviešu", "serviceId": "lv", "value": "拉脱维亚语" }, { "id": "ukrainian", "name": "УкраїнськаName", "serviceId": "uk", "value": "乌克兰语" }, { "id": "tatar", "name": "Татар", "serviceId": "tt", "value": "鞑靼语" }, { "id": "welsh", "name": "Cymraeg", "serviceId": "cy", "value": "威尔士语" }, { "id": "japanese", "name": "日本語", "serviceId": "ja", "value": "日语" }, { "id": "filipino", "name": "Pilipino", "serviceId": "tl", "value": "菲律宾语" }, { "id": "aymara", "name": "Aymara", "serviceId": "ay", "value": "艾马拉语" }, { "id": "lao", "name": "ກະຣຸນາ", "serviceId": "lo", "value": "老挝语" }, { "id": "telugu", "name": "తెలుగు", "serviceId": "te", "value": "泰卢固语" }, { "id": "romanian", "name": "Română", "serviceId": "ro", "value": "罗马尼亚语" }, { "id": "haitian_creole", "name": "Kreyòl ayisyen", "serviceId": "ht", "value": "海地克里奥尔语" }, { "id": "dogrid", "name": "डोग्रिड ने दी", "serviceId": "doi", "value": "多格来语" }, { "id": "swedish", "name": "Svenska", "serviceId": "sv", "value": "瑞典语" }, { "id": "maithili", "name": "मरातिली", "serviceId": "mai", "value": "迈蒂利语" }, { "id": "thai", "name": "ภาษาไทย", "serviceId": "th", "value": "泰语" }, { "id": "armenian", "name": "հայերեն", "serviceId": "hy", "value": "亚美尼亚语" }, { "id": "burmese", "name": "ဗာရမ်", "serviceId": "my", "value": "缅甸语" }, { "id": "pashto", "name": "پښتو", "serviceId": "ps", "value": "普什图语" }, { "id": "hmong", "name": "Hmoob", "serviceId": "hmn", "value": "苗语" }, { "id": "dhivehi", "name": "ދިވެހި", "serviceId": "dv", "value": "迪维希语" }, { "id": "chinese_traditional", "name": "繁體中文", "serviceId": "zh-TW", "value": "中文（繁体）" }, { "id": "luxembourgish", "name": "Lëtzebuergesch", "serviceId": "lb", "value": "卢森堡语" }, { "id": "sindhi", "name": "سنڌي", "serviceId": "sd", "value": "信德语" }, { "id": "kurdish", "name": "Kurdî", "serviceId": "ku", "value": "库尔德语（库尔曼吉语）" }, { "id": "turkish", "name": "Türkçe", "serviceId": "tr", "value": "土耳其语" }, { "id": "macedonian", "name": "Македонски", "serviceId": "mk", "value": "马其顿语" }, { "id": "bulgarian", "name": "български", "serviceId": "bg", "value": "保加利亚语" }, { "id": "malay", "name": "Malay", "serviceId": "ms", "value": "马来语" }, { "id": "luganda", "name": "luganda", "serviceId": "lg", "value": "卢干达语" }, { "id": "marathi", "name": "मराठी", "serviceId": "mr", "value": "马拉地语" }, { "id": "estonian", "name": "eesti keel", "serviceId": "et", "value": "爱沙尼亚语" }, { "id": "malayalam", "name": "മലമാലം", "serviceId": "ml", "value": "马拉雅拉姆语" }, { "id": "deutsch", "name": "Deutsch", "serviceId": "de", "value": "德语" }, { "id": "slovene", "name": "slovenščina", "serviceId": "sl", "value": "斯洛文尼亚语" }, { "id": "urdu", "name": "اوردو", "serviceId": "ur", "value": "乌尔都语" }, { "id": "portuguese", "name": "Português", "serviceId": "pt", "value": "葡萄牙语" }, { "id": "igbo", "name": "igbo", "serviceId": "ig", "value": "伊博语" }, { "id": "kurdish_sorani", "name": "کوردی-سۆرانی", "serviceId": "ckb", "value": "库尔德语（索拉尼）" }, { "id": "oromo", "name": "adeta", "serviceId": "om", "value": "奥罗莫语" }, { "id": "greek", "name": "Ελληνικά", "serviceId": "el", "value": "希腊语" }, { "id": "spanish", "name": "español", "serviceId": "es", "value": "西班牙语" }, { "id": "frisian", "name": "Frysk", "serviceId": "fy", "value": "弗里西语" }, { "id": "somali", "name": "Soomaali", "serviceId": "so", "value": "索马里语" }, { "id": "amharic", "name": "አማርኛ", "serviceId": "am", "value": "阿姆哈拉语" }, { "id": "nyanja", "name": "potakuyan", "serviceId": "ny", "value": "齐切瓦语" }, { "id": "punjabi", "name": "ਪੰਜਾਬੀ", "serviceId": "pa", "value": "旁遮普语" }, { "id": "basque", "name": "euskara", "serviceId": "eu", "value": "巴斯克语" }, { "id": "italian", "name": "Italiano", "serviceId": "it", "value": "意大利语" }, { "id": "albanian", "name": "albanian", "serviceId": "sq", "value": "阿尔巴尼亚语" }, { "id": "korean", "name": "한어", "serviceId": "ko", "value": "韩语" }, { "id": "tajik", "name": "Таjikӣ", "serviceId": "tg", "value": "塔吉克语" }, { "id": "finnish", "name": "Suomalainen", "serviceId": "fi", "value": "芬兰语" }, { "id": "kyrgyz", "name": "Кыргыз тили", "serviceId": "ky", "value": "吉尔吉斯语" }, { "id": "ewe", "name": "Eʋegbe", "serviceId": "ee", "value": "埃维语" }, { "id": "croatian", "name": "Hrvatski", "serviceId": "hr", "value": "克罗地亚语" }, { "id": "creole", "name": "a n:n", "serviceId": "kri", "value": "克里奥尔语" }, { "id": "quechua", "name": "Quechua", "serviceId": "qu", "value": "克丘亚语" }, { "id": "bosnian", "name": "bosanski", "serviceId": "bs", "value": "波斯尼亚语" }, { "id": "maori", "name": "Maori", "serviceId": "mi", "value": "毛利语" }, { "id": "oriya", "name": "ଓଡିଆ", "serviceId": "or", "value": "奥利亚语" }, { "id": "tigrean", "name": "ትግናን", "serviceId": "ti", "value": "蒂格尼亚语" }, { "id": "kazakh", "name": "қазақ", "serviceId": "kk", "value": "哈萨克语" }, { "id": "lingala", "name": "Lingala", "serviceId": "ln", "value": "林格拉语" }, { "id": "malagasy", "name": "Malagasy", "serviceId": "mg", "value": "马尔加什语" }, { "id": "mongolian", "name": "Монгол", "serviceId": "mn", "value": "蒙古语" }, { "id": "mizo", "name": "Mizo tawng", "serviceId": "lus", "value": "米佐语" }, { "id": "xhosa", "name": "IsiXhosa", "serviceId": "xh", "value": "南非科萨语" }, { "id": "zulu", "name": "Zulu", "serviceId": "zu", "value": "南非祖鲁语" }, { "id": "serbian", "name": "Српски", "serviceId": "sr", "value": "塞尔维亚语" }, { "id": "sepeti", "name": "Sepeti", "serviceId": "nso", "value": "塞佩蒂语" }, { "id": "sesotho", "name": "Sesotho", "serviceId": "st", "value": "塞索托语" }, { "id": "meitei", "name": "แบบไทย", "serviceId": "mni-Mtei", "value": "梅泰语（曼尼普尔语）" }, { "id": "uyghur", "name": "ئۇيغۇر", "serviceId": "ug", "value": "维吾尔语" }, { "id": "uzbek", "name": "o\'zbek", "serviceId": "uz", "value": "乌兹别克语" }, { "id": "ilokano", "name": "Ilocano", "serviceId": "ilo", "value": "伊洛卡诺语" }, { "id": "indonesian", "name": "bahasa Indonesia", "serviceId": "id", "value": "印尼语" }, { "id": "Indonesianj", "name": "Basa Jawa Indonesia", "serviceId": "jw", "value": "印尼爪哇语" }, { "id": "xitsonga", "name": "Xitsonga", "serviceId": "ts", "value": "宗加语" }, { "id": "esperanto", "name": "Esperanto", "serviceId": "eo", "value": "世界语" } ] }';
    return $json;
}

class CSF_Module_Wml_Count
{
    //每日更新的文章数量
    public static function WeeklyUpdate()
    {
        $date_query = array(
            array(
            'after'=>'1 day ago'
            )
            );$args = array(
            'post_type' => 'post',
            'post_status'=>'publish',
            'date_query' => $date_query,
            'no_found_rows' => true,
            'suppress_filters' => true,
            'fields'=>'ids',
            'posts_per_page'=>-1
            );$query = new WP_Query( $args );return $query->post_count;
    } 
    //统计本周文章数量
    public static function get_posts_count_from_last_168h($post_type ='post')
    {
        global $wpdb;
        $numposts = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(ID) ".
                "FROM {$wpdb->posts} ".
                "WHERE ".
                    "post_status='publish' ".
                    "AND post_type= %s ".
                    "AND post_date> %s",
                $post_type, date('Y-m-d H:i:s', strtotime('-168 hours'))
            )
        );
        return $numposts;
    }
    //统计总访问量
    public static function all_view()
    {
        global $wpdb;
        $count=0;
        $views= $wpdb->get_results("SELECT * FROM $wpdb->postmeta WHERE meta_key='views'");
        foreach($views as $key=>$value){
        $meta_value=$value->meta_value;
        if($meta_value!=' '){
            $count+=(int)$meta_value;
        }
        }return $count;
    }
    //新注册用户
    public static function new_user()
    {   
        global $wpdb;
        // 定义SQL查询来获取最新注册的十个用户    
        $sql = "SELECT ID, user_login, user_registered,display_name   
        FROM $wpdb->users    
        ORDER BY user_registered DESC    
        LIMIT ".wml_zib('cheat_xhy').""; 
        // 执行查询
        $users = $wpdb->get_results($sql);
        return $users;
    }
}

//标题前缀
class DearLicy_Module
{
    public static function DearLicy_imgtitle($palette = array())
    {
            $palette = array_merge($palette, array(
                'shice'    => array('url('.WML_ZIB_BEAUT_DIR_URL.'/img/feature/horn-qz1.svg);width: 50px;'),
                'dujia'    => array('url('.WML_ZIB_BEAUT_DIR_URL.'/img/feature/horn-qz2.svg);width: 50px;'),
                'shoufa'   => array('url('.WML_ZIB_BEAUT_DIR_URL.'/img/feature/horn-qz3.svg);width: 50px;'),
            ));
        return $palette;
    }

}