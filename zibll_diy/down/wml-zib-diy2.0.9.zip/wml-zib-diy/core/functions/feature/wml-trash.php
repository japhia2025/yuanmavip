<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-14 22:29:01
 $ @ 最后修改: 2024-11-14 19:45:48
 $ @ 文件路径: \wml-zib-diy\core\functions\feature\wml-trash.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/


//开启回收站
if (wml_zib('trash_switch', false)) {
    //判断是否开启回收站定义
    function enable_media_notices() {
        $is_defined = defined( 'MEDIA_TRASH' );
        if ( !($is_defined && MEDIA_TRASH )) {
            ?>
             <div class="notice notice-error is-dismissible">
             <p>提示：要在媒体中启用回收站功能，请添加一行定义<code>define( 'MEDIA_TRASH', 'true' );</code>到主目录<code>wp-config.php</code>文件中，在“<code>就这，停止编辑</code>”这一行之前。</p>
            </div>
            <?php
        }
    }
    add_action('admin_notices','enable_media_notices');

    //后台添加回收站按钮
    add_action('admin_footer', 'wml_admin_footer');
    function wml_admin_footer()
    { ?>
        <script>
                (function($) {
                    "use strict";
                    $(document).ready(function(){
                        $("#menu-media ul").append("<li class='media-trash-menu'><a class='media-trash' href='upload.php?mode=list&attachment-filter=trash&media_folder'>回收站</a></li>");
                        <?php if(isset($_REQUEST['attachment-filter']) && $_REQUEST['attachment-filter']=="trash") { ?>
                            $("#menu-media .current").removeClass("current");
                            $("#menu-media .media-trash-menu").addClass("current");
                            $(".wp-filter .view-switch a").remove();
                            $(".wp-filter .view-switch").css("height","28px").css("margin", "0");
                        <?php } ?>
                    });
                })(jQuery);
            </script>
    <?php }
}
