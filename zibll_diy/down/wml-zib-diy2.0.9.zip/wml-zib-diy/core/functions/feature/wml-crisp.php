<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-20 19:08:54
 $ @ 最后修改: 2024-11-20 23:05:40
 $ @ 文件路径: \wml-zib-diy\core\functions\feature\wml-crisp.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/
if (! defined('ABSPATH')) {
	die;
}
if (wml_zib('chat_crisp', false)) {
    //后台更新KEY
    if(is_admin()&&isset($_GET['_wpnonce'])){
        //if(isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'])) {
            if (isset($_GET["crisp_website_id"]) && !empty($_GET["crisp_website_id"])) {
                $options = get_option('wml_zib_diy');
                $options['chat_crisp_key']=sanitize_text_field($_GET["crisp_website_id"]);
                update_option("wml_zib_diy", $options);

                // 如果需要，清除WP火箭缓存
                if (function_exists("rocket_clean_domain")) {
                    rocket_clean_domain();
                }

                // 如果需要，清除WP超级缓存
                if (function_exists("wp_cache_clean_cache")) {
                    global $file_prefix;
                    wp_cache_clean_cache($file_prefix, true);
                }
            }
        //}
    }
    //前端显示
    if(wml_zib('chat_crisp_key')){
        add_action("wp_enqueue_scripts", "wml_crisp_enqueue_script");
        //add_action("script_loader_tag", "wml_crisp_enqueue_async", 10, 2)
    };
}

function wml_crisp_enqueue_script() {
    $website_id = wml_zib('chat_crisp_key');
    $locale = str_replace("_", "-", strtolower(get_locale()));
    $locale = preg_replace("/([a-z]{2}-[a-z]{2})(-.*)/", "$1", $locale);
    if (!isset($website_id) || empty($website_id)) {
      return;
    }
    $output="
      window.\$crisp=[];
      if (!window.CRISP_RUNTIME_CONFIG) {
        window.CRISP_RUNTIME_CONFIG = {}
      }
      if (!window.CRISP_RUNTIME_CONFIG.locale) {
        window.CRISP_RUNTIME_CONFIG.locale = '$locale'
      }
      CRISP_WEBSITE_ID = '$website_id';";
    $output .= wml_crisp_sync_wordpress_user();
    $cache_buster = date("Ymd");
    if(wml_zib('chat_crisp_js')==1){
        $l_js=WML_ZIB_BEAUT_DIR_ASSETS."app/crisp/l.js";
    }else{
        $l_js="https://client.crisp.chat/l.js";
    }
    wp_enqueue_script("crisp", $l_js, array(), $cache_buster, true);
    wp_add_inline_script("crisp", $output, "before");
  }
  //用户信息
  function wml_crisp_sync_wordpress_user() {
    $output = "";
    if (is_user_logged_in()) {
      $current_user = wp_get_current_user();
    }
    if (!isset($current_user)) {
      return "";
    }
    $email = esc_js($current_user->user_email);
    $nickname = esc_js($current_user->display_name);
    if (!empty($email)) {
      $output .= "\$crisp.push(['set', 'user:email', '" . $email . "']);";
    }
    if (!empty($nickname)) {
      $output .= "\$crisp.push(['set', 'user:nickname', '" . $nickname . "']);";
    }
    return $output;
  }
  
  /* function wml_crisp_enqueue_async($tag, $handle) {
    if ("crisp" !== $handle ) {
      return $tag;
    }
    return str_replace("src", " async src", $tag );
  } */

?>