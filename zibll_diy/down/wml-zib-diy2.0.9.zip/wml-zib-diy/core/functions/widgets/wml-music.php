<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-11 03:28:47
 $ @ 最后修改: 2024-11-14 21:15:39
 $ @ 文件路径: \wml-zib-diy\core\widgets\wml-music.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/


//音乐播放器
if (wml_zib('music_switch', false)) {
    //加载CSS+JS
    add_action('wp_enqueue_scripts', 'music_css_js');
    function music_css_js() {
        ?>
        <!-- require APlayer -->
        <link rel="stylesheet" href="https://lf9-cdn-tos.bytecdntp.com/cdn/expire-1-M/aplayer/1.10.1/APlayer.min.css">
        <script src="https://lf9-cdn-tos.bytecdntp.com/cdn/expire-1-M/aplayer/1.10.1/APlayer.min.js"></script>
        <!-- require MetingJS -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/meting/2.0.1/Meting.min.js"></script>
        <?php
    }
    if(wml_zib('music_type')==2){
        function wml_zib_music_switch()
        {
            $palette=CSF_Module_Wml_Zib::zib_palette(array(), array('t','c', 'b'));
            $theme=$palette[wml_zib('music_theme')][0];
            wml_zib('music_autoplay', false)?$autoplay='ture':$autoplay='false';
            echo '
            <meting-js type="playlist" volume="1" preload="auto" lrctype="0" list-max-height="300px" server="'.wml_zib('music_server').'" id="'.wml_zib('music_id').'" autoplay="'.$autoplay.'" loop="'.wml_zib('music_loop').'" order="'.wml_zib('music_order').'" list-folded="'.wml_zib('music_folded').'" theme="'.$theme.'" mutex="ture" fixed="ture"></meting-js>';
        }
        add_action('wp_footer', 'wml_zib_music_switch');
    }else{
        //注册钩子
        add_action('widgets_init', 'register_music');
        function register_music()
        {
            register_widget('wml_music');
        }
        class wml_music extends WP_Widget
        {
            public function __construct()
            {
                //定义小工具
                $widget = array(
                    'w_id'        => 'wml_music',
                    'w_name'      => 'WML - 音乐播放器',
                    'classname'   => '',
                    'description' => '侧边音乐播放器',
                );
                parent::__construct($widget['w_id'], $widget['w_name'], $widget);
            }

            public function widget($args, $instance)
            {
                if (!zib_widget_is_show($instance)) {
                    return;
                }
                extract($args);
                
                $palette=CSF_Module_Wml_Zib::zib_palette(array(), array('t','c', 'b'));
                $theme=$palette[wml_zib('music_theme')][0];
                wml_zib('music_autoplay', false)?$autoplay='ture':$autoplay='false';
                echo '
                <div class="zib-widget"><meting-js type="playlist" volume="1" preload="auto" lrctype="0" list-max-height="300px" server="'.wml_zib('music_server').'" id="'.wml_zib('music_id').'" autoplay="'.$autoplay.'" loop="'.wml_zib('music_loop').'" order="'.wml_zib('music_order').'" list-folded="'.wml_zib('music_folded').'" theme="'.$theme.'" mutex="ture"></meting-js></div>';
            }
        }
    }
}