<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-12-19 23:20:28
 $ @ 最后修改: 2024-12-25 04:43:12
 $ @ 文件路径: \wml-zib-diy\core\functions\safe\wml-login.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

//登录限制
//强制注销模式
if (wml_zib('safe_login_is', false)){
    $type = wml_zib('safe_login_type'); //限制模式
    //强制模式
    //if($type==1){
        function wml_user_has_concurrent_sessions() {
            return ( is_user_logged_in() && count( wp_get_all_sessions() ) > 1 );
        }
        function wml_get_current_session() {
            $sessions = WP_Session_Tokens::get_instance( get_current_user_id() );
            return $sessions->get( wp_get_session_token() );
        }
        function wml_disallow_account_sharing() {
            if ( ! wml_user_has_concurrent_sessions() ) {
                return;
            }
            $newest  = max( wp_list_pluck( wp_get_all_sessions(), 'login' ) );
            $session = wml_get_current_session();
            if ( $session['login'] === $newest ) {
                wp_destroy_other_sessions();
            } else {
                wp_destroy_current_session();
            }
        }
        $login=1;
        if(wml_zib('safe_login_pc_user')){
            $safe_login_pc_user = preg_split("/,|，|\s|\n/", wml_zib('safe_login_pc_user'));
            if (in_array(get_current_user_id(), $safe_login_pc_user)){
                $login=2;
            }
        }
        if(wml_zib('safe_login_pc_role')){
            $safe_login_pc_role = preg_split("/,|，|\s|\n/", wml_zib('safe_login_pc_role'));
            global $current_user;
            if (in_array($current_user->roles[0], $safe_login_pc_role)){
                $login=2;
            }
        }
        if($login==1){
            add_action( 'init', 'wml_disallow_account_sharing' );
        }
    //}
}


?>