<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 13:44:10
 $ @ 最后修改: 2024-11-14 19:58:21
 $ @ 文件路径: \wml-zib-diy\core\functions\beautify\wml-right.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

//可爱调皮小猫
if (wml_zib('cat', false))
{
    function wml_zib_cat() { ?>
        <style>
            #maomao {position: fixed;bottom: 40px;right: -5px;width: 57px;height: 70px;background-image: url(<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/img/right/mao.svg' ?>);background-position: center;background-size: cover;background-repeat: no-repeat;transition: background .3s;z-index: 99999999999999 }#maomao:hover {background-position: 60px 50%;}
        </style>
        <div id="maomao" onmouseout="duoMaomao()" style="bottom: 60vh;"></div>
        <script>
            var randomNum=function(a,n){switch(arguments.length){case 1:return parseInt(Math.random()*a+1,10);case 2:return parseInt(Math.random()*(n-a+1)+a,10);default:return 0}},duoMaomao=function(){$("#maomao").css("bottom",randomNum(1,90)+"vh")};
        </script>
    <?php }
    add_action('wp_footer', 'wml_zib_cat');
}

// 调皮小萝莉
if (wml_zib('tiaopill'))
{
    function wml_zib_tiaopill() { ?>
        <style>
            #tiaopill {position: fixed;bottom: 40px;right: -5px;width: 57px;height: 70px;background-image: url(<?php echo WML_ZIB_BEAUT_DIR_ASSETS . '/img/right/decorate1.png' ?>);background-position: center;background-size: cover;background-repeat: no-repeat;transition: background .3s;z-index: 99999999999999 }#tiaopill:hover {background-position: 60px 50%;}
        </style>
        <div id="tiaopill" onmouseout="duoMaomao()" style="bottom: 60vh;"></div>
        <script>
            var randomNum=function(a,t){switch(arguments.length){case 1:return parseInt(Math.random()*a+1,10);case 2:return parseInt(Math.random()*(t-a+1)+a,10);default:return 0}},duoMaomao=function(){$("#tiaopill").css("bottom",randomNum(1,90)+"vh")};
        </script>
    <?php }
    add_action('wp_footer', 'wml_zib_tiaopill');
}

// 悬浮按钮美化
if (wml_zib('xfan', false))
{
    function wml_zib_xfan() { ?>
        <style>
             .float-right .float-btn {width: 40px;line-height: 40px;display: block;font-size: 1.4em;--this-color: #fff;--this-bg: var(--float-btn-bg);background: linear-gradient(90deg, #fdfffc73 0%, #ff5683 100%);position: relative;color: var(--this-color) !important;}.float-right.round .float-btn {margin-top: 5px;border-radius: 20px;}
        </style>
    <?php }
    add_action('wp_footer', 'wml_zib_xfan');
}

//右侧悬浮按钮图片
if (wml_zib('suspension', false))
{
    function wml_zibsuspension() { ?>
        <style>
            span.float-btn.more-btn.hover-show.nowave {margin-top: 0 }.float-right.round.position-bottom {background: #fff;border-radius: var(--main-radius);transition: 0s;right: 1px;bottom: 170px;border-radius: 20px 0 0 20px;box-shadow: -5px 3px 10px 0 rgb(5 5 5 / 15%) }.float-right.round .float-btn {border-radius: 8px 0 0 17px }.float-right .float-btn {background: #fff }.float-right.round.position-bottom::before {content: '';width: 30px;height: 60px;background: url(<?php echo wml_zib('suspension_img') ?>);background-size: cover;display: block;margin: 5px 3px 0 7px;}.dark-theme .float-right.round.position-bottom {background: #414141;border: 1px solid #4a4a4a;transition: 0s }.dark-theme .float-right .float-btn {background: #414141 }.dark-theme .float-right.round.position-bottom a:hover {background: #505255;--this-color: var(--muted-2-color) }.dark-theme .float-right.round.position-bottom span:hover {background: #505255;--this-color: var(--muted-2-color) }span.newadd-btns.hover-show.float-btn.add-btn .hover-show-con.dropdown-menu.drop-newadd>a:hover {background-color: #d8d8d836;border-radius: 8px }a.float-btn.ontop.fade {display: none }
        </style>
    <?php }
    add_action('wp_footer', 'wml_zibsuspension');
}
