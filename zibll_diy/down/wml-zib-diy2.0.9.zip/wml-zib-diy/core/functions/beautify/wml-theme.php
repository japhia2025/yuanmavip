<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-12-02 05:48:47
 $ @ 最后修改: 2024-12-02 06:07:09
 $ @ 文件路径: \wml-zib-diy\core\functions\beautify\wml-theme.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (wml_zib('theme_snowy', false)){
    // 引入静态文件
    function wml_snow_scripts() {
        wp_enqueue_script('wml_snowfall', WML_ZIB_BEAUT_DIR_ASSETS . 'theme/snowy/snowfall.jquery.min.js', array('jquery'), null, true);
        wp_enqueue_script('wml_snow_js', WML_ZIB_BEAUT_DIR_ASSETS. 'theme/snowy/script.js', array('jquery'), null, true);
        wp_enqueue_style('wml_snow_css', WML_ZIB_BEAUT_DIR_ASSETS . 'theme/snowy/style.css', array());
    }
    add_action('wp_footer', 'wml_snow_scripts');
    if (wml_zib('theme_snowy_music', false)){
        // 插入所需HTML
        function wml_snow_html() {
            echo '
        <i style="display: inline-block; height: auto; position: fixed; bottom: 0; z-index: 110; margin-bottom: 20px; left: 50%; transform: translateX(-50%); transition: all 0.5s ease;">
            <div class="player">
                <div id="info" class="info">
                    <span class="artist">圣诞节 - 铃儿响叮当</span>
                    <span class="name">纯音乐</span>
                    <div class="progress-bar">
                        <span class="current-time">0:00</span>
                        <span class="duration">0:00</span>
                        <div class="bar"></div>
                    </div>
                </div>
                <div id="control-panel" class="control-panel">
                    <div class="album-art"></div>
                    <div class="controls">
                        <div class="prev"></div>
                        <div id="play" class="play"></div>
                        <div class="next"></div>
                    </div>
                </div>
            </div>
        </i>';
        }
        if (!wp_is_mobile()) {
            add_action('wp_footer', 'wml_snow_html');
        }
    }
    // 移除子比主题的go跳转调用函数
    remove_action('template_redirect', 'zib_gophp_template', 5);

    // 使用插件go跳转函数
    function wml_snow_gophp_template() {
        $golink = get_query_var('golink');
        //error_log("golink: " . print_r($golink, true)); // 添加调试信息
        if ($golink) {
            global $wp_query;
            $wp_query->is_home = false;
            $wp_query->is_page = true;

            $zib_snow_template = WML_ZIB_BEAUT_DIR_ASSETS . 'theme/snowy/wml_snow_go.php';
            if (file_exists($zib_snow_template)) {
                $template = $zib_snow_template;
            } else {
                $template = TEMPLATEPATH . '/go.php';
            }

            if (session_status() == PHP_SESSION_NONE) {
                session_start();
            }

            $_SESSION['GOLINK'] = $golink;
            load_template($template);
            exit;
        }
    }
    add_action('template_redirect', 'wml_snow_gophp_template', 5);
}


?>