<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-11-23 20:33:57
 $ @ 最后修改: 2024-12-01 10:03:44
 $ @ 文件路径: \wml-zib-diy\core\lib\index.php
 $ @ 简要说明: 由Japhia开发用于WordPress to zibll主题专用的美化增强插件。
 $ @ 联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

if (! defined('ABSPATH')) {
	die;
}


//开启水印功能
if (wml_zib('imk_onOff', false)) {
	if(wml_zib('imk-types')==1){
		// 检查PHP是否安装了Imagick
		if (!extension_loaded('imagick')) {
			function imk_notice_new_install()
			{
				$con = '<div class="notice notice-success is-dismissible">
						<h2 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 感谢您使用外贸啦DIY</h2>
						<p>imagemagick 扩展未安装，水印功能请先安装 imagemagick 扩展。</p>
					</div>';
				echo $con;
			}
			add_action('admin_notices', 'imk_notice_new_install');
		}else{
			require_once 'watermark/wml-imk.php';//上传图片水印
		}
	}else{
		require_once 'watermark/ytsy.php';//无损水印
	}
}

//开启缩略图裁剪功能
if (wml_zib('thumbnail_is', false)) {
	// 检查PHP版本是否符合
	if(version_compare(PHP_VERSION,'7.4.0','ge')){
		require_once 'wthnbo/wthnbo.php';//缩略图边框裁剪
	}else{
		function imk_notice_new_install()
		{
			$con = '<div class="notice notice-success is-dismissible">
					<h2 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 感谢您使用'.WML_ZIB_DIY_NAME.'</h2>
					<p>您的PHP版本小于7.4,当前版本为 '.PHP_VERSION.',无法兼容缩略边框生成功能。请将PHP版本升级到7.4或以上</p>
				</div>';
			echo $con;
		}
		add_action('admin_notices', 'imk_notice_new_install');
	}
}
//站点地图
if (wml_zib('seo_sitemap', false)) {
	require_once 'sitemap/sitemap.php';//生成sitemap地图
}
?>