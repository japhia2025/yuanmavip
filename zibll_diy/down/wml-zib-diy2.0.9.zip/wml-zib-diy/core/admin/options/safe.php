<?php
/**************************************************************************** 
 $ @ 作者名称: Japhia
 $ @ 创建日期: 2024-10-05 16:10:03
 $ @ 最后修改: 2024-12-25 03:53:08
 $ @ 文件路径: \wml-zib-diy\core\admin\options\safe.php
 $ @ 简要说明: 有问题联系作者：QQ:181682233 邮箱：japhia@mail.com 网址：waimao.la
 $ @ Copyright (c) 2024 by Japhia, All Rights Reserved. 
 ****************************************************************************/

CSF::createSection(
    $prefix,
    array(
        'id' => 'safe',
        'title' => '安全组件',
        'icon' => 'fa fa-fw fa-shield',
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'safe',
        'title' => '禁用&防扒',
        'icon' => 'fa fa-fw fa-hand-spock-o',
        'description' => '',
        'fields' => array(
            array(
                'id' => 'disable_admin',
                'type' => 'switcher',
                'label' => '启用后，管理员登录无受以下防扒设定限制。',
                'default' => false,
                'title' => '排除管理员',
            ),
            array(
                'id' => 'disablecopy',
                'type' => 'switcher',
                'label' => '启用后，网站用户将无法进行复制（前台无提示）。',
                'default' => false,
                'title' => '禁用复制',
            ),
            array(
                'id' => 'dismouse',
                'type' => 'switcher',
                'label' => '启用后，网站用户将无法使用鼠标进行选中（前台无提示）。',
                'default' => false,
                'title' => '禁用鼠标选中',
            ),
            array(
                'title' => '禁止图片拖放',
                'label' => '启用后，用户将不能拖放网站中图片（前台无提示）。',
                'id' => 'notuofang',
                'default' => false,
                'type' => 'switcher'
            ),
            array(
                'title' => '禁止打开控制台',
                'label' => '禁止打开控制台，网页禁止打开控制台（前台无提示）。',
                'id' => 'nodebugger',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'id' => 'disable',
                'type' => 'switcher',
                'label' => 'F12，Ctrl+U，Ctrl+S，Ctrl+Shift+I，右键等禁用并提示。',
                'default' => false,
                'title' => '禁用并提示',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title'   => ' ',
                'desc'    => '选择需要禁用的操作（可多选）',
                'id'      => 'disable_click',
                'class' => 'compact', 
                'type'    => "checkbox",
                'inline'  => true,
                'options' => array(
                    'disable_f'   => __('F12', 'zib_language'),
                    'disable_u'       => __('Ctrl+U', 'zib_language'),
                    'disable_s'   => __('Ctrl+S', 'zib_language'),
                    'disable_i'    => __('Ctrl+Shift+I', 'zib_language'),
                    'disable_r'    => __('右键', 'zib_language'),
                ),
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => 'F12提示标题', 
                'id' => 'disable_f_t', 
                'default' => '呃！别瞎按', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => 'F12提示内容', 
                'class' => 'compact', 
                'id' => 'disable_f_c', 
                'default' => '你按这个想干嘛！再按就找不到我咯', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => 'Ctrl+U提示标题', 
                'id' => 'disable_u_t', 
                'default' => '嘿！Brother', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => 'Ctrl+U提示内容', 
                'class' => 'compact', 
                'id' => 'disable_u_c', 
                'default' => '老弟，源码得换方式获取哦~', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => 'Ctrl+S提示标题', 
                'id' => 'disable_s_t', 
                'default' => '哎！你瞧瞧你', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => 'Ctrl+S提示内容', 
                'class' => 'compact', 
                'id' => 'disable_s_c', 
                'default' => '网页得换方法保存哦~', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => 'Ctrl+Shift+I提示标题', 
                'id' => 'disable_i_t', 
                'default' => '呐！这个也不行', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => 'Ctrl+Shift+I提示内容', 
                'class' => 'compact', 
                'id' => 'disable_i_c', 
                'default' => '还是按点别的吧！', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => '右键提示标题', 
                'id' => 'disable_r_t', 
                'default' => '嗯？没有右键菜单', 
                'type' => 'text',
            ),
            array(
                'dependency' => array('disable', '!=', ''), 
                'title' => '右键提示内容', 
                'class' => 'compact', 
                'id' => 'disable_r_c', 
                'default' => '复制请用键盘快捷键[Ctrl+C]', 
                'type' => 'text',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'safe',
        'title' => '会员&注册',
        'icon' => 'fa fa-fw fa-registered',
        'description' => '',
        'fields' => array(
            array(
                'title' => '用户限制',
                'label'    => '注册用户名限制总开关',
                'id' => 'regxz_is',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('regxz_is', '!=', ''), 
                'title' => '首个字母',
                'label'    => '注册用户名首个字符必须字母',
                'id' => 'regxz_szm',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('regxz_is', '!=', ''), 
                'id' => 'regxz_type',
                'title' => '限制模式',
                'default' => '1',
                'inline' => true,
                'type' => 'radio',
                'options' => array(
                    '1' => '禁止模式',
                    '2' => '允许模式',
                ),
                'class' => 'compact', 
            ),
            array(
                'dependency' => array(
                    array('regxz_is', '!=', ''),
                    array('regxz_type', '==', '1'),
                ),
                'title'   => '禁用选择',
                'id'      => 'regxz_jz',
                'type'    => "checkbox",
                'inline'  => true,
                'desc'    => '选择禁用用户名包含的字符（可多选）',
                'options' => array(
                    'kg'  => '空格',
                    'zw'  => '中文',
                    'dx'  => '大写',
                    'xh'  => '下划线',
                    'fh'  => '特殊符号',
                ),
                'class' => 'compact', 
                //'default' => array('kg', 'zw', 'dx', 'xh', 'fh'),
            ),
            array(
                'dependency' => array(
                    array('regxz_is', '!=', ''),
                    array('regxz_type', '==', '2'),
                ),
                'title'    => '允许选择',
                'desc'    => '选择允许的用户名包含字符',
                'id'       => 'regxz_yx',
                'default'  => '7',
                'type'     => 'select',
                'options'  => array(
                    '1' =>'字母',
                    '2' =>'字母+数字',
                    '3' =>'字母+数字+下划线',
                    '4' =>'字母+数字+下划线+中文',
                    '5' =>'小写字母',
                    '6' =>'小写字母+数字',
                    '7' =>'小写字母+数字+下划线',
                    '8' =>'小写字母+数字+下划线+中文',
                    '9' =>'中文',
                ),
                'class' => 'compact', 
            ),
            array(
                'dependency' => array('regxz_is', '!=', ''), 
                'title'    => __('自定义用户名限制', 'zib_language'),
                //'subtitle' => __('禁止的用户名关键词', 'zib_language'),
                'desc'     => __('前台注册时，不能使用包含这些关键字的用户名(请用逗号或换行分割)', 'zib_language'),
                'id'       => 'regxz_diy',
                'default'  => "admin,test,waimaola",
                'sanitize' => false,
                'type'     => 'textarea',
                'class' => 'compact', 
            ),
            array(
                'title' => '密码限制',
                'label'    => '注册密码限制总开关',
                'id' => 'regxz_p_is',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('regxz_p_is', '!=', ''),
                'id'      => 'regxz_p_length',
                'title'   => '密码长度',
                'desc'    => '',
                'default' => 6,
                'max'     => 30,
                'min'     => 6,
                'step'    => 1,
                'unit'    => '位',
                'type'    => 'slider',
            ),
            array(
                'dependency' => array('regxz_p_is', '!=', ''),
                'title'   => '包含选择',
                'id'      => 'regxz_p_jz',
                'type'    => "checkbox",
                'inline'  => true,
                'desc'    => '选择密码中必须包含的字符（可多选）',
                'options' => array(
                    'dx'  => '大写',
                    'xx'  => '小写',
                    'sz'  => '数字',
                    'fh'  => '特殊符号',
                ),
                'class' => 'compact', 

            ),
            array(
                'dependency' => array('regxz_p_is', '!=', ''), 
                'title'    => __('自定义密码限制', 'zib_language'),
                'desc'     => __('前台注册时，不能使用这些密码(请用逗号或换行分割)', 'zib_language'),
                'id'       => 'regxz_p_diy',
                'default'  => "123456,asd123,waimaola",
                'sanitize' => false,
                'type'     => 'textarea',
                'class' => 'compact', 
            ),
            array(
                'title' => '注册送会员',
                'label'    => '新用户注册送会员',
                'id' => 'regxz_s_hy',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('regxz_s_hy', '!=', ''), 
                'id' => 'regxz_s_hy_dj',
                'title' => ' ',
                'subtitle' => '会员等级',
                'default' => '1',
                'inline' => true,
                'type' => 'radio',
                'options' => array(
                    '1' => '一级会员',
                    '2' => '二级会员',
                ),
                'class' => 'compact', 
            ),
            array(
                'dependency' => array('regxz_s_hy', '!=', ''), 
                'title'    => ' ',
                'subtitle' => '赠送时间',
                'id'       => 'regxz_s_hy_sj',
                'class'    => 'compact',
                'default'  => 3,
                'max'      => 365,
                'min'      => 1,
                'step'     => 1,
                'unit'     => '天',
                'type'     => 'spinner',
            ),
            array(
                'title' => '注册加认证',
                'label'    => '新用户注册送认证',
                'id' => 'regxz_s_rz',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('regxz_s_rz', '!=', ''), 
                'title' => ' ',
                'subtitle' => '认证名称',
                'desc'    => '',
                'id' => 'regxz_s_rz_mc',
                'default' => 'WML认证用户',
                'type' => 'text',
                'class' => 'mini-input compact',
            ),
            array(
                'dependency' => array('regxz_s_rz', '!=', ''), 
                'title' => ' ',
                'subtitle' => '认证说明',
                'desc'    => '',
                'id' => 'regxz_s_rz_sm',
                'default' => 'WML官方认证用户',
                'type' => 'text',
                'class' => 'mini-input compact',
            ),
            array(
                'title' => '注册随机头像',
                'id' => 'regxz_tx',
                'default' => false,
                'type' => 'switcher',
            ),
            array(
                'dependency' => array('regxz_tx', '!=', ''), 
                'title' => ' ',
                'subtitle' => '头像路径',
                'desc'    => '把头像文件上传到该目录，支持jpg,jpeg,png,gif',
                'id' => 'regxz_tx_lj',
                'default' => '/wp-content/uploads/tx/',
                'type' => 'text',
                'class' => 'compact',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'safe',
        'title' => '登录&管理',
        'icon' => 'fa fa-fw fa-window-maximize',
        'description' => '',
        'fields' => array(
            array(
                'title' => '账号限制',
                'label'    => '限制禁止多人登录同一账号开关',
                'id' => 'safe_login_is',
                'default' => false,
                'type' => 'switcher',
            ),
            // array(
            //     'dependency' => array('safe_login_is', '!=', ''), 
            //     'id' => 'safe_login_type',
            //     'title' => '限制模式',
            //     'desc'    => '强制登录：如果有其他用户已经登录，就会将其强制注销；注销登录：用户必须从另一台设备主动注销后才能继续。',
            //     'default' => '1',
            //     'inline' => true,
            //     'type' => 'radio',
            //     'options' => array(
            //         '1' => '强制登录',
            //         '2' => '注销登录',
            //     ),
            // ),
            // array(
            //     'dependency' => array(
            //         array('safe_login_is', '!=', ''),
            //         array('safe_login_type', '==', '2'),
            //     ),
            //     'title' => '最大活跃',
            //     'desc'    => '一个账户允许同时活跃登录数，如果达到限制，用户必须从一台设备注销后才能继续',
            //     'id' => 'safe_login_active',
            //     'default' => '1',
            //     'type' => 'text',
            //     'class' => 'mini-input compact',
            // ),
            array(
                'dependency' => array('safe_login_is', '!=', ''), 
                'title' => '排除用户',
                'desc'    => '不受最大活跃登录数用户ID，多个ID以英文逗号分割',
                'id' => 'safe_login_pc_user',
                'default' => '1',
                'type' => 'text',
                'class' => 'mini-input',
            ),
            array(
                'dependency' => array('safe_login_is', '!=', ''), 
                'title' => '排除角色',
                'desc'    => '不受最大活跃登录数用户角色，多个ID以英文逗号分割',
                'id' => 'safe_login_pc_role',
                'default' => 'administrator',
                'type' => 'text',
                'class' => 'mini-input compact',
            ),
        )
    )
);

CSF::createSection(
    $prefix,
    array(
        'parent' => 'safe',
        'title' => '更多&安全',
        'icon' => 'fa fa-fw fa-shield',
        'description' => '',
        'fields' => array(
            array(
                'title'   => ' ',
                'type'    => "content",
                'content' => '<div style="color:#ff2153;"><i class="fa fa-fw fa-info-circle fa-fw"></i>更多安全功能正在紧张开发中...</div>',
            ),
        )
    )
);