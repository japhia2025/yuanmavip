=== kuhei ===
Tags: admin theme, custom admin
Requires at least: 4.7
Tested up to: 6.6.1
Stable tag: 1.0
Requires PHP: 5.6.20

自定义管理主题 使用 Admin Menu Editor Pro 插件生成.

== Description ==

自定义管理主题 使用 Admin Menu Editor Pro 插件生成.

== Installation ==

1. Upload the `` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.